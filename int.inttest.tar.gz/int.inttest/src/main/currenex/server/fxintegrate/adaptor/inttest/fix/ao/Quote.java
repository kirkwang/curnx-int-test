package currenex.server.fxintegrate.adaptor.inttest.fix.ao;

import com.google.common.base.MoreObjects;

import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession.Subscription;

public final class Quote {
        public final String requestId;
        public final String quoteId;
        public final String symbol;
        public final String symbolSfx;
        public final String bidPrice;
        public final String offerPrice;
        public final String bidAmount;
        public final String offerAmount;
        public final String valueDate;
        public final String securityType;
        public final String validUntilTime;
        public final String fixingDate;
        public final String bidSpotRate;
        public final String offerSpotRate;
        public final String bidFwdPoints;
        public final String offerFwdPoints;

        public Quote(final String requestId, final String quoteId, final String symbol, final String bidPrice, final String offerPrice, final String bidAmount,
                final String offerAmount, final String valueDate) {
            this.requestId = requestId;
            this.quoteId = quoteId;
            this.symbol = symbol;
            this.bidPrice = bidPrice;
            this.offerPrice = offerPrice;
            this.bidAmount = bidAmount;
            this.offerAmount = offerAmount;
            this.valueDate = valueDate;
            this.securityType = "FOR";
            this.symbolSfx = "SP";
            this.validUntilTime = null;
            this.fixingDate = null;
            this.bidSpotRate = null;
            this.offerSpotRate = null;
            this.bidFwdPoints = null;
            this.offerFwdPoints = null;

        }

        public Quote(final String requestId, final String quoteId, final String symbol, final String bidPrice, final String offerPrice, final String bidAmount,
                final String offerAmount, final String valueDate, final String securityType, final String validUntilTime)
        {
            this.requestId = requestId;
            this.quoteId = quoteId;
            this.symbol = symbol;
            this.symbolSfx = "SP";
            this.bidPrice = bidPrice;
            this.offerPrice = offerPrice;
            this.bidAmount = bidAmount;
            this.offerAmount = offerAmount;
            this.valueDate = valueDate;
            this.securityType = securityType;
            this.validUntilTime = validUntilTime;
            this.fixingDate = null;
            this.bidSpotRate = null;
            this.offerSpotRate = null;
            this.bidFwdPoints = null;
            this.offerFwdPoints = null;
         }

        public Quote(final String requestId, final String quoteId, final String symbol, final String symbolSfx, final String bidPrice, final String offerPrice, final String bidAmount,
                final String offerAmount, final String valueDate, final String securityType, final String validUntilTime, final String fixingDate)
        {
            this.requestId = requestId;
            this.quoteId = quoteId;
            this.symbol = symbol;
            this.symbolSfx = symbolSfx;
            this.bidPrice = bidPrice;
            this.offerPrice = offerPrice;
            this.bidAmount = bidAmount;
            this.offerAmount = offerAmount;
            this.valueDate = valueDate;
            this.securityType = securityType;
            this.validUntilTime = validUntilTime;
            this.fixingDate = fixingDate;
            this.bidSpotRate = null;
            this.offerSpotRate = null;
            this.bidFwdPoints = null;
            this.offerFwdPoints = null;
         }
        
        public Quote(final Subscription sub, final String quoteId, 
                final String bidPrice, final String offerPrice,
                final String bidAmount,final String offerAmount, 
                final String validUntilTime,
                final String bidSpotRate, final String offerSpotRate,
                final String bidFwdPoints, final String offerFwdPoints)
        {
            this.requestId = sub.requestId;
            this.quoteId = quoteId;
            this.symbol = sub.symbol;
            this.symbolSfx = sub.symbolSfx;
            this.bidPrice = bidPrice;
            this.offerPrice = offerPrice;
            this.bidAmount = bidAmount;
            this.offerAmount = offerAmount;
            this.valueDate = sub.valueDate;
            this.securityType = sub.securityType;
            this.validUntilTime = validUntilTime;
            this.fixingDate = sub.fixingDate;
            this.bidSpotRate = bidSpotRate;
            this.offerSpotRate = offerSpotRate;
            this.bidFwdPoints = bidFwdPoints;
            this.offerFwdPoints = offerFwdPoints;
         }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("requestId", requestId)
                .add("quoteId", quoteId)
                .add("symbol", symbol)
                .add("symbolSfx", symbolSfx)
                .add("bidPrice", bidPrice)
                .add("bidAmount", bidAmount)
                .add("offerAmount", offerAmount)
                .add("valueDate", valueDate)
                .add("securityType", securityType)
                .add("validUntilTime", validUntilTime)
                .add("fixingDate", fixingDate)
                .add("bidFwdPoints", bidFwdPoints)
                .add("offerFwdPoints", offerFwdPoints)
                .toString();
    }
}
