package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class Allocation {
    
    public final String allocAccount;
    public final String individualAllocID;
    public final String allocQty;
    public String settlCurrAmt;
    public String nestedPartyID;
    
    public Allocation(String allocAccount, String individualAllocID, String allocQty){
        this.allocAccount = allocAccount;
        this.individualAllocID =individualAllocID; 
        this.allocQty = allocQty;
    }

    public Allocation(String allocAccount, String individualAllocID, String allocQty, String nestedPartyID){
        this.allocAccount = allocAccount;
        this.individualAllocID =individualAllocID; 
        this.allocQty = allocQty;
        this.nestedPartyID = nestedPartyID;
    }
}
