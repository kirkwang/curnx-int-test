package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class CxNowTicker {
    
    private short instrumentIndex;
    private int rate;
    private char sizeIndicator;
    private char tickerType;
    private long transacTime;
    
    
    public CxNowTicker(short instrumentIndex, int rate, char sizeIndicator,
            char tickerType, long transacTime) {
        super();
        this.instrumentIndex = instrumentIndex;
        this.rate = rate;
        this.sizeIndicator = sizeIndicator;
        this.tickerType = tickerType;
        this.transacTime = transacTime;
    }


    public short getInstrumentIndex() {
        return instrumentIndex;
    }


    public void setInstrumentIndex(short instrumentIndex) {
        this.instrumentIndex = instrumentIndex;
    }


    public int getRate() {
        return rate;
    }


    public void setRate(int rate) {
        this.rate = rate;
    }


    public char getSizeIndicator() {
        return sizeIndicator;
    }


    public void setSizeIndicator(char sizeIndicator) {
        this.sizeIndicator = sizeIndicator;
    }


    public char getTickerType() {
        return tickerType;
    }


    public void setTickerType(char tickerType) {
        this.tickerType = tickerType;
    }

    public long getTransacTime() {
        return transacTime;
    }


    public void setTransacTime(long transacTime) {
        this.transacTime = transacTime;
    }
    
    

}
