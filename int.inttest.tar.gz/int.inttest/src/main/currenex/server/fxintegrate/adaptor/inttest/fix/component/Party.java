package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class Party {
    
    public final String partyID;
    public final String partyIDSource;
    public final String partyRole;
    
    public Party(String partyID, String partyIDSource, String partyRole){
        this.partyID = partyID;
        this.partyIDSource = partyIDSource;
        this.partyRole = partyRole;
    }
}
