package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import java.nio.ByteBuffer;

import org.jboss.netty.channel.Channel;

public interface ItchMsgSender {
    void setChannel(Channel channel);
    void closeChannel();

    void send(ByteBuffer buffer);
}
