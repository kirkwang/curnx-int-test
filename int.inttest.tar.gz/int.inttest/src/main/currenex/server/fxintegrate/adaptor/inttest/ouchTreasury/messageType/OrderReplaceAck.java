package currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.messageType;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateFieldChar;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateFieldLong;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.FIELD_CLORDERID;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.FIELD_ERRORCODE;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.FIELD_PREVCLORDERID;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.FIELD_STATUS;

public class OrderReplaceAck {
    
    private int newClOrderID;
    private int prevClOrderID;
    private char status;
    private short errorCode;
    
    public OrderReplaceAck(int newClOrderID, int prevClOrderID, char status, short errorCode){
        
        this.newClOrderID = newClOrderID;
        this.prevClOrderID = prevClOrderID;
        this.status = status;
        this.errorCode = errorCode;
        
    }

    public int getNewClOrderID() {
        return newClOrderID;
    }

    public void setNewClOrderID(int newClOrderID) {
        this.newClOrderID = newClOrderID;
    }

    public int getPrevClOrderID() {
        return prevClOrderID;
    }

    public void setPrevClOrderID(int prevClOrderID) {
        this.prevClOrderID = prevClOrderID;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public short getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(short errorCode) {
        this.errorCode = errorCode;
    }
    
    public void doAssert(int newClOrderID, int prevClOrderID, char status, short errorCode) throws Exception{
        System.out.println("Validating OrderReplaceAck:");
        
        validateFieldLong(FIELD_CLORDERID, newClOrderID, this.getNewClOrderID());
        validateFieldLong(FIELD_PREVCLORDERID, prevClOrderID, this.getPrevClOrderID());
        validateFieldChar(FIELD_STATUS, status, this.getStatus());
        validateFieldLong(FIELD_ERRORCODE, errorCode, this.getErrorCode());
    }
    
    @Override
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append("OrderReplaceAck:");
        sb.append(" NewClOrderID="+newClOrderID);
        sb.append(", PrevClOrderID="+prevClOrderID);
        sb.append(", Status="+status);
        sb.append(", ErrorCode="+errorCode);
        
        return sb.toString();
    }

}
