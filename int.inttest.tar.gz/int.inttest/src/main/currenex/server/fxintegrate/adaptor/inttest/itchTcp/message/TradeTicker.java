package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class TradeTicker {
    
    private short instrumentIndex;
    private int rate;
    private char tickerType;
    private long transacTime;
    
    public TradeTicker(short instrumentIndex, int rate, char tickerType,
            long transacTime) {
        super();
        this.instrumentIndex = instrumentIndex;
        this.rate = rate;
        this.tickerType = tickerType;
        this.transacTime = transacTime;
    }

    public short getInstrumentIndex() {
        return instrumentIndex;
    }

    public void setInstrumentIndex(short instrumentIndex) {
        this.instrumentIndex = instrumentIndex;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public char getTickerType() {
        return tickerType;
    }

    public void setTickerType(char tickerType) {
        this.tickerType = tickerType;
    }

    public long getTransacTime() {
        return transacTime;
    }

    public void setTransacTime(long transacTime) {
        this.transacTime = transacTime;
    }

    
}
