package currenex.server.fxintegrate.adaptor.inttest.ouch.message;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.ouch.Constants.*;

public class Trade {
    
    private int clOrdId;
    private long orderId;
    private short instrumentIndex;
    private char side;
    private long fillAmt;
    private int fillRate;
    private String execBroker;
    private String executionID;
    private char execType;
    private long settleDate;
    private long tradeDate;
    private long transactTime;
    private long leavesAmt;
    private char aggressorFlag;
    
    public Trade(int clOrdId, long orderId, short instrumentIndex, char side,
            long fillAmt, int fillRate, String execBroker, String executionID,
            char execType, long settleDate, long tradeDate, long transactTime,
            long leavesAmt, char aggressorFlag) {
        super();
        this.clOrdId = clOrdId;
        this.orderId = orderId;
        this.instrumentIndex = instrumentIndex;
        this.side = side;
        this.fillAmt = fillAmt;
        this.fillRate = fillRate;
        this.execBroker = execBroker;
        this.executionID = executionID;
        this.execType = execType;
        this.settleDate = settleDate;
        this.tradeDate = tradeDate;
        this.transactTime = transactTime;
        this.leavesAmt = leavesAmt;
        this.aggressorFlag = aggressorFlag;
    }

    public int getClOrdId() {
        return clOrdId;
    }

    public void setClOrdId(int clOrdId) {
        this.clOrdId = clOrdId;
    }

    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public short getInstrumentIndex() {
        return instrumentIndex;
    }

    public void setInstrumentIndex(short instrumentIndex) {
        this.instrumentIndex = instrumentIndex;
    }

    public char getSide() {
        return side;
    }

    public void setSide(char side) {
        this.side = side;
    }

    public long getFillAmt() {
        return fillAmt;
    }

    public void setFillAmt(long fillAmt) {
        this.fillAmt = fillAmt;
    }

    public int getFillRate() {
        return fillRate;
    }

    public void setFillRate(int fillRate) {
        this.fillRate = fillRate;
    }

    public String getExecBroker() {
        return execBroker;
    }

    public void setExecBroker(String execBroker) {
        this.execBroker = execBroker;
    }

    public String getExecutionID() {
        return executionID;
    }

    public void setExecutionID(String executionID) {
        this.executionID = executionID;
    }

    public char getExecType() {
        return execType;
    }

    public void setExecType(char execType) {
        this.execType = execType;
    }

    public long getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(long settleDate) {
        this.settleDate = settleDate;
    }

    public long getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(long tradeDate) {
        this.tradeDate = tradeDate;
    }

    public long getTransactTime() {
        return transactTime;
    }

    public void setTransactTime(long transactTime) {
        this.transactTime = transactTime;
    }

    public long getLeavesAmt() {
        return leavesAmt;
    }

    public void setLeavesAmt(long leavesAmt) {
        this.leavesAmt = leavesAmt;
    }

    public char getAggressorFlag() {
        return aggressorFlag;
    }

    public void setAggressorFlag(char aggressorFlag) {
        this.aggressorFlag = aggressorFlag;
    }
    
    public void doAssert(int clOrdId, long orderId, short instrumentIndex, char side,
            long fillAmt, int fillRate, String execBroker, String executionID,
            char execType, long leavesAmt, char aggressorFlag) throws Exception{
        System.out.println("Validating Trade:");
        
        validateFieldLong(FIELD_CLORDERID, clOrdId, this.clOrdId);
        validateFieldLong(FIELD_ORDERID, orderId, this.orderId);
        validateFieldNotNull(FIELD_INSTRUMENTINDEX, Short.toString(this.instrumentIndex));
        validateFieldChar(FIELD_SIDE, side, this.side);
        validateFieldLong(FIELD_FILLAMT, fillAmt, this.fillAmt);
        validateFieldLong(FIELD_FILLRATE, fillRate, this.fillRate);
        validateFieldLong(FIELD_LEAVESAMT, leavesAmt, this.leavesAmt);
        validateFieldChar(FIELD_AGGRESSORFLAG, aggressorFlag, this.aggressorFlag);
        validateFieldNotNull(FIELD_TRANSACTTIME, Long.toString(this.transactTime));
        validateFieldNotNull(FIELD_TRADEDATE, Long.toString(this.tradeDate));
        validateFieldNotNull(FIELD_SETTLEDATE, Long.toString(this.settleDate));
        validateFieldNotNull(FIELD_EXECUTIONID, this.executionID);
        validateField(FIELD_EXECBROKER, execBroker, this.execBroker);
        validateFieldChar(FIELD_EXECTYPE, execType, this.execType);
    }
}
