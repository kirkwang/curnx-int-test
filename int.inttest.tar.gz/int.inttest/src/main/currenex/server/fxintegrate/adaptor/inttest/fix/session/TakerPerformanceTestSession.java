package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import java.util.Date;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import com.google.common.collect.MapMaker;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.FixTagConstants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;


public class TakerPerformanceTestSession extends TakerTestSession{
    private Message executionReport = null;
    private Long timeStampOutGoing = null;
    private static MapMaker mapMaker = new MapMaker();
    private final Map<String, Long> idToTimeStampStartMap = mapMaker.makeMap();
    private final Map<String, Long> idToTimeStampEndMap = mapMaker.makeMap();

    public TakerPerformanceTestSession(Properties props) throws Exception {
        super(props);
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void handleExecutionReport(Message message) throws Exception {
        long timeStamp = System.nanoTime();

        String orderID = message.getStringFieldValue(Constants.TAGOrderID);
        String clientOrderID = message.getStringFieldValue(Constants.TAGClOrdID);
        String originalClOrdID = message.getStringFieldValue(Constants.TAGOrigClOrdID);
        String execType = message.getStringFieldValue(Constants.TAGExecType);
        String orderStatus = message.getStringFieldValue(Constants.TAGOrdStatus);

        setExecutionReport(message);

        BlockingQueue<Message> msgQ = orderMsgMap.get(originalClOrdID);
        if (msgQ == null) {
            msgQ = orderMsgMap.get(clientOrderID);
            if (msgQ == null) {
                msgQ = orderMsgMap.get("UNKNOWN");
            }
        }
        msgQ.add(message);

        if (execType.equals(Constants.EXECTYPE_New)) {//new
            if (orderStatus != null && orderStatus.equals(Constants.ORDSTATUS_New)) {
                System.out.println(" new order accepted: orderID=" + orderID + " clOrdID=" + clientOrderID);
            }
        } else if (orderStatus.equals(Constants.ORDSTATUS_PartiallyFilled)) { //partial fill
            System.out.println(" order partially filled: orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else if (orderStatus.equals(Constants.ORDSTATUS_Filled)) { //complete filled
            System.out.println(" order full filled: orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else if (execType.equals(Constants.EXECTYPE_Cancelled)) { //cancelled
            System.out.println(" order cancelled: orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else if (execType.equals(Constants.EXECTYPE_Replaced)) { //replaced
            System.out.println(" order replaced: orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else if (execType.equals(Constants.EXECTYPE_Rejected)) {
            System.out.println(" order rejected: orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else {
            System.err.println("unknown exec type=" + execType);
        }
        getIdToTimeStampEndMap().put(clientOrderID, timeStamp);

    }


    @Override
    public void submitRetailOrderOnBehalf(String clOrdId, String secClordId, String symbol, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
            String expDate, String expTime, String minQty, String expSeconds, String stopSide,
            String trailBy, String maxSlippage, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        //testing for dev-13522, remove
        //msg.setField("7589", "1.502011");
        getIdToTimeStampStartMap().put(clOrdId, System.nanoTime());
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    @Override
    public void submitOrderCancelRequest(String orderId, String clOrdId, String origClientOrderId, String onBehalf, String orderType, String side, String ccyPair) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS))
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if (getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGProduct, "4");
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        timeStampOutGoing = System.nanoTime();
        sendFixMessage(msg);
    }

    @Override
    public void submitRetailOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        if(symbolSfx!=null)
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        if(securityType!=null)
            msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        getIdToTimeStampStartMap().put(clOrdId, System.nanoTime());
        sendFixMessage(msg);
    }

    public Long getTimeStampOutGoing() {
        return timeStampOutGoing;
    }

    public void setTimeStampOutGoing(
            Long timeStampBeforeSendingOrder) {
        this.timeStampOutGoing = timeStampBeforeSendingOrder;
    }

    public Message getExecutionReport() {
        return executionReport;
    }

    public void setExecutionReport(Message executionReport) {
        this.executionReport = executionReport;
    }

    public Map<String, Long> getIdToTimeStampStartMap() {
        return idToTimeStampStartMap;
    }

    public Map<String, Long> getIdToTimeStampEndMap() {
        return idToTimeStampEndMap;
    }

}
