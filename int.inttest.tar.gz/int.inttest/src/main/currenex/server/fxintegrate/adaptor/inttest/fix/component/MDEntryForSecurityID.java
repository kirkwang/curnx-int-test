package currenex.server.fxintegrate.adaptor.inttest.fix.component;

import static org.junit.Assert.*;

public class MDEntryForSecurityID extends MDEntry{
    
    //required tags
    private String securityID;
    private String securityIDSource;
    private String product;
    private String maturityDate;
    private String issueDate;
    private String couponRate;
    private String datedDate;
    private String interestAccrualDate;
    
    //non-required tags, only sent for SecurityIDs from pricing file
    private String date;
    private String fairCouponRate;
    private String firstTradeDate;
    private String legRepurchaseRate;
    private String nextFixingDate;
    private String fixedNPV;
    private String floatNPV;
    private String NPV;
    private String accruedCoupons;
    private String dailyIncrementalErisPAI;
    private String erisPai;
    private String settlementPrice;
    private String fedFundsRate;
    private String priorSettlementPrice;
    private String factor;
    private String erisPAIDate;
    private String fixedPayment;
    private String floatingPayment;
    private String nextFixedPaymentDate;
    private String nextFixedPaymentAmount;
    private String legIssueDate;
    private String nextFloatingPaymentAmount;
    private String previousSettlementDate;
    private String previousErisPAI;
    private String fedFundsDate;
    private String accrualDays;
    private String nominal;
    private String legCreditRating;
    private String legContractMultiplier;
    private String nextFloatingPaymentDate;
    private String symbolTplus1;
    private String symbolSfxTplus1;
    private String openInterest;
    private String PV01;
    private String shortName;
    private String DV01;
    private String finalSettlementPrice;
    private String finalSettlementNPV;
    
    public String getSecurityID() {
        return securityID;
    }
    public void setSecurityID(String securityID) {
        this.securityID = securityID;
    }
    public String getSecurityIDSource() {
        return securityIDSource;
    }
    public void setSecurityIDSource(String securityIDSource) {
        this.securityIDSource = securityIDSource;
    }
    public String getProduct() {
        return product;
    }
    public void setProduct(String product) {
        this.product = product;
    }
    public String getMaturityDate() {
        return maturityDate;
    }
    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }
    public String getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }
    public String getCouponRate() {
        return couponRate;
    }
    public void setCouponRate(String couponRate) {
        this.couponRate = couponRate;
    }
    public String getDatedDate() {
        return datedDate;
    }
    public void setDatedDate(String datedDate) {
        this.datedDate = datedDate;
    }
    public String getInterestAccrualDate() {
        return interestAccrualDate;
    }
    public void setInterestAccrualDate(String interestAccrualDate) {
        this.interestAccrualDate = interestAccrualDate;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getFairCouponRate() {
        return fairCouponRate;
    }
    public void setFairCouponRate(String fairCouponRate) {
        this.fairCouponRate = fairCouponRate;
    }
    public String getFirstTradeDate() {
        return firstTradeDate;
    }
    public void setFirstTradeDate(String firstTradeDate) {
        this.firstTradeDate = firstTradeDate;
    }
    public String getLegRepurchaseRate() {
        return legRepurchaseRate;
    }
    public void setLegRepurchaseRate(String legRepurchaseRate) {
        this.legRepurchaseRate = legRepurchaseRate;
    }
    public String getNextFixingDate() {
        return nextFixingDate;
    }
    public void setNextFixingDate(String nextFixingDate) {
        this.nextFixingDate = nextFixingDate;
    }
    public String getFixedNPV() {
        return fixedNPV;
    }
    public void setFixedNPV(String fixedNPV) {
        this.fixedNPV = fixedNPV;
    }
    public String getFloatNPV() {
        return floatNPV;
    }
    public void setFloatNPV(String floatNPV) {
        this.floatNPV = floatNPV;
    }
    public String getNPV() {
        return NPV;
    }
    public void setNPV(String nPV) {
        NPV = nPV;
    }
    public String getAccruedCoupons() {
        return accruedCoupons;
    }
    public void setAccruedCoupons(String accruedCoupons) {
        this.accruedCoupons = accruedCoupons;
    }
    public String getDailyIncrementalErisPAI() {
        return dailyIncrementalErisPAI;
    }
    public void setDailyIncrementalErisPAI(String dailyIncrementalErisPAI) {
        this.dailyIncrementalErisPAI = dailyIncrementalErisPAI;
    }
    public String getErisPai() {
        return erisPai;
    }
    public void setErisPai(String erisPai) {
        this.erisPai = erisPai;
    }
    public String getSettlementPrice() {
        return settlementPrice;
    }
    public void setSettlementPrice(String settlementPrice) {
        this.settlementPrice = settlementPrice;
    }
    public String getFedFundsRate() {
        return fedFundsRate;
    }
    public void setFedFundsRate(String fedFundsRate) {
        this.fedFundsRate = fedFundsRate;
    }
    public String getPriorSettlementPrice() {
        return priorSettlementPrice;
    }
    public void setPriorSettlementPrice(String priorSettlementPrice) {
        this.priorSettlementPrice = priorSettlementPrice;
    }
    public String getFactor() {
        return factor;
    }
    public void setFactor(String factor) {
        this.factor = factor;
    }
    public String getErisPAIDate() {
        return erisPAIDate;
    }
    public void setErisPAIDate(String erisPAIDate) {
        this.erisPAIDate = erisPAIDate;
    }
    public String getFixedPayment() {
        return fixedPayment;
    }
    public void setFixedPayment(String fixedPayment) {
        this.fixedPayment = fixedPayment;
    }
    public String getFloatingPayment() {
        return floatingPayment;
    }
    public void setFloatingPayment(String floatingPayment) {
        this.floatingPayment = floatingPayment;
    }
    public String getNextFixedPaymentDate() {
        return nextFixedPaymentDate;
    }
    public void setNextFixedPaymentDate(String nextFixedPaymentDate) {
        this.nextFixedPaymentDate = nextFixedPaymentDate;
    }
    public String getNextFixedPaymentAmount() {
        return nextFixedPaymentAmount;
    }
    public void setNextFixedPaymentAmount(String nextFixedPaymentAmount) {
        this.nextFixedPaymentAmount = nextFixedPaymentAmount;
    }
    public String getLegIssueDate() {
        return legIssueDate;
    }
    public void setLegIssueDate(String legIssueDate) {
        this.legIssueDate = legIssueDate;
    }
    public String getNextFloatingPaymentAmount() {
        return nextFloatingPaymentAmount;
    }
    public void setNextFloatingPaymentAmount(String nextFloatingPaymentAmount) {
        this.nextFloatingPaymentAmount = nextFloatingPaymentAmount;
    }
    public String getPreviousSettlementDate() {
        return previousSettlementDate;
    }
    public void setPreviousSettlementDate(String previousSettlementDate) {
        this.previousSettlementDate = previousSettlementDate;
    }
    public String getPreviousErisPAI() {
        return previousErisPAI;
    }
    public void setPreviousErisPAI(String previousErisPAI) {
        this.previousErisPAI = previousErisPAI;
    }
    public String getFedFundsDate() {
        return fedFundsDate;
    }
    public void setFedFundsDate(String fedFundsDate) {
        this.fedFundsDate = fedFundsDate;
    }
    public String getAccrualDays() {
        return accrualDays;
    }
    public void setAccrualDays(String accrualDays) {
        this.accrualDays = accrualDays;
    }
    public String getNominal() {
        return nominal;
    }
    public void setNominal(String nominal) {
        this.nominal = nominal;
    }
    public String getLegCreditRating() {
        return legCreditRating;
    }
    public void setLegCreditRating(String legCreditRating) {
        this.legCreditRating = legCreditRating;
    }
    public String getLegContractMultiplier() {
        return legContractMultiplier;
    }
    public void setLegContractMultiplier(String legContractMultiplier) {
        this.legContractMultiplier = legContractMultiplier;
    }
    public String getNextFloatingPaymentDate() {
        return nextFloatingPaymentDate;
    }
    public void setNextFloatingPaymentDate(String nextFloatingPaymentDate) {
        this.nextFloatingPaymentDate = nextFloatingPaymentDate;
    }
    public String getSymbolTplus1() {
        return symbolTplus1;
    }
    public void setSymbolTplus1(String symbolTplus1) {
        this.symbolTplus1 = symbolTplus1;
    }
    public String getSymbolSfxTplus1() {
        return symbolSfxTplus1;
    }
    public void setSymbolSfxTplus1(String symbolSfxTplus1) {
        this.symbolSfxTplus1 = symbolSfxTplus1;
    }
    public String getOpenInterest() {
        return openInterest;
    }
    public void setOpenInterest(String openInterest) {
        this.openInterest = openInterest;
    }
    public String getPV01() {
        return PV01;
    }
    public void setPV01(String pV01) {
        PV01 = pV01;
    }
    public String getShortName() {
        return shortName;
    }
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }
    public String getDV01() {
        return DV01;
    }
    public void setDV01(String dV01) {
        DV01 = dV01;
    }
    public String getFinalSettlementPrice() {
        return finalSettlementPrice;
    }
    public void setFinalSettlementPrice(String finalSettlementPrice) {
        this.finalSettlementPrice = finalSettlementPrice;
    }
    public String getFinalSettlementNPV() {
        return finalSettlementNPV;
    }
    public void setFinalSettlementNPV(String finalSettlementNPV) {
        this.finalSettlementNPV = finalSettlementNPV;
    }
    
    public void validateForSecurityIDsCreatedIntraDay() throws Exception{
        assertNull(date);
        assertNull(fairCouponRate);
        assertNull(firstTradeDate);
        assertNull(legRepurchaseRate);
        assertNull(nextFixingDate);
        assertNull(fixedNPV);
        assertNull(floatNPV);
        assertNull(NPV);
        assertNull(accruedCoupons);
        assertNull(dailyIncrementalErisPAI);
        assertNull(erisPai);
        assertNull(settlementPrice);
        assertNull(fedFundsRate);
        assertNull(priorSettlementPrice);
        assertNull(factor);
        assertNull(erisPAIDate);
        assertNull(fixedPayment);
        assertNull(floatingPayment);
        assertNull(nextFixedPaymentDate);
        assertNull(nextFixedPaymentAmount);
        assertNull(legIssueDate);
        assertNull(nextFloatingPaymentAmount);
        assertNull(previousSettlementDate);
        assertNull(previousErisPAI);
        assertNull(fedFundsDate);
        assertNull(accrualDays);
        assertNull(nominal);
        assertNull(legCreditRating);
        assertNull(legContractMultiplier);
        assertNull(nextFloatingPaymentDate);
        assertNull(symbolTplus1);
        assertNull(symbolSfxTplus1);
        assertNull(openInterest);
        assertNull(PV01);
        assertNull(shortName);
        assertNull(DV01);
        assertNull(finalSettlementPrice);
        assertNull(finalSettlementNPV);
    }
    
    public void validateForSecurityIDsFromPricingFile() throws Exception{
        assertNotNull(date);
        assertNotNull(fairCouponRate);
        assertNotNull(firstTradeDate);
//        assertNull(legRepurchaseRate);
//        assertNotNull(nextFixingDate);
        assertNotNull(fixedNPV);
        assertNotNull(floatNPV);
        assertNotNull(NPV);
        assertNotNull(accruedCoupons);
        assertNotNull(dailyIncrementalErisPAI);
        assertNotNull(erisPai);
        assertNotNull(settlementPrice);
        assertNotNull(fedFundsRate);
        assertNotNull(priorSettlementPrice);
        assertNotNull(factor);
        assertNotNull(erisPAIDate);
        assertNotNull(fixedPayment);
        assertNotNull(floatingPayment);
        assertNotNull(nextFixedPaymentDate);
        assertNotNull(nextFixedPaymentAmount);
//        assertNotNull(legIssueDate);
//        assertNotNull(nextFloatingPaymentAmount);
        assertNotNull(previousSettlementDate);
        assertNotNull(previousErisPAI);
        assertNotNull(fedFundsDate);
        assertNotNull(accrualDays);
        assertNotNull(nominal);
//        assertNotNull(legCreditRating);
//        assertNotNull(legContractMultiplier);
        assertNotNull(nextFloatingPaymentDate);
//        assertNotNull(symbolTplus1);
//        assertNotNull(symbolSfxTplus1);
        assertNotNull(openInterest);
        assertNotNull(PV01);
        assertNotNull(shortName);
//        assertNotNull(DV01);
//        assertNotNull(finalSettlementPrice);
//        assertNotNull(finalSettlementNPV);
    }
    
    @Override
    public String toString(){
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("couponRate: "+couponRate+"\n");
        sb.append("date: "+date+"\n");
        sb.append("fairCouponRate: "+fairCouponRate+"\n");
        sb.append("firstTradeDate: "+firstTradeDate+"\n");
        sb.append("legRepurchaseRate: "+legRepurchaseRate+"\n");
        sb.append("nextFixingDate: "+nextFixingDate+"\n");
        sb.append("fixedNPV: "+fixedNPV+"\n");
        sb.append("floatNPV: "+floatNPV+"\n");
        sb.append("NPV: "+NPV+"\n");
        sb.append("accruedCoupons: "+accruedCoupons+"\n");
        sb.append("dailyIncrementalErisPAI: "+dailyIncrementalErisPAI+"\n");
        sb.append("erisPai: "+erisPai+"\n");
        sb.append("settlementPrice: "+settlementPrice+"\n");
        sb.append("fedFundsRate: "+fedFundsRate+"\n");
        sb.append("priorSettlementPrice: "+priorSettlementPrice+"\n");
        sb.append("factor: "+factor+"\n");
        sb.append("erisPAIDate: "+erisPAIDate+"\n");
        sb.append("fixedPayment: "+fixedPayment+"\n");
        sb.append("floatingPayment: "+floatingPayment+"\n");
        sb.append("nextFixedPaymentDate: "+nextFixedPaymentDate+"\n");
        sb.append("nextFixedPaymentAmount: "+nextFixedPaymentAmount+"\n");
        sb.append("legIssueDate: "+legIssueDate+"\n");
        sb.append("nextFloatingPaymentAmount: "+nextFloatingPaymentAmount+"\n");
        sb.append("previousSettlementDate: "+previousSettlementDate+"\n");
        sb.append("previousErisPAI: "+previousErisPAI+"\n");
        sb.append("fedFundsDate: "+fedFundsDate+"\n");
        sb.append("accrualDays: "+accrualDays+"\n");
        sb.append("nominal: "+nominal+"\n");
        sb.append("legCreditRating: "+legCreditRating+"\n");
        sb.append("legContractMultiplier: "+legContractMultiplier+"\n");
        sb.append("nextFloatingPaymentDate: "+nextFloatingPaymentDate+"\n");
        sb.append("symbolTplus1: "+symbolTplus1+"\n");
        sb.append("symbolSfxTplus1: "+symbolSfxTplus1+"\n");
        sb.append("openInterest: "+openInterest+"\n");
        sb.append("PV01: "+PV01+"\n");
        sb.append("shortName: "+shortName+"\n");
        sb.append("DV01: "+DV01+"\n");
        sb.append("finalSettlementPrice: "+finalSettlementPrice+"\n");
        sb.append("finalSettlementNPV: "+finalSettlementNPV+"\n");
        
        return sb.toString();
    }
    
}
