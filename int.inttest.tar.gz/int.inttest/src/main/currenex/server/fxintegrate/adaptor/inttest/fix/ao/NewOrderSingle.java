package currenex.server.fxintegrate.adaptor.inttest.fix.ao;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;

public final class NewOrderSingle {
    
    public final String clOrdId;
    
    //TODO Parties
    private String traderUser;
    
    private String currency;
    private String side;
    private String symbol;
    private String symbolSfx;
    private String product;
    private String securityType;
    private String transacTime;
    private String orderQty;
    private String ordType;
    private String price;
    private String timeInForce;
    private String minQty;
    private String account;
    
    private String handlInst;
    private String midMatchTriggerRate;
    private String stopSide;
    private String trailBy;
    
    
    public NewOrderSingle(String clOrdId, String currency,
            String side, String symbol, String symbolSfx, String product,
            String securityType, String orderQty,
            String ordType, String price, String timeInForce, String minQty) {
        super();
        this.clOrdId = clOrdId;
        this.currency = currency;
        this.side = side;
        this.symbol = symbol;
        this.symbolSfx = symbolSfx;
        this.product = product;
        this.securityType = securityType;
        this.transacTime = null;
        this.orderQty = orderQty;
        this.ordType = ordType;
        this.price = price;
        this.timeInForce = timeInForce;
        this.minQty = minQty;
    }
    
    public NewOrderSingle(String clOrdId, String currency,
            String side, String symbol, String symbolSfx, String product,
            String securityType, String orderQty, String ordType, 
            String price, String timeInForce, String minQty, String traderUser) {
        super();
        this.clOrdId = clOrdId;
        this.currency = currency;
        this.side = side;
        this.symbol = symbol;
        this.symbolSfx = symbolSfx;
        this.product = product;
        this.securityType = securityType;
        this.transacTime = null;
        this.orderQty = orderQty;
        this.ordType = ordType;
        this.price = price;
        this.timeInForce = timeInForce;
        this.minQty = minQty;
        this.traderUser = traderUser;
    }
    
    public static NewOrderSingle createTrailingStopOrder(String clOrdId, String currency,
            String side, String symbol, String symbolSfx, String orderQty,
            String price, String minQty, String stopSide, String trailBy) throws Exception{
        
        NewOrderSingle newTrailingStopOrder = new NewOrderSingle(clOrdId, currency,
                side, symbol, symbolSfx, Constants.PRODUCT_Currency, Constants.SECURITYTYPE_ForeignExchange, 
                orderQty, Constants.ORDTYPE_TrailingStop, price, Constants.TIMEINFORCE_GoodTillCancel, minQty);
        
        newTrailingStopOrder.setStopSide(stopSide);
        newTrailingStopOrder.setTrailBy(trailBy);

        return newTrailingStopOrder;
    }
    
    
    public static NewOrderSingle createMidMatchOrder(String clOrdId, String side, 
            String symbol, String symbolSfx, String orderQty, String midMatchTriggerRate) throws Exception{
        
        NewOrderSingle newMidMatchOrder = new NewOrderSingle(clOrdId, 
                "USD",
                side, 
                symbol, 
                symbolSfx, 
                Constants.PRODUCT_Government, 
                Constants.SECURITYTYPE_Govt, 
                orderQty, 
                Constants.ORDTYPE_MidMatch, 
                null, 
                Constants.TIMEINFORCE_GoodTillCancel, 
                null);
        
        newMidMatchOrder.setHandlInst(Constants.HANDLINST_AutoPrivateNoBroker);
        newMidMatchOrder.setMidMatchTriggerRate(midMatchTriggerRate);

        return newMidMatchOrder;
    }
    
    public static NewOrderSingle createIfDoneOrder(String clOrdId, String side, 
            String symbol, String symbolSfx, String orderQty, String midMatchTriggerRate) throws Exception{
        
        NewOrderSingle newMidMatchOrder = new NewOrderSingle(clOrdId, 
                "USD",
                side, 
                symbol, 
                symbolSfx, 
                Constants.PRODUCT_Government, 
                Constants.SECURITYTYPE_Govt, 
                orderQty, 
                Constants.ORDTYPE_MidMatch, 
                null, 
                Constants.TIMEINFORCE_GoodTillCancel, 
                null);
        
        newMidMatchOrder.setHandlInst(Constants.HANDLINST_AutoPrivateNoBroker);
        newMidMatchOrder.setMidMatchTriggerRate(midMatchTriggerRate);

        return newMidMatchOrder;
    }


    public String getClOrdId() {
        return clOrdId;
    }

    public String getCurrency() {
        return currency;
    }


    public String getSide() {
        return side;
    }


    public String getSymbol() {
        return symbol;
    }


    public String getSymbolSfx() {
        return symbolSfx;
    }


    public String getProduct() {
        return product;
    }


    public String getSecurityType() {
        return securityType;
    }


    public String getTransacTime() {
        return transacTime;
    }


    public String getOrderQty() {
        return orderQty;
    }


    public String getOrdType() {
        return ordType;
    }


    public String getPrice() {
        return price;
    }


    public String getTimeInForce() {
        return timeInForce;
    }


    public String getMinQty() {
        return minQty;
    }

    public String getStopSide() {
        return stopSide;
    }

    public void setStopSide(String stopSide) {
        this.stopSide = stopSide;
    }

    public String getTrailBy() {
        return trailBy;
    }

    public void setTrailBy(String trailBy) {
        this.trailBy = trailBy;
    }

    public String getHandlInst() {
        return handlInst;
    }

    public void setHandlInst(String handlInst) {
        this.handlInst = handlInst;
    }

    public String getMidMatchTriggerRate() {
        return midMatchTriggerRate;
    }

    public void setMidMatchTriggerRate(String midMatchTriggerRate) {
        this.midMatchTriggerRate = midMatchTriggerRate;
    }

    public String getTraderUser() {
        return traderUser;
    }

    public void setTraderUser(String traderUser) {
        this.traderUser = traderUser;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
    
    


}
