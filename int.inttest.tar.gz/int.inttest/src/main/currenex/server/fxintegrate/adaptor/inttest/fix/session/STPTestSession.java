package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTag;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTagNotNull;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.*;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

import currenex.server.fxintegrate.adaptor.fix.gateway.session.IFixGroup;
import currenex.server.fxintegrate.adaptor.fix.gateway.session.quickfix.QFMsgParser;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession.Subscription;

/**
 * @author Leo Zhou <lzhou@currenex.com>
 */
public final class STPTestSession extends ATestSession {
    public static final String TAGTradeID = "1003";
    private static final String TAGDefaultCstmApplverID = "1408";
    private static final String MSGType_XMLMessage = "n";
    private final long DEF_WAIT_TIME = 8000;
    private final long DEF_WAIT_TIME_SHORT = 3000;

    //agent specific properties
    private String type;
    private final String relationship;

    private final BlockingQueue<Message> reportQueue = new LinkedBlockingQueue<Message>(); //stores TradeCaptureReport msgs
    private final BlockingQueue<Message> xmlReportQueue = new LinkedBlockingQueue<Message>();
    private final BlockingQueue<Message> reqAckQueue = new LinkedBlockingQueue<Message>();
    private final BlockingQueue<Message> rejectQueue = new LinkedBlockingQueue<Message>();

    private final List<String> stpEvents = new ArrayList<String>();

    public STPTestSession(Properties props) throws Exception {
        this(props.getProperty(PARTYID),
                props.getProperty(HOST),
                Integer.parseInt(props.getProperty(PORT)),
                props.getProperty(SENDERCOMPID),
                props.getProperty(TARGETCOMPID),
                props.getProperty(TYPE),
                props.getProperty(DATADICTIONARY),
                props.getProperty(RELATIONSHIP),
                props.getProperty(FIXVERSION),
                props.getProperty(RSAKEYTYPE),
                props.getProperty(PASSWORD, DEFAULT_PASSWORD));
        this.logonRetries = Integer.parseInt(props.getProperty(LOGONRETRIES, "3"));
    }

    public STPTestSession(@Nullable String partyId,
                          String host,
                          int port,
                          String senderCompId,
                          String targetCompId,
                          String type,
                          @Nullable String dataDictionary,
                          @Nullable String relationship,
                          @Nullable String fixVersion,
                          @Nullable String rsaKeyType,
                          @Nullable String password) throws Exception
    {
        super(partyId, host, port, senderCompId, targetCompId, dataDictionary, fixVersion, rsaKeyType, password, null, null);
        this.type = type;
        this.relationship = relationship;
    }

    public void subscribeTradeCaptureReport(String requestId, String subscriptionType) throws Exception {
        
        subscribeTradeCaptureReport(requestId,
                Constants.TRADEREQUESTTYPE_AllTrades,
                subscriptionType,
                "NA",
                "2.0");
    }

    public void subscribeTradeCaptureReport(String requestId, String tradeRequestType, String subscriptionType,
            String symbol, String version) throws Exception {
        
        Message msg = new Message(Constants.MSGTradeCaptureReportRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGTradeRequestID, requestId);
        msg.setField(Constants.TAGTradeRequestType, tradeRequestType);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(TAGDefaultCstmApplverID, version);
        sendFixMessage(msg);
    }
    
    public void subscribeToTCR(String version) throws Exception {
        
        subscribeToTradeCaptureReport(Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe, version);
    }
    
    public void subscribeToTCRUpdatesOnly(String version) throws Exception {
        
        subscribeToTradeCaptureReport(Constants.SUBSCRIPTIONREQUESTTYPE_UpdatesOnly, version);
    }
    
    public void unsubscribeToTCR(String version) throws Exception {
        
        subscribeToTradeCaptureReport(Constants.SUBSCRIPTIONREQUESTTYPE_Unsubscribe, version);
    }
    
    public void subscribeTradeCaptureReport() throws Exception {
        
        subscribeToTCR("2.0");
    }
    
    public void subscribeTradeCaptureReportUpdatesOnly() throws Exception {
        
        subscribeToTCRUpdatesOnly("2.0");
    }
    
    public void subscribeTradeCaptureReportNew() throws Exception {
        
        subscribeToTCR("2.1");
    }
    
    public void subscribeTradeCaptureReportNewUpdatesOnly() throws Exception {
        
        subscribeToTCRUpdatesOnly("2.1");
    }
    
    private void subscribeToTradeCaptureReport(String subscriptionType, String version) throws Exception {
        
        clearReportQueue();
        
        subscribeTradeCaptureReport("testStpSub"+System.currentTimeMillis(), 
                Constants.TRADEREQUESTTYPE_AllTrades,
                subscriptionType, 
                "NA", 
                version);
        Message msg = getMessageFromRequestAckQueue(DEF_WAIT_TIME);
        assertNotNull("no request ack msg was received", msg);
        
        validateTag(Constants.TAGTradeRequestStatus, Constants.TRADEREQUESTSTATUS_Accepted
                , msg.getStringFieldValue(Constants.TAGTradeRequestStatus));
        validateTag(Constants.TAGTradeRequestResult, Constants.TRADEREQUESTRESULT_Successful
                , msg.getStringFieldValue(Constants.TAGTradeRequestResult));
    }
    
    public void clearTradeCaptureReports() throws Exception{
        clearTradeCaptureReports(DEF_WAIT_TIME_SHORT);
    }
    
    public void clearTradeCaptureReports(long waitTime) throws Exception{
        Message tradeMsg = getMessageFromReportQueue(waitTime);
        while(tradeMsg!=null)
        {
            String reportId = tradeMsg.getStringFieldValue(Constants.TAGTradeReportID);
            ackTradeCaptureReport(reportId);
            tradeMsg = getMessageFromReportQueue(waitTime);
        }
    }
    
    public void clearXMLTradeCaptureReports() throws Exception{
        Message tradeMsg = getMessageFromXMLReportQueue(DEF_WAIT_TIME_SHORT);
        while(tradeMsg!=null)
        {
            ackXmlTradeCaptureReport(tradeMsg);
            tradeMsg = getMessageFromXMLReportQueue(DEF_WAIT_TIME_SHORT);
        }
    }

    public void checkNullTradeCaptureReport() throws Exception{
        checkNullTradeCaptureReport(3000);
    }
    
    public void checkNullTradeCaptureReport(long waitTime) throws Exception{
        Message tradeMsg = getMessageFromReportQueue(waitTime);
        assertNull("No TCR should be received",tradeMsg);
    }
    
    public void checkNullXMLReport() throws Exception{
        Message tradeMsg = getMessageFromXMLReportQueue(3000);
        assertNull("No TCR should be received",tradeMsg);
    }
    
    public Message checkTradeCaptureReport() throws Exception{
        return checkTradeCaptureReport(DEF_WAIT_TIME, false);
    }
    
    public Message checkTradeCaptureReport(long waitTime) throws Exception{
        return checkTradeCaptureReport(waitTime, false);
    }
    
    public Message checkTradeCaptureReport(boolean hasAdditionalTerms) throws Exception{
        return checkTradeCaptureReport(DEF_WAIT_TIME, hasAdditionalTerms);
    }
    
    public Message checkTradeCaptureReport(long waitTime, boolean hasAdditionalTerms) throws Exception{
        Message tradeMsg = getMessageFromReportQueue(waitTime);
        assertNotNull("Didnt receive TradeCaptureRport for stpUser:"+this.getUserName(), tradeMsg);
        String reportId = tradeMsg.getStringFieldValue(Constants.TAGTradeReportID);
        
        //DEV-31177
        checkAdditionalTermsInTCR(tradeMsg, hasAdditionalTerms);
        
        ackTradeCaptureReport(reportId);
        return tradeMsg;
    }
    
    private void checkAdditionalTermsInTCR(Message tcr, boolean hasAdditionalTerms) throws Exception{
        
        validateTag(Constants.TAGNoSides, "1", tcr.getStringFieldValue(Constants.TAGNoSides));
        IFixGroup[] sides = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoSides, Constants.TAGiSide);
        assertEquals("Incorrect number of sides in TCR", 1, sides.length);
        
        if(hasAdditionalTerms){
            validateTagNotNull(Constants.TAGText, sides[0].getStringValFor(Constants.TAGiText));
        }else{
            validateTag(Constants.TAGText, null, sides[0].getStringValFor(Constants.TAGiText));
        }
        
    }
    
    
    public void doAssertionCheckForTCR_RFQ(Message tcr, Message executionReport,
            TakerTestSession taker, MakerTestSession maker, String symbolSfx, String hubUserName) throws Exception{
        
        String amount = executionReport.getStringFieldValue(Constants.TAGOrderQty);
        String tradeID = executionReport.getStringFieldValue(Constants.TAGExecID);
        String price = executionReport.getStringFieldValue(Constants.TAGPrice);
        
        if(symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)) {
            price = executionReport.getStringFieldValue(Constants.TAGAvgPx);
        }
        
        String tradeDate = executionReport.getStringFieldValue(Constants.TAGTradeDate);
        String settlDate = executionReport.getStringFieldValue(Constants.TAGSettlDate);
        String side = executionReport.getStringFieldValue(Constants.TAGSide);
        String fixingDate = executionReport.getStringFieldValue(Constants.TAGFixingDate);
        String account = executionReport.getStringFieldValue(Constants.TAGAccount);
        String noAllocs = executionReport.getStringFieldValue(Constants.TAGNoAllocs);
        String securityType = null;
        String execType = Constants.EXECTYPE_New;
        String lastSpotRate = executionReport.getStringFieldValue(Constants.TAGLastSpotRate);
        String lastForwardPoints = executionReport.getStringFieldValue(Constants.TAGLastForwardPoints);
        String lastSwapPoints = executionReport.getStringFieldValue(Constants.TAGLastForwardPoints2);
        String midPx2 = executionReport.getStringFieldValue(Constants.TAGMidPx2);
        String orderQty2 = executionReport.getStringFieldValue(Constants.TAGOrderQty2);
        String settlDate2 = executionReport.getStringFieldValue(Constants.TAGSettlDate2);
        
        boolean allocated = (noAllocs!=null);
        
        String allocID1 = null;
        String allocAccount1 = null;
        String allocAmount1 = null;
        String allocID2 = null;
        String allocAccount2 = null;
        String allocAmount2 = null;
        
        if(allocated){
            IFixGroup[] allocs = 
                    executionReport.getParser().getDynamicGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            
            allocID1 = allocs[0].getStringValFor(Constants.TAGiIndividualAllocID);
            allocAccount1 = allocs[0].getStringValFor(Constants.TAGiAllocAccount);
            allocAmount1 = allocs[0].getStringValFor(Constants.TAGiAllocQty);
            
            allocID2 = allocs[1].getStringValFor(Constants.TAGiIndividualAllocID);
            allocAccount2 = allocs[1].getStringValFor(Constants.TAGiAllocAccount);
            allocAmount2 = allocs[1].getStringValFor(Constants.TAGiAllocQty);
        }
        String symbol = executionReport.getStringFieldValue(Constants.TAGSymbol);
        
        Subscription sub = maker.getSubscription(symbol);
        
        doAssertionCheckForTCR(tcr, amount, taker, maker, execType, tradeID, price, tradeDate, settlDate, side, fixingDate, 
                allocated, account, null, null, symbol, symbolSfx, null, null, null, null, 
                allocID1, allocAccount1, allocAmount1, allocID2, allocAccount2, allocAmount2, null, securityType, false, false, 
                lastSpotRate, lastForwardPoints, lastSwapPoints, midPx2, orderQty2, settlDate2, sub, hubUserName, Constants.TRDTYPE_RFQ, null);
    }
    
    
    public void doAssertionCheckForTCR_ESP(Message tcr, Message executionReport,
            TakerTestSession taker, MakerTestSession maker, String symbolSfx, String hubUserName) throws Exception{
        
        String amount = executionReport.getStringFieldValue(Constants.TAGOrderQty);
        String tradeID = executionReport.getStringFieldValue(Constants.TAGExecID);
        String price = executionReport.getStringFieldValue(Constants.TAGPrice);        
        String tradeDate = executionReport.getStringFieldValue(Constants.TAGTradeDate);
        String settlDate = executionReport.getStringFieldValue(Constants.TAGSettlDate);
        String side = executionReport.getStringFieldValue(Constants.TAGSide);
        String fixingDate = executionReport.getStringFieldValue(Constants.TAGFixingDate);
        String account = taker.getPartyId();
        String securityType = null;
        String execType = Constants.EXECTYPE_New;
        String lastSpotRate = price;
        String lastForwardPoints = executionReport.getStringFieldValue(Constants.TAGLastForwardPoints);
        String lastSwapPoints = executionReport.getStringFieldValue(Constants.TAGLastForwardPoints2);
        String midPx2 = executionReport.getStringFieldValue(Constants.TAGMidPx2);
        String orderQty2 = executionReport.getStringFieldValue(Constants.TAGOrderQty2);
        String settlDate2 = executionReport.getStringFieldValue(Constants.TAGSettlDate2);
        String clOrdId = executionReport.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = executionReport.getStringFieldValue(Constants.TAGSymbol);
        String hubName = null;
        
        boolean allocated = false;
        String allocID1 = null;
        String allocAccount1 = null;
        String allocAmount1 = null;
        String allocID2 = null;
        String allocAccount2 = null;
        String allocAmount2 = null;
        
        Subscription sub = maker.getSubscription(symbol);
        
        doAssertionCheckForTCR(tcr, amount, taker, maker, execType, tradeID, price, tradeDate, settlDate, side, fixingDate, 
                allocated, account, null, null, symbol, symbolSfx, null, null, null, null, 
                allocID1, allocAccount1, allocAmount1, allocID2, allocAccount2, allocAmount2, null, securityType, false, false, 
                lastSpotRate, lastForwardPoints, lastSwapPoints, midPx2, orderQty2, settlDate2, sub, hubUserName, Constants.TRDTYPE_ESP, clOrdId);
    }   

    
    public void doAssertionCheckForTCR_ClrNDF(Message tcr, Message executionReport,
            TakerTestSession taker, MakerTestSession maker, String execType, String TakerFirmLei, String MakerFirmLei,
            String clearPrefix, String FCMTaker, String FCMTakerLEI) throws Exception{
        
        String amount = executionReport.getStringFieldValue(Constants.TAGOrderQty);
        String tradeID = executionReport.getStringFieldValue(Constants.TAGExecID);
        String price = executionReport.getStringFieldValue(Constants.TAGPrice);
        String tradeDate = executionReport.getStringFieldValue(Constants.TAGTradeDate);
        String settlDate = executionReport.getStringFieldValue(Constants.TAGSettlDate);
        String side = executionReport.getStringFieldValue(Constants.TAGSide);
        String fixingDate = executionReport.getStringFieldValue(Constants.TAGFixingDate);
        String account = executionReport.getStringFieldValue(Constants.TAGAccount);
        String noAllocs = executionReport.getStringFieldValue(Constants.TAGNoAllocs);
        String securityType = Constants.SECURITYTYPE_ForeignExchangeNDF;
        String lastForwardPoints = "0.00000000";
        boolean allocated = (noAllocs!=null);
        
        String allocID1 = null;
        String allocAccount1 = null;
        String allocAmount1 = null;
        String allocID2 = null;
        String allocAccount2 = null;
        String allocAmount2 = null;
        
        if(allocated){
            IFixGroup[] allocs = 
                    executionReport.getParser().getDynamicGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            
            allocID1 = allocs[0].getStringValFor(Constants.TAGiIndividualAllocID);
            allocAccount1 = allocs[0].getStringValFor(Constants.TAGiAllocAccount);
            allocAmount1 = allocs[0].getStringValFor(Constants.TAGiAllocQty);
            
            allocID2 = allocs[1].getStringValFor(Constants.TAGiIndividualAllocID);
            allocAccount2 = allocs[1].getStringValFor(Constants.TAGiAllocAccount);
            allocAmount2 = allocs[1].getStringValFor(Constants.TAGiAllocQty);
            
            IFixGroup[] nestedParties = 
                    allocs[0].getDynamicSubGroupDataFor(Constants.TAGiNoNestedPartyIDs, Constants.TAGiNestedPartyID);
            FCMTakerLEI = nestedParties[0].getStringValFor(Constants.TAGiNestedPartyID);
        }
        String symbol = executionReport.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = Constants.SYMBOLSFX_Forward;
        
        IFixGroup[] regulatoryTradeIDs = 
                executionReport.getParser().getDynamicGroupDataFor(Constants.TAGiNoRegulatoryTradeIDs, Constants.TAGiRegulatoryTradeID);
        String UsiUtiPrefix = regulatoryTradeIDs[0].getStringValFor(Constants.TAGiRegulatoryTradeIDSource);
        
        doAssertionCheckForTCR(tcr, amount, taker, maker, execType, tradeID, price, tradeDate, settlDate, side, fixingDate, 
                allocated, account, TakerFirmLei, MakerFirmLei, symbol, symbolSfx, UsiUtiPrefix, clearPrefix, FCMTaker, FCMTakerLEI, 
                allocID1, allocAccount1, allocAmount1, allocID2, allocAccount2, allocAmount2, Constants.TRDTYPE_RegularTrade,
                securityType, true, true, price, lastForwardPoints, null, null, null, null, null, null, Constants.TRDTYPE_RFQ, null);
        
    }
    
    public void doAssertionCheckForTCR_OnHoldOrClr(Message tcr, Message newTradeTCR, Message executionReport,
            TakerTestSession taker, MakerTestSession maker, String execType, String TakerFirmLei, String MakerFirmLei,
            String clearPrefix, String FCMTaker, String FCMTakerLEI) throws Exception{


        
        String amount = null;
        String tradeID = null;
        String price = executionReport.getStringFieldValue(Constants.TAGPrice);
        String tradeDate = executionReport.getStringFieldValue(Constants.TAGTradeDate);
        String settlDate = executionReport.getStringFieldValue(Constants.TAGSettlDate);
        String side = null;
        String fixingDate = executionReport.getStringFieldValue(Constants.TAGFixingDate);
        String account = null;
        String symbol = executionReport.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = Constants.SYMBOLSFX_Forward;
        String securityType = Constants.SECURITYTYPE_ForeignExchangeNDF;
        String lastForwardPoints = "0.00000000";
        
        IFixGroup[] regulatoryTradeIDs = 
                executionReport.getParser().getDynamicGroupDataFor(Constants.TAGiNoRegulatoryTradeIDs, Constants.TAGiRegulatoryTradeID);
        String UsiUtiPrefix = regulatoryTradeIDs[0].getStringValFor(Constants.TAGiRegulatoryTradeIDSource);
        
        IFixGroup[] sides = 
                newTradeTCR.getParser().getDynamicGroupDataFor(Constants.TAGiNoSides, Constants.TAGiSide);
        
        IFixGroup[] allocs = 
                sides[0].getDynamicSubGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
        
        for(IFixGroup alloc:allocs){
            if(alloc.getStringValFor(Constants.TAGiIndividualAllocID).equals(tcr.getStringFieldValue(Constants.TAGExecID))){
                
                amount = alloc.getStringValFor(Constants.TAGiAllocQty);
                tradeID = alloc.getStringValFor(Constants.TAGiSecondaryIndividualAllocID);
                side = alloc.getStringValFor(Constants.TAGiAllocSide);
                account = alloc.getStringValFor(Constants.TAGiAllocAccount);
                
            }
        }
          /*  
        IFixGroup[] nestedParties = 
                allocs[0].getDynamicSubGroupDataFor(Constants.TAGiNoNestedPartyIDs, Constants.TAGiNestedPartyID);
        FCMTakerLEI = nestedParties[0].getStringValFor(Constants.TAGiNestedPartyID);
        */
        doAssertionCheckForTCR(tcr, amount, taker, maker, execType, tradeID, price, tradeDate, settlDate, side, fixingDate, 
                false, account, TakerFirmLei, MakerFirmLei, symbol, symbolSfx, UsiUtiPrefix, clearPrefix, FCMTaker, FCMTakerLEI, 
                null, null, null, null, null, null, Constants.TRDTYPE_RegularTrade, securityType, true, true, price, lastForwardPoints,
                null, null, null, null, null, null, Constants.TRDTYPE_RFQ, null);
        
    }
    
    private void doAssertionCheckForTCR(Message tcr, String amount,
            TakerTestSession taker, MakerTestSession maker, String execType, String tradeID, String price, String tradeDate, 
            String settlDate, String side, String fixingDate, boolean allocated, String account,
            String TakerFirmLei, String MakerFirmLei, String symbol, String symbolSfx, String UsiUtiPrefix, String clearPrefix, String FCMTaker,
            String FCMTakerLEI, String allocID1, String allocAccount1, String allocAmount1, String allocID2, String allocAccount2, 
            String allocAmount2, String secondaryTradeType, String securityType, boolean isNDF, boolean isClearing,
            String lastSpotRate, String lastForwardPoints, String lastSwapPoints, String midPx2, String orderQty2,
            String settlDate2, Subscription sub, String hubUserName, String trdType, String clOrdId) throws Exception{

        validateTagNotNull(Constants.TAGTradeReportID, tcr.getStringFieldValue(Constants.TAGTradeReportID)); 
        validateTagNotNull(Constants.TAGTradeRequestID, tcr.getStringFieldValue(Constants.TAGTradeRequestID)); 
        String lastQty = String.format("%.2f", Double.parseDouble(amount));
        validateTag(Constants.TAGTrdType, trdType, tcr.getStringFieldValue(Constants.TAGTrdType)); 
        validateTag(Constants.TAGSecondaryTrdType, secondaryTradeType, tcr.getStringFieldValue(Constants.TAGSecondaryTrdType)); 
        
        if(execType.equals(Constants.EXECTYPE_New) || execType.equals(Constants.EXECTYPE_Allocated)){
            validateTag(Constants.TAGTradeID, tradeID, tcr.getStringFieldValue(Constants.TAGTradeID)); 
            if(!symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)){
                if(sub!=null && trdType.equals(Constants.TRDTYPE_RFQ)) {
                    validateTag(Constants.TAGSecondaryExecID, "execId"+sub.clOrdId, tcr.getStringFieldValue(Constants.TAGSecondaryExecID)); //TODO buy vs sell  ExecID vs SecondaryExecID
                } else if(trdType.equals(Constants.TRDTYPE_RFQ)) {
                    validateTag(Constants.TAGSecondaryExecID, "execId"+tradeID, tcr.getStringFieldValue(Constants.TAGSecondaryExecID)); //TODO buy vs sell  ExecID vs SecondaryExecID
                } else {
                    validateTagNotNull(Constants.TAGSecondaryExecID, tcr.getStringFieldValue(Constants.TAGSecondaryExecID));
                }
            } else {
                validateTag(Constants.TAGSecondaryExecID, null, tcr.getStringFieldValue(Constants.TAGSecondaryExecID));
            }
            validateTag(Constants.TAGLastQty, lastQty, tcr.getStringFieldValue(Constants.TAGLastQty));
        }else{
            validateTagNotNull(Constants.TAGTradeID, tcr.getStringFieldValue(Constants.TAGTradeID)); 
            //validateTag(Constants.TAGTrdType, null, tcr.getStringFieldValue(Constants.TAGTrdType)); 
            //validateTag(Constants.TAGSecondaryTrdType, null, tcr.getStringFieldValue(Constants.TAGSecondaryTrdType));
            validateTagNotNull(Constants.TAGLastQty, tcr.getStringFieldValue(Constants.TAGLastQty));
        }
        validateTag(Constants.TAGTrdSubType, null, tcr.getStringFieldValue(Constants.TAGTrdSubType));
        
        if(hubUserName!=null && !symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)) {
            validateTagNotNull(Constants.TAGTrdMatchID, tcr.getStringFieldValue(Constants.TAGTrdMatchID));
        } else {
            validateTag(Constants.TAGTrdMatchID, null, tcr.getStringFieldValue(Constants.TAGTrdMatchID));
        }

        validateTag(Constants.TAGPreviouslyReported, "N", tcr.getStringFieldValue(Constants.TAGPreviouslyReported)); 
        validateTag(Constants.TAGExecType, execType, tcr.getStringFieldValue(Constants.TAGExecType)); 
        
        /* Parties validation*/
        boolean hasOriCust = false;
        boolean hasClearingFirm = false;
        boolean hasExecutingFirm = false;
        boolean hasHubIntermediary = false;
        
        if(isNDF) {
            validateTag(Constants.TAGNoRootPartyIDs, "3", tcr.getStringFieldValue(Constants.TAGNoRootPartyIDs));
        } else {
            validateTag(Constants.TAGNoRootPartyIDs, "2", tcr.getStringFieldValue(Constants.TAGNoRootPartyIDs));
        } 

        IFixGroup[] rootPartyIDs = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoRootPartyIDs, Constants.TAGiRootPartyID);

        String takerRootPartyIDSource = null;
        String makerRootPartyIDSource = null;
        
        if(isNDF){
            if(side.equals(Constants.SIDE_Buy)) {
                takerRootPartyIDSource = Constants.ROOTPARTYIDSOURCE_ReportingParty;
            } else {
                makerRootPartyIDSource = Constants.ROOTPARTYIDSOURCE_ReportingParty;
            }
        }
        
        for(IFixGroup party:rootPartyIDs){
            switch(party.getStringValFor(Constants.TAGiRootPartyRole)){
                case "13": hasOriCust = true;
                           validateTag(Constants.TAGRootPartyID, taker.getPartyId(), 
                                   party.getStringValFor(Constants.TAGiRootPartyID)); 
                           validateTag(Constants.TAGRootPartyIDSource, takerRootPartyIDSource, 
                                   party.getStringValFor(Constants.TAGiRootPartyIDSource)); 
                           if(isNDF) {
                            checkRootSubParty(party, taker.getUserName(), TakerFirmLei);
                        } else {
                            checkRootSubParty(party, taker.getUserName(), null);
                        }
                           break;
                case "1": hasExecutingFirm = true;
                          validateTag(Constants.TAGRootPartyID, maker.getPartyId(), 
                                  party.getStringValFor(Constants.TAGiRootPartyID)); 
                          validateTag(Constants.TAGRootPartyIDSource, makerRootPartyIDSource, 
                                  party.getStringValFor(Constants.TAGiRootPartyIDSource)); 
                          if(isNDF) {
                            checkRootSubParty(party, maker.getUserName(), MakerFirmLei);
                        }
                          break;
                case "4": hasClearingFirm = true;
                           if(this.getPartyId().equals(taker.getPartyId())){
                               validateTag(Constants.TAGRootPartyID, FCMTaker, 
                                       party.getStringValFor(Constants.TAGiRootPartyID)); 
                               checkRootSubParty(party, null, FCMTakerLEI);
                           }else{/*//TODO 20150209
                               validateTag(Constants.TAGRootPartyID, FCMMaker, 
                                       party.getStringValFor(Constants.TAGiRootPartyID));
                               checkRootSubParty(party, null, FCMMakerLei);*/
                           }
                           validateTag(Constants.TAGRootPartyIDSource, null, party.getStringValFor(Constants.TAGiRootPartyIDSource));
                           break;
                case "29": hasHubIntermediary = true;
                            //TODO
                            validateTag(Constants.TAGRootPartyIDSource, null, party.getStringValFor(Constants.TAGiRootPartyIDSource));
                            if(isNDF) {
                                checkRootSubParty(party, hubUserName, TakerFirmLei);
                            } else {
                                checkRootSubParty(party, hubUserName, null);
                            }
                            break;                           
                default:   fail("Unpxected value of RootPartyRole: "+party.getStringValFor(Constants.TAGiRootPartyRole));
                           break;
            } 
        }
        
        assertTrue("No Originating Customer party in TCR",hasOriCust);
        
        if(isClearing) {
            assertTrue("No Clearing Firm  party in TCR",hasClearingFirm);
        }
        
        if(hubUserName!=null) {
            assertTrue("No Hub/Intermediary in TCR",hasHubIntermediary);
        }
        else {
            assertTrue("No Executing firm party in TCR",hasExecutingFirm); //TODO
        }
        
        validateTag(Constants.TAGSymbolSfx, symbolSfx, tcr.getStringFieldValue(Constants.TAGSymbolSfx));
        
        if(symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)){
            validateTag(Constants.TAGSymbol, "CD/CD", tcr.getStringFieldValue(Constants.TAGSymbol));//TODO LD symbol
            validateTag(Constants.TAGProduct, Constants.PRODUCT_LoanAndDeposit, tcr.getStringFieldValue(Constants.TAGProduct));
        }else{
            validateTag(Constants.TAGSymbol, symbol, tcr.getStringFieldValue(Constants.TAGSymbol));
            validateTag(Constants.TAGProduct, Constants.PRODUCT_Currency, tcr.getStringFieldValue(Constants.TAGProduct));
        }
            
        
        validateTag(Constants.TAGSecurityType, securityType, tcr.getStringFieldValue(Constants.TAGSecurityType));
        
        if(!isClearing) {
            validateTag(Constants.TAGNoInstrumentParties, null, tcr.getStringFieldValue(Constants.TAGNoInstrumentParties));
        } else{
        validateTag(Constants.TAGNoInstrumentParties, "1", tcr.getStringFieldValue(Constants.TAGNoInstrumentParties));
        
        IFixGroup[] instrumentParties = tcr.getParser()
                .getDynamicGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID);
        
        validateTag(Constants.TAGInstrumentPartyID, "LCH", instrumentParties[0].getStringValFor(Constants.TAGiInstrumentPartyID));
        validateTag(Constants.TAGInstrumentPartyIDSource, "D", instrumentParties[0].getStringValFor(Constants.TAGiInstrumentPartyIDSource));
        validateTag(Constants.TAGInstrumentPartyRole, "21", instrumentParties[0].getStringValFor(Constants.TAGiInstrumentPartyRole));
        }
        
        validateTag(Constants.TAGLastPx, price+"0000", tcr.getStringFieldValue(Constants.TAGLastPx));
        
        String calculatedCcyLastQty = String.format("%.2f", Double.parseDouble(amount) * Double.parseDouble(price));
        
        if(symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)){
            validateTagNotNull(Constants.TAGCalculatedCcyLastQty, tcr.getStringFieldValue(Constants.TAGCalculatedCcyLastQty));
            validateTag(Constants.TAGSettlCurrency, null, tcr.getStringFieldValue(Constants.TAGSettlCurrency));
            validateTag(Constants.TAGLastSpotRate, null, tcr.getStringFieldValue(Constants.TAGLastSpotRate));
            validateTag(Constants.TAGLastForwardPoints, null, tcr.getStringFieldValue(Constants.TAGLastForwardPoints));
            validateTagNotNull(Constants.TAGTradeDate, tcr.getStringFieldValue(Constants.TAGTradeDate));
            validateTagNotNull(Constants.TAGSettlDate, tcr.getStringFieldValue(Constants.TAGSettlDate));//TODO get LD settl date
        }else{
            validateTag(Constants.TAGCalculatedCcyLastQty, calculatedCcyLastQty, tcr.getStringFieldValue(Constants.TAGCalculatedCcyLastQty));
            validateTag(Constants.TAGSettlCurrency, symbol.split("/")[1], tcr.getStringFieldValue(Constants.TAGSettlCurrency));
            validateTag(Constants.TAGLastSpotRate, Double.parseDouble(lastSpotRate), Double.parseDouble(tcr.getStringFieldValue(Constants.TAGLastSpotRate)));
            if(!symbolSfx.equals(Constants.SYMBOLSFX_Spot)){
                if((lastForwardPoints!=null && tcr.getStringFieldValue(Constants.TAGLastForwardPoints)!=null)) {
                    validateTag(Constants.TAGLastForwardPoints, Double.parseDouble(lastForwardPoints), 
                            Double.parseDouble(tcr.getStringFieldValue(Constants.TAGLastForwardPoints)));
                } else {
                    fail("Unexpected lastForwardPoints");
                }
            }
            Calendar cal = Calendar.getInstance();
            int day = cal.get(Calendar.DAY_OF_WEEK);
            if(day==Calendar.FRIDAY || day==Calendar.SATURDAY || day==Calendar.SUNDAY){
                validateTagNotNull(Constants.TAGTradeDate, tcr.getStringFieldValue(Constants.TAGTradeDate)); //tradeDate is not in sync in ER during weekend
            }else{
                validateTag(Constants.TAGTradeDate, tradeDate, tcr.getStringFieldValue(Constants.TAGTradeDate));
            }
            
            validateTag(Constants.TAGSettlDate, settlDate, tcr.getStringFieldValue(Constants.TAGSettlDate));
        }
        validateTag(Constants.TAGCurrency, symbol.split("/")[0], tcr.getStringFieldValue(Constants.TAGCurrency));
        
        if(symbolSfx.equals(Constants.SYMBOLSFX_Swap)){
            validateTag(Constants.TAGLastSwapPoints, Double.parseDouble(lastSwapPoints), 
                    Double.parseDouble(tcr.getStringFieldValue(Constants.TAGLastSwapPoints)));
            validateTag(Constants.TAGMidPx2, Double.parseDouble(midPx2), 
                    Double.parseDouble(tcr.getStringFieldValue(Constants.TAGMidPx2)));
            validateTag(Constants.TAGOrderQty2, Double.parseDouble(orderQty2), 
                    Double.parseDouble(tcr.getStringFieldValue(Constants.TAGOrderQty2)));
            validateTag(Constants.TAGSettlDate2, settlDate2, tcr.getStringFieldValue(Constants.TAGSettlDate2));
            
            String calculatedCcyLastQty2 = String.format("%.2f", Double.parseDouble(orderQty2) * Double.parseDouble(midPx2));
            
            validateTag(Constants.TAGCalculatedCcyLastQty2, calculatedCcyLastQty2, tcr.getStringFieldValue(Constants.TAGCalculatedCcyLastQty2));
            validateTag(Constants.TAGFixingDate2, null, tcr.getStringFieldValue(Constants.TAGFixingDate2));
        }else{
            validateTag(Constants.TAGLastSwapPoints, null, tcr.getStringFieldValue(Constants.TAGLastSwapPoints));
            validateTag(Constants.TAGMidPx2, null, tcr.getStringFieldValue(Constants.TAGMidPx2));
            validateTag(Constants.TAGOrderQty2, null, tcr.getStringFieldValue(Constants.TAGOrderQty2));
            if(symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)) {
                validateTagNotNull(Constants.TAGSettlDate2, tcr.getStringFieldValue(Constants.TAGSettlDate2));
            } else {
                validateTag(Constants.TAGSettlDate2, null, tcr.getStringFieldValue(Constants.TAGSettlDate2));
            }
            validateTag(Constants.TAGCalculatedCcyLastQty2, null, tcr.getStringFieldValue(Constants.TAGCalculatedCcyLastQty2));
            validateTag(Constants.TAGFixingDate2, null, tcr.getStringFieldValue(Constants.TAGFixingDate2));
        }
        
        if(this.getType().equalsIgnoreCase("HUB")) {
            validateTag(Constants.TAGNoLegs, "1", tcr.getStringFieldValue(Constants.TAGNoLegs));
        } else {
            validateTag(Constants.TAGNoLegs, null, tcr.getStringFieldValue(Constants.TAGNoLegs));
        }
        
        validateTagNotNull(Constants.TAGTransactTime, tcr.getStringFieldValue(Constants.TAGTransactTime));
        
        validateTag(Constants.TAGNoSides, "1", tcr.getStringFieldValue(Constants.TAGNoSides));
        
        IFixGroup[] sides = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoSides, Constants.TAGiSide);
        
        if(symbolSfx.equals(Constants.SYMBOLSFX_LoanDeposit)){
            side = (side.equals(Constants.SIDE_Buy))?Constants.SIDE_Borrow:Constants.SIDE_Lend;
            validateTag(Constants.TAGSide, side, sides[0].getStringValFor(Constants.TAGiSide));   
            validateTagNotNull(Constants.TAGAccount, sides[0].getStringValFor(Constants.TAGiAccount)); //TODO get the account
            validateTag(Constants.TAGiExchangeRule, "ACT/360", sides[0].getStringValFor(Constants.TAGiExchangeRule));
        }else{
            validateTag(Constants.TAGSide, side, sides[0].getStringValFor(Constants.TAGiSide));
            if((!execType.equals(Constants.EXECTYPE_ClearingHold) && !execType.equals(Constants.EXECTYPE_FullyCleared) 
                    && this.getType().equals("MAKER")) || !isClearing) {
                validateTag(Constants.TAGAccount, account, sides[0].getStringValFor(Constants.TAGiAccount));
            }
            validateTag(Constants.TAGiExchangeRule, null, sides[0].getStringValFor(Constants.TAGiExchangeRule));
        }
        
        validateTag(Constants.TAGClOrdID, clOrdId, sides[0].getStringValFor(Constants.TAGiClOrdID));
        validateTag(Constants.TAGSecondaryClOrdID, null, sides[0].getStringValFor(Constants.TAGiSecondaryClOrdID));
        


        if(execType.equals(Constants.EXECTYPE_FullyCleared) && !allocated){
            if(this.getType().equals("AGENT")) {
                validateTag(Constants.TAGiNoSideRegulatoryTradeIDs, "3", sides[0].getStringValFor(Constants.TAGiNoSideRegulatoryTradeIDs));
            } else {
                validateTag(Constants.TAGiNoSideRegulatoryTradeIDs, "2", sides[0].getStringValFor(Constants.TAGiNoSideRegulatoryTradeIDs));
            }
        }else if(isNDF) {
            validateTag(Constants.TAGiNoSideRegulatoryTradeIDs, "1", sides[0].getStringValFor(Constants.TAGiNoSideRegulatoryTradeIDs));
        } else {
            validateTag(Constants.TAGiNoSideRegulatoryTradeIDs, null, sides[0].getStringValFor(Constants.TAGiNoSideRegulatoryTradeIDs));
        }
        
        if(isNDF){
        IFixGroup[] regTradeIDs = sides[0].getDynamicSubGroupDataFor(Constants.TAGiNoSideRegulatoryTradeIDs, Constants.TAGiSideRegulatoryTradeID);
        
        validateTag(Constants.TAGiSideRegulatoryTradeID, tradeID, regTradeIDs[0].getStringValFor(Constants.TAGiSideRegulatoryTradeID));
        validateTag(Constants.TAGiSideRegulatoryTradeIDSource, UsiUtiPrefix, regTradeIDs[0].getStringValFor(Constants.TAGiSideRegulatoryTradeIDSource));
        validateTag(Constants.TAGiSideRegulatoryTradeIDEvent, "0", regTradeIDs[0].getStringValFor(Constants.TAGiSideRegulatoryTradeIDEvent));
        validateTag(Constants.TAGiSideRegulatoryTradeIDType, Constants.SIDEREGULATORYTRADEIDTYPE_NearLeg, 
                regTradeIDs[0].getStringValFor(Constants.TAGiSideRegulatoryTradeIDType));
        
        if(execType.equals(Constants.EXECTYPE_FullyCleared) && !allocated){           
            validateTagNotNull(Constants.TAGiSideRegulatoryTradeID, regTradeIDs[1].getStringValFor(Constants.TAGiSideRegulatoryTradeID));
            validateTag(Constants.TAGiSideRegulatoryTradeIDSource, clearPrefix, regTradeIDs[1].getStringValFor(Constants.TAGiSideRegulatoryTradeIDSource));
            validateTag(Constants.TAGiSideRegulatoryTradeIDEvent, "2", regTradeIDs[1].getStringValFor(Constants.TAGiSideRegulatoryTradeIDEvent));
            validateTag(Constants.TAGiSideRegulatoryTradeIDType, Constants.SIDEREGULATORYTRADEIDTYPE_NearLeg, 
                    regTradeIDs[1].getStringValFor(Constants.TAGiSideRegulatoryTradeIDType));
            
            if(this.getType().equals("AGENT")){
                validateTagNotNull(Constants.TAGiSideRegulatoryTradeID, regTradeIDs[2].getStringValFor(Constants.TAGiSideRegulatoryTradeID));
                validateTag(Constants.TAGiSideRegulatoryTradeIDSource, clearPrefix, regTradeIDs[2].getStringValFor(Constants.TAGiSideRegulatoryTradeIDSource));
                validateTag(Constants.TAGiSideRegulatoryTradeIDEvent, "2", regTradeIDs[2].getStringValFor(Constants.TAGiSideRegulatoryTradeIDEvent));
                validateTag(Constants.TAGiSideRegulatoryTradeIDType, "2", //TODO 20150209 
                        regTradeIDs[2].getStringValFor(Constants.TAGiSideRegulatoryTradeIDType));
            }
        }
        }
        
        
        if(allocated){
            validateTag(Constants.TAGiNoAllocs, "2", sides[0].getStringValFor(Constants.TAGiNoAllocs));
            
            if(this.getType()!=null && this.getType().equals("MAKER")){
                allocAccount1 = allocAccount2 = account;
            }
            
            IFixGroup[] allocs = sides[0].getDynamicSubGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            int correctSubFunds = 0;
            
            for(IFixGroup alloc: allocs){
                String secondaryIndividualAllocId = null;
                
                if(alloc.getStringValFor(Constants.TAGiIndividualAllocID).equals(allocID1)){
                    correctSubFunds++;
                    validateTag(Constants.TAGiAllocAccount, allocAccount1, alloc.getStringValFor(Constants.TAGiAllocAccount));
                    validateTag(Constants.TAGiAllocQty, allocAmount1+".00", alloc.getStringValFor(Constants.TAGiAllocQty));
                    validateTagNotNull(Constants.TAGiSecondaryIndividualAllocID, alloc.getStringValFor(Constants.TAGiSecondaryIndividualAllocID));//TODO get from ER
                    secondaryIndividualAllocId = alloc.getStringValFor(Constants.TAGiSecondaryIndividualAllocID);
                    validateTagNotNull(Constants.TAGiCalculatedAllocQty, alloc.getStringValFor(Constants.TAGiCalculatedAllocQty));//TODO get from ER
                }else if(alloc.getStringValFor(Constants.TAGiIndividualAllocID).equals(allocID2)){
                    correctSubFunds++;
                    validateTag(Constants.TAGiAllocAccount, allocAccount2, alloc.getStringValFor(Constants.TAGiAllocAccount));
                    validateTag(Constants.TAGiAllocQty, allocAmount2+".00", alloc.getStringValFor(Constants.TAGiAllocQty));
                    validateTagNotNull(Constants.TAGiSecondaryIndividualAllocID, alloc.getStringValFor(Constants.TAGiSecondaryIndividualAllocID));//TODO get from ER
                    secondaryIndividualAllocId = alloc.getStringValFor(Constants.TAGiSecondaryIndividualAllocID);
                    validateTagNotNull(Constants.TAGiCalculatedAllocQty, alloc.getStringValFor(Constants.TAGiCalculatedAllocQty));//TODO get from ER
                }
                validateTag(Constants.TAGiAllocSide, side, alloc.getStringValFor(Constants.TAGiAllocSide));
                validateTag(Constants.TAGiSfbkSettleDate, null, alloc.getStringValFor(Constants.TAGiSfbkSettleDate));
                validateTag(Constants.TAGiSfbkPoints, null, alloc.getStringValFor(Constants.TAGiSfbkPoints));
                validateTag(Constants.TAGiAllocQty2, null, alloc.getStringValFor(Constants.TAGiAllocQty2));
                validateTag(Constants.TAGiFarCalculatedAllocQty, null, alloc.getStringValFor(Constants.TAGiFarCalculatedAllocQty));

                if(execType.equals(Constants.EXECTYPE_New) || execType.equals(Constants.EXECTYPE_Allocated)){
                    validateTag(Constants.TAGiConfirmStatus, null, alloc.getStringValFor(Constants.TAGiConfirmStatus));
                    validateTag(Constants.TAGiNoAllocRegulatoryTradeIDs, "1", alloc.getStringValFor(Constants.TAGiNoAllocRegulatoryTradeIDs));
                }else if(execType.equals(Constants.EXECTYPE_FullyCleared)){
                    validateTag(Constants.TAGiConfirmStatus, Constants.CONFIRMSTATUS_Cleared, alloc.getStringValFor(Constants.TAGiConfirmStatus));
                    validateTag(Constants.TAGiNoAllocRegulatoryTradeIDs, "2", alloc.getStringValFor(Constants.TAGiNoAllocRegulatoryTradeIDs));
                }
                
                IFixGroup[] allocRegulatoryTradeID = 
                        alloc.getDynamicSubGroupDataFor(Constants.TAGiNoAllocRegulatoryTradeIDs, Constants.TAGiAllocRegulatoryTradeID);
                
                validateTag(Constants.TAGiAllocRegulatoryTradeID, secondaryIndividualAllocId, 
                        allocRegulatoryTradeID[0].getStringValFor(Constants.TAGiAllocRegulatoryTradeID));
                validateTag(Constants.TAGiAllocRegulatoryTradeIDSource, UsiUtiPrefix, 
                        allocRegulatoryTradeID[0].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDSource));
                validateTag(Constants.TAGiAllocRegulatoryTradeIDEvent, "1", 
                        allocRegulatoryTradeID[0].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDEvent));
                validateTag(Constants.TAGiAllocRegulatoryTradeIDType, Constants.SIDEREGULATORYTRADEIDTYPE_NearLeg, 
                        allocRegulatoryTradeID[0].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType));
                
                if(execType.equals(Constants.EXECTYPE_FullyCleared) ||
                        (execType.equals(Constants.EXECTYPE_PartiallyFilled) && alloc.getStringValFor(Constants.TAGiIndividualAllocID).equals(allocID1))){                   
                    validateTagNotNull(Constants.TAGiAllocRegulatoryTradeID, allocRegulatoryTradeID[1].getStringValFor(Constants.TAGiAllocRegulatoryTradeID));
                    validateTag(Constants.TAGiAllocRegulatoryTradeIDSource, clearPrefix, 
                            allocRegulatoryTradeID[1].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDSource));
                    validateTag(Constants.TAGiAllocRegulatoryTradeIDEvent, "2", 
                            allocRegulatoryTradeID[1].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDEvent));
                    validateTag(Constants.TAGiAllocRegulatoryTradeIDType, Constants.SIDEREGULATORYTRADEIDTYPE_NearLeg, 
                            allocRegulatoryTradeID[1].getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType));
                }
            }
            assertEquals("Incorrect subFunds", 2, correctSubFunds);
        }else{
            validateTag(Constants.TAGiNoAllocs, null, sides[0].getStringValFor(Constants.TAGiNoAllocs));
            validateTag(Constants.TAGiAggressorIndicator, "Y", sides[0].getStringValFor(Constants.TAGiAggressorIndicator));//TODO check spec for alloc
        }
        

        validateTag(Constants.TAGFixingDate, fixingDate, tcr.getStringFieldValue(Constants.TAGFixingDate));
        }
    
    
    
    
    
    public void doAssertionCheckForTCR_MidT(Message tcr, Message executionReport, TakerTestSession taker, 
            String hubBankUserName, boolean newOrRebookOnly, boolean isT0match) throws Exception{
        
        String amount = executionReport.getStringFieldValue(Constants.TAGOrderQty);
        String tradeID = executionReport.getStringFieldValue(Constants.TAGExecID);
        String price = executionReport.getStringFieldValue(Constants.TAGPrice);        
        String tradeDate = executionReport.getStringFieldValue(Constants.TAGTradeDate);
        String settlDate = executionReport.getStringFieldValue(Constants.TAGSettlDate);
        String side = executionReport.getStringFieldValue(Constants.TAGSide);
        String account = taker.getPartyId();
        String securityType = "TNOTE";
        String execType;
        
        if(newOrRebookOnly){
            execType = Constants.EXECTYPE_New; 
        }else if(isT0match){
            execType = Constants.EXECTYPE_MidMatchT0Trade; 
        }else{ //Tn match
            execType = Constants.EXECTYPE_MidMatchTNTrade;
        }
        
        String symbol = executionReport.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = executionReport.getStringFieldValue(Constants.TAGSymbolSfx);
        String trdType = Constants.TRDTYPE_MIDT;
        String tradeLinkId = null;
        String yield = executionReport.getStringFieldValue(Constants.TAGYield);
        String lastPx = executionReport.getStringFieldValue(Constants.TAGLastPx);
        
        doAssertionCheckForTCROXO(tcr, tradeID, trdType, execType, tradeLinkId, amount, taker, price, tradeDate, settlDate, side,
                account, symbol, symbolSfx, securityType, hubBankUserName, yield, lastPx);
    }
    

    private void doAssertionCheckForTCROXO(Message tcr, String tradeID, String trdType, String execType, String tradeLinkId, String amount,
            TakerTestSession taker, String price, String tradeDate, 
            String settlDate, String side, String account, String symbol, String symbolSfx, String securityType,
            String hubBankUserName, String yield, String lastPx) throws Exception{

        validateTagNotNull(Constants.TAGTradeReportID, tcr.getStringFieldValue(Constants.TAGTradeReportID)); 
        validateTag(Constants.TAGTradeID, tradeID, tcr.getStringFieldValue(Constants.TAGTradeID)); 
        validateTagNotNull(Constants.TAGTradeRequestID, tcr.getStringFieldValue(Constants.TAGTradeRequestID));
        validateTag(Constants.TAGTrdType, trdType, tcr.getStringFieldValue(Constants.TAGTrdType));
        validateTag(Constants.TAGExecType, execType, tcr.getStringFieldValue(Constants.TAGExecType));
        
        if(tradeLinkId==null){
            validateTagNotNull(Constants.TAGTradeLinkID, tcr.getStringFieldValue(Constants.TAGTradeLinkID));
        }else{
            validateTag(Constants.TAGTradeLinkID, tradeLinkId, tcr.getStringFieldValue(Constants.TAGTradeLinkID));
        }
        
        validateTagNotNull(Constants.TAGPreviouslyReported, tcr.getStringFieldValue(Constants.TAGPreviouslyReported));
        validateTag(Constants.TAGPriceType, Constants.PRICETYPE_Price, tcr.getStringFieldValue(Constants.TAGPriceType));
        
        /* Parties validation*/
        boolean hasOriCust = false;
        boolean hasHubIntermediary = false;
        
        validateTag(Constants.TAGNoRootPartyIDs, "2", tcr.getStringFieldValue(Constants.TAGNoRootPartyIDs));

        IFixGroup[] rootPartyIDs = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoRootPartyIDs, Constants.TAGiRootPartyID);
        assertNotNull("Null rootPartyIDs", rootPartyIDs);
        assertEquals("Incorrect number of rootPartyIDs", 2, rootPartyIDs.length);
        
        for(IFixGroup party:rootPartyIDs){
            switch(party.getStringValFor(Constants.TAGiRootPartyRole)){
                case "13": hasOriCust = true;
                           validateTag(Constants.TAGRootPartyID, taker.getPartyId(), party.getStringValFor(Constants.TAGiRootPartyID));
                           checkRootSubParty(party, taker.getUserName(), null);
                           break;
                case "29": hasHubIntermediary = true;
                           validateTag(Constants.TAGRootPartyID, this.getPartyId(), party.getStringValFor(Constants.TAGiRootPartyID));
                           checkRootSubParty(party, hubBankUserName, null);
                           break;                           
                default:   fail("Unpxected value of RootPartyRole: "+party.getStringValFor(Constants.TAGiRootPartyRole));
                           break;
            } 
            validateTag(Constants.TAGRootPartyIDSource, null, party.getStringValFor(Constants.TAGiRootPartyIDSource));
        }
        
        assertTrue("No Originating Customer party in TCR",hasOriCust);
        assertTrue("No Hub party in TCR",hasHubIntermediary);
        
        validateTag(Constants.TAGSymbol, symbol, tcr.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGSymbolSfx, symbolSfx, tcr.getStringFieldValue(Constants.TAGSymbolSfx));
        validateTagNotNull(Constants.TAGSecurityID, tcr.getStringFieldValue(Constants.TAGSecurityID));
        validateTag(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip, tcr.getStringFieldValue(Constants.TAGSecurityIDSource));
        validateTag(Constants.TAGProduct, Constants.PRODUCT_Government, tcr.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSecurityType, securityType, tcr.getStringFieldValue(Constants.TAGSecurityType));
        validateTagNotNull(Constants.TAGMaturityDate, tcr.getStringFieldValue(Constants.TAGMaturityDate));
        validateTagNotNull(Constants.TAGIssueDate, tcr.getStringFieldValue(Constants.TAGIssueDate));
        validateTagNotNull(Constants.TAGCouponRate, tcr.getStringFieldValue(Constants.TAGCouponRate));
        //validateTag(Constants.TAGYield, yield, tcr.getStringFieldValue(Constants.TAGYield)); //TODO 
        validateTagNotNull(Constants.TAGLastQty, tcr.getStringFieldValue(Constants.TAGLastQty));
        validateTag(Constants.TAGLastQty, Double.parseDouble(amount), Double.parseDouble(tcr.getStringFieldValue(Constants.TAGLastQty)));
        validateTagNotNull(Constants.TAGLastPx, tcr.getStringFieldValue(Constants.TAGLastPx));
        validateTag(Constants.TAGLastPx, Double.parseDouble(lastPx), Double.parseDouble(tcr.getStringFieldValue(Constants.TAGLastPx)));
        validateTag(Constants.TAGTradeDate, tradeDate, tcr.getStringFieldValue(Constants.TAGTradeDate));
        
        
        double grossTradeAmt = 0;
        double accruedInterestAmt = 0;
        
        /* TrdInstrmtLegGrp validation*/
        if(execType.equals(Constants.EXECTYPE_MidMatchTNTrade)){   // No leg for MidX Tn event    
            validateTag(Constants.TAGNoLegs, "0", tcr.getStringFieldValue(Constants.TAGNoLegs));
        }else{
            
            validateTag(Constants.TAGNoLegs, "1", tcr.getStringFieldValue(Constants.TAGNoLegs));
            
            IFixGroup[] legs = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);
            
            assertNotNull("Null legs", legs);
            assertEquals("Incorrect number of legs", 1, legs.length);
            validateTag(Constants.TAGiLegSymbol, "NA", legs[0].getStringValFor(Constants.TAGiLegSymbol));
            //validateTag(Constants.TAGLegPrice, Double.parseDouble(lastPx), Double.parseDouble(legs[0].getStringValFor(Constants.TAGiLegPrice))); //TODO
            validateTag(Constants.TAGLegQty, Double.parseDouble(amount), Double.parseDouble(legs[0].getStringValFor(Constants.TAGiLegQty)));
            

            validateTag(Constants.TAGNoNestedPartyIDs, "2", legs[0].getStringValFor(Constants.TAGiNoNestedPartyIDs));
            
            IFixGroup[] nestedParties = legs[0].getDynamicSubGroupDataFor(Constants.TAGiNoNestedPartyIDs, Constants.TAGiNestedPartyID);
            
            assertNotNull("Null nestedParties", nestedParties);
            assertEquals("Incorrect number of nestedParties", 2, nestedParties.length);
            
            for(IFixGroup nestedParty:nestedParties){
                
                validateTagNotNull(Constants.TAGNestedPartyID, nestedParty.getStringValFor(Constants.TAGiNestedPartyID));
                validateTagNotNull(Constants.TAGNestedPartyRole, nestedParty.getStringValFor(Constants.TAGiNestedPartyRole));
                validateTag(Constants.TAGNoNestedPartySubIDs, "1", nestedParty.getStringValFor(Constants.TAGiNoNestedPartySubIDs));
                
                IFixGroup[] nestedPartySubIDs = nestedParty.getDynamicSubGroupDataFor(Constants.TAGiNoNestedPartySubIDs, Constants.TAGiNestedPartySubID);
                
                assertNotNull("Null nestedPartySubIDs", nestedPartySubIDs);
                assertEquals("Incorrect number of nestedPartySubIDs", 1, nestedPartySubIDs.length);
                
                validateTagNotNull(Constants.TAGNestedPartySubID, nestedPartySubIDs[0].getStringValFor(Constants.TAGiNestedPartySubID));
                validateTag(Constants.TAGNestedPartySubIDType, Constants.NESTEDPARTYSUBIDTYPE_IndividualPerson, nestedPartySubIDs[0].getStringValFor(Constants.TAGiNestedPartySubIDType));
            }
            
//            String legGrossTradeAmount = String.format("%.2f", Double.parseDouble(amount)*Double.parseDouble(lastPx));
//            validateTag(Constants.TAGiLegGrossTradeAmount, legGrossTradeAmount, legs[0].getStringValFor(Constants.TAGiLegGrossTradeAmount));//TODO
            validateTagNotNull(Constants.TAGiLegGrossTradeAmount, legs[0].getStringValFor(Constants.TAGiLegGrossTradeAmount));
            validateTagNotNull(Constants.TAGiLegLastQty, legs[0].getStringValFor(Constants.TAGiLegLastQty));
            
            grossTradeAmt = Double.valueOf(legs[0].getStringValFor(Constants.TAGiLegGrossTradeAmount));
            accruedInterestAmt = Double.valueOf(legs[0].getStringValFor(Constants.TAGiLegLastQty));
        }

        validateTagNotNull(Constants.TAGTransactTime, tcr.getStringFieldValue(Constants.TAGTransactTime));
        validateTag(Constants.TAGSettlDate, settlDate, tcr.getStringFieldValue(Constants.TAGSettlDate));
        validateTag(Constants.TAGNoSides, "1", tcr.getStringFieldValue(Constants.TAGNoSides));
        
        IFixGroup[] sides = tcr.getParser().getDynamicGroupDataFor(Constants.TAGiNoSides, Constants.TAGiSide);
        assertNotNull("Null sides", sides);
        assertEquals("Incorrect number of sides", 1, sides.length);
        validateTag(Constants.TAGSide, side, sides[0].getStringValFor(Constants.TAGiSide));
        validateTag(Constants.TAGAccount, account, sides[0].getStringValFor(Constants.TAGiAccount));
        validateTagNotNull(Constants.TAGiGrossTradeAmt, sides[0].getStringValFor(Constants.TAGiGrossTradeAmt));
        validateTagNotNull(Constants.TAGiAccruedInterestAmt, sides[0].getStringValFor(Constants.TAGiAccruedInterestAmt));
        validateTagNotNull(Constants.TAGiAggressorIndicator, sides[0].getStringValFor(Constants.TAGiAggressorIndicator));
        
        if(execType.equals(Constants.EXECTYPE_MidMatchT0Trade)){
            validateTag(Constants.TAGGrossTradeAmt, grossTradeAmt, Double.valueOf(sides[0].getStringValFor(Constants.TAGiGrossTradeAmt)));
            validateTag(Constants.TAGAccruedInterestAmt, accruedInterestAmt, Double.valueOf(sides[0].getStringValFor(Constants.TAGiAccruedInterestAmt)));
        }
        
    }
    
    
    
    private void checkRootSubParty(IFixGroup party, String userID, String lei) throws Exception{
        boolean hasIndividualPerson = false;
        boolean hasLEI = false;
        
        if(lei!=null) {
            validateTag(Constants.TAGNoRootSubParties, "2", 
                    party.getStringValFor(Constants.TAGiNoRootSubParties));
        } else {
            validateTag(Constants.TAGNoRootSubParties, "1", 
                    party.getStringValFor(Constants.TAGiNoRootSubParties));
        } 
        
        IFixGroup[] rootSubParties = party.getDynamicSubGroupDataFor(Constants.TAGiNoRootSubParties, Constants.TAGiRootPartySubID);
        for(IFixGroup subParty:rootSubParties){
            switch(subParty.getStringValFor(Constants.TAGiRootPartySubIDType)){
            case "2": hasIndividualPerson = true;
                      validateTag(Constants.TAGRootPartySubID, userID, 
                              subParty.getStringValFor(Constants.TAGiRootPartySubID));
                      break;
            case "N": hasLEI=true;
                      validateTag(Constants.TAGRootPartySubID, lei, 
                              subParty.getStringValFor(Constants.TAGiRootPartySubID));
                      break;
            default: fail("Unpxected value of RootPartySubIDType: "+subParty.getStringValFor(Constants.TAGiRootPartySubIDType));
                     break;
            }
        }
        if(userID!=null) {
            assertTrue("No Individual Person in RootSubParty in TCR", hasIndividualPerson);
        }
        if(lei!=null) {
            assertTrue("No LEI in RootSubParty in TCR", hasLEI);
        }
    }
    
    
    

    @Override
    public void onFixMessage(Message message) throws Exception {
        String type = message.getStringFieldValue(Constants.TAGMsgType);
        if (type.equals(Constants.MSGTradeCaptureReportRequestAck)) {
            System.out.println("TradeCaptureReportRequestAck Message received");
            handleTradeCaptureReportRequestAck(message);
        }
        else if (type.equals(Constants.MSGTradeCaptureReport)) {
            handleTradeCaptureReport(message);
        } else if (type.equals(Constants.MSGBusinessMessageReject)) {
            rejectQueue.add(message);
        } else if (type.equals(Constants.MSGReject)) {
            rejectQueue.add(message);
        }
        else if (type.equals(MSGType_XMLMessage)) {
            handleXMLTradeCaptureReport(message);
        }
        else {
            System.err.println("unhandle FIX message from SERVER");
        }

    }

    private void handleTradeCaptureReport(Message message) throws Exception{
        String reportId = message.getStringFieldValue(Constants.TAGTradeReportID);
        if(stpEvents.contains(reportId))
        {
            throw new IllegalArgumentException("duplicate report received!! " + reportId);
        }
        stpEvents.add(reportId);
        reportQueue.add(message);
    }

    private void handleXMLTradeCaptureReport(Message message) throws Exception{
        xmlReportQueue.add(message);
    }

    public void ackTradeCaptureReport(String tradeReportId) throws Exception {
        Message tradeReportAck = new Message(Constants.MSGTradeCaptureReportAck, getSenderCompId(), getTargetCompId(), getFixVersion());
        tradeReportAck.setField(Constants.TAGTradeReportID, tradeReportId);
        tradeReportAck.setField(Constants.TAGSymbol, "NA");
        sendFixMessage(tradeReportAck);
    }

    private void ackXmlTradeCaptureReport(String tradeId) throws Exception {
        
        if(!tradeId.startsWith("A") && !tradeId.startsWith("T")){
            return;
        }//ack only when tradeId starts with A or T
        
        
        Message tradeReportAck = new Message("n", getSenderCompId(), getTargetCompId(), getFixVersion());
        String tag213 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><RealTimeReply><trade><id>" + tradeId + "</id><status>received</status></trade></RealTimeReply>";
        tradeReportAck.setField(212, 133);
        tradeReportAck.setField(213, tag213);
        sendFixMessage(tradeReportAck);
    }
    
    
    
    public void ackXmlTradeCaptureReport(Message xmlTCR) throws Exception {
        
        String input = xmlTCR.getParser().getStringValFor(QFMsgParser.FIX_HR_PART, 213);
        String a = "<tradeId>";
        String b = "</tradeId>";
                
        if(input.indexOf(a) == -1 || input.indexOf(b) == -1) {
            throw new IllegalArgumentException("one of the search strings is not present!!");
        }
        String[] tokens = input.split(a);
        String[] tradeIds = new String[tokens.length-1];
        for(int i=1;i<tokens.length;i++)
        {
            tradeIds[i-1] = tokens[i].split(b)[0];
//           System.out.println("result: "  + (i-1) + " : " + result[i-1]);
        }
        
        for(String tradeId : tradeIds) {
            this.ackXmlTradeCaptureReport(tradeId);
        }
    }
    
    

    private void handleTradeCaptureReportRequestAck(Message message) throws Exception{
        String tradeRequestId = message.getStringFieldValue(Constants.TAGTradeRequestID);
        String subscriptionType = message.getStringFieldValue(Constants.TAGSubscriptionRequestType);
        String tradeRequestStatus = message.getStringFieldValue(Constants.TAGTradeRequestStatus);
        String tradeRequestResult = message.getStringFieldValue(Constants.TAGTradeRequestResult);
        if (tradeRequestStatus.equals("0")) {
            System.out.println(tradeRequestId + " accepted " +  subscriptionType);
        } else {
                String reason;
                if (tradeRequestResult.equals("8")) {
                    reason = "Unsupported TradeRequestType";
                } else if (tradeRequestStatus.equals("9")) {
                    reason = "Unauthorized for trade capture report request";
                } else {
                    reason = "Other";
                }
              System.out.println(tradeRequestId + " rejected " + reason);
            }
        reqAckQueue.add(message);
    }

    public Message getMessageFromReportQueue(long timeout) throws Exception {
        return reportQueue.poll(timeout, TimeUnit.MILLISECONDS);
    }

    public Message getMessageFromXMLReportQueue(long timeout) throws Exception {
        return xmlReportQueue.poll(timeout, TimeUnit.MILLISECONDS);
    }

    public Message getMessageFromRejectQueue(long timeout) throws Exception {
        return rejectQueue.poll(timeout, TimeUnit.MILLISECONDS);
    }

    public Message getMessageFromRequestAckQueue(long timeout) throws Exception {
        return reqAckQueue.poll(timeout, TimeUnit.MILLISECONDS);
    }

    public int getReportQueueSize() {
        return reportQueue.size();
    }

    public boolean isThereInReportQueue(Message msg) {
        boolean isRemoved = true;
        synchronized(reportQueue) {
            for (Message m : reportQueue) {
                if (msg.equals(m)) {
                    isRemoved = false;
                }
            }
        }

        return isRemoved;
    }
    
    public void clearReportQueue(){
        reportQueue.clear();
        xmlReportQueue.clear();
        stpEvents.clear();
    }
    
    public void clearRejectQueue(){
        rejectQueue.clear();
    }

    public String getType()
    {
        return this.type;
    }

    public void setType(String type)
    {
        this.type=type;
    }

    public String getRelationship()
    {
        return this.relationship;
    }

    public String getUserName()
    {
        return getSenderCompId();
    }

    public String getPartyName() {
        return getPartyId();
    }
}
