package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import java.io.File;
import java.io.IOException;
import java.net.SocketAddress;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat;
import currenex.util.threadpool.ExclusiveTask;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelPipelineFactory;

public class CxNowItchTestClient {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchTestClient.class);
    private final ClientBootstrap clientBootstrap;
    private final SocketAddress remoteAddress;
    private final ChannelFutureListener futureListener;
    private final ChannelPipelineFactory pipelineFactory;
    private final CxNowItchTestRunner testRunner;
    private final Semaphore testFinished;

    private final File resultsFile;
    private final ExclusiveTask writeTask;
    private volatile boolean writesDisabled = false;

    @Inject
    CxNowItchTestClient(ClientBootstrap clientBootstrap, SocketAddress remoteAddress,
            ChannelFutureListener futureListener, ChannelPipelineFactory pipelineFactory,
            CxNowItchTestRunner testRunner, ExclusiveTask.Factory exclusiveTaskFactory,
            @Named("writeIntervalMillis") long writeIntervalMillis,
            @Named("resultsFile") File resultsFile,
            @Named("testFinished") Semaphore testFinished) throws IOException {
        this.clientBootstrap = clientBootstrap;
        this.remoteAddress = remoteAddress;
        this.futureListener = futureListener;
        this.pipelineFactory = pipelineFactory;
        this.testRunner = testRunner;
        this.testFinished = testFinished;

        this.resultsFile = resultsFile;
        this.writeTask = exclusiveTaskFactory.newTask("cxNowItchPerformance", () -> {
            while (true) {
                try {
                    Thread.sleep(writeIntervalMillis);
                    writeStatsToFile(false);
                } catch (InterruptedException e) {
                    log.log(Level.SEVERE, "writeTask threw exception", e);
                    break;
                }
            }
        });
    }

    public void run() throws Exception {
        log.info("Attempting to connect to " + remoteAddress);
        clientBootstrap.setPipelineFactory(pipelineFactory);
        clientBootstrap.connect(remoteAddress).addListener(futureListener);

        writeTask.poke();
        testRunner.runTest();
        testFinished.acquire();

        log.infof("Test finished, writing final results to file=%s", resultsFile.getAbsolutePath());
        writeStatsToFile(true);
        System.exit(0);
    }

    private synchronized void writeStatsToFile(boolean disableWrites) {
        if (writesDisabled) return;
        this.writesDisabled = disableWrites;
        new CxNowTestStat().writeStats(resultsFile);
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            log.info("Usage: <path to properties file>");
            return;
        }

        try {
            Guice.createInjector(new CxNowItchTestModule(args[0])).getInstance(CxNowItchTestClient.class).run();
        } catch (Exception e) {
            log.log(Level.SEVERE, "Exception caught while running CxNow test client", e);
        }
    }
}