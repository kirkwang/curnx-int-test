package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class SubscriptionReply {

    private int sessionID;
    private short instrumentIndex;
    private char type;
    private String reason;
    
    public SubscriptionReply(int sessionID, short instrumentIndex, char type,
            String reason) {
        super();
        this.sessionID = sessionID;
        this.instrumentIndex = instrumentIndex;
        this.type = type;
        this.reason = reason;
    }

    public int getSessionID() {
        return sessionID;
    }

    public void setSessionID(int sessionID) {
        this.sessionID = sessionID;
    }

    public short getInstrumentIndex() {
        return instrumentIndex;
    }

    public void setInstrumentIndex(short instrumentIndex) {
        this.instrumentIndex = instrumentIndex;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
    
    
}
