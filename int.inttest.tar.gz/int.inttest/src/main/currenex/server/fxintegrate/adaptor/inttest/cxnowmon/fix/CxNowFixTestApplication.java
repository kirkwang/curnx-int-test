package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.fix;

import static currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat.MsgTypes.*;


import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import com.google.common.base.Throwables;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.util.W3CDate;
import currenex.time.MicroInstant;
import quickfix.Application;
import quickfix.FieldNotFound;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.InvalidMessage;
import quickfix.Message;
import quickfix.MessageCracker;
import quickfix.MessageUtils;
import quickfix.RejectLogon;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionNotFound;
import quickfix.UnsupportedMessageType;
import quickfix.field.MDEntryTime;
import quickfix.field.MDEntryType;
import quickfix.field.MDFeedType;
import quickfix.field.MDReqID;
import quickfix.field.MarketDepth;
import quickfix.field.MsgType;
import quickfix.field.NoRelatedSym;
import quickfix.field.Password;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.field.SymbolSfx;
import quickfix.field.TransactTime;
import quickfix.fix44.MarketDataIncrementalRefresh;
import quickfix.fix44.MarketDataRequest;
import quickfix.fix44.MarketDataRequestReject;

public class CxNowFixTestApplication extends MessageCracker implements Application {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowFixTestApplication.class);
    private final Map<Character, Boolean> subscriptions;
    private final List<String> instruments;
    private final String password;
    private final CxNowTestStat cxNowTestStat;

    @Inject CxNowFixTestApplication(@Named("subscriptions") Map<Character, Boolean> subscriptions,
            @Named("instruments") List<String> instruments,
            @Named("password") String password, CxNowTestStat cxNowTestStat) {
        this.subscriptions = subscriptions;
        this.instruments = instruments;
        this.password = password;
        this.cxNowTestStat = cxNowTestStat;
    }

    /** Quickfixj callbacks */

    @Override public void onCreate(SessionID sessionId) {
        log.info("QuickFixJ session initialized, sessionId=" + sessionId);
    }

    @Override public void onLogon(SessionID sessionId) {
        subscribeToCxNow(sessionId);
    }

    @Override public void onLogout(SessionID sessionId) {
    }

    /** Outgoing logic */

    @Override public void toAdmin(Message message, SessionID sessionId) {
        try {
            MsgType msgType = new MsgType(MessageUtils.getMessageType(message.toString()));
            if (msgType.getValue().equals(MsgType.LOGON)) {
                message.setField(new Password(password));
            }
        } catch (InvalidMessage invalidMessage) {
            log.warning("Invalid message: " + message);
            Throwables.propagate(invalidMessage);
        }
    }

    @Override public void toApp(Message message, SessionID sessionId) {
    }

    private void subscribeToCxNow(SessionID sessionId) {
        instruments.forEach(instrument -> {
            MarketDataRequest marketDataRequest = new MarketDataRequest(
                    new MDReqID("cxnowmon"),
                    new SubscriptionRequestType('C'),
                    new MarketDepth(0));

            MarketDataRequest.NoMDEntryTypes entryTypes = new MarketDataRequest.NoMDEntryTypes();
            addMarketDataRequestGroup(marketDataRequest, entryTypes);

            MarketDataRequest.NoRelatedSym relatedSymbols = new MarketDataRequest.NoRelatedSym();
            addMarketDataInstrumentGroup(marketDataRequest, relatedSymbols, instrument);

            try {
                Session.sendToTarget(marketDataRequest, sessionId);
                cxNowTestStat.addTime(0, SUBSCRIPTION_REQ);
            } catch (SessionNotFound sessionNotFound) {
                log.log(Level.SEVERE, "Session not found: " + sessionNotFound.getMessage(), sessionNotFound);
            }
        });
    }

    private void addMarketDataRequestGroup(MarketDataRequest message, MarketDataRequest.NoMDEntryTypes group) {
        subscriptions.entrySet().forEach(entry -> {
            if (!entry.getValue()) return;
            group.set(new MDEntryType(entry.getKey()));
            message.addGroup(group);
        });
    }

    private static void addMarketDataInstrumentGroup(MarketDataRequest message, MarketDataRequest.NoRelatedSym group,
            String instrument) {
        message.addField(new NoRelatedSym(1));
        message.addField(new Symbol(instrument));
        message.addField(new SymbolSfx("SP"));
    }

    /** Incoming logic */

    @Override public void fromAdmin(Message message, SessionID sessionId)
            throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, RejectLogon {
    }

    @Override public void fromApp(Message message, SessionID sessionId)
            throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue, UnsupportedMessageType {
        try {
            crack(message, sessionId);
        } catch (Exception e) {
            log.info("Error cracking message: " + message);
        }
    }

    @Override public void onMessage(MarketDataRequestReject message, SessionID sessionId) {
        MicroInstant microInstant = MicroInstant.now();
        recordTime(message, REJECT, microInstant.getMillis());
    }

    @Override public void onMessage(MarketDataIncrementalRefresh message, SessionID sessionId) {
        MicroInstant microInstant = MicroInstant.now();
        long currentTimeMillis = microInstant.getMillis();

        try {
            MDFeedType feedType = new MDFeedType();
            message.get(feedType);
            switch(feedType.getValue()) {
                case 'b':
                    recordTime(message, NOW_DEPTH_OF_BOOK, currentTimeMillis);
                    break;
                case 't':
                    recordTime(message, NOW_TICKER, currentTimeMillis);
                    recordTickerTransactTime(message, currentTimeMillis);
                    break;
                case 'w':
                    recordTime(message, NOW_WAMR, currentTimeMillis);
                    recordWamrCalcTime(message, currentTimeMillis);
                    break;
                case 'M':
                    recordTime(message, NOW_MID, currentTimeMillis);
                    break;
            }
        } catch (FieldNotFound fieldNotFound) {
            log.severef("Unable to find feed type in message: %s", message);
        }
    }

    private void recordTime(Message message, CxNowTestStat.MsgTypes msgType, long currentTimeMillis) {
        try {
            long timestamp = message.getHeader().getUtcTimeStamp(52).getTime();
            cxNowTestStat.addTime((int) (currentTimeMillis - timestamp), msgType);
        } catch (FieldNotFound fieldNotFound) {
            log.severef("Could not find timestamp in message: %s", message);
        }
    }

    private void recordTickerTransactTime(Message message, long currentTimeMillis) throws FieldNotFound {
        MarketDataIncrementalRefresh.NoMDEntries group = new MarketDataIncrementalRefresh.NoMDEntries();
        TransactTime tickerTransactTime = new TransactTime();
        message.getGroup(1, group);
        group.get(tickerTransactTime);

        long transactTime = tickerTransactTime.getValue().getTime();
        cxNowTestStat.addTime((int) (currentTimeMillis - transactTime), TICKER_TRANSACT_TIME);
    }

    private void recordWamrCalcTime(MarketDataIncrementalRefresh message, long currentTimeMillis) throws FieldNotFound {
        MarketDataIncrementalRefresh.NoMDEntries group = new MarketDataIncrementalRefresh.NoMDEntries();
        int numGroups = message.getGroupCount(Integer.parseInt(Constants.TAGNoMDEntries));

        for (int i = 0; i < numGroups; ++i) {
            try {
                message.getGroup(1, group);
                Date calcTime = W3CDate.W3CToDate(group.getString(MDEntryTime.FIELD), false, true);
                cxNowTestStat.addTime((int) (currentTimeMillis - calcTime.getTime()), WAMR_CALC_TIME_MILLIS);
            } catch (Exception e) {
                log.log(Level.SEVERE, "Caught exception", e);
            }
        }
    }
}
