package currenex.server.fxintegrate.adaptor.inttest.ouchMaker.message;

public class ExecutionReportAck {
    
    
    private int clOrdID;
    private String executionID;
    private boolean isCustomerAggresor;
    private String LMUID;
    
    public ExecutionReportAck(int clOrdID, String executionID,
            boolean isCustomerAggresor, String lMUID) {
        super();
        this.clOrdID = clOrdID;
        this.executionID = executionID;
        this.isCustomerAggresor = isCustomerAggresor;
        this.LMUID = lMUID;
    }

    public int getClOrdID() {
        return clOrdID;
    }

    public void setClOrdID(int clOrdID) {
        this.clOrdID = clOrdID;
    }

    public String getExecutionID() {
        return executionID;
    }

    public void setExecutionID(String executionID) {
        this.executionID = executionID;
    }

    public boolean isCustomerAggresor() {
        return isCustomerAggresor;
    }

    public void setCustomerAggresor(boolean isCustomerAggresor) {
        this.isCustomerAggresor = isCustomerAggresor;
    }

    public String getLMUID() {
        return LMUID;
    }

    public void setLMUID(String lMUID) {
        LMUID = lMUID;
    }
    
    

}
