package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class SecurityListGroup {
    
    private final String symbol;
    private final String symbolSfx;
    private String securityID;
    private String securityIDSource;
    private final int product;
    private final String securityType;
    private String maturityDate;
    private String issueDate;
    private final String factor;
    private final String currency;
    private String couponRate;
    private String cpRegType;
    private String priceType;
    private String datedDate;
    private String interestAccrualDate;
    
    public SecurityListGroup(String symbol, String symbolSfx, String securityIDSource, int product,
            String securityType, String factor, String currency, String couponRate, String issueDate, 
            String cpRegType, String priceType, String datedDate, String interestAccrualDate) {
        super();
        this.symbol = symbol;
        this.symbolSfx = symbolSfx;
        this.securityIDSource = securityIDSource;
        this.product = product;
        this.securityType = securityType;
        this.factor = factor;
        this.currency = currency;
        this.couponRate = couponRate;
        this.issueDate = issueDate;
        this.cpRegType = cpRegType;
        this.priceType = priceType;
        this.datedDate = datedDate;
        this.interestAccrualDate = interestAccrualDate;
    }

    public String getSecurityID() {
        return securityID;
    }

    public void setSecurityID(String securityID) {
        this.securityID = securityID;
    }

    public String getSecurityIDSource() {
        return securityIDSource;
    }

    public void setSecurityIDSource(String securityIDSource) {
        this.securityIDSource = securityIDSource;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getSymbolSfx() {
        return symbolSfx;
    }

    public int getProduct() {
        return product;
    }

    public String getSecurityType() {
        return securityType;
    }

    public String getFactor() {
        return factor;
    }

    public String getCurrency() {
        return currency;
    }

    public String getCouponRate() {
        return couponRate;
    }

    public void setCouponRate(String couponRate) {
        this.couponRate = couponRate;
    }

    public String getCpRegType() {
        return cpRegType;
    }

    public void setCpRegType(String cpRegType) {
        this.cpRegType = cpRegType;
    }

    public String getPriceType() {
        return priceType;
    }

    public void setPriceType(String priceType) {
        this.priceType = priceType;
    }

    public String getDatedDate() {
        return datedDate;
    }

    public void setDatedDate(String datedDate) {
        this.datedDate = datedDate;
    }

    public String getInterestAccrualDate() {
        return interestAccrualDate;
    }

    public void setInterestAccrualDate(String interestAccrualDate) {
        this.interestAccrualDate = interestAccrualDate;
    }

}
