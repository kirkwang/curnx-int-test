package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.*;
import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.annotation.Nullable;

import currenex.server.fxintegrate.adaptor.fix.gateway.session.IFixGroup;
import currenex.server.fxintegrate.adaptor.fix.util.FixMsgConstants;
import currenex.server.fxintegrate.adaptor.fix.util.FixTagConstants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.ao.Quote;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.Allocation;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.InstrumentParty;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.Party;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.RFQLeg;

/**
 * @author Leo Zhou <lzhou@currenex.com>
 */
public final class MakerTestSession extends ATestSession {

    public static final String MSGApplicationPing = "U1";
    public static final String MSGApplicationPingReply = "U2";
    public static final String MSGOrderTimeout = "U3";
    public static final String MSGInitialize = "U4";
    public static final String MSGCancelAllQuotes = "U5";
    public static final String MSGBusinessMessageReject = "j";
    public static final String TAGApplicationPingID = "7532";

    private final Map<String, Subscription> subscriptions = Collections.synchronizedMap(new HashMap<String, Subscription>());
    private final Map<String, Quote> topOfBookPrices = Collections.synchronizedMap(new HashMap<String, Quote>());
    private final BlockingQueue<Message> orderQueue = new ArrayBlockingQueue<Message>(50000);
    private final BlockingQueue<Message> orderMultiLegQueue = new ArrayBlockingQueue<Message>(50000);
    private final BlockingQueue<Message> ackQueue = new ArrayBlockingQueue<Message>(50000);
    private final BlockingQueue<Message> rejectQueue = new ArrayBlockingQueue<Message>(50000);
    private final BlockingQueue<Message> pingQueue = new ArrayBlockingQueue<Message>(50000);
    private final BlockingQueue<Message> qrQueue = new ArrayBlockingQueue<Message>(50000);
    private boolean replyImmediately = false;
    
    private Properties makerProperties; 
    
    public MakerTestSession(Properties props) throws Exception {
        super(props.getProperty(PARTYID),
                props.getProperty(HOST),
                Integer.parseInt(props.getProperty(PORT)),
                props.getProperty(SENDERCOMPID),
                props.getProperty(TARGETCOMPID),
                props.getProperty(DATADICTIONARY),
                props.getProperty(FIXVERSION),
                props.getProperty(RSAKEYTYPE),
                props.getProperty(PASSWORD, DEFAULT_PASSWORD),
                props.getProperty(FILESTOREPATH),
                props.getProperty(RESETSEQNUM),
                props.getProperty(LOGONRETRIES, "3")
                );
        this.makerProperties = props;
    }

    public MakerTestSession(@Nullable String partyId,
                            String host,
                            int port,
                            String senderCompId,
                            String targetCompId,
                            @Nullable String dataDictionary,
                            @Nullable String fixVersion,
                            @Nullable String password) throws Exception {
        super(partyId, host, port, senderCompId, targetCompId, dataDictionary, fixVersion, null, password, null, null);
    }

    public static final class Subscription {
        public final String requestId;
        public final String symbol;
        public String valueDate;
        public final String amount;
        public final @Nullable String symbolSfx;
        public final @Nullable String securityID;
        public @Nullable String securityIDSource;
        public @Nullable String maturityDate;
        public @Nullable String issueDate;
        public @Nullable String factor;
        public @Nullable String datedDate;
        public @Nullable String interestAccrualDate;
        public @Nullable String transactTime;
        public @Nullable String noRelatedSym;
        public @Nullable String product;
        public final @Nullable String quoteType;
        public final @Nullable String account;
        public final @Nullable String noLegs;
        public final @Nullable String legSymbol;
        public final @Nullable String legSymbolSfx;
        public final @Nullable String legSecId;
        public final @Nullable String legSecIdSrc;
        public final @Nullable String legSecType;
        public final @Nullable String legMaturityDate;
        public final @Nullable String legQty;
        public final @Nullable String legSettlDate;
        public @Nullable String priceType;
        public @Nullable String securityType;
        public @Nullable String venueType;
        public @Nullable Allocation[] allocations;
        public @Nullable InstrumentParty[] instrumentParties;
        public @Nullable Party[] parties;

        //RFQ trading - FX
        public String clOrdId;
        public String side;
        public String currency;
        public String fixingDate;
        public String fixingDate2;
        public String inCompetition;
        public String numOfCompetitors;
        
        public RFQLeg[] rfqLegs;
        
        
        
        //Swap
        public @Nullable String valueDate2;
        public @Nullable String amount2;
        
        //ESP
        public @Nullable String streamRef;

        public Subscription(final String requestId, final String symbol, final String valueDate, final String amount) {
            this(requestId, symbol, valueDate, amount, null, null);
        }

        public Subscription(final String requestId, final String symbol, final String valueDate, final String amount, final String symbolSfx, final String securityID) {
            this(requestId, symbol, valueDate, amount, symbolSfx, securityID, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        }

        public Subscription(final String requestId, final String symbol, final String valueDate, final String amount, final String symbolSfx, final String securityID,
                String noRelatedSym, String product, String quoteType, String account, String noLegs, String legSymbol,
                String legSymbolSfx, String legSecId, String legSecIdSrc, String legSecType, String legMaturityDate,
                String legQty, String legSettlDate, String priceType)
        {
            this.requestId = requestId;
            this.symbol = symbol;
            this.valueDate = valueDate;
            this.amount = amount;
            this.symbolSfx = symbolSfx;
            this.securityID = securityID;
            this.noRelatedSym = noRelatedSym;
            this.product = product;
            this.quoteType = quoteType;
            this.account = account;
            this.noLegs = noLegs;
            this.legSymbol = legSymbol;
            this.legSymbolSfx = legSymbolSfx;
            this.legSecId = legSecId;
            this.legSecIdSrc = legSecIdSrc;
            this.legSecType = legSecType;
            this.legMaturityDate = legMaturityDate;
            this.legQty = legQty;
            this.legSettlDate = legSettlDate;
            this.priceType = priceType;
        }

        public Subscription(final String requestId, final String symbol, final String valueDate, final String amount, final String symbolSfx, final String securityID,
                String noRelatedSym, String product, String quoteType, String account, String noLegs, String legSymbol,
                String legSymbolSfx, String legSecId, String legSecIdSrc, String legSecType, String legMaturityDate,
                String legQty, String legSettlDate, String priceType, String fixingDate)
        {
            this.requestId = requestId;
            this.symbol = symbol;
            this.valueDate = valueDate;
            this.amount = amount;
            this.symbolSfx = symbolSfx;
            this.securityID = securityID;
            this.noRelatedSym = noRelatedSym;
            this.product = product;
            this.quoteType = quoteType;
            this.account = account;
            this.noLegs = noLegs;
            this.legSymbol = legSymbol;
            this.legSymbolSfx = legSymbolSfx;
            this.legSecId = legSecId;
            this.legSecIdSrc = legSecIdSrc;
            this.legSecType = legSecType;
            this.legMaturityDate = legMaturityDate;
            this.legQty = legQty;
            this.legSettlDate = legSettlDate;
            this.priceType = priceType;
            this.fixingDate = fixingDate;
        }

        @Override
        public String toString() {
            String str = "requestId=" + requestId + " symbol=" + symbol + " valueDate=" + valueDate;
            if (amount != null) {
                str = str +  " amount=" + amount;
            }
            if (symbolSfx != null) {
                str = str +  " symbolSfx=" + symbolSfx;
            }
            if (securityID != null) {
                str = str +  " securityID=" + securityID;
            }
            return str;
        }
    }

    @Override
    public void refresh() throws Exception {
        subscriptions.clear();
        topOfBookPrices.clear();
        orderQueue.clear();
        orderMultiLegQueue.clear();
        ackQueue.clear();
        rejectQueue.clear();
        pingQueue.clear();
        qrQueue.clear();
    }

    @Override
    public void onFixMessage(Message message) throws Exception {
        String type = message.getStringFieldValue(Constants.TAGMsgType);
        if (type.equals(Constants.MSGQuoteRequest)) {
            qrQueue.add(message);
                handleQuoteRequest(message);
        }
        else if (type.equals(Constants.MSGOrderSingle)) {
            handleOrderSingle(message);
        }
        else if (type.equals(Constants.MSGNewOrderMultileg)) {
            handleOrderMultiLeg(message);
        }
        else if (type.equals(MSGCancelAllQuotes)) {
        }
        else if (type.equals(MSGApplicationPing)) {
            handleApplicationPing(message);
        }
        else if (type.equals(MSGApplicationPingReply)) {
            handleApplicationPingReply(message);
        }
        else if (type.equals(MSGBusinessMessageReject)){
            handleBusinessReject(message);
        }
        else if (type.equals(Constants.MSGReject)){
            handleBusinessReject(message);
        }
        else if (type.equals(MSGOrderTimeout))
        {
            handleOrderTimeout(message);
        }
        else if(type.equals(Constants.MSGDontKnowTrade))
        {
            handleDontKnowTrade(message);
        }
        else if(type.equals(Constants.MSGQuoteResponse))
        {
            handleQuoteResponse(message);
        }
        else if(type.equals(Constants.MSGExecutionReport))
        {
            handleExecutionReport(message);
        }
        else if(type.equals(Constants.MSGExecutionAcknowledgement))
        {
            handleExecutionAcknowledgement(message);
        }
        else {
            System.err.println("unhandle FIX message from SERVER");
        }
    }

    public void initialize() throws Exception{
        Message msg = new Message(MSGInitialize, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void initialize(String myDate) throws Exception
    {
        Message msg = new Message(MSGInitialize, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(myDate!=null) {
            msg.setField(Constants.TAGTransactTime, myDate);
        }
        sendFixMessage(msg);
    }

    public void badInitialize() throws Exception
    {
        Message msg = new Message(MSGInitialize, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }
    
    private void checkActiveSubscriptions(int waitSeconds) throws Exception {
        int retry = 0;
        if(waitSeconds<=0) {
            waitSeconds=10;
        }
        while(this.getActiveSubscriptionsSnapshot().isEmpty() && retry < (waitSeconds*2)){
            Thread.sleep(500);
            retry ++;
        }
    }
    
    public void checkActiveSubscriptions() throws Exception {
        checkActiveSubscriptions(8);
    }
    
    public void initialize(int waitSeconds) throws Exception{
        initialize();
        checkActiveSubscriptions(waitSeconds);
    }
    
    public Subscription getSubscription(String symbol, String symbolSfx) throws Exception {
        
        Map<String, MakerTestSession.Subscription> allSubs = this
                .getActiveSubscriptionsSnapshot();
        assertFalse("quote request list is empty", allSubs.isEmpty());
        
        Subscription sub = null;

        for (Entry<String, Subscription> subEntry : allSubs.entrySet()) {
            sub = subEntry.getValue();
            if (sub.symbol.equals(symbol) && 
                    ( symbolSfx==null ||
                      (sub.symbolSfx == null || sub.symbolSfx.equals(symbolSfx))
                    )){
                return sub;
            }
        }
        return null;
    }
    
    public Subscription getSubscriptionWithVenueType(String symbol, String symbolSfx, String venueType) throws Exception {
        if (venueType==null){
            return getSubscription(symbol, symbolSfx);
        }

        Map<String, MakerTestSession.Subscription> allSubs = this
                .getActiveSubscriptionsSnapshot();
        assertFalse("quote request list is empty", allSubs.isEmpty());
        
        Subscription sub;

        for (Entry<String, Subscription> subEntry : allSubs.entrySet()) {
            sub = subEntry.getValue();
            if (sub.symbol.equals(symbol) && 
                    ( (symbolSfx==null&&sub.symbolSfx==null) ||
                      (symbolSfx != null && symbolSfx.equals(sub.symbolSfx))
                    )  &&
                    ((venueType == null && sub.venueType == null) ||
                            ((venueType != null && sub.venueType != null) && venueType.equals(sub.venueType)))){
                return sub;
            }
        }
        return null;
    }
    
    
    public Subscription getSubscription(String symbol, String symbolSfx, String streamRef) throws Exception {
        
        Map<String, MakerTestSession.Subscription> allSubs = this
                .getActiveSubscriptionsSnapshot();
        assertFalse("quote request list is empty", allSubs.isEmpty());
        
        Subscription sub = null;

        for (Entry<String, Subscription> subEntry : allSubs.entrySet()) {
            sub = subEntry.getValue();            
            if (sub.symbol.equals(symbol) 
                    && (sub.symbolSfx == null || sub.symbolSfx.equals(symbolSfx))
                    && (streamRef==null || streamRef.equals(sub.streamRef))) {
                return sub;
            }
        }
        return null;
    }
    
    public Subscription getSubscription(String symbol) throws Exception {

        return this.getSubscription(symbol, null);
    }
    
    public Subscription getSubscriptionRfqMultiLeg(String symbol) throws Exception {
        
        Map<String, MakerTestSession.Subscription> allSubs = this
                .getActiveSubscriptionsSnapshot();
        assertFalse("quote request list is empty", allSubs.isEmpty());
        
        Subscription sub = null;

        for (Entry<String, Subscription> subEntry : allSubs.entrySet()) {
            sub = subEntry.getValue();
            if (sub.symbol.equals(symbol) && sub.rfqLegs!=null){
                return sub;
            }
        }
        return null;
    }

    public Message getOrder(long timeout) throws Exception {
        Message msg = orderQueue.poll(timeout, TimeUnit.MILLISECONDS);
        return msg;
    }
    
    public Message getOrderMultiLeg(long timeout) throws Exception {
        Message msg = orderMultiLegQueue.poll(timeout, TimeUnit.MILLISECONDS);
        return msg;
    }
    
    public Message getAck(long timeout) throws Exception {
        Message msg = ackQueue.poll(timeout, TimeUnit.MILLISECONDS);
        return msg;
    }

    public Message getQuoteRequestMessage(long timeout) throws Exception {
        return qrQueue.poll(timeout, TimeUnit.MILLISECONDS);
    }

    public void submitMassQuote(int numQuoteSets, String[] quoteSetId, int[] numQuoteEntries, String[][] quoteEntryId, String[][] symbol,
            String[][] symSfx, String[][] product, String[][] bidSize, String[][] offerSize, String[][] validUntilTime, String[][] bidSpRate, String[][] offerSpRate,
            String[][] bidFwdPts, String[][] offerFwdPts, String[][] settlDate, String[][] settlDate2, String[][] bidFwdPts2, String[][] offerFwdPts2) throws Exception
    {
        Message msg = new Message(FixMsgConstants.MSGMassQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteID, "NA");
        msg.setField(Constants.TAGNoQuoteSets, numQuoteSets);
        for(int i=0; i<numQuoteSets; i++)
        {
            msg.addField(Constants.TAGQuoteSetID, quoteSetId[i]);
            msg.addField(Constants.TAGTotNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            msg.addField(Constants.TAGNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            for(int ii=0; ii<numQuoteEntries[i]; ii++)
            {
                msg.addField(Constants.TAGQuoteEntryID, quoteEntryId[i][ii]);
                msg.addField(Constants.TAGSymbol, symbol[i][ii]);
                msg.addField(Constants.TAGSymbolSfx, symSfx[i][ii]);
                msg.addField(Constants.TAGProduct, product[i][ii]);
                if(bidSize != null && bidSize[i][ii] != null) {
                    msg.addField(Constants.TAGBidSize, bidSize[i][ii]);
                }
                if(offerSize != null && offerSize[i][ii] != null) {
                    msg.addField(Constants.TAGOfferSize, offerSize[i][ii]);
                }
                if(validUntilTime != null && validUntilTime[i][ii] != null) {
                    msg.addField(Constants.TAGValidUntilTime, validUntilTime[i][ii]);
                }
                if(bidSpRate != null && bidSpRate[i][ii] != null) {
                    msg.addField(Constants.TAGBidSpotRate, bidSpRate[i][ii]);
                }
                if(offerSpRate != null && offerSpRate[i][ii] != null) {
                    msg.addField(Constants.TAGOfferSpotRate, offerSpRate[i][ii]);
                }
                if(bidFwdPts != null && bidFwdPts[i][ii] != null) {
                    msg.addField(Constants.TAGBidForwardPoints, bidFwdPts[i][ii]);
                }
                if(offerFwdPts != null && offerFwdPts[i][ii] != null) {
                    msg.addField(Constants.TAGOfferForwardPoints, offerFwdPts[i][ii]);
                }
                if(settlDate != null && settlDate[i][ii] != null) {
                    msg.addField(Constants.TAGSettlDate, settlDate[i][ii]);
                }
                if(settlDate2 != null && settlDate2[i][ii] != null) {
                    msg.addField(Constants.TAGSettlDate2, settlDate2[i][ii]);
                }
                if(bidFwdPts2 != null && bidFwdPts2[i][ii] != null) {
                    msg.addField(Constants.TAGBidForwardPoints2, bidFwdPts2[i][ii]);
                }
                if(offerFwdPts2 != null && offerFwdPts2[i][ii] != null) {
                    msg.addField(Constants.TAGOfferForwardPoints2, offerFwdPts2[i][ii]);
                }
            }
        }
        sendFixMessage(msg);
    }

    public void submitMassQuote(int numQuoteSets, String[] quoteSetId, int[] numQuoteEntries, String[] quoteEntryId, String[] symbol,
            String[] symSfx, String[] product, String[] bidSize, String[] offerSize, String[] validUntilTime, String[] bidSpRate, String[] offerSpRate,
            String[] bidFwdPts, String[] offerFwdPts, String[] settlDate, String[] settlDate2, String[] bidFwdPts2, String[] offerFwdPts2
            ) throws Exception{
        submitMassQuote(numQuoteSets, quoteSetId, numQuoteEntries, quoteEntryId, symbol,
                symSfx, product, bidSize, offerSize, validUntilTime, bidSpRate, offerSpRate,
                bidFwdPts, offerFwdPts, settlDate, settlDate2, bidFwdPts2, offerFwdPts2,
                null);
    }


    public void submitMassQuote(int numQuoteSets, String[] quoteSetId, int[] numQuoteEntries, String[] quoteEntryId, String[] symbol,
            String[] symSfx, String[] product, String[] bidSize, String[] offerSize, String[] validUntilTime, String[] bidSpRate, String[] offerSpRate,
            String[] bidFwdPts, String[] offerFwdPts, String[] settlDate, String[] settlDate2, String[] bidFwdPts2, String[] offerFwdPts2,
            String[] venueType) throws Exception
    {
        Message msg = new Message(FixMsgConstants.MSGMassQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteID, "NA");
        msg.setField(Constants.TAGNoQuoteSets, numQuoteSets);
        for(int i=0; i<numQuoteSets; i++)
        {
            msg.addField(Constants.TAGQuoteSetID, quoteSetId[i]);
            msg.addField(Constants.TAGTotNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            msg.addField(Constants.TAGNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            msg.addField(Constants.TAGQuoteEntryID, quoteEntryId[i]);
            msg.addField(Constants.TAGSymbol, symbol[i]);
            msg.addField(Constants.TAGSymbolSfx, symSfx[i]);
            msg.addField(Constants.TAGProduct, product[i]);
            if(bidSize != null && bidSize[i] != null) {
                msg.addField(Constants.TAGBidSize, bidSize[i]);
            }
            if(offerSize != null && offerSize[i] != null) {
                msg.addField(Constants.TAGOfferSize, offerSize[i]);
            }
            if(validUntilTime != null && validUntilTime[i] != null) {
                msg.addField(Constants.TAGValidUntilTime, validUntilTime[i]);
            }
            if(bidSpRate != null && bidSpRate[i] != null) {
                msg.addField(Constants.TAGBidSpotRate, bidSpRate[i]);
            }
            if(offerSpRate != null && offerSpRate[i] != null) {
                msg.addField(Constants.TAGOfferSpotRate, offerSpRate[i]);
            }
            if(bidFwdPts != null && bidFwdPts[i] != null) {
                msg.addField(Constants.TAGBidForwardPoints, bidFwdPts[i]);
            }
            if(offerFwdPts != null && offerFwdPts[i] != null) {
                msg.addField(Constants.TAGOfferForwardPoints, offerFwdPts[i]);
            }
            if(settlDate != null && settlDate[i] != null) {
                msg.addField(Constants.TAGSettlDate, settlDate[i]);
            }
            if(settlDate2 != null && settlDate2[i] != null) {
                msg.addField(Constants.TAGSettlDate2, settlDate2[i]);
            }
            if(bidFwdPts2 != null && bidFwdPts2[i] != null) {
                msg.addField(Constants.TAGBidForwardPoints2, bidFwdPts2[i]);
            }
            if(offerFwdPts2 != null && offerFwdPts2[i] != null) {
                msg.addField(Constants.TAGOfferForwardPoints2, offerFwdPts2[i]);
            }
            if(venueType != null && venueType[i] != null) {
                msg.addField(Constants.TAGVenueType, venueType[i]);
        }
        }
        sendFixMessage(msg);
    }


    
    public void submitMassQuoteFwdSwap(int numQuoteSets, String[] quoteSetId, String[] quoteEntryId, String[] symbol,
            String[] symSfx, String[] securityType, String[] bidSize, String[] offerSize, String[] validUntilTime, String[] bidSpRate, String[] offerSpRate,
            String[] bidFwdPts, String[] offerFwdPts, String[] settlDate, String[] settlDate2, String[] bidFwdPts2, String[] offerFwdPts2,
            String[] fixingDate, String[] fixingDate2) throws Exception
    {
        Message msg = new Message(FixMsgConstants.MSGMassQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteID, "NA");
        msg.setField(Constants.TAGNoQuoteSets, numQuoteSets);
        for(int i=0; i<numQuoteSets; i++)
        {
            msg.addField(Constants.TAGQuoteSetID, quoteSetId[i]);
            msg.addField(Constants.TAGTotNoQuoteEntries, "1");
            msg.addField(Constants.TAGNoQuoteEntries, "1");
            msg.addField(Constants.TAGQuoteEntryID, quoteEntryId[i]);
            msg.addField(Constants.TAGSymbol, symbol[i]);
            msg.addField(Constants.TAGSymbolSfx, symSfx[i]);
            msg.addField(Constants.TAGProduct, Constants.PRODUCT_Currency);
            
            if(securityType != null && securityType[i] != null) {
                msg.addField(Constants.TAGSecurityType, securityType[i]);
            }
            if(bidSize != null && bidSize[i] != null) {
                msg.addField(Constants.TAGBidSize, bidSize[i]);
            }
            if(offerSize != null && offerSize[i] != null) {
                msg.addField(Constants.TAGOfferSize, offerSize[i]);
            }
            if(validUntilTime != null && validUntilTime[i] != null) {
                msg.addField(Constants.TAGValidUntilTime, validUntilTime[i]);
            }
            if(bidSpRate != null && bidSpRate[i] != null) {
                msg.addField(Constants.TAGBidSpotRate, bidSpRate[i]);
            }
            if(offerSpRate != null && offerSpRate[i] != null) {
                msg.addField(Constants.TAGOfferSpotRate, offerSpRate[i]);
            }
            if(bidFwdPts != null && bidFwdPts[i] != null) {
                msg.addField(Constants.TAGBidForwardPoints, bidFwdPts[i]);
            }
            if(offerFwdPts != null && offerFwdPts[i] != null) {
                msg.addField(Constants.TAGOfferForwardPoints, offerFwdPts[i]);
            }
            if(settlDate != null && settlDate[i] != null) {
                msg.addField(Constants.TAGSettlDate, settlDate[i]);
            }
            if(settlDate2 != null && settlDate2[i] != null) {
                msg.addField(Constants.TAGSettlDate2, settlDate2[i]);
            }
            if(bidFwdPts2 != null && bidFwdPts2[i] != null) {
                msg.addField(Constants.TAGBidForwardPoints2, bidFwdPts2[i]);
            }
            if(offerFwdPts2 != null && offerFwdPts2[i] != null) {
                msg.addField(Constants.TAGOfferForwardPoints2, offerFwdPts2[i]);
            }
            if(fixingDate != null && fixingDate[i] != null) {
                msg.addField(Constants.TAGFixingDate, fixingDate[i]);
            }
            if(fixingDate2 != null && fixingDate2[i] != null) {
                msg.addField(Constants.TAGFixingDate2, fixingDate2[i]);
            }
        }
        sendFixMessage(msg);
    }

    public void submitMassQuoteNDF(int numQuoteSets, String[] quoteSetId, int[] numQuoteEntries, String[][] quoteEntryId, String[][] symbol,
            String[][] symSfx, String[][] product, String[][] securityType, String[][] bidSize, String[][] offerSize, String[][] validUntilTime,
            String[][] bidSpRate, String[][] offerSpRate, String[][] settlDate, String[][] fixingDate) throws Exception
    {
        Message msg = new Message(FixMsgConstants.MSGMassQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteID, "NA");
        msg.setField(Constants.TAGNoQuoteSets, numQuoteSets);
        for(int i=0; i<numQuoteSets; i++)
        {
            msg.addField(Constants.TAGQuoteSetID, quoteSetId[i]);
            msg.addField(Constants.TAGTotNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            msg.addField(Constants.TAGNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            for(int ii=0; ii<numQuoteEntries[i]; ii++)
            {
                msg.addField(Constants.TAGQuoteEntryID, quoteEntryId[i][ii]);
                msg.addField(Constants.TAGSymbol, symbol[i][ii]);
                msg.addField(Constants.TAGSymbolSfx, symSfx[i][ii]);
                msg.addField(Constants.TAGProduct, product[i][ii]);
                msg.addField(Constants.TAGSecurityType, securityType[i][ii]);
                if(bidSize != null && bidSize[i][ii] != null) {
                    msg.addField(Constants.TAGBidSize, bidSize[i][ii]);
                }
                if(offerSize != null && offerSize[i][ii] != null) {
                    msg.addField(Constants.TAGOfferSize, offerSize[i][ii]);
                }
                if(validUntilTime != null && validUntilTime[i][ii] != null) {
                    msg.addField(Constants.TAGValidUntilTime, validUntilTime[i][ii]);
                }
                if(bidSpRate != null && bidSpRate[i][ii] != null) {
                    msg.addField(Constants.TAGBidSpotRate, bidSpRate[i][ii]);
                }
                if(offerSpRate != null && offerSpRate[i][ii] != null) {
                    msg.addField(Constants.TAGOfferSpotRate, offerSpRate[i][ii]);
                }
                if(settlDate != null && settlDate[i][ii] != null) {
                    msg.addField(Constants.TAGSettlDate, settlDate[i][ii]);
                }
                if(fixingDate != null && fixingDate[i][ii] != null) {
                    msg.addField(Constants.TAGFixingDate, fixingDate[i][ii]);
                }
            }
        }
        sendFixMessage(msg);
    }

    public void submitTreasuryMassQuote(String quoteType, int numQuoteSets, String[] quoteSetId, int[] numQuoteEntries, String[][] quoteEntryId, String[][] symbol,
            String[][] symSfx, String[][] secId, String[][] secIdSrc, String[][] product, String[][] bidSize, String[][] offerSize, String[][] bidPx, String[][] offerPx, String[][] validUntilTime) throws Exception
    {
        Message msg = new Message(FixMsgConstants.MSGMassQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteID, "NA");
        if(quoteType != null) {
            msg.setField(Constants.TAGQuoteType, quoteType);
        }
        msg.setField(Constants.TAGNoQuoteSets, numQuoteSets);
        for(int i=0; i<numQuoteSets; i++)
        {
            msg.addField(Constants.TAGQuoteSetID, quoteSetId[i]);
            msg.addField(Constants.TAGTotNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            msg.addField(Constants.TAGNoQuoteEntries, Integer.toString(numQuoteEntries[i]));
            for(int ii=0; ii<numQuoteEntries[i]; ii++)
            {
                msg.addField(Constants.TAGQuoteEntryID, quoteEntryId[i][ii]);
                msg.addField(Constants.TAGSymbol, symbol[i][ii]);
                msg.addField(Constants.TAGSymbolSfx, symSfx[i][ii]);
                msg.addField(Constants.TAGSecurityID, secId[i][ii]);
                msg.addField(Constants.TAGSecurityIDSource, secIdSrc[i][ii]);
                msg.addField(Constants.TAGProduct, product[i][ii]);
                if(bidSize != null && bidSize[i][ii] != null) {
                    msg.addField(Constants.TAGBidSize, bidSize[i][ii]);
                }
                if(offerSize != null && offerSize[i][ii] != null) {
                    msg.addField(Constants.TAGOfferSize, offerSize[i][ii]);
                }
                if(bidPx != null && bidPx[i][ii] != null) {
                    msg.addField(Constants.TAGBidPx, bidPx[i][ii]);
                }
                if(offerPx != null && offerPx[i][ii] != null) {
                    msg.addField(Constants.TAGOfferPx, offerPx[i][ii]);
                }
                if(validUntilTime != null && validUntilTime[i][ii] != null) {
                    msg.addField(Constants.TAGValidUntilTime, validUntilTime[i][ii]);
                }
            }
        }
        sendFixMessage(msg);
    }

    public void submitQuote(Quote quote) throws Exception{
        String requestId = quote.requestId;
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quote.quoteId);
        msg.setField(Constants.TAGSymbol, quote.symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, quote.symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        if(quote.securityType!=null) {
            msg.setField(Constants.TAGSecurityType, quote.securityType);
        }
        msg.setField(Constants.TAGFutSettDate, quote.valueDate);
        if(quote.bidPrice!=null)
        {
            msg.setField(Constants.TAGBidPx, quote.bidPrice);
        }
        if(quote.offerPrice!=null)
        {
            msg.setField(Constants.TAGOfferPx, quote.offerPrice);
        }
        if(quote.bidAmount!=null)
        {
            msg.setField(Constants.TAGBidSize, quote.bidAmount);
        }
        if(quote.offerAmount!=null)
        {
            msg.setField(Constants.TAGOfferSize, quote.offerAmount);
        }
        if(quote.validUntilTime!=null)
        {
            msg.setField(Constants.TAGValidUntilTime, quote.validUntilTime);
        }
        if(quote.bidPrice!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, quote.bidPrice);
        }
        if(quote.offerPrice!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, quote.offerPrice);
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, quote.fixingDate);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuote(String symbol, String bidPx, String offerPx, String bidAmt, String offerAmt, String bidSpotRate, String offerSpotRate) throws Exception{
        
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        Subscription sub = getSubscription(symbol, Constants.SYMBOLSFX_Spot);
        String requestId = sub.requestId;
        
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, "quote-"+System.currentTimeMillis());
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, sub.symbolSfx);
            msg.setField(Constants.TAGProduct, sub.product);
        }
        msg.setField(Constants.TAGSecurityType, sub.securityType);
        msg.setField(Constants.TAGFutSettDate, sub.valueDate);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGBidSize, bidAmt);
        msg.setField(Constants.TAGOfferSize, offerAmt);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, sub.fixingDate);
        }
        sendFixMessage(msg);
    }
    
    public Quote submitQuoteEsp(String amount, String symbol, String bixPx, String offerPx) throws Exception {

        Subscription sub = getSubscription(symbol, Constants.SYMBOLSFX_Spot);
        assertNotNull("Maker didnt get QuoteRequest for "+symbol+"-SP", sub);
        
        String bidAmount = (bixPx==null)?null:amount; 
        String offerAmount = (offerPx==null)?null:amount; 

        Quote quote = new Quote(sub.requestId, "testQuote"+System.nanoTime(),
                sub.symbol, bixPx, offerPx, bidAmount, offerAmount, sub.valueDate);
        submitQuote(quote);
        
        return quote;
    }
    
    public void submitQuoteEspNDF(String amount, String symbol, String symbolSfx, String bixPx, String offerPx) throws Exception {

        Subscription sub = getSubscription(symbol, symbolSfx);
        assertNotNull(this.getUserName()+" didnt get QuoteRequest for "+symbol+"-"+symbolSfx, sub);
        
        Quote quote = new Quote(sub.requestId, "testQuote"+System.currentTimeMillis(), sub.symbol, symbolSfx, 
                bixPx, offerPx, amount, amount, sub.valueDate, sub.securityType, null, sub.fixingDate);

        submitQuoteEspFwdPoints(quote, "0.0000", "0.0000");
    }
    
    //set venueType to "M" as MTF quote or null for CX quote.
    public void submitSingleQuoteEsp(String amount, String symbol, String symbolSfx,
            String bidAllin, String offerAllin,
            String bidSpotRate, String offerSpotRate,
            String bidPointNearLeg, String offerPointNearLeg,
            String venueType) throws Exception {
        Subscription sub = getSubscriptionWithVenueType(symbol, symbolSfx, venueType);
        assertNotNull("sub ("+symbol+","+symbolSfx+","+venueType+") is null", sub);
        Quote quote = new Quote(sub.requestId, "testQuote"+System.currentTimeMillis(), sub.symbol, symbolSfx,
                bidAllin, offerAllin, amount, amount, sub.valueDate, sub.securityType, null, sub.fixingDate);
        submitEspQuote(quote, bidSpotRate, offerSpotRate,
                bidPointNearLeg, offerPointNearLeg,
                null/*bidPointFarLeg*/, null/*offerPointFarLeg*/, venueType);
    }

    public void submitSingleQuoteEspWithMtfVenueToCxInstr(String amount, String symbol, String symbolSfx,
            String bidAllin, String offerAllin,
            String bidSpotRate, String offerSpotRate,
            String bidPointNearLeg, String offerPointNearLeg) throws Exception {

        Subscription sub = getSubscription(symbol, symbolSfx);

        assertNotNull("sub (" + symbol + "," + symbolSfx + ") is null", sub);

        Quote quote = new Quote(sub.requestId, "testQuote"+System.currentTimeMillis(), sub.symbol/*"GBP/JPY"*/, symbolSfx,
                bidAllin, offerAllin, amount, amount, sub.valueDate, sub.securityType, null, sub.fixingDate);

        submitEspQuote(quote, bidSpotRate, offerSpotRate,
                bidPointNearLeg, offerPointNearLeg,
                null/*bidPointFarLeg*/, null/*offerPointFarLeg*/, "M");
    }

    public void submitSingleQuoteEspWithCxVenueToMtfInstr(String amount, String symbol, String symbolSfx,
            String bidAllin, String offerAllin,
            String bidSpotRate, String offerSpotRate,
            String bidPointNearLeg, String offerPointNearLeg) throws Exception {

        Subscription sub = getSubscriptionWithVenueType(symbol, symbolSfx, "M");
        assertNotNull("sub ("+symbol+","+symbolSfx+","+"M"+") is null", sub);
        Quote quote = new Quote(sub.requestId, "testQuote"+System.currentTimeMillis(), sub.symbol/*"GBP/JPY"*/, symbolSfx,
                bidAllin, offerAllin, amount, amount, sub.valueDate, sub.securityType, null, sub.fixingDate);

        submitEspQuote(quote, bidSpotRate, offerSpotRate,
                bidPointNearLeg, offerPointNearLeg,
                null/*bidPointFarLeg*/, null/*offerPointFarLeg*/, null);
    }

    public void submitEspQuote(Quote quote,
            String bidSpotRate, String offerSpotRate,
            String bidPointNearLeg, String offerPointNearLeg,
            String bidPointFarLeg, String offerPointFarLeg, String venueType) throws Exception{
        String requestId = quote.requestId;
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quote.quoteId);
        msg.setField(Constants.TAGSymbol, quote.symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, quote.symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, quote.securityType);
        msg.setField(Constants.TAGFutSettDate, quote.valueDate);
        msg.setField(Constants.TAGBidPx, quote.bidPrice);
        msg.setField(Constants.TAGOfferPx, quote.offerPrice);
        msg.setField(Constants.TAGBidSize, quote.bidAmount);
        msg.setField(Constants.TAGOfferSize, quote.offerAmount);
        msg.setField(Constants.TAGValidUntilTime, quote.validUntilTime);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGBidForwardPoints, bidPointNearLeg);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGOfferForwardPoints, offerPointNearLeg);
        msg.setField(Constants.TAGBidForwardPoints2, bidPointFarLeg);
        msg.setField(Constants.TAGOfferForwardPoints2, offerPointFarLeg);

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, quote.fixingDate);
        }
        msg.setField(Constants.TAGVenueType, venueType);
        sendFixMessage(msg);
        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuoteEsp(Subscription sub, String amount, String bixPx, String offerPx) throws Exception {

        Quote quote = new Quote(sub.requestId, "makerTestQuote"+System.currentTimeMillis(), 
                sub.symbol, bixPx, offerPx, amount, amount, sub.valueDate);
        submitQuote(quote);
    }
    
    public void submitQuoteEris(Subscription sub, String amount, String bixPx, String offerPx) throws Exception {
        
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, sub.requestId);
        msg.setField(Constants.TAGQuoteID, "testErisQuote-"+System.currentTimeMillis());
        msg.setField(Constants.TAGQuoteType, "0");
        msg.setField(Constants.TAGSymbol, sub.symbol);
        msg.setField(Constants.TAGSymbolSfx, sub.symbolSfx);
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGSecurityType, sub.securityType);
        msg.setField(Constants.TAGBidPx, bixPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGBidSize, amount);
        msg.setField(Constants.TAGOfferSize, amount);
        msg.setField(Constants.TAGValidUntilTime, null);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }
    
    public void submitQuoteEspFwdPoints(Quote quote, String bidFwdPoints, String offerFwdPoints) throws Exception{
        String requestId = quote.requestId;
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quote.quoteId);
        msg.setField(Constants.TAGSymbol, quote.symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, quote.symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, quote.securityType);
        msg.setField(Constants.TAGFutSettDate, quote.valueDate);
        //msg.setField(Constants.TAGBidPx, quote.bidPrice);
        //msg.setField(Constants.TAGOfferPx, quote.offerPrice);
        msg.setField(Constants.TAGBidSize, quote.bidAmount);
        msg.setField(Constants.TAGOfferSize, quote.offerAmount);
        msg.setField(Constants.TAGValidUntilTime, quote.validUntilTime);
        msg.setField(Constants.TAGBidSpotRate, quote.bidPrice);
        msg.setField(Constants.TAGBidForwardPoints, bidFwdPoints);
        msg.setField(Constants.TAGOfferSpotRate, quote.offerPrice);
        msg.setField(Constants.TAGOfferForwardPoints, offerFwdPoints);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, quote.fixingDate);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuoteEspFwdWithPoints(Subscription sub, String bidSpotRate, String bidFwdPoints, 
            String offerSpotRate, String offerFwdPoints, String amount) throws Exception{
        
        Quote quote = new Quote(sub.requestId, "makerTestQuote"
                + System.currentTimeMillis(), sub.symbol, sub.symbolSfx, bidSpotRate, offerSpotRate,
                amount, amount, sub.valueDate, "FOR", null, null);
        
        //String requestId = quote.requestId;
        String requestId = sub.requestId;
        
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quote.quoteId);
        msg.setField(Constants.TAGSymbol, quote.symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, quote.symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, quote.securityType);
        msg.setField(Constants.TAGFutSettDate, quote.valueDate);
        //msg.setField(Constants.TAGBidPx, quote.bidPrice);
        //msg.setField(Constants.TAGOfferPx, quote.offerPrice);
        msg.setField(Constants.TAGBidSize, quote.bidAmount);
        msg.setField(Constants.TAGOfferSize, quote.offerAmount);
        msg.setField(Constants.TAGValidUntilTime, quote.validUntilTime);
        msg.setField(Constants.TAGBidSpotRate, quote.bidPrice);
        msg.setField(Constants.TAGBidForwardPoints, bidFwdPoints);
        msg.setField(Constants.TAGOfferSpotRate, quote.offerPrice);
        msg.setField(Constants.TAGOfferForwardPoints, offerFwdPoints);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, quote.fixingDate);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuoteEspFwdAllinRate(Quote quote) throws Exception{
        String requestId = quote.requestId;
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quote.quoteId);
        msg.setField(Constants.TAGSymbol, quote.symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, quote.symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, quote.securityType);
        msg.setField(Constants.TAGFutSettDate, quote.valueDate);
        msg.setField(Constants.TAGBidPx, quote.bidPrice);
        msg.setField(Constants.TAGOfferPx, quote.offerPrice);
        msg.setField(Constants.TAGBidSpotRate, quote.bidPrice);
        msg.setField(Constants.TAGOfferSpotRate, quote.offerPrice);
        msg.setField(Constants.TAGBidSize, quote.bidAmount);
        msg.setField(Constants.TAGOfferSize, quote.offerAmount);
        msg.setField(Constants.TAGValidUntilTime, quote.validUntilTime);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGFixingDate, quote.fixingDate);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitQuotesIrsRFQ(String quoteReqId, String quoteId, String account, String bidPx,
            String offerPx, String priceType) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGPriceType, priceType);
        sendFixMessage(msg);
        Quote quote = new Quote(quoteReqId, quoteId, null, bidPx,
                offerPx, null, null, null, "IRS", null);
        getTopOfBookPrices().put(quoteReqId, quote);
    }

    public void submitQuotesLDRFQ(String requestId,
            String quoteId, String symbol, String product, String bidPx) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(bidPx!=null) {
            msg.setField(Constants.TAGBidPx, bidPx);
        }
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, symbol, bidPx,
                null, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }


    public void submitQuotesRFQ(String requestId,
            String quoteId, String symbol, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGBidForwardPoints, "0.0000");
        msg.setField(Constants.TAGOfferForwardPoints, "0.0000");
        
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }


    public void submitQuotesRFQFwd(String requestId,
            String quoteId, String symbol, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
            
        if(bidSpotRate!=null){
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, "0.04");
        }
        
        msg.setField(Constants.TAGOfferPx, offerPx);
        
        if(offerSpotRate!=null){
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, "-0.07");
        }
        
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitQuotesRFQSwap(String requestId,
            String quoteId, String symbol, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
            
        if(bidSpotRate!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, "0.04");
            msg.setField(Constants.TAGBidForwardPoints2, "-0.01");
        }
        
        msg.setField(Constants.TAGOfferPx, offerPx);

        if(offerSpotRate!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, "-0.07");
            msg.setField(Constants.TAGOfferForwardPoints2, "0.02");
        }
        
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitQuotesRFQSwap(String requestId,
            String quoteId, String symbol, String symbolSfx,String product, String securityType, 
            String bidPx, String offerPx, String bidSpotRate,
            String offerSpotRate, String bidForwardPoints, String offerForwardPoints, 
            String midPx, String bidForwardPoints2, String offerForwardPoints2, 
            String midPx2
            ) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGBidPx, bidPx);
        
        if(bidSpotRate!=null){
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, bidForwardPoints);
            msg.setField(Constants.TAGBidForwardPoints2, bidForwardPoints2);
        }
        
        msg.setField(Constants.TAGOfferPx, offerPx);
        
        if(offerSpotRate!=null){
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoints);
            msg.setField(Constants.TAGOfferForwardPoints2, offerForwardPoints2);
        }
        
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGMidPx2, midPx2);
        
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, symbol, bidPx,
                offerPx, null, null, null);

        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuotesRFQSwapMakerOBO(String requestId,
            String quoteId, String symbol, String symbolSfx,String product, String securityType, 
            String bidPx, String offerPx, String bidSpotRate,
            String offerSpotRate, String bidForwardPoints, String offerForwardPoints, 
            String midPx, String bidForwardPoints2, String offerForwardPoints2, 
            String midPx2, String routedUserId
            ) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        if(routedUserId!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedUserId);
            msg.setField(Constants.TAGPartyRole, "3");
        }
        if(bidPx!=null) {
            msg.setField(Constants.TAGBidPx, bidPx);
        }
        if(bidSpotRate!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, bidForwardPoints);
            msg.setField(Constants.TAGBidForwardPoints2, bidForwardPoints2);
        }
        if(offerPx!=null) {
            msg.setField(Constants.TAGOfferPx, offerPx);
        }
        if(offerSpotRate!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoints);
            msg.setField(Constants.TAGOfferForwardPoints2, offerForwardPoints2);
        }
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGMidPx2, midPx2);
        
         sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, symbol, bidPx,
                offerPx, null, null, null);

        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitExecReportRFQSwap(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String product, String securityType, 
            String side, String orderQty, String orderType, String price, String currency, String lastSpotRate, 
            String leavesQty, Date tradeDate, String SettlCurrAmount, String noRegIds, String regTradeId, 
            String regTradeIdSource, String regTradeIdType
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSecurityType, securityType);
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
        }
        if(lastSpotRate!=null) {
            msg.setField(Constants.TAGLastSpotRate, lastSpotRate);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        msg.setField(Constants.TAGRegulatoryTradeIDType, regTradeIdType);
         sendFixMessage(msg);
    }

    public void submitQuotesRFQFwd(String requestId,
            String quoteId, String symbol, String symbolSfx, String product, String securityType, 
            String bidPx, String bidSpotRate, String offerPx, String offerSpotRate, 
            String bidForwardPoints, String offerForwardPoints, String midPx) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        if(bidPx!=null) {
            msg.setField(Constants.TAGBidPx, bidPx);
        }
        if(bidSpotRate!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, bidForwardPoints);
        }
        if(offerPx!=null) {
            msg.setField(Constants.TAGOfferPx, offerPx);
        }
        if(offerSpotRate!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoints);
        }
        msg.setField(Constants.TAGMidPx, midPx);

         sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }
    
    public void submitQuotesRFQFwdMakerOBO(String requestId,
            String quoteId, String symbol, String symbolSfx, String product, String securityType, 
            String bidPx, String bidSpotRate, String offerPx, String offerSpotRate, 
            String bidForwardPoints, String offerForwardPoints, String midPx, String routedUserId) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        if(routedUserId!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedUserId);
            msg.setField(Constants.TAGPartyRole, "3");
        }
        if(bidPx!=null) {
            msg.setField(Constants.TAGBidPx, bidPx);
        }
        if(bidSpotRate!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, bidForwardPoints);
        }
        if(offerPx!=null) {
            msg.setField(Constants.TAGOfferPx, offerPx);
        }
        if(offerSpotRate!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoints);
        }
        msg.setField(Constants.TAGMidPx, midPx);

         sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitExecReportRFQFwd(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String currency,
            Date tradeDate, String lastSpotRate, String noRegIds, String regTradeId, 
            String regTradeIdSource
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
        }
        if(lastSpotRate!=null) {
            msg.setField(Constants.TAGLastSpotRate, lastSpotRate);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
         sendFixMessage(msg);
    }
    
    public void submitQuotesRFQ(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, null, null, null, null, null, null);
    }
    
    public void submitQuotesRFQLD(Subscription sub, String bidPx) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, null, null, null, null, null, null, null, null, null);
    }
    
    public void submitQuotesRFQFwd(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints, String midPx) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints, midPx, null, null, null);
    }
    
    public void submitQuotesRFQSwap(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints, midPx, bidFwdPoints2, offerFwdPoints2, midPx2);
    }
    
    public void submitQuotesRFQSpotMTF(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String quoteId, String venueType) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, null, null, null, null,
                null, null, quoteId, venueType);
    }

    public void submitQuotesRFQSpotMTFObo(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String quoteId, String venueType) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, null, null, null, null,
                null, null, quoteId, venueType);
    }

    public void submitQuotesRFQFwdMTF(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints, null,
                null, null, null, null, Constants.VENUETYPE_MTF);
    }

    public void submitQuotesRFQNdfMTF(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints, null,
                null, null, null, null, Constants.VENUETYPE_MTF, Constants.SECURITYTYPE_ForeignExchangeNDF);
    }

    public void submitQuotesRFQSwapMTF(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate, offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints, midPx,
                bidFwdPoints2, offerFwdPoints2, midPx2, null, Constants.VENUETYPE_MTF);
    }
    
    private void submitQuotesRFQ(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        String quoteId = "testQuote"+System.currentTimeMillis();
        
        msg.setField(Constants.TAGQuoteReqID, sub.requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, sub.symbol);
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGBidForwardPoints, bidFwdPoints);
        msg.setField(Constants.TAGOfferForwardPoints, offerFwdPoints);
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGBidForwardPoints2, bidFwdPoints2);
        msg.setField(Constants.TAGOfferForwardPoints2, offerFwdPoints2);
        msg.setField(Constants.TAGMidPx2, midPx2);
        sendFixMessage(msg);
        
//        Quote quote = new Quote(sub.requestId, quoteId, sub.symbol, sub.symbolSfx, bidPx, offerPx, sub.amount,
//                sub.amount, sub.valueDate, sub.securityType, null, sub.fixingDate);
        
        Quote quote = new Quote(sub, 
                quoteId,
                bidPx,
                offerPx,
                sub.amount,
                sub.amount,
                null,
                bidSpotRate, 
                offerSpotRate,
                bidFwdPoints, 
                offerFwdPoints);
        
        getTopOfBookPrices().put(sub.requestId, quote);
    }

    public void submitQuotesRFQ(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2, String quoteId) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate,
            offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints,
            midPx, bidFwdPoints2, offerFwdPoints2, midPx2, quoteId,
            null);
    }

    public void submitQuotesRFQ(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2, String quoteId,
            String venueType) throws Exception
    {
        submitQuotesRFQ(sub, bidPx, bidSpotRate,
                offerPx, offerSpotRate, bidFwdPoints, offerFwdPoints,
                midPx, bidFwdPoints2, offerFwdPoints2, midPx2, quoteId,
                venueType, null);
    }


    public void submitQuotesRFQ(Subscription sub, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String bidFwdPoints, String offerFwdPoints,
            String midPx, String bidFwdPoints2, String offerFwdPoints2, String midPx2, String quoteId,
            String venueType, String securityType) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if (quoteId==null){
            quoteId = "testQuote"+System.currentTimeMillis();
        }
        msg.setField(Constants.TAGQuoteReqID, sub.requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, sub.symbol);
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGBidForwardPoints, bidFwdPoints);
        msg.setField(Constants.TAGOfferForwardPoints, offerFwdPoints);
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGBidForwardPoints2, bidFwdPoints2);
        msg.setField(Constants.TAGOfferForwardPoints2, offerFwdPoints2);
        msg.setField(Constants.TAGMidPx2, midPx2);
        msg.setField(Constants.TAGVenueType, venueType);
        msg.setField(Constants.TAGSecurityType, securityType);
        sendFixMessage(msg);

        Quote quote = new Quote(sub.requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(sub.requestId, quote);
    }
    
    public void submitQuotesRFQLE(Subscription sub, String quoteId, 
            String bidPx, String offerPx, String clientId) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, sub.requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, sub.symbol);
        msg.setField(Constants.TAGSymbolSfx, sub.symbolSfx);
        msg.setField(Constants.TAGSecurityID, sub.securityID);
        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGSecurityType, sub.securityType);
        msg.setField(Constants.TAGAccount, clientId);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGPriceType, Constants.PRICETYPE_Price);
        sendFixMessage(msg);
    }
    
    public void submitQuotesRFQMultiLeg(String quoteReqId, String quoteId, String symbol, String product, String securityType,
            Subscription sub, String bidSpotRate, String offerSpotRate,
            Map<String, String> legBidForwardPoints, Map<String, String> legOfferForwardPoints, 
            String routedUserId) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        
        if(routedUserId!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedUserId);
            msg.setField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);
        }
        
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        
        if(sub.rfqLegs!=null){
            msg.setField(Constants.TAGNoLegs, sub.rfqLegs.length);
            
            for(RFQLeg rfqLeg:sub.rfqLegs){
                msg.setField(Constants.TAGLegSymbol, rfqLeg.legSymbol);
                msg.setField(Constants.TAGLegSide, rfqLeg.legSide);
                msg.setField(Constants.TAGLegCurrency, rfqLeg.legCurrency);
                msg.setField(Constants.TAGLegQty, rfqLeg.legOrderQty);
                msg.setField(Constants.TAGLegSettlDate, rfqLeg.legSettlDate);
                msg.setField(Constants.TAGLegRefID, rfqLeg.legRefID);
                msg.setField(Constants.TAGLegBidForwardPoints, legBidForwardPoints.get(rfqLeg.legRefID));
                msg.setField(Constants.TAGLegOfferForwardPoints, legOfferForwardPoints.get(rfqLeg.legRefID));
            }
        }
        
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        sendFixMessage(msg);
    }
    
    public void submitQuotesRFQMultiLeg(Subscription sub, String bidSpotRate, String offerSpotRate,
            Map<String, String> legBidForwardPoints, Map<String, String> legOfferForwardPoints, 
            String routedUserId) throws Exception
    {        
        submitQuotesRFQMultiLeg(sub.requestId, "testMultiLegQuote" + System.currentTimeMillis(), sub.symbol,
                sub.product, sub.securityType, sub, bidSpotRate, offerSpotRate, legBidForwardPoints,
                legOfferForwardPoints,
                routedUserId);
    }

    public void submitQuotesRFQ(String requestId,
            String quoteId, String symbol, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String midPx, String midPx2) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGMidPx2, midPx2);
        
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitQuotesRFQ(String requestId,
            String quoteId, String symbol, String symbolSfx, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String midPx, String midPx2, String bidForwardPoint, String offerForwardPoint) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGMidPx2, midPx2);
        msg.setField(Constants.TAGBidForwardPoints, bidForwardPoint);
        msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoint);
        sendFixMessage(msg);
         
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }
    public void submitQuotesRFQMakerOBO(String requestId,
            String quoteId, String symbol, String product, String securityType, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String midPx, String midPx2, String routedUserId) throws Exception
    {
        submitQuotesRFQMakerOBO(requestId,
                quoteId, symbol, product, securityType, bidPx, bidSpotRate,
                offerPx, offerSpotRate, midPx, midPx2, routedUserId, null);
    }

    public void submitQuotesRFQMakerOBO(String requestId,
            String quoteId, String symbol, String product, String securityType, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate, String midPx, String midPx2, String routedUserId,
            String venueType) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        
        if(routedUserId!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedUserId);
            msg.setField(Constants.TAGPartyRole, "3");
        }
        
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGMidPx, midPx);
        msg.setField(Constants.TAGMidPx2, midPx2);
        msg.setField(Constants.TAGVenueType, venueType);

        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }


    public void submitBadQuotesRFQ(String requestId,
            String quoteId, String symbol, String product, String bidPx, String bidSpotRate,
            String offerPx, String offerSpotRate) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGAccount, "makertestaccount");
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitBadQuotes(String requestId,
            String quoteId, String symbol, String valueDate, String bidPrice, String bidSpotRate,
            String offerPrice, String offerSpotRate, String bidFwdPts, String offerFwdPts, String bidAmt, String offerAmt, String transactTime) throws Exception
   {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, "SP");
            msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        }
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGBidPx, bidPrice);
        msg.setField(Constants.TAGOfferPx, offerPrice);
        msg.setField(Constants.TAGBidSize, bidAmt);
        msg.setField(Constants.TAGOfferSize,offerAmt);
        msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
        msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
        msg.setField(Constants.TAGBidForwardPoints, bidFwdPts);
        msg.setField(Constants.TAGOfferForwardPoints, offerFwdPts);
        msg.setField(Constants.TAGTransactTime, transactTime);
            
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, symbol, bidPrice,
                offerPrice, bidAmt, offerAmt, valueDate);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitTreasuryQuotesESP(String symbol, String symbolSfx, 
            String bidPrice, String offerPrice,String bidAmt, String offerAmt) throws Exception
   {
        Subscription sub = this.getSubscription(symbol, symbolSfx);  
        String quoteId = "testTreQuote-"+ System.currentTimeMillis();
        
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGQuoteReqID, sub.requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSecurityID, sub.securityID);
        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Government);
        msg.setField(Constants.TAGBidPx, bidPrice);
        msg.setField(Constants.TAGOfferPx, offerPrice);
        msg.setField(Constants.TAGBidSize, bidAmt);
        msg.setField(Constants.TAGOfferSize,offerAmt);
        msg.setField(Constants.TAGValidUntilTime, null);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGPriceType, sub.priceType);

        sendFixMessage(msg);
        Quote quote = new Quote(sub.requestId, quoteId, symbol, bidPrice,
                offerPrice, bidAmt, offerAmt, null);
        getTopOfBookPrices().put(sub.requestId, quote);
    }
    
    public void submitTreasuryQuotes(String requestId,
            String quoteId, String symbol, String symbolSfx, String secID, String secSource, String pdt,
            String bidPrice, String offerPrice,String bidAmt, String offerAmt, String validUntilTime, String transactTime, String priceType) throws Exception
   {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(secID!=null) {
            msg.setField(Constants.TAGSecurityID, secID);
        }
        if(secSource!=null) {
            msg.setField(Constants.TAGSecurityIDSource, secSource);
        }
        if(pdt!=null) {
            msg.setField(Constants.TAGProduct, pdt);
        }
        if(bidPrice!=null) {
            msg.setField(Constants.TAGBidPx, bidPrice);
        }
        if(offerPrice!=null) {
            msg.setField(Constants.TAGOfferPx, offerPrice);
        }
       if(bidAmt!=null) {
        msg.setField(Constants.TAGBidSize, bidAmt);
    }
       if(offerAmt!=null) {
        msg.setField(Constants.TAGOfferSize,offerAmt);
    }
       if(validUntilTime!=null) {
        msg.setField(Constants.TAGValidUntilTime,validUntilTime);
    }
        if(transactTime!=null) {
            msg.setField(Constants.TAGTransactTime, transactTime);
        }
        if(priceType!=null) {
            msg.setField(Constants.TAGPriceType, priceType);
        }

        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, symbol, bidPrice,
                offerPrice, bidAmt, offerAmt, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitTreasuryQuotesRFQ(String requestId,
            String quoteId, String product, String account,
            String numLegs, String legSymbol, String legSymbolSfx, String legSecID, String legSecIdSrc, String legQty,
            String legBidPx, String legOfferPx, String validUntilTime) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(account!=null) {
            msg.setField(Constants.TAGAccount, account);
        }
        if(numLegs!=null) {
            msg.setField(Constants.TAGNoLegs, numLegs);
        }
        if(legSymbol!=null) {
            msg.setField(Constants.TAGLegSymbol, legSymbol);
        }
        if(legSymbolSfx!=null) {
            msg.setField(Constants.TAGLegSymbolSfx, legSymbolSfx);
        }
        if(legSecID!=null) {
            msg.setField(Constants.TAGLegSecurityID, legSecID);
        }
        if(legSecIdSrc!=null) {
            msg.setField(Constants.TAGLegSecurityIDSource, legSecIdSrc);
        }
        if(legQty!=null) {
            msg.setField(Constants.TAGLegQty, legQty);
        }
        if(legBidPx!=null) {
            msg.setField(Constants.TAGLegBidPx, legBidPx);
        }
       if(legOfferPx!=null) {
        msg.setField(Constants.TAGLegOfferPx, legOfferPx);
    }
       if(validUntilTime!=null) {
        msg.setField(Constants.TAGValidUntilTime,validUntilTime);
    }
        sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, legBidPx,
                legOfferPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

    public void submitTreasuryQuoteReqRej(String requestId,
            String reason) throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteRequestReject, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(reason!=null) {
            msg.setField(Constants.TAGQuoteRequestRejectReason, reason);
        }
        //this is now a required field in govex
        msg.setField(Constants.TAGNoRelatedSym, "0");
        sendFixMessage(msg);
    }

    public void submitQuoteReqRej(String requestId,
            String reason) throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteRequestReject, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(reason!=null) {
            msg.setField(Constants.TAGQuoteRequestRejectReason, reason);
        }
        //this is now a required field in FX
        msg.setField(Constants.TAGNoRelatedSym, "0");
        msg.setField(Constants.TAGText, "rejecting quote!!!");
        sendFixMessage(msg);
    }

    public void submitTreasuryQuoteCancel(String requestId,
            String quoteId, String cancelType) throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(cancelType!=null) {
            msg.setField(Constants.TAGQuoteCancelType, cancelType);
        }
        sendFixMessage(msg);
    }

    public void submitEmptyQuote() throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void submitCancelQuote(Quote quote) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, quote.requestId);
        msg.setField(Constants.TAGQuoteID, "makerQuoteCancel"+System.currentTimeMillis());
        msg.setField(Constants.TAGQuoteCancelType, "1");
        msg.setField(Constants.TAGSymbol, quote.symbol);
        sendFixMessage(msg);
        getTopOfBookPrices().remove(quote.requestId);
    }

    public void submitCancelQuote42(Quote quote) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, quote.requestId);
        msg.setField(Constants.TAGQuoteID, "makerQuoteCancel"+System.currentTimeMillis());
        msg.setField(Constants.TAGQuoteCancelType, "1");
        msg.setField(Constants.TAGNoQuoteEntries, "1");
        msg.setField(Constants.TAGSymbol, quote.symbol);
        sendFixMessage(msg);
        getTopOfBookPrices().remove(quote.requestId);
    }

    public void submitQuoteCancelRFQ(String reqId, String quoteId, String cancelType) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(reqId!=null) {
            msg.setField(Constants.TAGQuoteReqID, reqId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(cancelType!=null) {
            msg.setField(Constants.TAGQuoteCancelType, cancelType);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().remove(reqId);
    }

    public void submitCancelQuote(Quote quote, String side) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, quote.requestId);
        msg.setField(Constants.TAGQuoteID, "makerQuoteCancel"+System.currentTimeMillis());
        msg.setField(Constants.TAGQuoteCancelType, "1");
        msg.setField(Constants.TAGSymbol, quote.symbol);
        msg.setField(Constants.TAGSide, side);
        sendFixMessage(msg);
        getTopOfBookPrices().remove(quote.requestId);
    }

    public void submitCancelQuote(String requestId, String symbol, String side) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, "makerQuoteCancel"+System.currentTimeMillis());
        msg.setField(Constants.TAGQuoteCancelType, "1");

        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        sendFixMessage(msg);
        getTopOfBookPrices().remove(requestId);
    }

    public void submitBadCancelQuote(String requestId, String quoteId, String cancelType, String symbol, String side) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(cancelType!=null) {
            msg.setField(Constants.TAGQuoteCancelType, cancelType);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        sendFixMessage(msg);
    }

    public void submitEmptyCancelQuote() throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void submitQuoteAck(String reqId, String status, String reason) throws Exception {
        submitQuoteAck(reqId, status, reason, null);
    }

    public void submitQuoteAck(String reqId, String status, String reason, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGQuoteAcknowledgement, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(reqId!=null) {
            msg.setField(Constants.TAGQuoteReqID, reqId);
        }
        if(status!=null) {
            msg.setField(Constants.TAGQuoteAckStatus, status);
        }
        if(reason!=null) {
            msg.setField(Constants.TAGQuoteRejectReason, reason);
        }
        msg.setField(Constants.TAGVenueType, venueType);

        sendFixMessage(msg);
        getTopOfBookPrices().remove(reqId);
    }

    public void submitEmptyQuoteAck() throws Exception {
        Message msg = new Message(Constants.MSGQuoteAcknowledgement, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void submitCancelAllRates() throws Exception
    {
        SimpleDateFormat m_format = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");
        m_format.setTimeZone(TimeZone.getTimeZone("GMT"));
        submitCancelAllRates(m_format.format(new Date()));
    }
    
    public void submitCancelAllRates(String transactTime) throws Exception
    {
        Message msg = new Message(MSGCancelAllQuotes, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(transactTime!=null) {
            msg.setField(Constants.TAGTransactTime, transactTime);
        }
        sendFixMessage(msg);

        //remove all quotes from book
        for (Entry<String, MakerTestSession.Subscription> subEntry : subscriptions.entrySet())
        {
            MakerTestSession.Subscription sub = subEntry.getValue();
            getTopOfBookPrices().remove(sub.requestId);
        }
    }

    public void submitEmptyCancelAllRates() throws Exception
    {
        Message msg = new Message(MSGCancelAllQuotes, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void clearAllActiveSubscriptions()
    {
        subscriptions.clear();
    }

    public void submitQuotesRFQNDF(String requestId, String quoteId, String symbol, String symbolSfx,
            String product, String securityType, String bidPx, String offerPx, String bidSpotRate, String offerSpotRate,
            String bidForwardPoints, String offerForwardPoints, String midPx) throws Exception
    {
        Message msg = new Message(Constants.MSGQuote, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(requestId!=null) {
            msg.setField(Constants.TAGQuoteReqID, requestId);
        }
        if(quoteId!=null) {
            msg.setField(Constants.TAGQuoteID, quoteId);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        msg.setField(Constants.TAGSecurityType,  securityType);
        if(bidPx!=null) {
            msg.setField(Constants.TAGBidPx, bidPx);
        }
        if(bidSpotRate!=null)
        {
            msg.setField(Constants.TAGBidSpotRate, bidSpotRate);
            msg.setField(Constants.TAGBidForwardPoints, bidForwardPoints);
        }
        if(offerPx!=null) {
            msg.setField(Constants.TAGOfferPx, offerPx);
        }
        if(offerSpotRate!=null)
        {
            msg.setField(Constants.TAGOfferSpotRate, offerSpotRate);
            msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoints);
        }


         sendFixMessage(msg);
        Quote quote = new Quote(requestId, quoteId, null, bidPx,
                offerPx, null, null, null);
        getTopOfBookPrices().put(requestId, quote);
    }

   public void submitExecReportRFQNDF(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String product, String securityType,
            String side, String orderQty, String orderType, String price, String currency, String lastSpotRate,
            String leavesQty, String cumQty, String avgPx, Date tradeDate, String settlCurrAmt, String fixingDate,
            String fixingDate2, String noRegIds, String regTradeId, String regTradeIdSource, String regTradeIdType
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSecurityType, securityType);
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, settlCurrAmt);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
            msg.setField(Constants.TAGLastSpotRate, price);

        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGFixingDate,  fixingDate);
        msg.setField(Constants.TAGFixingDate2,  fixingDate2);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        msg.setField(Constants.TAGRegulatoryTradeIDType, regTradeIdType);
         sendFixMessage(msg);
    }
   
   public void submitExecReportRFQNDF(String orderId, String secClOrdId, String clOrdId, String execId,
           String execType, String ordStatus, String settlDate, String symbol, String product, String securityType,
           String side, String orderQty, String orderType, String price, String currency, String lastSpotRate,
           String leavesQty, String cumQty, String avgPx, Date tradeDate, String settlCurrAmt, String fixingDate,
           String fixingDate2
           ) throws Exception{
       Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
       if(orderId!=null) {
        msg.setField(Constants.TAGOrderID, orderId);
    }
       if(secClOrdId!=null) {
        msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
    }
       if(clOrdId!=null) {
        msg.setField(Constants.TAGClOrdID, clOrdId);
    }
       if(execId!=null) {
        msg.setField(Constants.TAGExecID, execId);
    }
       if(execType!=null) {
        msg.setField(Constants.TAGExecType, execType);
    }
       if(ordStatus!=null) {
        msg.setField(Constants.TAGOrdStatus, ordStatus);
    }
       if(settlDate!=null) {
        msg.setField(Constants.TAGSettlDate, settlDate);
    }
       if(symbol!=null) {
        msg.setField(Constants.TAGSymbol, symbol);
    }
       msg.setField(Constants.TAGProduct, "4");
       msg.setField(Constants.TAGSecurityType, securityType);
       if(side!=null) {
        msg.setField(Constants.TAGSide, side);
    }
       if(orderQty!=null)
       {
           msg.setField(Constants.TAGOrderQty, orderQty);
           msg.setField(Constants.TAGCumQty, orderQty);
           msg.setField(Constants.TAGSettlCurrAmt, settlCurrAmt);
       }
       msg.setField(Constants.TAGLeavesQty, "0");
       if(orderType!=null) {
        msg.setField(Constants.TAGOrdType, orderType);
    }
       if(price!=null)
       {
           msg.setField(Constants.TAGPrice, price);
           msg.setField(Constants.TAGAvgPx, price);
           msg.setField(Constants.TAGLastSpotRate, price);

       }
       if(tradeDate!=null) {
        msg.setField(Constants.TAGTradeDate, tradeDate.toString());
    }
       msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
       msg.setField(Constants.TAGCurrency, currency);
       msg.setField(Constants.TAGFixingDate,  fixingDate);
       msg.setField(Constants.TAGFixingDate2,  fixingDate2);
        sendFixMessage(msg);
   }


    public void orderReplyFilled(String clOrdId,  String orderId, String execId, String symbol, String price, String side,
            String filledAmount, String valueDate) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }

        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);

        if(valueDate!=null) {
            msg.setField(Constants.TAGFutSettDate, valueDate);
        }

        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
         if(filledAmount!=null) {
            msg.setField(Constants.TAGOrderQty, filledAmount);
        }
          if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }

            msg.setField(Constants.TAGLeavesQty, "0");

            msg.setField(Constants.TAGCumQty, filledAmount);

            msg.setField(Constants.TAGAvgPx, price);
        sendFixMessage(msg);
    }

    public void submitBadExecReport(String clOrdId,  String orderId, String execId, String execTransType,
            String execType, String ordStatus, String symbol, String price, String side,
            String ordQty, String leavesQty, String cumQty, String valueDate) throws Exception{
        
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, execId);
        msg.setField(Constants.TAGExecTransType, execTransType);
        msg.setField(Constants.TAGExecType, execType);
        msg.setField(Constants.TAGOrdStatus, ordStatus);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLeavesQty, leavesQty);
        msg.setField(Constants.TAGCumQty, cumQty);
        msg.setField(Constants.TAGAvgPx, price);

        //44 testing, remove
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, "SP");
            msg.setField(Constants.TAGProduct, "4");
            msg.setField(Constants.TAGLastSpotRate, price);
        }
        
        sendFixMessage(msg);
    }
    
    public void submitQuoteReqRej(String requestId,
            String reason, String text) throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteRequestReject, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteRequestRejectReason, reason);
        //this is now a required field in FX
        msg.setField(Constants.TAGNoRelatedSym, "0");
        msg.setField(Constants.TAGText, text);
        sendFixMessage(msg);
    }

    public void submitBadExecReport(String clOrdId,  String orderId, String execId, String execTransType,
            String execType, String ordStatus, String symbol, String price, String side,
            String ordQty, String leavesQty, String cumQty, String valueDate, String currency, String transTime) throws Exception{
        
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());

            msg.setField(Constants.TAGOrderID, orderId);
            msg.setField(Constants.TAGClOrdID, clOrdId);
            msg.setField(Constants.TAGExecID, execId);
            msg.setField(Constants.TAGExecTransType, execTransType);
            msg.setField(Constants.TAGExecType, execType);
            msg.setField(Constants.TAGOrdStatus, ordStatus);
            msg.setField(Constants.TAGFutSettDate, valueDate);
            msg.setField(Constants.TAGSymbol, symbol);
            msg.setField(Constants.TAGSymbolSfx, "SP");
            msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
            msg.setField(Constants.TAGSide, side);
            msg.setField(Constants.TAGOrderQty, ordQty);
            msg.setField(Constants.TAGLastSpotRate, price);
            msg.setField(Constants.TAGLeavesQty, leavesQty);
            msg.setField(Constants.TAGCumQty, cumQty);
            msg.setField(Constants.TAGAvgPx, price);
            msg.setField(Constants.TAGCurrency, currency);
            msg.setField(Constants.TAGTransactTime, transTime);
            
            sendFixMessage(msg);
    }

    public void submitTreasuryExecReport(String clOrdId,  String orderId, String execId, String execTransType,
            String execType, String ordStatus, String price, String side, String ordQty, String leavesQty,
            String cumQty,String transTime, String product, String symbol, String symbolSfx, String secId, String secIdSrc)
    throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execTransType!=null) {
            msg.setField(Constants.TAGExecTransType, execTransType);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
         if(ordQty!=null) {
            msg.setField(Constants.TAGOrderQty, ordQty);
        }
          if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }
          if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, leavesQty);
        }
          if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, cumQty);
        }
          if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
          if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
          if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
          if(secId!=null) {
            msg.setField(Constants.TAGSecurityID, secId);
        }
          if(secIdSrc!=null) {
            msg.setField(Constants.TAGSecurityIDSource, secIdSrc);
        }
          if(transTime!=null) {
            msg.setField(Constants.TAGTransactTime, transTime);
        }
          //QuickFix requirement
          msg.setField(Constants.TAGAvgPx, "0");
          //testing DEV-10553
//          msg.setField(Constants.TAGLastQty, "1001093.75");
//          msg.setField(Constants.TAGGrossTradeAmt, "1001993.75");
        sendFixMessage(msg);
    }

    public void submitExecReportIrsRFQ(String orderId, String quoteRespId, String clOrdId, String execId, String execType, String ordStatus,
            String symbol, String matDate, String cfad, String settDate, String side, String cumQty, String priceType, String avgPx, Date tradeDate) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGQuoteRespID, quoteRespId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, execId);
        msg.setField(Constants.TAGExecType, execType);
        msg.setField(Constants.TAGOrdStatus, ordStatus);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGMaturityDate, matDate);
        msg.setField(Constants.TAGDatedDate, cfad);
        msg.setField(Constants.TAGInterestAccrualDate, settDate);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, "D");
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, cumQty);
        msg.setField(Constants.TAGAvgPx, avgPx);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, avgPx);
        msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void submitExecReportRFQCD(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String currency,
            Date tradeDate, String lastSpotRate
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
        }
        if(lastSpotRate!=null) {
            msg.setField(Constants.TAGLastSpotRate, lastSpotRate);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
         sendFixMessage(msg);
    }

    public void submitTreasuryExecReport(String clOrdId,  String orderId, String execId, String execTransType,
            String execType, String ordStatus, String price, String side, String ordQty, String leavesQty,
            String cumQty,String transTime, String product, String symbol, String symbolSfx, String secId, String secIdSrc,
            String avgPx)
    throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execTransType!=null) {
            msg.setField(Constants.TAGExecTransType, execTransType);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
         if(ordQty!=null) {
            msg.setField(Constants.TAGOrderQty, ordQty);
        }
          if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }
          if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, leavesQty);
        }
          if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, cumQty);
        }
          if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
          if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
          if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
          if(secId!=null) {
            msg.setField(Constants.TAGSecurityID, secId);
        }
          if(secIdSrc!=null) {
            msg.setField(Constants.TAGSecurityIDSource, secIdSrc);
        }
          if(transTime!=null) {
            msg.setField(Constants.TAGTransactTime, transTime);
        }
          if(avgPx!=null) {
            msg.setField(Constants.TAGAvgPx, avgPx);
        }
        sendFixMessage(msg);
    }

    public void submitExecReportRFQ(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String currency, Date tradeDate
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
            msg.setField(Constants.TAGLastSpotRate, price);

        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
         sendFixMessage(msg);
    }
    
    public void submitExecReportRFQRejected(String orderId, String secClOrdId, String clOrdId, String execId, 
            String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String currency, Date tradeDate, String text
            ) throws Exception{
        submitExecReportRFQRejected(orderId, secClOrdId, clOrdId, execId,
            settlDate, symbol, side, orderQty,
            SettlCurrAmount, orderType, price, currency, tradeDate, text,
            null);
    }
    
    public void submitExecReportRFQRejected(String orderId, String secClOrdId, String clOrdId, String execId, 
            String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String currency, Date tradeDate, String text,
            String venueType) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Rejected);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Rejected);
        
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
            msg.setField(Constants.TAGLastSpotRate, price);

        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
        if(text!=null) {
            msg.setField(Constants.TAGText, text);
        }
        if(venueType!=null) {
            msg.setField(Constants.TAGVenueType, venueType);
        }
         sendFixMessage(msg);
    }
    
    public void submitExecReportRFQSpot(String orderId, String secClOrdId, String clOrdId, String execId,
            String execType, String ordStatus, String settlDate, String symbol, String side, String orderQty,
            String SettlCurrAmount, String orderType, String price, String cumQty, String currency, Date tradeDate
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(settlDate!=null) {
            msg.setField(Constants.TAGSettlDate, settlDate);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        msg.setField(Constants.TAGProduct, "4");
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null)
        {
            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.setField(Constants.TAGCumQty, orderQty);
            msg.setField(Constants.TAGSettlCurrAmt, SettlCurrAmount);
        }
        msg.setField(Constants.TAGLeavesQty, "0");
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(price!=null)
        {
            msg.setField(Constants.TAGPrice, price);
            msg.setField(Constants.TAGAvgPx, price);
            msg.setField(Constants.TAGLastSpotRate, price);

        }
        msg.setField(Constants.TAGCumQty, cumQty);
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGCurrency, currency);
         sendFixMessage(msg);
    }


    public void submitExecReportLDRFQ(String orderId, String secClOrdId, String clOrdId, String execId, String execType, String ordStatus,
            String symbol, String product, String side, String orderQty, String leavesQty, String cumQty, String avgPx
            ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(secClOrdId!=null) {
            msg.setField(Constants.TAGSecondaryClOrdID, secClOrdId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
            msg.setField(Constants.TAGProduct, product);
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderQty!=null) {
            msg.setField(Constants.TAGOrderQty, orderQty);
        }
        if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, "0");
        }
        if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, orderQty);
        }
        if(avgPx!=null) {
            msg.setField(Constants.TAGAvgPx, avgPx);
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
         sendFixMessage(msg);
    }


    public void submitTreasuryExecReportRFQ(String orderId, String clOrdId, String execId, String execType, String ordStatus,
                                            String side, String orderType, String leavesQty, String cumQty, Date tradeDate, String numLegs, String legSymbol,
                                            String legSymbolSfx, String legSecId, String legSecIdSrc, String legSide
    ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, leavesQty);
        }
        if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, cumQty);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGProduct, "6");
        //required for QuickFix
        msg.setField(Constants.TAGAvgPx, "100.109375");
        msg.setField(Constants.TAGSymbol, "NA");
        if(numLegs!=null) {
            msg.setField(Constants.TAGNoLegs, numLegs);
        }
        if(legSymbol!=null) {
            msg.setField(Constants.TAGLegSymbol, legSymbol);
        }
        if(legSymbolSfx!=null) {
            msg.setField(Constants.TAGLegSymbolSfx, legSymbolSfx);
        }
        if(legSecId!=null) {
            msg.setField(Constants.TAGLegSecurityID, legSecId);
        }
        if(legSecIdSrc!=null) {
            msg.setField(Constants.TAGLegSecurityIDSource, legSecIdSrc);
        }
        if(legSide!=null) {
            msg.setField(Constants.TAGLegSide, legSide);
        }

        //to test DEV-10544
        msg.setField(Constants.TAGLegLastPx, "100.109375");
        msg.setField(1075, "1001210.93");
        msg.setField(1418 ,"1001093.75");
        sendFixMessage(msg);
    }

    public void submitTreasuryExecReportRFQ(String orderId, String clOrdId, String execId, String execType, String ordStatus,
                                            String side, String orderType, String leavesQty, String cumQty, Date tradeDate, String numLegs, String legSymbol,
                                            String legSymbolSfx, String legSecId, String legSecIdSrc, String legSide, String quoteRespId
    ) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, leavesQty);
        }
        if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, cumQty);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGProduct, "6");
        //required for QuickFix
        msg.setField(Constants.TAGAvgPx, "100.109375");
        msg.setField(Constants.TAGSymbol, "NA");
        if(numLegs!=null) {
            msg.setField(Constants.TAGNoLegs, numLegs);
        }
        if(legSymbol!=null) {
            msg.setField(Constants.TAGLegSymbol, legSymbol);
        }
        if(legSymbolSfx!=null) {
            msg.setField(Constants.TAGLegSymbolSfx, legSymbolSfx);
        }
        if(legSecId!=null) {
            msg.setField(Constants.TAGLegSecurityID, legSecId);
        }
        if(legSecIdSrc!=null) {
            msg.setField(Constants.TAGLegSecurityIDSource, legSecIdSrc);
        }
        if(legSide!=null) {
            msg.setField(Constants.TAGLegSide, legSide);
        }
        if(quoteRespId!=null) {
            msg.setField(Constants.TAGQuoteRespID, quoteRespId);
        }

        //to test DEV-10544
        msg.setField(Constants.TAGLegLastPx, "100.109375");
        msg.setField(1075, "1001210.93");
        msg.setField(1418 ,"1001093.75");
        sendFixMessage(msg);
    }

    public void submitTreasuryExecReportRFQ(String orderId, String clOrdId, String execId, String execType, String ordStatus,
            String side, String orderType, String leavesQty, String cumQty, Date tradeDate, String numLegs, String legSymbol,
            String legSymbolSfx, String legSecId, String legSecIdSrc, String legSide, String legQty, String symbol, String product,
            String avgPx) throws Exception{
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId!=null) {
            msg.setField(Constants.TAGOrderID, orderId);
        }
        if(clOrdId!=null) {
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        if(execId!=null) {
            msg.setField(Constants.TAGExecID, execId);
        }
        if(execType!=null) {
            msg.setField(Constants.TAGExecType, execType);
        }
        if(side!=null) {
            msg.setField(Constants.TAGSide, side);
        }
        if(orderType!=null) {
            msg.setField(Constants.TAGOrdType, orderType);
        }
        if(ordStatus!=null) {
            msg.setField(Constants.TAGOrdStatus, ordStatus);
        }
        if(leavesQty!=null) {
            msg.setField(Constants.TAGLeavesQty, leavesQty);
        }
        if(cumQty!=null) {
            msg.setField(Constants.TAGCumQty, cumQty);
        }
        if(tradeDate!=null) {
            msg.setField(Constants.TAGTradeDate, tradeDate.toString());
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));

        if(product!=null) {
            msg.setField(Constants.TAGProduct, product);
        }
        if(avgPx!=null) {
            msg.setField(Constants.TAGAvgPx, avgPx);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(numLegs!=null) {
            msg.setField(Constants.TAGNoLegs, numLegs);
        }
        if(legSymbol!=null) {
            msg.setField(Constants.TAGLegSymbol, legSymbol);
        }
        if(legSymbolSfx!=null) {
            msg.setField(Constants.TAGLegSymbolSfx, legSymbolSfx);
        }
        if(legSecId!=null) {
            msg.setField(Constants.TAGLegSecurityID, legSecId);
        }
        if(legSecIdSrc!=null) {
            msg.setField(Constants.TAGLegSecurityIDSource, legSecIdSrc);
        }
        if(legSide!=null) {
            msg.setField(Constants.TAGLegSide, legSide);
        }
        if(legQty!=null) {
            msg.setField(Constants.TAGLegQty, legQty);
        }
        msg.setField(Constants.TAGLegLastPx, "100.109375");
        sendFixMessage(msg);
    }

    public void submitEmptyExecutionReport() throws Exception
    {
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void submitEmptyQuoteReqRej() throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteRequestReject, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }
    
    public void orderReplyFilledRFQ(Message orderMsg) throws Exception {
        
        String lastSpotRate = orderMsg.getStringFieldValue(Constants.TAGPrice);
               
        orderReplyFilledRFQ(orderMsg, lastSpotRate, null, null, null, null, null, null);
    }
    
    public void orderReplyFilledRFQLD(Message orderMsg) throws Exception {
                       
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String secondaryClOrdId = orderMsg.getStringFieldValue(Constants.TAGSecondaryClOrdID);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "OrderId" + clOrdId);
        msg.setField(Constants.TAGSecondaryClOrdID, secondaryClOrdId);
        msg.setField(Constants.TAGClOrdID, "ClOrdId" + clOrdId);
        msg.setField(Constants.TAGExecID, "ExecId"+clOrdId);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_MoneyMarket);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, null); //TODO
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        
        sendFixMessage(msg);
    }
    
    public void orderReplyFilledRFQFwd(Message orderMsg, Message quote) throws Exception {

        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        boolean termsTrading = (orderMsg.getStringFieldValue(Constants.TAGCurrency)
                .equals(orderMsg.getStringFieldValue(Constants.TAGSymbol).split("/")[1]));
        
//        String lastSpotRate = ((!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)))?
//                quote.getStringFieldValue(Constants.TAGOfferSpotRate):
//                    quote.getStringFieldValue(Constants.TAGBidSpotRate);
//
//        String lastForwardPoints = ((!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)))?
//                quote.getStringFieldValue(Constants.TAGOfferForwardPoints):
//                    quote.getStringFieldValue(Constants.TAGBidForwardPoints);
        String lastSpotRate = null;
        String lastForwardPoints = null;
                
        String quoteReqId = orderMsg.getStringFieldValue(Constants.TAGSecondaryClOrdID);
        assertNotNull("null SecondaryClOrdID in RFQ order", quoteReqId);
        
        Quote sentQuote = this.getTopOfBookPrices().get(quoteReqId);
        
        if( (!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)) ){
            
            lastSpotRate = (sentQuote!=null && sentQuote.offerSpotRate!=null)? 
                    sentQuote.offerSpotRate : quote.getStringFieldValue(Constants.TAGOfferSpotRate);
            lastForwardPoints = (sentQuote!=null && sentQuote.offerFwdPoints!=null)? 
                    sentQuote.offerFwdPoints : quote.getStringFieldValue(Constants.TAGOfferForwardPoints);
        }else{
            
            lastSpotRate = (sentQuote!=null && sentQuote.bidSpotRate!=null)? 
                    sentQuote.bidSpotRate : quote.getStringFieldValue(Constants.TAGBidSpotRate);
            lastForwardPoints = (sentQuote!=null && sentQuote.bidFwdPoints!=null)? 
                    sentQuote.bidFwdPoints : quote.getStringFieldValue(Constants.TAGBidForwardPoints);
        }
                
        orderReplyFilledRFQ(orderMsg, lastSpotRate, lastForwardPoints, null, null, null, null, null);
    }    
    
    public void orderReplyFilledRFQSwap(Message orderMsg, Message quote) throws Exception {

        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        boolean termsTrading = (orderMsg.getStringFieldValue(Constants.TAGCurrency)
                .equals(orderMsg.getStringFieldValue(Constants.TAGSymbol).split("/")[1]));
        
        String lastSpotRate = (side.equals(Constants.SIDE_Buy))?
                quote.getStringFieldValue(Constants.TAGOfferSpotRate):
                    quote.getStringFieldValue(Constants.TAGBidSpotRate);

        String lastForwardPoints = (side.equals(Constants.SIDE_Buy))?
                quote.getStringFieldValue(Constants.TAGOfferForwardPoints):
                    quote.getStringFieldValue(Constants.TAGBidForwardPoints);
                
        if(termsTrading){
            lastSpotRate = (side.equals(Constants.SIDE_Sell))?
                    quote.getStringFieldValue(Constants.TAGOfferSpotRate):
                    quote.getStringFieldValue(Constants.TAGBidSpotRate);

            lastForwardPoints = (side.equals(Constants.SIDE_Sell))?
                    quote.getStringFieldValue(Constants.TAGOfferForwardPoints):
                    quote.getStringFieldValue(Constants.TAGBidForwardPoints);
        }

        String valueDate2 = quote.getStringFieldValue(Constants.TAGFutSettDate2);
        String orderQty2 = quote.getStringFieldValue(Constants.TAGOrderQty2);
        String lastForwardPoints2 = quote.getStringFieldValue(Constants.TAGLastForwardPoints2);
        String price2 = null;//TODO
        String settlCurrAmt2 = null;//TODO
                
        orderReplyFilledRFQ(orderMsg, lastSpotRate, lastForwardPoints, valueDate2, orderQty2, lastForwardPoints2,
                price2, settlCurrAmt2);
    }
    
    
    private void orderReplyFilledRFQ(Message orderMsg, String lastSpotRate, String lastForwardPoints, 
            String valueDate2, String orderQty2, String lastForwardPoints2, String price2, String settlCurrAmt2) throws Exception {
        
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String secondaryClOrdId = orderMsg.getStringFieldValue(Constants.TAGSecondaryClOrdID);
        String valueDate = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String currency = orderMsg.getStringFieldValue(Constants.TAGCurrency);
        String settlCurrAmt = Double.toString((Double.valueOf(price) * Double.valueOf(orderQty)));

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGSecondaryClOrdID, secondaryClOrdId);
        msg.setField(Constants.TAGClOrdID, "clOrdId" + clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGSettlDate, valueDate);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGLastSpotRate, lastSpotRate);
        msg.setField(Constants.TAGLastForwardPoints, lastForwardPoints);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGTradeDate, new Date().toString());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGSettlCurrAmt, settlCurrAmt);
        //Tags for Swap
        msg.setField(Constants.TAGFutSettDate2, valueDate2);
        msg.setField(Constants.TAGOrderQty2, orderQty2);
        msg.setField(Constants.TAGLastForwardPoints2, lastForwardPoints2);
        msg.setField(Constants.TAGPrice2, price2);
        msg.setField(Constants.TAGSettlCurrAmt2, settlCurrAmt2);
        
        //add for MTF, venue type can be get from order msg : null|M
        msg.setField(Constants.TAGVenueType, orderMsg.getStringFieldValue(Constants.TAGVenueType));
        
        sendFixMessage(msg);
    }
    
    
    public void orderReplyFilledRFQMultiLeg(Message orderMsg, Message quote, String lastSpotRate) throws Exception {
        
        assertNotNull("symbol is null in NewOrderSingle", orderMsg.getStringFieldValue(Constants.TAGSymbol));
        Subscription sub = this.getSubscriptionRfqMultiLeg(orderMsg.getStringFieldValue(Constants.TAGSymbol));
        
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "mLegOrderId" + clOrdId);
        msg.setField(Constants.TAGSecondaryClOrdID, sub.requestId);
        msg.setField(Constants.TAGClOrdID, "mLegClOrdId" + clOrdId);
        msg.setField(Constants.TAGExecID, "mLegExecId"+clOrdId);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGSecurityType, sub.securityType);
        msg.setField(Constants.TAGSide, Constants.SIDE_Undisclosed);
        msg.setField(Constants.TAGLastSpotRate, lastSpotRate);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, "0");
        msg.setField(Constants.TAGTradeDate, new Date().toString());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGNoLegs, orderMsg.getStringFieldValue(Constants.TAGNoLegs));
        
        IFixGroup[] legsInOrder = orderMsg.getParser().getDynamicGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);
        IFixGroup[] legsInQuote = quote.getParser().getDynamicGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);
        RFQLeg[] legsInQuoteRequest = sub.rfqLegs;
        
        for(IFixGroup aLegInOrder:legsInOrder){
            
            msg.setField(Constants.TAGLegSymbol, aLegInOrder.getStringValFor(Constants.TAGiLegSymbol));
            msg.setField(Constants.TAGLegSide, aLegInOrder.getStringValFor(Constants.TAGiLegSide));
            msg.setField(Constants.TAGLegCurrency, aLegInOrder.getStringValFor(Constants.TAGiLegCurrency));
            
            //Adding legAllocations from QuoteRequest
            for(RFQLeg aLegInQuoteRequest:legsInQuoteRequest){
                if(aLegInOrder.getStringValFor(Constants.TAGiLegRefID) != null &&
                        aLegInOrder.getStringValFor(Constants.TAGiLegRefID).equals(aLegInQuoteRequest.legRefID)){
                    
                    Allocation[] allocs = aLegInQuoteRequest.allocations;
                    
                    if(allocs!=null && allocs.length>0){
                        msg.setField(Constants.TAGNoLegAllocs, allocs.length);
                        
                        for(Allocation alloc:allocs){
                            msg.setField(Constants.TAGLegAllocAccount, alloc.allocAccount);
                            msg.setField(Constants.TAGLegAllocQty, alloc.allocQty);
                        }
                    }
                }
            }
            
            msg.setField(Constants.TAGLegRefID, aLegInOrder.getStringValFor(Constants.TAGiLegRefID));
            msg.setField(Constants.TAGLegSettlDate, aLegInOrder.getStringValFor(Constants.TAGiLegSettlDate));
            msg.setField(Constants.TAGLegLastPx, aLegInOrder.getStringValFor(Constants.TAGiLegPrice));
            
            //Adding legLastForwardPoints from Quote
            for(IFixGroup aLegInQuote:legsInQuote){
                
                String legRefIDInQuote = aLegInQuote.getStringValFor(Constants.TAGiLegRefID);
                
                if(legRefIDInQuote!=null && legRefIDInQuote.equals(aLegInOrder.getStringValFor(Constants.TAGiLegRefID))){
                    
                    String legLastForwardPoints = (aLegInOrder.getStringValFor(Constants.TAGiLegSide).equals(Constants.SIDE_Buy))?
                            aLegInQuote.getStringValFor(Constants.TAGiLegOfferForwardPoints):
                                aLegInQuote.getStringValFor(Constants.TAGiLegBidForwardPoints);
                    
                    msg.setField(Constants.TAGLegLastForwardPoints, legLastForwardPoints);
                }
            }
                        
            Double legPrice = aLegInOrder.getStringValFor(Constants.TAGiLegPrice)==null? 0 : Double.valueOf(aLegInOrder.getStringValFor(Constants.TAGiLegPrice));
            Double legOrderQty = aLegInOrder.getStringValFor(Constants.TAGiLegQty)==null? 0 : Double.valueOf(aLegInOrder.getStringValFor(Constants.TAGiLegQty));
            Double calculatedLegLastQty = legPrice * legOrderQty;
            
            msg.setField(Constants.TAGLegLastQty, String.valueOf(calculatedLegLastQty));
        }
        
        sendFixMessage(msg);
    }


    public void orderReplyFilled(Message orderMsg) throws Exception {
        orderReplyFilled(orderMsg, null, null);
    }
    
    
    public void orderReplyFilled(Message orderMsg, String overwriteTagNum, String overwriteTagValue) throws Exception {
        
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String product = orderMsg.getStringFieldValue(Constants.TAGProduct);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);
        String venueType = orderMsg.getStringFieldValue(Constants.TAGVenueType);
        
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGOrderID, (Constants.TAGOrderID.equals(overwriteTagNum))?overwriteTagValue:"orderid"+clOrdId);
        msg.setField(Constants.TAGClOrdID, (Constants.TAGClOrdID.equals(overwriteTagNum))?overwriteTagValue:clOrdId);
        msg.setField(Constants.TAGExecID, (Constants.TAGExecID.equals(overwriteTagNum))?overwriteTagValue:"execId"+clOrdId);
        msg.setField(Constants.TAGExecType, (Constants.TAGExecType.equals(overwriteTagNum))?overwriteTagValue:getFixVersion().endsWith("4.4")?Constants.EXECTYPE_Trade:Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, (Constants.TAGOrdStatus.equals(overwriteTagNum))?overwriteTagValue:Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, (Constants.TAGFutSettDate.equals(overwriteTagNum))?overwriteTagValue:valueDateStr);
        msg.setField(Constants.TAGSymbol, (Constants.TAGSymbol.equals(overwriteTagNum))?overwriteTagValue:symbol);
        msg.setField(Constants.TAGSymbolSfx, (Constants.TAGSymbolSfx.equals(overwriteTagNum))?overwriteTagValue:getFixVersion().endsWith("4.4")?symbolSfx:null);
        msg.setField(Constants.TAGProduct, (Constants.TAGProduct.equals(overwriteTagNum))?overwriteTagValue:getFixVersion().endsWith("4.4")?product:null);
        msg.setField(Constants.TAGSecurityType, (Constants.TAGSecurityType.equals(overwriteTagNum))?overwriteTagValue:securityType);
        msg.setField(Constants.TAGSide, (Constants.TAGSide.equals(overwriteTagNum))?overwriteTagValue:side);
        msg.setField(Constants.TAGOrderQty, (Constants.TAGOrderQty.equals(overwriteTagNum))?overwriteTagValue:orderQty);
        msg.setField(Constants.TAGCurrency, (Constants.TAGCurrency.equals(overwriteTagNum))?overwriteTagValue:null);
        msg.setField(Constants.TAGLastQty, (Constants.TAGLastQty.equals(overwriteTagNum))?overwriteTagValue:orderQty);
        msg.setField(Constants.TAGLastPx, (Constants.TAGLastPx.equals(overwriteTagNum))?overwriteTagValue:null);
        msg.setField(Constants.TAGLastSpotRate, (Constants.TAGLastSpotRate.equals(overwriteTagNum))?overwriteTagValue:getFixVersion().endsWith("4.4")?price:null);
        msg.setField(Constants.TAGLeavesQty, (Constants.TAGLeavesQty.equals(overwriteTagNum))?overwriteTagValue:"0");
        msg.setField(Constants.TAGCumQty, (Constants.TAGCumQty.equals(overwriteTagNum))?overwriteTagValue:orderQty);
        msg.setField(Constants.TAGAvgPx, (Constants.TAGAvgPx.equals(overwriteTagNum))?overwriteTagValue:price);
        msg.setField(Constants.TAGTransactTime, (Constants.TAGTransactTime.equals(overwriteTagNum))?overwriteTagValue:dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, (Constants.TAGFixingDate.equals(overwriteTagNum))?overwriteTagValue:fixingDate);
        
        //add venueType
        msg.setField(Constants.TAGVenueType, (Constants.TAGVenueType.equals(overwriteTagNum))?overwriteTagValue:venueType);

        sendFixMessage(msg);
    }
    
    public void orderReplyFilled(Message orderMsg, Map<String, String> overwrittenTagAndValue) throws Exception {
        
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String product = orderMsg.getStringFieldValue(Constants.TAGProduct);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);
        String venueType = orderMsg.getStringFieldValue(Constants.TAGVenueType);
        
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGOrderID, (overwrittenTagAndValue.containsKey(Constants.TAGOrderID))?overwrittenTagAndValue.get(Constants.TAGOrderID):"orderid"+clOrdId);
        msg.setField(Constants.TAGClOrdID, (overwrittenTagAndValue.containsKey(Constants.TAGClOrdID))?overwrittenTagAndValue.get(Constants.TAGClOrdID):clOrdId);
        msg.setField(Constants.TAGExecID, (overwrittenTagAndValue.containsKey(Constants.TAGExecID))?overwrittenTagAndValue.get(Constants.TAGExecID):"execId"+clOrdId);
        msg.setField(Constants.TAGExecType, (overwrittenTagAndValue.containsKey(Constants.TAGExecType))?overwrittenTagAndValue.get(Constants.TAGExecType):getFixVersion().endsWith("4.4")?Constants.EXECTYPE_Trade:Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, (overwrittenTagAndValue.containsKey(Constants.TAGOrdStatus))?overwrittenTagAndValue.get(Constants.TAGOrdStatus):Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, (overwrittenTagAndValue.containsKey(Constants.TAGFutSettDate))?overwrittenTagAndValue.get(Constants.TAGFutSettDate):valueDateStr);
        msg.setField(Constants.TAGSymbol, (overwrittenTagAndValue.containsKey(Constants.TAGSymbol))?overwrittenTagAndValue.get(Constants.TAGSymbol):symbol);
        msg.setField(Constants.TAGSymbolSfx, (overwrittenTagAndValue.containsKey(Constants.TAGSymbolSfx))?overwrittenTagAndValue.get(Constants.TAGSymbolSfx):getFixVersion().endsWith("4.4")?symbolSfx:null);
        msg.setField(Constants.TAGProduct, (overwrittenTagAndValue.containsKey(Constants.TAGProduct))?overwrittenTagAndValue.get(Constants.TAGProduct):getFixVersion().endsWith("4.4")?product:null);
        msg.setField(Constants.TAGSecurityType, (overwrittenTagAndValue.containsKey(Constants.TAGSecurityType))?overwrittenTagAndValue.get(Constants.TAGSecurityType):securityType);
        msg.setField(Constants.TAGSide, (overwrittenTagAndValue.containsKey(Constants.TAGSide))?overwrittenTagAndValue.get(Constants.TAGSide):side);
        msg.setField(Constants.TAGOrderQty, (overwrittenTagAndValue.containsKey(Constants.TAGOrderQty))?overwrittenTagAndValue.get(Constants.TAGOrderQty):orderQty);
        msg.setField(Constants.TAGCurrency, (overwrittenTagAndValue.containsKey(Constants.TAGCurrency))?overwrittenTagAndValue.get(Constants.TAGCurrency):null);
        msg.setField(Constants.TAGLastQty, (overwrittenTagAndValue.containsKey(Constants.TAGLastQty))?overwrittenTagAndValue.get(Constants.TAGLastQty):orderQty);
        msg.setField(Constants.TAGLastPx, (overwrittenTagAndValue.containsKey(Constants.TAGLastPx))?overwrittenTagAndValue.get(Constants.TAGLastPx):null);
        msg.setField(Constants.TAGLastSpotRate, (overwrittenTagAndValue.containsKey(Constants.TAGLastSpotRate))?overwrittenTagAndValue.get(Constants.TAGLastSpotRate):getFixVersion().endsWith("4.4")?price:null);
        msg.setField(Constants.TAGLeavesQty, (overwrittenTagAndValue.containsKey(Constants.TAGLeavesQty))?overwrittenTagAndValue.get(Constants.TAGLeavesQty):"0");
        msg.setField(Constants.TAGCumQty, (overwrittenTagAndValue.containsKey(Constants.TAGCumQty))?overwrittenTagAndValue.get(Constants.TAGCumQty):orderQty);
        msg.setField(Constants.TAGAvgPx, (overwrittenTagAndValue.containsKey(Constants.TAGAvgPx))?overwrittenTagAndValue.get(Constants.TAGAvgPx):price);
        msg.setField(Constants.TAGTransactTime, (overwrittenTagAndValue.containsKey(Constants.TAGTransactTime))?overwrittenTagAndValue.get(Constants.TAGTransactTime):dateFormat.format(
                new Date()));
        msg.setField(Constants.TAGFixingDate, (overwrittenTagAndValue.containsKey(
                Constants.TAGFixingDate))?overwrittenTagAndValue.get(
                Constants.TAGFixingDate):fixingDate);

        //add venueType
        msg.setField(Constants.TAGVenueType, (overwrittenTagAndValue.containsKey(Constants.TAGVenueType))?overwrittenTagAndValue.get(
                Constants.TAGVenueType):venueType);

        //add lastForwardPoints
        msg.setField(Constants.TAGLastForwardPoints, (overwrittenTagAndValue.containsKey(Constants.TAGLastForwardPoints))?
                overwrittenTagAndValue.get(Constants.TAGLastForwardPoints):null);
        
        sendFixMessage(msg);
    }
    
    
    
    public void orderReplyFilledTreasury(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String product = orderMsg.getStringFieldValue(Constants.TAGProduct);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);
        String securityID = orderMsg.getStringFieldValue(Constants.TAGSecurityID);
        String securityIDSource = orderMsg.getStringFieldValue(Constants.TAGSecurityIDSource);
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, product);
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, price);
        }
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);
        msg.setField(Constants.TAGSecurityID, securityID);
        msg.setField(Constants.TAGSecurityIDSource, securityIDSource);
        msg.setField(Constants.TAGGrossTradeAmt, orderQty);
        
        sendFixMessage(msg);
    }
    
    
    public void orderReplyRejectedTreasury(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String product = orderMsg.getStringFieldValue(Constants.TAGProduct);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);
        String securityID = orderMsg.getStringFieldValue(Constants.TAGSecurityID);
        String securityIDSource = orderMsg.getStringFieldValue(Constants.TAGSecurityIDSource);
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "UNKNOWN");
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "UNKNOWN");
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Rejected);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Rejected);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, product);
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, "0");
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);
        msg.setField(Constants.TAGSecurityID, securityID);
        msg.setField(Constants.TAGSecurityIDSource, securityIDSource);
        
        sendFixMessage(msg);
    }

    public void orderReplyMultiFilled(Message orderMsg, String leavesQty, String lastShares) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        }
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, price);
        }
        msg.setField(Constants.TAGLastShares, lastShares);
        msg.setField(Constants.TAGLeavesQty, leavesQty);
        msg.setField(Constants.TAGCumQty, Integer.parseInt(orderQty)-Integer.parseInt(leavesQty));
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }
    
    public void orderReplyMultiFilledFwd(Message orderMsg, String leavesQty, String lastShares, double spotRate, double forwardPoints) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        } else {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        }
        
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, spotRate);
            msg.setField(Constants.TAGLastForwardPoints, forwardPoints);
        }
        msg.setField(Constants.TAGLastShares, lastShares);
        msg.setField(Constants.TAGLeavesQty, leavesQty);
        msg.setField(Constants.TAGCumQty, Integer.parseInt(orderQty)-Integer.parseInt(leavesQty));
        msg.setField(Constants.TAGAvgPx, spotRate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }

    public void orderReplyFilledFwd(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        }else{
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        }
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        //msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLastPx, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, price);
            msg.setField(Constants.TAGLastForwardPoints, "0.0000");
        }
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }
    
    public void orderReplyFilledFwd(Message orderMsg, String point) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        }else{
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        }
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLastPx, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, Float.toString(Float.parseFloat(price)-Float.parseFloat(point)));
            msg.setField(Constants.TAGLastForwardPoints, point);
        }
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, Float.toString(Float.parseFloat(price)-Float.parseFloat(point)));//this should be 'price' after the fix
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }
    
    public void orderReplyFilledFwd(Message orderMsg, double spotRate, double forwardPoints) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        }else{
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        }
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        //msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLastPx, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, spotRate);
            msg.setField(Constants.TAGLastForwardPoints, forwardPoints);
        }
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, spotRate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }
    
    public void orderReplyFilledNDF(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        //msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        }
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        if(getFixVersion().endsWith("4.4"))
        {
            msg.setField(Constants.TAGLastSpotRate, price);
        }
        msg.setField(Constants.TAGLastForwardPoints, "0");
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }

    public void orderReplyFilled(Message orderMsg, String avgPx) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "orderid" + clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGLastSpotRate, avgPx);
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGAvgPx, avgPx);
        sendFixMessage(msg);
    }

    public void orderReplyCancel(Message orderMsg, String cumQty) throws Exception {

        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Cancelled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Cancelled);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, cumQty);
        sendFixMessage(msg);
    }

    public void orderReplyRejected(String clOrdId, String orderId) throws Exception {

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGExecID, "UNKNOWN");
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, "8");
        msg.setField(Constants.TAGOrdStatus, "8");
        sendFixMessage(msg);
    }

    public void orderReplyPartiallyFilled(Message orderMsg, String myAmount) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String secId = orderMsg.getStringFieldValue(Constants.TAGSecurityID);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        if(valueDateStr!=null) {
            msg.setField(Constants.TAGFutSettDate, valueDateStr);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGSide, side);
        if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGGrossTradeAmt, myAmount);
        msg.setField(Constants.TAGLeavesQty, Integer.parseInt(orderQty)-Integer.parseInt(myAmount));
        msg.setField(Constants.TAGCumQty, myAmount);
        msg.setField(Constants.TAGLastShares, orderQty);
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGiLastSpotRate, price);
        if(secId!=null)
        {
        msg.setField(Constants.TAGSecurityID, secId);

        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        }
        sendFixMessage(msg);
    }


    public void orderReplyPartiallyFilled(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String secId = orderMsg.getStringFieldValue(Constants.TAGSecurityID);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Filled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        if(valueDateStr!=null) {
            msg.setField(Constants.TAGFutSettDate, valueDateStr);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGSide, side);
        if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGOrderQty, orderQty);
       msg.setField(Constants.TAGLeavesQty, "100000");
        msg.setField(Constants.TAGCumQty, orderQty);
        msg.setField(Constants.TAGLastShares, orderQty);
        if(secId!=null)
        {
        msg.setField(Constants.TAGSecurityID, secId);

        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, "6");
        }
        sendFixMessage(msg);
    }

    public void orderReplyPartiallyFilledTreasury(Message orderMsg) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = orderMsg.getStringFieldValue(Constants.TAGSymbolSfx);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String secId = orderMsg.getStringFieldValue(Constants.TAGSecurityID);




        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Trade);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled);
        if(valueDateStr!=null) {
            msg.setField(Constants.TAGFutSettDate, valueDateStr);
        }
        if(symbol!=null) {
            msg.setField(Constants.TAGSymbol, symbol);
        }
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGSide, side);
        if(price!=null) {
            msg.setField(Constants.TAGPrice, price);
        }
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGOrderQty, orderQty);
       msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, orderQty);
        if(secId!=null)
        {
        msg.setField(Constants.TAGSecurityID, secId);

        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, "6");
        }
        sendFixMessage(msg);
    }
    
    public void orderReplyRejectedRFQ(Message order) throws Exception {
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "testOrdRej"+System.currentTimeMillis());
        msg.setField(Constants.TAGSecondaryClOrdID, order.getStringFieldValue(Constants.TAGSecondaryClOrdID));
        msg.setField(Constants.TAGClOrdID, order.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGExecID, "testExec"+System.currentTimeMillis());
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Rejected);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Rejected);
        msg.setField(Constants.TAGSettlDate, order.getStringFieldValue(Constants.TAGSettlDate));
        msg.setField(Constants.TAGSymbol, order.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGProduct, order.getStringFieldValue(Constants.TAGProduct));
        msg.setField(Constants.TAGSymbolSfx, order.getStringFieldValue(Constants.TAGSymbolSfx));
        msg.setField(Constants.TAGSide,  order.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGOrderQty,  order.getStringFieldValue(Constants.TAGOrderQty));
        msg.setField(Constants.TAGOrdType,  Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGPrice,  order.getStringFieldValue(Constants.TAGPrice));
        msg.setField(Constants.TAGCurrency,  order.getStringFieldValue(Constants.TAGCurrency));
        msg.setField(Constants.TAGLastSpotRate,  order.getStringFieldValue(Constants.TAGPrice));
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, order.getStringFieldValue(Constants.TAGOrderQty));
        msg.setField(Constants.TAGAvgPx, order.getStringFieldValue(Constants.TAGPrice));
        msg.setField(Constants.TAGTradeDate, new Date().toString());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGSettlCurrAmt, 
                Double.valueOf(order.getStringFieldValue(Constants.TAGPrice)) * Double.valueOf(order.getStringFieldValue(Constants.TAGOrderQty)));
        
        sendFixMessage(msg);
    }
    
    public void orderReplyRejected(Message order, String ordRejReason) throws Exception {
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "UNKNOWN");
        msg.setField(Constants.TAGClOrdID, order.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGExecID, "UNKNOWN");
        msg.setField(Constants.TAGExecTransType, getFixVersion().endsWith("4.2")?Constants.EXECTRANSTYPE_New:null);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Rejected);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Rejected);
        msg.setField(Constants.TAGOrdRejReason, ordRejReason);
        msg.setField(Constants.TAGFutSettDate, null);
        msg.setField(Constants.TAGSymbol, null);
        msg.setField(Constants.TAGSymbolSfx, null);
        msg.setField(Constants.TAGSide,  order.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGOrderQty,  null);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, "0");
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGVenueType, order.getStringFieldValue(Constants.TAGVenueType));
        
        sendFixMessage(msg);
    }

    public void orderReplyRejectedMtf(Message order, String ordRejReason, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, "UNKNOWN");
        msg.setField(Constants.TAGClOrdID, order.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGExecID, "UNKNOWN");
        msg.setField(Constants.TAGExecTransType, getFixVersion().endsWith("4.2")?Constants.EXECTRANSTYPE_New:null);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_Rejected);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_Rejected);
        msg.setField(Constants.TAGOrdRejReason, ordRejReason);
        msg.setField(Constants.TAGFutSettDate, null);
        msg.setField(Constants.TAGSymbol, null);
        msg.setField(Constants.TAGSymbolSfx, null);
        msg.setField(Constants.TAGSide,  order.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGOrderQty,  null);
        msg.setField(Constants.TAGLeavesQty, "0");
        msg.setField(Constants.TAGCumQty, "0");
        msg.setField(Constants.TAGAvgPx, "0");
        msg.setField(Constants.TAGVenueType, venueType);

        sendFixMessage(msg);
    }



    public void orderReplyRejected(Message order) throws Exception {
        this.orderReplyRejected(order, Constants.ORDREJREASON_OrderExceedsLimit);
    }
 
    public void orderReplyMultipleFills(Message orderMsg, String leavesQty, String cumQty, String lastShares) throws Exception {
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String valueDateStr = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, clOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGExecID, "execId"+clOrdId);
        msg.setField(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_New);
        msg.setField(Constants.TAGExecType, Constants.EXECTYPE_PartiallyFilled);
        msg.setField(Constants.TAGOrdStatus, Constants.ORDSTATUS_PartiallyFilled);
        msg.setField(Constants.TAGFutSettDate, valueDateStr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGLeavesQty, leavesQty);
        msg.setField(Constants.TAGCumQty, cumQty);
        msg.setField(Constants.TAGAvgPx, price);
        msg.setField(Constants.TAGLastShares, lastShares);
        sendFixMessage(msg);
    }

    public void sendApplicationPing(String pingID, String transTime) throws Exception{
        Message msg = new Message(MSGApplicationPing, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(pingID!=null) {
            msg.setField(TAGApplicationPingID, pingID);
        }
        if(transTime!=null) {
            msg.setField(Constants.TAGTransactTime, transTime);
        }
        session.send(msg.getMessage());
    }



    public void sendApplicationPingReply(String pingID, String transTime) throws Exception{
        Message msg = new Message(MSGApplicationPingReply, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(pingID!=null) {
            msg.setField(TAGApplicationPingID, pingID);
        }
        if(transTime!=null) {
            msg.setField(Constants.TAGTransactTime, transTime);
        }
        session.send(msg.getMessage());
    }

    public Map<String, Subscription> getActiveSubscriptionsSnapshot() {
        Map<String, Subscription> subMap =  new HashMap<String, Subscription>();
        subMap.putAll(subscriptions);
        return subMap;
    }

    private void handleOrderSingle(Message message) throws Exception{
        if (replyImmediately == true){
            orderReplyFilled(message);
        } else {
            orderQueue.add(message);
        }
    }
    
    private void handleOrderMultiLeg(Message message) throws Exception{
        orderMultiLegQueue.add(message);
    }

    private void handleExecutionReport(Message message) throws Exception{
        orderQueue.add(message);
    }
    
    private void handleExecutionAcknowledgement(Message message) throws Exception{
        ackQueue.add(message);
    }

    private void handleQuoteResponse(Message message) throws Exception{
        orderQueue.add(message);
    }

    private void handleQuoteRequest(Message message) throws Exception
    {
        String requestId = message.getStringFieldValue(Constants.TAGQuoteReqID);
        String clOrdId = message.getStringFieldValue(Constants.TAGClOrdID);
        String noRelatedSym = message.getStringFieldValue(Constants.TAGNoRelatedSym);
        String fixingDate = message.getStringFieldValue(Constants.TAGFixingDate);
        String fixingDate2 = message.getStringFieldValue(Constants.TAGFixingDate2);
        String inCompetition = message.getStringFieldValue(Constants.TAGInCompetition);
        String numOfCompetitors = message.getStringFieldValue(Constants.TAGNumOfCompetitors);
        String venueType = message.getStringFieldValue(Constants.TAGiVenueType);
        
        Integer noRelatedSymNumber = Integer.parseInt(noRelatedSym);

        String qty = null;
        String[] qtys = message.getParser().getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGOrderQty, noRelatedSymNumber);
        if (qtys != null && qtys.length >0){
            qty = qtys[0];
        }

        String valueDateStr = null;
        String[] valueDateStrs = message.getParser().getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGFutSettDate, noRelatedSymNumber);
        if (valueDateStrs != null && valueDateStrs.length >0){
            valueDateStr = valueDateStrs[0];
        }
        
        
        String qty2 = null;
        String[] qty2s = message.getParser().getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGOrderQty2, noRelatedSymNumber);
        if (qty2s != null && qty2s.length >0){
            qty2 = qty2s[0];
        }

        String valueDateStr2 = null;
        String[] valueDateStr2s = message.getParser().getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGFutSettDate2, noRelatedSymNumber);
        if (valueDateStr2s != null && valueDateStr2s.length >0){
            valueDateStr2 = valueDateStr2s[0];
        }
        
        
        String type = null;
        String[] types = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGQuoteRequestType,
                noRelatedSymNumber);
        if (types != null && types.length >0){
            type = types[0];
        }

        validateTag(Constants.TAGNoRelatedSym, "1", noRelatedSym);
        IFixGroup[] relatedSyms = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoRelatedSym, Constants.TAGiSymbol);
        assertTrue("Incorrect number of relatedSym in QuoteRequest", relatedSyms.length == 1);
        IFixGroup symGroup = relatedSyms[0]; 

        String symbol = symGroup.getStringValFor(Constants.TAGiSymbol);
        String symbolSfx = symGroup.getStringValFor(Constants.TAGiSymbolSfx);
        String securityID = symGroup.getStringValFor(Constants.TAGiSecurityID);
        String securityIDSource = symGroup.getStringValFor(Constants.TAGiSecurityIDSource);
        String maturityDate = symGroup.getStringValFor(Constants.TAGiMaturityDate);
        String issueDate = symGroup.getStringValFor(Constants.TAGiIssueDate);
        String factor = symGroup.getStringValFor(Constants.TAGiFactor);
        String cpRegType = symGroup.getStringValFor(Constants.TAGiCPRegType);
        String datedDate = symGroup.getStringValFor(Constants.TAGiDatedDate);
        String interestAccrualDate = symGroup.getStringValFor(Constants.TAGiInterestAccrualDate);
        String transacTime = symGroup.getStringValFor(Constants.TAGiTransactTime);
        String streamRef = symGroup.getStringValFor(Constants.TAGiStreamReference);
        String securityType = symGroup.getStringValFor(Constants.TAGiSecurityType);
        
        //Handling RFQ Multi-Leg (167=MLEG)
        RFQLeg[] rfqLegs = null;
        if(securityType!=null && securityType.equals(Constants.SECURITYTYPE_MultiLegContract)){
            validateTagNotNull(Constants.TAGNoLegs, symGroup.getStringValFor(Constants.TAGiNoLegs));
            int noLegs = Integer.valueOf(symGroup.getStringValFor(Constants.TAGiNoLegs));
            IFixGroup[] quoteRequestLegs = symGroup.getDynamicSubGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);
            assertTrue("Incorrect number of RFQ legs in QuoteRequest", quoteRequestLegs.length == noLegs);
            
            rfqLegs = new RFQLeg[noLegs];
            int currentLegIndex = 0;
            
            for(IFixGroup leg:quoteRequestLegs){
                
                //Handling legAllocs
                validateTagNotNull(Constants.TAGiNoLegAllocs, leg.getStringValFor(Constants.TAGiNoLegAllocs));
                int noLegAllocs = Integer.valueOf(leg.getStringValFor(Constants.TAGiNoLegAllocs));
                
                IFixGroup[] legAllocs = leg.getDynamicSubGroupDataFor(Constants.TAGiNoLegAllocs, Constants.TAGiLegAllocAccount);
                assertTrue("Incorrect number of allocations in RFQ leg in QuoteRequest", legAllocs.length == noLegAllocs);
                Allocation[] allocsForLeg = new Allocation[noLegAllocs];
                
                for(int i=0;i<legAllocs.length;i++){
                    String legAllocAccount = legAllocs[i].getStringValFor(Constants.TAGiLegAllocAccount);
                    String legAllocQty = legAllocs[i].getStringValFor(Constants.TAGiLegAllocQty);
                    
                    allocsForLeg[i] = new Allocation(legAllocAccount, null, legAllocQty);
                }
                
                //Handling other tags in the leg
                String legSymbol = leg.getStringValFor(Constants.TAGiLegSymbol);
                String legSide = leg.getStringValFor(Constants.TAGiLegSide);
                String legCurrency = leg.getStringValFor(Constants.TAGiLegCurrency);
                String legOrderQty = leg.getStringValFor(Constants.TAGiLegQty);
                String legSettlDate = leg.getStringValFor(Constants.TAGiLegSettlDate);
                String legRefID = leg.getStringValFor(Constants.TAGiLegRefID);
                
                rfqLegs[currentLegIndex] = new RFQLeg(legSymbol, 
                        legSide, 
                        legCurrency, 
                        allocsForLeg, 
                        legOrderQty, 
                        legSettlDate, 
                        legRefID);
                
                currentLegIndex++;
            }
        }

        //rfq specific fields - assuming no switches


        String product = null;
        String[] products = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGProduct, noRelatedSymNumber);
        if (products != null && products.length > 0){
            product = products[0];
        }


        String quoteType = null;
        String[] quoteTypes = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGQuoteType, noRelatedSymNumber);
        if (quoteTypes != null && quoteTypes.length >0){
            quoteType = quoteTypes[0];
        }

        String account = null;
        String[] accounts = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGAccount, noRelatedSymNumber);
        if (accounts != null && accounts.length >0){
            account = accounts[0];
        }

        String version = "FIX."+ getFixVersion();
        String noLegs = null;
        Integer noLegsNumber = null;
        String[] noLegss = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, noRelatedSymNumber);

        if (noLegss != null && noLegss.length>0){
            noLegs = noLegss[0];
            noLegsNumber = Integer.parseInt(noLegs);
        }

//        System.out.println("noLegs = " + noLegs);
//        System.out.println("noLegsNumber = " + noLegsNumber);

        String     legSymbol = null;
        String[]   legSymbols= null;
        String[][] legSymbolss;


        String     legSymbolSfx = null;
        String[]   legSymbolSfxs = null;
        String[][] legSymbolSfxss;

        String     legSecurityID   = null;
        String[]   legSecurityIDs  = null;
        String[][] legSecurityIDss;

        String     legSecurityIDSrc   = null;
        String[]   legSecurityIDSrcs  = null;
        String[][] legSecurityIDSrcss;

        String     legSecurityType   = null;
        String[]   legSecurityTypes  = null;
        String[][] legSecurityTypess;

        String     legMatDate   = null;
        String[]   legMatDates  = null;
        String[][] legMatDatess;

        String     legQty   = null;
        String[]   legQtys  = null;
        String[][] legQtyss;

        String     legSettDate   = null;
        String[]   legSettDates  = null;
        String[][] legSettDatess;

        if (noLegsNumber != null && noLegsNumber>0){
        try{

            legSymbolss = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegSymbol, noLegsNumber, version);

            if (legSymbolss != null && legSymbolss.length >0){
                legSymbols = legSymbolss[0];
            }
            if (legSymbols != null && legSymbols.length >0){
                legSymbol = legSymbols[0];
            }



            legSymbolSfxss = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegSymbolSfx, noLegsNumber, version);
            if (legSymbolSfxss != null && legSymbolSfxss.length >0){
                legSymbolSfxs = legSymbolSfxss[0];
            }
            if (legSymbolSfxs != null && legSymbolSfxs.length >0){
                legSymbolSfx = legSymbolSfxs[0];
            }


            legSecurityIDss = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegSecurityID, noLegsNumber, version);
            if (legSecurityIDss != null && legSecurityIDss.length >0){
                legSecurityIDs = legSecurityIDss[0];
            }
            if (legSecurityIDs != null && legSecurityIDs.length >0){
                legSecurityID = legSecurityIDs[0];
            }


            legSecurityIDSrcss = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegSecurityIDSource, noLegsNumber, version);
            if (legSecurityIDSrcss != null && legSecurityIDSrcss.length >0){
                legSecurityIDSrcs = legSecurityIDSrcss[0];
            }
            if (legSecurityIDSrcs != null && legSecurityIDSrcs.length >0){
                legSecurityIDSrc = legSecurityIDSrcs[0];
            }


            legSecurityTypess = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegSecurityType, noLegsNumber, version);
            if (legSecurityTypess != null && legSecurityTypess.length >0){
                legSecurityTypes = legSecurityTypess[0];
            }
            if (legSecurityTypes != null && legSecurityTypes.length >0){
                legSecurityType = legSecurityTypes[0];
            }





            legMatDatess = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegMaturityDate, noLegsNumber, version);
            if (legMatDatess != null && legMatDatess.length >0){
                legMatDates = legMatDatess[0];
            }
            if (legMatDates != null && legMatDates.length >0){
                legMatDate = legMatDates[0];
            }




            legQtyss = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegQty, noLegsNumber, version);
            if (legQtyss != null && legQtyss.length >0){
                legQtys = legQtyss[0];
            }
            if (legQtys != null && legQtys.length >0){
                legQty = legQtys[0];
            }



            legSettDatess = message.getSubGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGNoLegs, FixTagConstants.TAGLegFutSettDate, noLegsNumber, version);
            if (legSettDatess != null && legSettDatess.length >0){
                legSettDates = legSettDatess[0];
            }
            if (legSettDates != null && legSettDates.length >0){
                legSettDate = legSettDates[0];
            }
        } catch (NullPointerException e) {
           e.printStackTrace();
        }
        }
        
//        IFixGroup[] noRelatedSyms = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoRelatedSym, Constants.TAGiSymbol);
//        assertNotNull("NoRelatedSym should exist in QuoteRequest", noRelatedSyms);
        String noInstrumentParties = symGroup.getStringValFor(Constants.TAGiNoInstrumentParties);
        InstrumentParty[] instrumentParties = null;
        if(noInstrumentParties!=null){
            instrumentParties = new InstrumentParty[Integer.valueOf(noInstrumentParties)];
            
            IFixGroup[] instrumentPartyGrps = symGroup.getDynamicSubGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID);
            assertNotNull("Error in InstrumentParties component in QuoteRequest.", instrumentPartyGrps);
            assertTrue("Error in number of InstrumentParties in QuoteRequest.", Integer.valueOf(noInstrumentParties)==instrumentPartyGrps.length);
            for(int i=0;i<instrumentPartyGrps.length;i++){
                instrumentParties[i] = new InstrumentParty(instrumentPartyGrps[i].getStringValFor(Constants.TAGiInstrumentPartyID),
                        instrumentPartyGrps[i].getStringValFor(Constants.TAGiInstrumentPartyIDSource),
                        instrumentPartyGrps[i].getStringValFor(Constants.TAGiInstrumentPartyRole));
            }
        }
        
        String noPartyIDs = symGroup.getStringValFor(Constants.TAGiNoPartyIDs);
        Party[] parties = null;
        if(noPartyIDs!=null){
            parties = new Party[Integer.valueOf(noPartyIDs)];
            
            IFixGroup[] partyIDs = symGroup.getDynamicSubGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID);
            assertNotNull("Error in Parties component in QuoteRequest.", partyIDs);
            assertTrue("Error in number of Parties in QuoteRequest.", Integer.valueOf(noPartyIDs)==partyIDs.length);
            for(int i=0;i<partyIDs.length;i++){
                parties[i] = new Party(partyIDs[i].getStringValFor(Constants.TAGiPartyID), null, partyIDs[i].getStringValFor(Constants.TAGiPartyRole));
            }
        }
        
        
        String noAllocs = message.getStringFieldValue(Constants.TAGNoAllocs);
        Allocation[] allocations = null;
        if(noAllocs!=null){
            allocations = new Allocation[Integer.valueOf(noAllocs)];
            
            IFixGroup[] allocs = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            assertNotNull("Error in allocation component in QuoteRequest.", allocs);
            assertTrue("Error in number of allocations in QuoteRequest.", Integer.valueOf(noAllocs)==allocs.length);
            for(int i=0;i<allocs.length;i++){
                allocations[i] = new Allocation(allocs[i].getStringValFor(Constants.TAGiAllocAccount),
                        allocs[i].getStringValFor(Constants.TAGiIndividualAllocID),
                        allocs[i].getStringValFor(Constants.TAGiAllocQty));
                allocations[i].settlCurrAmt = allocs[i].getStringValFor(Constants.TAGiSettlCurrAmt);
                }
        }
        
        String priceType = null;
        String[] priceTypes = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGPriceType, noRelatedSymNumber);
        if (priceTypes != null && priceTypes.length >0){
            priceType = priceTypes[0];
        }

        String side = null;
        String[] sides = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGSide, noRelatedSymNumber);
        if (sides != null && sides.length >0){
            side = sides[0];
        }

        String currency = null;
        String[] currencys = message.getGroupDataFor(FixTagConstants.TAGNoRelatedSym, FixTagConstants.TAGCurrency, noRelatedSymNumber);
        if (currencys != null && currencys.length >0){
            currency = currencys[0];
        }
        
        //rfq trading - treasury
        if(noLegs!=null)
        {
            Subscription sub = new Subscription(requestId, symbol, valueDateStr, qty, symbolSfx, securityID,
                    noRelatedSym, product, quoteType, account, noLegs, legSymbol, legSymbolSfx, legSecurityID,
                    legSecurityIDSrc, legSecurityType, legMatDate, legQty, legSettDate, priceType);
            sub.rfqLegs = rfqLegs;
            sub.securityType = securityType;
            sub.inCompetition = inCompetition;
            sub.numOfCompetitors = numOfCompetitors;
            subscriptions.put(requestId, sub);
            System.out.println("setup sub for multileg=" + sub);
            return;
        }

        if(fixingDate!=null)
        {
            
            Subscription sub = new Subscription(requestId, symbol, valueDateStr, qty, symbolSfx, securityID,
                    noRelatedSym, product, quoteType, account, noLegs, legSymbol, legSymbolSfx, legSecurityID,
                    legSecurityIDSrc, legSecurityType, legMatDate, legQty, legSettDate, priceType, fixingDate);

            if(side!=null) {
                sub.side = side;
            }
            if(currency!=null) {
                sub.currency = currency;
            }
            if(valueDateStr2!=null) {
                sub.valueDate2 = valueDateStr2;
            }
            if(qty2!=null) {
                sub.amount2 = qty2;
            }
            if(clOrdId!=null) {
                sub.clOrdId = clOrdId;
            }
            if(securityType!=null) {
                sub.securityType = securityType;
            }
            if(venueType!=null) {
                sub.venueType = venueType;
            }
            if(streamRef!=null) {
                sub.streamRef = streamRef;
            }
            if(fixingDate2!=null) {
                sub.fixingDate2 = fixingDate2;
            }
            if(allocations!=null) {
                sub.allocations = allocations;
            }
            if(instrumentParties!=null) {
                sub.instrumentParties = instrumentParties;
            }
            if(parties!=null) {
                sub.parties = parties;
            }

            subscriptions.put(requestId, sub);
            System.out.println("setup sub=" + sub);
        }
        //esp trading
        else if(symbol!=null)
        {
            if (type == null) { // subscribe
                Subscription sub = new Subscription(requestId, symbol, valueDateStr, qty, symbolSfx, securityID);

                //rfq FX trading
                sub.clOrdId = clOrdId;
                sub.side = side;
                sub.valueDate = valueDateStr;
                sub.product = product;
                sub.currency = currency;
                sub.valueDate2 = valueDateStr2;
                sub.amount2 = qty2;
                sub.streamRef = streamRef;
                sub.securityType = securityType;
                sub.venueType = venueType;
                sub.allocations = allocations;
                sub.parties = parties;
                sub.securityIDSource = securityIDSource;
                sub.maturityDate = maturityDate;
                sub.issueDate = issueDate;
                sub.factor = factor;
                sub.priceType = cpRegType;
                sub.datedDate = datedDate;
                sub.interestAccrualDate = interestAccrualDate;
                sub.transactTime = transacTime;
                sub.noRelatedSym = noRelatedSym;
                sub.rfqLegs = rfqLegs;

                subscriptions.put(requestId, sub);

                System.out.println("setup esp sub=" + sub);
            }
            else if (type.equals("3")){ //unsubscribe
                Subscription sub = subscriptions.remove(requestId);
                if (sub == null) {
                    System.err.println("attempt to unsubscribe empty subscription");
                }else{
                    System.out.println("Unsubscribe QuoteRequest: "+requestId);
                }
            } else {
                throw new IllegalArgumentException("unknown quote request type=" + type);
            }
        }

        else
        {
            throw new IllegalArgumentException("symbol not set");
        }

    }



    private void handleApplicationPing(Message message) throws Exception{
        Message msg = new Message(MSGApplicationPingReply, getSenderCompId(), getTargetCompId(), getFixVersion());
        String applicationPingId = message.getStringFieldValue(TAGApplicationPingID);
        msg.setField(TAGApplicationPingID, applicationPingId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        session.send(msg.getMessage());

    }
    private void handleApplicationPingReply(Message message) throws Exception{
        pingQueue.add(message);
    }

    private void handleBusinessReject(Message message) throws Exception {
        rejectQueue.add(message);
    }
    private void handleOrderTimeout(Message message) throws Exception{
        rejectQueue.add(message);
    }
    private void handleDontKnowTrade(Message message) throws Exception {
        rejectQueue.add(message);
    }

    public Message getMessageFromRejectQueue(long timeout) throws Exception
    {
        Message msg = null;
        try
        {
            msg = rejectQueue.poll(timeout, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromPingQueue(long timeout) throws Exception
    {
        Message msg = null;
        try
        {
            msg = pingQueue.poll(timeout, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return msg;
    }

    public String getUserName()
    {
        return super.getSenderCompId();
    }

    @Deprecated
    public String getPartyName()
    {
        return getPartyId();
    }

    public Map<String, Quote> getTopOfBookPrices() {
        return topOfBookPrices;
    }
    
    public void startReplyingImmediately(){
        replyImmediately = true;
    }
    
    public void stopReplyingImmediately(){
        replyImmediately = false;
    }
    
    @Override
    public void logout() {
        //Refresh maker data before logout
        try{
            this.refresh();
        }catch(Exception e){
            e.printStackTrace();
        }
        super.logout();
    }
    
    public void doAssertionCheckForOrderReceived(Message takerOrder, TakerTestSession taker, Message makerOrder) throws Exception
    {        
        doAssertionCheckForOrderReceived(takerOrder, taker, makerOrder,
                takerOrder.getStringFieldValue(Constants.TAGPrice));
    }
    
    public void doAssertionCheckForOrderReceived(Message takerOrder, TakerTestSession taker, Message makerOrder, String price) throws Exception
    {
        assertNotNull("no order was received", makerOrder);
        validateTagNotNull(Constants.TAGClOrdID, makerOrder.getStringFieldValue(Constants.TAGClOrdID));
        validateTag(Constants.TAGNoPartyIDs, "2", makerOrder.getStringFieldValue(Constants.TAGNoPartyIDs));
        
        int checkedParties = 0;
        boolean hasTakerParty = false;
        boolean hasTakerUser = false;
        
        IFixGroup[] parties = makerOrder.getParser().getDynamicGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID);
        assertTrue("Unexpected party size in maker received order", parties.length==2);
        
        for(IFixGroup party:parties){
            if(party.getStringValFor(Constants.TAGiPartyRole).equals("1")){ //taker party
                //validateTag(Constants.TAGPartyID, taker.getPartyId(), party.getStringValFor(Constants.TAGiPartyID));//TODO remove
                hasTakerParty = true;
                checkedParties++;
            }else if(party.getStringValFor(Constants.TAGiPartyRole).equals("3")){ //taker user
                //validateTag(Constants.TAGPartyID, taker.getUserName(), party.getStringValFor(Constants.TAGiPartyID));//TODO remove
                hasTakerUser = true;
                checkedParties++;
            } else {
                fail("Unexpected partyID");
            }
        }
        
        assertTrue("Missing partyID", checkedParties==2);
        assertTrue("Missing partyID for taker party", hasTakerParty);
        assertTrue("Missing partyID for taker user", hasTakerUser);
        
        validateTagNotNull(Constants.TAGSettlDate, makerOrder.getStringFieldValue(Constants.TAGSettlDate)); 
        validateTag(Constants.TAGHandlInst, Constants.HANDLINST_AutoPublicBrokerOK, makerOrder.getStringFieldValue(Constants.TAGHandlInst));
        validateTag(Constants.TAGSymbol, takerOrder.getStringFieldValue(Constants.TAGSymbol), makerOrder.getStringFieldValue(Constants.TAGSymbol));
        
        if(takerOrder.getStringFieldValue(Constants.TAGSymbolSfx) == null) {
            validateTag(Constants.TAGSymbolSfx, "SP", makerOrder.getStringFieldValue(Constants.TAGSymbolSfx));
        } else {
            validateTag(Constants.TAGSymbolSfx, takerOrder.getStringFieldValue(Constants.TAGSymbolSfx), makerOrder.getStringFieldValue(Constants.TAGSymbolSfx));
        }
        
        validateTag(Constants.TAGProduct, Constants.PRODUCT_Currency, makerOrder.getStringFieldValue(Constants.TAGProduct));        
        
        if(takerOrder.getStringFieldValue(Constants.TAGSecurityType) == null) {
            validateTag(Constants.TAGSecurityType, "FOR", makerOrder.getStringFieldValue(Constants.TAGSecurityType));
        } else {
            validateTag(Constants.TAGSecurityType, takerOrder.getStringFieldValue(Constants.TAGSecurityType), makerOrder.getStringFieldValue(Constants.TAGSecurityType));
        }   

        validateTag(Constants.TAGSide, takerOrder.getStringFieldValue(Constants.TAGSide), makerOrder.getStringFieldValue(Constants.TAGSide));        

        //validateTag(Constants.TAGOrderQty, takerOrder.getStringFieldValue(Constants.TAGMinQty), makerOrder.getStringFieldValue(Constants.TAGOrderQty));//TODO    
        validateTagNotNull(Constants.TAGOrderQty, makerOrder.getStringFieldValue(Constants.TAGOrderQty));
        validateTag(Constants.TAGOrdType, Constants.ORDTYPE_ForexPreviouslyQuoted, makerOrder.getStringFieldValue(Constants.TAGOrdType));     
        
        validateTag(Constants.TAGPrice, price, makerOrder.getStringFieldValue(Constants.TAGPrice));   
        validateTag(Constants.TAGCurrency, takerOrder.getStringFieldValue(Constants.TAGCurrency), makerOrder.getStringFieldValue(Constants.TAGCurrency));     
        validateTagNotNull(Constants.TAGQuoteID, makerOrder.getStringFieldValue(Constants.TAGQuoteID)); 
        validateTag(Constants.TAGTimeInForce, Constants.TIMEINFORCE_FillOrKill, makerOrder.getStringFieldValue(Constants.TAGTimeInForce));        
        validateTag(Constants.TAGiAggressorIndicator, "Y", makerOrder.getStringFieldValue(Constants.TAGiAggressorIndicator));   
        validateTagNotNull(Constants.TAGStreamReference, makerOrder.getStringFieldValue(Constants.TAGStreamReference)); 
    }
    
    
    public void doAssertionCheckForRFQOrder(Subscription sub, TakerTestSession routedTaker, Message makerOrder, String side, Message quote, double spread) throws Exception
    {
        assertNotNull("no order was received", makerOrder);
        validateTag(Constants.TAGClOrdID, sub.clOrdId, makerOrder.getStringFieldValue(Constants.TAGClOrdID));
        validateTag(Constants.TAGSecondaryClOrdID, sub.requestId, makerOrder.getStringFieldValue(Constants.TAGSecondaryClOrdID));
        validateTag(Constants.TAGSettlDate, sub.valueDate, makerOrder.getStringFieldValue(Constants.TAGSettlDate));
        
        boolean isNDF = (sub.securityType.equals(Constants.SECURITYTYPE_ForeignExchangeNDF));
        boolean isMTF = sub.venueType != null && sub.venueType.equals("M");
        if(isNDF) {
            if(isMTF) {
                //TBD: for MTF NDF, this is not decided.
                validateTag(Constants.TAGNoPartyIDs, "2", makerOrder.getStringFieldValue(Constants.TAGNoPartyIDs));
            }else{
            validateTag(Constants.TAGNoPartyIDs, "4", makerOrder.getStringFieldValue(Constants.TAGNoPartyIDs));
            }
        } else {
            validateTag(Constants.TAGNoPartyIDs, "2", makerOrder.getStringFieldValue(Constants.TAGNoPartyIDs));
        }
        
        int checkedParties = 0;
        boolean hasTakerParty = false;
        boolean hasTakerUser = false;
        boolean hasExecutionVenue = false;
        boolean hasDataRepository = false;
        
        IFixGroup[] parties = makerOrder.getParser().getDynamicGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID);
        
        if(isNDF) {
            if(isMTF) {
                //TBD: for MTF NDF, this is not decided.
                assertTrue("Unexpected party size in maker received order", parties.length==2);
            }else {
            assertTrue("Unexpected party size in maker received order", parties.length==4);
            }
        } else {
            assertTrue("Unexpected party size in maker received order", parties.length==2);
        }
        
        String executingFirm = routedTaker.getPartyId();
        String clientID = routedTaker.getUserName();
        
        if(sub.parties!=null){
            for(Party party:sub.parties){
                if(party.partyRole.equals("1")) {
                    executingFirm = party.partyID;
                } else if(party.partyRole.equals("3")) {
                    clientID = party.partyID;
                }
            }
        }
        
        for(IFixGroup party:parties){
            if(party.getStringValFor(Constants.TAGiPartyRole).equals("1")){ //taker party
                validateTag(Constants.TAGPartyID, executingFirm, party.getStringValFor(Constants.TAGiPartyID));
                hasTakerParty = true;
                checkedParties++;
            }else if(party.getStringValFor(Constants.TAGiPartyRole).equals("3")){ //taker user
                validateTag(Constants.TAGPartyID, clientID, party.getStringValFor(Constants.TAGiPartyID));
                hasTakerUser = true;
                checkedParties++;
            }else if(party.getStringValFor(Constants.TAGiPartyRole).equals("73")){ //Execution Venue
                validateTag(Constants.TAGPartyID, "SwapEx", party.getStringValFor(Constants.TAGiPartyID));
                hasExecutionVenue = true;
                checkedParties++;
            }else if(party.getStringValFor(Constants.TAGiPartyRole).equals("102")){ //Data Repository
                validateTag(Constants.TAGPartyID, "DTCC", party.getStringValFor(Constants.TAGiPartyID));
                hasDataRepository = true;
                checkedParties++;
            } else {
                fail("Unexpected partyID");
            }
        }
        
        if(isNDF){
            if(isMTF) {
                //TBD: for MTF NDF, this is not decided.
            }else {
            assertTrue("Missing partyID", checkedParties==4);
            assertTrue("Missing partyID for Execution Venue", hasExecutionVenue);
            assertTrue("Missing partyID for Data Repository", hasDataRepository);
            }
        }else{
            assertTrue("Missing partyID", checkedParties==2);
        }
        assertTrue("Missing partyID for taker party", hasTakerParty);
        assertTrue("Missing partyID for taker user", hasTakerUser);
        
        validateTag(Constants.TAGSymbol, sub.symbol, makerOrder.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGSymbolSfx, sub.symbolSfx, makerOrder.getStringFieldValue(Constants.TAGSymbolSfx));
        validateTag(Constants.TAGProduct, sub.product, makerOrder.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSecurityType, sub.securityType, makerOrder.getStringFieldValue(Constants.TAGSecurityType));
        
        String tradeSide, price, price2 = null;
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
        Quote sentQuote = (Quote)this.getTopOfBookPrices().get(sub.requestId);
        
        if(!termsTrading){
            if(side.equals(Constants.SIDE_Buy) || side.equals(Constants.SIDE_TwoWayBuy)){
                tradeSide = Constants.SIDE_Buy;
                price = sentQuote.offerPrice;
                //price = quote.getStringFieldValue(Constants.TAGOfferPx);
                price2 = quote.getStringFieldValue(Constants.TAGBidPxFar);
            }else{
                tradeSide = Constants.SIDE_Sell;
                price = sentQuote.bidPrice;
                //price = quote.getStringFieldValue(Constants.TAGBidPx);
                price2 = quote.getStringFieldValue(Constants.TAGOfferPxFar);
            }
        }else{
            if(side.equals(Constants.SIDE_Buy) || side.equals(Constants.SIDE_TwoWayBuy)){
                tradeSide = Constants.SIDE_Buy;
                price = sentQuote.bidPrice;
                //price = quote.getStringFieldValue(Constants.TAGBidPx);
                price2 = quote.getStringFieldValue(Constants.TAGOfferPxFar);
            }else{
                tradeSide = Constants.SIDE_Sell;
                price = sentQuote.offerPrice;
                //price = quote.getStringFieldValue(Constants.TAGOfferPx);
                price2 = quote.getStringFieldValue(Constants.TAGBidPxFar);
            }
        }
        
        validateTag(Constants.TAGSide, tradeSide, makerOrder.getStringFieldValue(Constants.TAGSide));
        validateTagNotNull(Constants.TAGTransactTime, makerOrder.getStringFieldValue(Constants.TAGTransactTime)); 
        validateTag(Constants.TAGOrderQty, sub.amount, makerOrder.getStringFieldValue(Constants.TAGOrderQty));
        validateTag(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted, makerOrder.getStringFieldValue(Constants.TAGOrdType));
        validatePrice(Constants.TAGPrice, price, makerOrder.getStringFieldValue(Constants.TAGPrice));
        validateTag(Constants.TAGCurrency, sub.currency, makerOrder.getStringFieldValue(Constants.TAGCurrency));
        validateTagNotNull(Constants.TAGQuoteID, makerOrder.getStringFieldValue(Constants.TAGQuoteID)); 
        
        validateTag(Constants.TAGSettlDate2, sub.valueDate2, makerOrder.getStringFieldValue(Constants.TAGSettlDate2));
        validateTag(Constants.TAGOrderQty2, sub.amount2, makerOrder.getStringFieldValue(Constants.TAGOrderQty2));
        validateTag(Constants.TAGPrice2, price2, makerOrder.getStringFieldValue(Constants.TAGPrice2));
        
        validateTag(Constants.TAGFixingDate, sub.fixingDate, makerOrder.getStringFieldValue(Constants.TAGFixingDate));
        validateTag(Constants.TAGFixingDate2, sub.fixingDate2, makerOrder.getStringFieldValue(Constants.TAGFixingDate2));
        
        boolean isSwap = (price2!=null);
        
        if(isNDF && !isMTF){
            
            int checkedRegulatoryTradeIDs = 0;
            boolean hasNearLegID = false;
            boolean hasFarLegID = false;
            
            IFixGroup[] regulatoryTradeIDs = makerOrder.getParser()
                    .getDynamicGroupDataFor(Constants.TAGiNoRegulatoryTradeIDs, Constants.TAGiRegulatoryTradeID);
            
            if(isSwap){
                validateTag(Constants.TAGNoRegulatoryTradeIDs, "2", makerOrder.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
                assertTrue("Unexpected regulatory Trade ID size in maker received order", regulatoryTradeIDs.length==2);
            }else{
                validateTag(Constants.TAGNoRegulatoryTradeIDs, "1", makerOrder.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
                assertTrue("Unexpected regulatory Trade ID size in maker received order", regulatoryTradeIDs.length==1);
            }

            for(IFixGroup regulatoryTradeID:regulatoryTradeIDs){
                if(regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDType).equals("1")){
                    checkedRegulatoryTradeIDs++;
                    hasNearLegID = true;
                    validateTagNotNull(Constants.TAGiRegulatoryTradeID, regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeID));
                    validateTag(Constants.TAGiRegulatoryTradeIDSource, "1010000276", regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDSource));
                }else if(regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDType).equals("3")){
                    checkedRegulatoryTradeIDs++;
                    hasFarLegID = true;
                    validateTagNotNull(Constants.TAGiRegulatoryTradeID, regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeID));
                    validateTag(Constants.TAGiRegulatoryTradeIDSource, "1010000276", regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDSource));
                }
            }
            if(isSwap){
                assertTrue("Missing partyID", checkedRegulatoryTradeIDs==2);
                assertTrue("Missing regulatoryTradeID for Far Leg", hasFarLegID);
            } else {
                assertTrue("Missing partyID", checkedRegulatoryTradeIDs==1);
            }
            
            assertTrue("Missing regulatoryTradeID for Near Leg", hasNearLegID);
            validateTag(Constants.TAGVenueType, Constants.VENUETYPE_RegisteredMarket, makerOrder.getStringFieldValue(Constants.TAGVenueType));
            validateTag(Constants.TAGTrdType, Constants.TRDTYPE_RegularTrade, makerOrder.getStringFieldValue(Constants.TAGTrdType));
            
            if(sub.instrumentParties!=null){
                validateTag(Constants.TAGNoInstrumentParties, "1", makerOrder.getStringFieldValue(Constants.TAGNoInstrumentParties)); //Always 1
                IFixGroup[] instrumentPartyGrps = makerOrder.getParser().
                        getDynamicGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID);
                assertNotNull("Error getting InstrumentParties component in Quote", instrumentPartyGrps);
                assertTrue(instrumentPartyGrps.length==Integer.valueOf(makerOrder.getStringFieldValue(Constants.TAGNoInstrumentParties)));
                validateTag(Constants.TAGiInstrumentPartyID, sub.instrumentParties[0].instrumentPartyID
                        ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyID));
                validateTag(Constants.TAGiInstrumentPartyIDSource, sub.instrumentParties[0].instrumentPartyIDSource
                        ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyIDSource));
                validateTag(Constants.TAGiInstrumentPartyRole, sub.instrumentParties[0].instrumentPartyRole
                        ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyRole));
            }
            
        }else{
            validateTag(Constants.TAGNoRegulatoryTradeIDs, null, makerOrder.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
            //validateTag(Constants.TAGVenueType, null, makerOrder.getStringFieldValue(Constants.TAGVenueType));
            validateTag(Constants.TAGTrdType, null, makerOrder.getStringFieldValue(Constants.TAGTrdType));
        }
        
        
        if(sub.allocations!=null){
            validateTag(Constants.TAGiNoAllocs, Integer.toString(sub.allocations.length), 
                    makerOrder.getStringFieldValue(Constants.TAGiNoAllocs));
            
            IFixGroup[] allocations = makerOrder.getParser()
                    .getDynamicGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            assertNotNull("Error in allocation component in NewOrderSingle", allocations);
            assertTrue(allocations.length==sub.allocations.length);
            int checkedAllocs = 0;
            for(IFixGroup alloc:allocations){
                for(Allocation submittedAlloc:sub.allocations){
                    if(alloc.getStringValFor(Constants.TAGiAllocAccount).equals(submittedAlloc.allocAccount) &&
                            alloc.getStringValFor(Constants.TAGiAllocQty).equals(submittedAlloc.allocQty) &&
                            ((alloc.getStringValFor(Constants.TAGiSettlCurrAmt)!=null && alloc.getStringValFor(Constants.TAGiSettlCurrAmt).equals(submittedAlloc.settlCurrAmt)
                            || alloc.getStringValFor(Constants.TAGiSettlCurrAmt)==null))){
                        validateTag(Constants.TAGiAllocAccount, submittedAlloc.allocAccount, 
                                alloc.getStringValFor(Constants.TAGiAllocAccount)); // for printing log
                        validateTag(Constants.TAGiAllocQty, submittedAlloc.allocQty, 
                                alloc.getStringValFor(Constants.TAGiAllocQty)); // for printing log
                        validateTag(Constants.TAGiSettlCurrAmt, submittedAlloc.settlCurrAmt, 
                                alloc.getStringValFor(Constants.TAGiSettlCurrAmt)); // for printing log
                        checkedAllocs++;
                    }
                }
                
                if(sub.instrumentParties!=null){
                    
                    boolean hasNearLegUsiUtiCode = false;
                    boolean hasFarLegUsiUtiCode = false;
                    
                    String noAllocRegulatoryTradeIDs = (isSwap)?"2":"1";
                    validateTag(Constants.TAGiNoAllocRegulatoryTradeIDs, noAllocRegulatoryTradeIDs,
                            alloc.getStringValFor(Constants.TAGiNoAllocRegulatoryTradeIDs));

                    IFixGroup[] allocRegTradeIDs = alloc.getDynamicSubGroupDataFor(Constants.TAGiNoAllocRegulatoryTradeIDs, 
                            Constants.TAGiAllocRegulatoryTradeID);
                    assertNotNull("Error getting AllocRegulatoryTradeIDs in NewOrderSingle",allocRegTradeIDs);
                    assertTrue("Incorrect number of AllocRegulatoryTradeIDs",allocRegTradeIDs.length==Integer.valueOf(noAllocRegulatoryTradeIDs));
                    
                    for(IFixGroup allocRegTradeID:allocRegTradeIDs){
                        validateTagNotNull(Constants.TAGiAllocRegulatoryTradeID, 
                                allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeID));
                        validateTag(Constants.TAGiAllocRegulatoryTradeIDSource, "1010000276",
                                allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDSource));
                        validateTagNotNull(Constants.TAGiAllocRegulatoryTradeIDType, 
                                allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType));
                        if(allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType).equals("1")) {
                            hasNearLegUsiUtiCode = true;
                        } else if(allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType).equals("3")) {
                            hasFarLegUsiUtiCode = true;
                        }
                    }
                    
                    assertTrue("Missing near leg Usi/Uti code", hasNearLegUsiUtiCode);
                    if(isSwap) {
                        assertTrue("Missing far leg Usi/Uti code", hasFarLegUsiUtiCode);
                    }

                }
                
            }
            assertTrue("Error in allocation detail in NewOrderSingle", checkedAllocs==sub.allocations.length);
            
        }
    }
    
    public void doAssertionCheckForRFQQuoteRequest(Subscription sub, Allocation[] allocations, boolean isHubTrade) throws Exception
    {
        if(!isHubTrade && allocations!=null) {
            assertTrue("There is no allocation in QuoteRequest", sub.allocations!=null);
        }
    }
    
    public void doAssertionCheckForOrderTimeOut(Message orderTimeOut, String clOrdId) throws Exception
    {
        assertNotNull("Maker didnt receive OrderTimeOut", orderTimeOut);
        validateTag(Constants.TAGMsgType, MSGOrderTimeout, orderTimeOut.getStringFieldValue(Constants.TAGMsgType));
        validateTag(Constants.TAGClOrdID, clOrdId, orderTimeOut.getStringFieldValue(Constants.TAGClOrdID));
    }
    
    public void doAssertionCheckForDontKnowTrade(Message dontKnowTrade, String orderId, String execId, String dkReason,
            String symbol, String symbolSfx, String product, String side, String text) throws Exception
    {
        assertNotNull("Maker didnt receive DontKnowTrade", dontKnowTrade);
        validateTag(Constants.TAGMsgType, Constants.MSGDontKnowTrade, dontKnowTrade.getStringFieldValue(Constants.TAGMsgType));
        validateTag(Constants.TAGOrderID, orderId, dontKnowTrade.getStringFieldValue(Constants.TAGOrderID));
        validateTag(Constants.TAGExecID, execId, dontKnowTrade.getStringFieldValue(Constants.TAGExecID));
        validateTag(Constants.TAGDKReason, dkReason, dontKnowTrade.getStringFieldValue(Constants.TAGDKReason));
        validateTag(Constants.TAGSymbol, symbol, dontKnowTrade.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGSymbolSfx, symbolSfx, dontKnowTrade.getStringFieldValue(Constants.TAGSymbolSfx));
        validateTag(Constants.TAGProduct, product, dontKnowTrade.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSide, side, dontKnowTrade.getStringFieldValue(Constants.TAGSide));
        validateTag(Constants.TAGText, text, dontKnowTrade.getStringFieldValue(Constants.TAGText));
    }
    
    public void doAssertionCheckForExecutionAck(Message executionAck, String orderId, String clOrdId, String execId, String execAckStatus,
            String dkReason, String symbol, String symbolSfx, String product, String side, String orderQty, 
            String text, String LMUID, String venueType) throws Exception
    {
        assertNotNull("Maker didnt receive ExecutionAck", executionAck);
        validateTag(Constants.TAGMsgType, Constants.MSGExecutionAcknowledgement, executionAck.getStringFieldValue(Constants.TAGMsgType));
        validateTag(Constants.TAGOrderID, orderId, executionAck.getStringFieldValue(Constants.TAGOrderID));
        validateTag(Constants.TAGClOrdID, clOrdId, executionAck.getStringFieldValue(Constants.TAGClOrdID));
        validateTag(Constants.TAGExecAckStatus, execAckStatus, executionAck.getStringFieldValue(Constants.TAGExecAckStatus));
        validateTag(Constants.TAGExecID, execId, executionAck.getStringFieldValue(Constants.TAGExecID));
        validateTag(Constants.TAGDKReason, dkReason, executionAck.getStringFieldValue(Constants.TAGDKReason));
        validateTag(Constants.TAGSymbol, symbol, executionAck.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGSymbolSfx, symbolSfx, executionAck.getStringFieldValue(Constants.TAGSymbolSfx));
        validateTag(Constants.TAGProduct, product, executionAck.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSide, side, executionAck.getStringFieldValue(Constants.TAGSide));
        validateTag(Constants.TAGOrderQty, orderQty, executionAck.getStringFieldValue(Constants.TAGOrderQty));
        validateTag(Constants.TAGText, text, executionAck.getStringFieldValue(Constants.TAGText));
        validateTag(Constants.TAGLmuid, LMUID, executionAck.getStringFieldValue(Constants.TAGLmuid));
        validateTag(Constants.TAGVenueType, venueType, executionAck.getStringFieldValue(Constants.TAGVenueType));
    }

    public void submitRfqExecutionReport(Message orderMsg, Map<String, String> overwrittenTagAndValue) throws Exception {
        //below are default values, mostly read from orderMsg, some are null which can only be read from QUOTE msg.
        String orderId = "EROrderId" + System.currentTimeMillis();
        String secondaryClOrdId = orderMsg.getStringFieldValue(Constants.TAGSecondaryClOrdID);
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        String execId = "ERExecID";
        String execType = Constants.EXECTYPE_Filled; //filled by default, depends on FIX version?
        String orderStatus = Constants.ORDSTATUS_Filled; //filled by default, depends on FIX version?
        String orderRejectReason = null;
        String noPartyIDs = orderMsg.getStringFieldValue(Constants.TAGNoPartyIDs);
        Party [] parties = getParties(orderMsg);
        String settlDate = orderMsg.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = orderMsg.getStringFieldValue(Constants.TAGSymbol);
        String securityType = orderMsg.getStringFieldValue(Constants.TAGSecurityType);
        String noInstrumentParties = orderMsg.getStringFieldValue(Constants.TAGiNoInstrumentParties);
        InstrumentParty [] instrumentParties = getInstrumentParties(orderMsg);
        String side = orderMsg.getStringFieldValue(Constants.TAGSide);
        String orderQty = orderMsg.getStringFieldValue(Constants.TAGOrderQty);
        String price = orderMsg.getStringFieldValue(Constants.TAGPrice);
        String currency = orderMsg.getStringFieldValue(Constants.TAGCurrency);
        String lastSpotRate = null;//can be read from QUOTE msg: TAGOfferSpotRate|TAGBidSpotRate
        String lastForwardPoints = null;//can be read from QUOTE msg: TAGOfferForwardPoints|TAGBidForwardPoints
        String leavesQty = "0";
        String cumQty = orderQty;
        String avgPx = price;
        String tradeDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String transactionTime = dateFormat.format(new Date());
        String settlCurrAmt = Double.toString(Double.valueOf(price) * Double.valueOf(orderQty));
        String text = "";
        String settlDate2 = orderMsg.getStringFieldValue(Constants.TAGSettlDate2);
        String orderQty2 = orderMsg.getStringFieldValue(Constants.TAGOrderQty2);
        String lastForwardPoints2 = null; //can be read from QUOTE msg
        String price2 = orderMsg.getStringFieldValue(Constants.TAGPrice2);
        String settlCurrAmt2 = (price!=null&&orderQty2!=null)?Double.toString(Double.valueOf(price2) * Double.valueOf(orderQty2)):null;
        String fixingDate = orderMsg.getStringFieldValue(Constants.TAGFixingDate);
        String fixingDate2 = orderMsg.getStringFieldValue(Constants.TAGFixingDate2);
        String venueType = orderMsg.getStringFieldValue(Constants.TAGVenueType);

        //replace the values.
        orderId = replaceFieldValue(overwrittenTagAndValue, Constants.TAGOrderID, orderId);
        secondaryClOrdId = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSecondaryClOrdID, secondaryClOrdId);
        clOrdId = replaceFieldValue(overwrittenTagAndValue, Constants.TAGClOrdID, clOrdId);
        execId = replaceFieldValue(overwrittenTagAndValue, Constants.TAGExecID, execId);
        execType = replaceFieldValue(overwrittenTagAndValue, Constants.TAGExecType, execType);
        orderStatus = replaceFieldValue(overwrittenTagAndValue, Constants.TAGOrdStatus, orderStatus);
        orderRejectReason = replaceFieldValue(overwrittenTagAndValue, Constants.TAGOrdRejReason, orderRejectReason);
        noPartyIDs = replaceFieldValue(overwrittenTagAndValue, Constants.TAGNoPartyIDs, noPartyIDs);
        //parties = null;//ignore replace
        settlDate = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSettlDate, settlDate);
        symbol = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSymbol, symbol);
        securityType = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSecurityType, securityType);
        noInstrumentParties = replaceFieldValue(overwrittenTagAndValue, Constants.TAGNoInstrumentParties, noInstrumentParties);
        //instrumentParties = null;//ignore replace
        side = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSide, side);
        orderQty = replaceFieldValue(overwrittenTagAndValue, Constants.TAGOrderQty, orderQty);
        price = replaceFieldValue(overwrittenTagAndValue, Constants.TAGPrice, price);
        currency = replaceFieldValue(overwrittenTagAndValue, Constants.TAGCurrency, currency);
        lastSpotRate = replaceFieldValue(overwrittenTagAndValue, Constants.TAGLastSpotRate, lastSpotRate);
        lastForwardPoints = replaceFieldValue(overwrittenTagAndValue, Constants.TAGLastForwardPoints, lastForwardPoints);
        leavesQty = replaceFieldValue(overwrittenTagAndValue, Constants.TAGLeavesQty, leavesQty);
        cumQty = replaceFieldValue(overwrittenTagAndValue, Constants.TAGCumQty, cumQty);
        avgPx = replaceFieldValue(overwrittenTagAndValue, Constants.TAGAvgPx, avgPx);
        tradeDate = replaceFieldValue(overwrittenTagAndValue, Constants.TAGTradeDate, tradeDate);
        transactionTime = replaceFieldValue(overwrittenTagAndValue, Constants.TAGTransactTime, transactionTime);
        settlCurrAmt = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSettlCurrAmt, settlCurrAmt);
        text = replaceFieldValue(overwrittenTagAndValue, Constants.TAGText, text);
        settlDate2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSettlDate2, settlDate2);
        orderQty2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGOrderQty2, orderQty2);
        lastForwardPoints2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGLastForwardPoints2, lastForwardPoints2);
        price2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGPrice2, price2);
        settlCurrAmt2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGSettlCurrAmt2, settlCurrAmt2);
        fixingDate = replaceFieldValue(overwrittenTagAndValue, Constants.TAGFixingDate, fixingDate);
        fixingDate2 = replaceFieldValue(overwrittenTagAndValue, Constants.TAGFixingDate2, fixingDate2);
        venueType = replaceFieldValue(overwrittenTagAndValue, Constants.TAGVenueType, venueType);

        submitRfqExecutionReport(orderId, secondaryClOrdId, clOrdId, execId,
                execType, orderStatus, orderRejectReason, noPartyIDs, parties,
                settlDate, symbol, securityType, noInstrumentParties, instrumentParties,
                side, orderQty, price, currency, lastSpotRate, lastForwardPoints,
                leavesQty, cumQty, avgPx,
                tradeDate, transactionTime, settlCurrAmt, text, settlDate2,
                orderQty2, lastForwardPoints2, price2, settlCurrAmt2, fixingDate,
                fixingDate2, venueType);
    }
    
    public String getNameMappingUser() throws Exception{
        return makerProperties.getProperty("NAMEMAPPINGUSER");
    }
    
    public String getNameMappingFundsub() throws Exception{
        return makerProperties.getProperty("NAMEMAPPINGFUNDSUB");
    }

    private String replaceFieldValue(Map<String, String> map, String tag, String defaultValue){
        return map.containsKey(tag)?map.get(tag):defaultValue;
    }

    //the msg should be RFQ types: QuoteRequest, Quote, OrderSingle, ER
    private Party[] getParties(Message msg) throws Exception{
        String noPartyIDs = msg.getStringFieldValue(Constants.TAGNoPartyIDs);
        if(noPartyIDs == null){return null;}
        int noParties = Integer.parseInt(noPartyIDs);

        String [] partyIDs = msg.getGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID, noParties);
        String [] partyIDSources = msg.getGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyIDSource, noParties);
        String [] partyRoles = msg.getGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyRole, noParties);

        Party [] parties = new Party[noParties];
        for(int i=0;i<noParties;i++){
            if (partyIDSources==null || partyIDSources.length==0 ){
                parties[i] = new Party(partyIDs[i], null, partyRoles[i]);
            }else {
                parties[i] = new Party(partyIDs[i], partyIDSources[i], partyRoles[i]);
            }
        }

        return parties;
    }

    private InstrumentParty [] getInstrumentParties(Message msg) throws Exception{
        String noInstrumentPartyIDs = msg.getStringFieldValue(Constants.TAGNoInstrumentParties);//actually be 1 always.
        if(noInstrumentPartyIDs == null){return null;}
        int noInstrumentParties = Integer.parseInt(noInstrumentPartyIDs);

        String [] partyIDs = msg.getGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID, noInstrumentParties);
        String [] partyIDSources = msg.getGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyIDSource, noInstrumentParties);
        String [] partyRoles = msg.getGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyRole, noInstrumentParties);

        InstrumentParty[] parties = new InstrumentParty[noInstrumentParties];
        for(int i=0;i<noInstrumentParties;i++){
            parties[i] = new InstrumentParty(partyIDs[i], partyIDSources[i], partyRoles[i]);
        }

        return parties;
    }

    private void submitRfqExecutionReport(String orderId, String secondaryClOrdId, String clOrdId, String execId,
            String execType, String orderStatus, String orderRejectReason, String noPartyIDs, Party[] parties,
            String settlDate, String symbol, String securityType, String noInstrumentParties, InstrumentParty[] instrumentParties,
            String side, String orderQty, String price, String currency, String lastSpotRate, String lastForwardPoints,
            String leavesQty, String cumQty, String avgPx,
            String tradeDate, String transactionTime, String settlCurrAmt, String text, String settlDate2,
            String orderQty2, String lastForwardPoints2, String price2, String settlCurrAmt2, String fixingDate,
            String fixingDate2, String venueType) throws Exception {

        Message msg = new Message(Constants.MSGExecutionReport, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); //Y, OrderID is required to be unique for each chain of orders.
        msg.setField(Constants.TAGSecondaryClOrdID, secondaryClOrdId); //Y, QuoteRequestID
        msg.setField(Constants.TAGClOrdID, clOrdId); //Y, Client order id
        msg.setField(Constants.TAGExecID, execId); //Y, Maker trade ID
        msg.setField(Constants.TAGExecType, execType); //Y, 2-filled, 8-Reject
        msg.setField(Constants.TAGOrdStatus, orderStatus); //Y, 2-filled, 8-Reject
        msg.setField(Constants.TAGOrdRejReason, orderRejectReason); //N, For optional use with ExecType = 8
        /*component <Parties>*/
        msg.setField(Constants.TAGNoPartyIDs, noPartyIDs);
        if(noPartyIDs!=null && parties!=null){
            for(Party p : parties){
                msg.addField(Constants.TAGPartyID, p.partyID);
                msg.addField(Constants.TAGPartyIDSource, p.partyIDSource);
                msg.addField(Constants.TAGPartyRole, p.partyRole);
            }
        }
        msg.setField(Constants.TAGSettlDate, settlDate); //Y, Uses YYYYMMDD format (or tenor), This value should confirm value submitted in QuoteRequest/NewOrderSingle.
        //Begin Component block <Instrument>
        msg.setField(Constants.TAGSymbol, symbol); //Y, Currency pair of the request
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency); //Y, Supported values: 4=Currency
        msg.setField(Constants.TAGSecurityType, securityType); //N, Supported values: FOR = Foreign Exchange Contract, FXNDF = Non deliverable forward
        /*component <InstrumentParties>*/
        msg.setField(Constants.TAGNoInstrumentParties, noInstrumentParties);
        if(noInstrumentParties!=null){
            for(InstrumentParty p : instrumentParties){
                msg.addField(Constants.TAGInstrumentPartyID, p.instrumentPartyID);
                msg.addField(Constants.TAGInstrumentPartyIDSource, p.instrumentPartyIDSource);
                msg.addField(Constants.TAGInstrumentPartyRole, p.instrumentPartyRole);
            }
        }
        //End Component block <Instrument>
        msg.setField(Constants.TAGSide, side); //Y, 1=Buy or Buy/Sell for swap, 2=Sell or Sell/Buy for swap
        msg.setField(Constants.TAGOrderQty, orderQty); //Y, The order amount in the currency specified in tag 15.
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted); //Y, D=Previously quoted
        msg.setField(Constants.TAGPrice, price); //Y, The all-in rate for spot, forward, or near leg swap
        msg.setField(Constants.TAGCurrency, currency); //Y, The dealt currency of the order
        msg.setField(Constants.TAGLastSpotRate, lastSpotRate); //Y, The spot rate, Not required for denied trades (150=8)
        msg.setField(Constants.TAGLastForwardPoints, lastForwardPoints);//N, The forward points of forward and near leg for swap
        msg.setField(Constants.TAGLeavesQty, leavesQty);//Y, 0 for all RFS fills
        msg.setField(Constants.TAGCumQty, cumQty);//Y, Same as OrderQty
        msg.setField(Constants.TAGAvgPx, avgPx);//Y, Same as Price
        msg.setField(Constants.TAGTradeDate, tradeDate);//Y, Trade date for the deal.
        msg.setField(Constants.TAGTransactTime, transactionTime);//Y, Time stamp on this deal (GMT)
        msg.setField(Constants.TAGSettlCurrAmt, settlCurrAmt);//Settlement currency amount for spot, forward, and near leg swap. Not required for denied trades (150=8).
        msg.setField(Constants.TAGText, text);//N, Descriptive text field
        //Tags only for Swap
        msg.setField(Constants.TAGFutSettDate2, settlDate2);//N, Swap far leg settlement date, usage is the same as for SettlDate.
        msg.setField(Constants.TAGOrderQty2, orderQty2);//N, Swap far leg amount
        msg.setField(Constants.TAGLastForwardPoints2, lastForwardPoints2);//N, Swap far leg forward points.
        msg.setField(Constants.TAGPrice2, price2);//N, Swap far leg all-in price
        msg.setField(Constants.TAGSettlCurrAmt2, settlCurrAmt2);//N, Swap far leg counter currency amount
        msg.setField(Constants.TAGFixingDate, fixingDate);//N,Fixing date for NDF, or near leg fixing date for NDF swaps
        msg.setField(Constants.TAGFixingDate2, fixingDate2);//N,Far leg fixing date for NDF swaps

        msg.setField(Constants.TAGVenueType, venueType);//N, venueType

        sendFixMessage(msg);
    }
}
