package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import static com.google.common.base.MoreObjects.firstNonNull;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTag;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTagNotNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

import com.gemalto.ggs.ezio.rsaclient.HsmSecurity;
import currenex.server.e2ee.E2EEClientImpl;
import currenex.server.e2ee.IE2EEClient;
import currenex.server.fxintegrate.adaptor.fix.gateway.session.quickfix.cxoverride.QFSeqNumbersOnlyMemoryStoreFactory;
import currenex.server.fxintegrate.adaptor.fix.initiator.connection.fix.quickfix.cxoverride.QFThreadedSocketInitiator;
import currenex.server.fxintegrate.adaptor.fix.util.FixTagConstants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.TestScreenLogFactory;
import quickfix.Application;
import quickfix.DefaultMessageFactory;
import quickfix.DoNotSend;
import quickfix.FieldNotFound;
import quickfix.FileStoreFactory;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.Initiator;
import quickfix.LogFactory;
import quickfix.LogUtil;
import quickfix.MessageFactory;
import quickfix.MessageStoreFactory;
import quickfix.MessageUtils;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.StringField;
import quickfix.UnsupportedMessageType;
import quickfix.field.MsgType;
import quickfix.field.SenderSubID;

/**
 * @author Leo Zhou <lzhou@currenex.com>
 */
public abstract class ATestSession implements Application {
    protected static final String DEFAULT_PASSWORD = "Test123456";
    private static final String DEFAULT_FIX_VERSION = "4.4";
    private static final String DEFAULT_LOGON_RETRIES = "3";

    private static final String rsaKeyQA = "C7163FF8DB79BEB3E4F610E785C79DFBA68873416110462674246B40420232D1F44ECFCA1D577C58EDC3A5BE5410A328362243A6F154A9C9FD7E3FA7B6C64F63307264F5D44B18B7F9E6CC1B056CF393F51A347D543554B46C5012E6E5F3A1C361FCF3B0FCFAA88291AE47E46B9B3E2133AF5F7E824E987CDE95E9E6311C8F4F";
    private static final String rsaKeyBRET = "F310A4FAA751CF47D015FE4B3E70830B495B5F92B99B872EFAFFF33FC9ADD436CCDCE168EE57EA143981430E01CEB8F1CDC819E621506860427C23E8E918CDF5B5E145D8C517891CCB003440F09F5C3C367A5BF200764E9B516102ADF57091C21C47FAB19139112408020CAF0C54EAACE040BBF8BCE0275FA7160B448152477D";
    private static final String rsaKeyPRET = "A9BF556F51B47EDEE99AC8912A90183318A8B3FD8BB4187BA5EF15D873152151BCE68A3CCD5B9232C4380C2A1BF144202EF454BC1212A07078F2EFC0CB75C58698364D96B103CF8952D0012A5D7344FD74E3EEE7AB39E74ED8B887338995A2B0DEA9AF19D83EE66EE3612B44C44A026F55BEBAFCE17CD63F470516D4D0ACE6E9";

    private final String host;
    private final int port;
    private String senderCompId; // TODO make final; eliminate clone() call
    private final String targetCompId;
    private final String fixVersion;
    private String password;
    private int heartbeatInterval=30;
    private final @Nullable String partyId;
    private final String fileStorePath;
 
    protected Session session;
    protected volatile boolean isRunning = false;
    protected final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");
    protected final BlockingQueue<Message> msgQ = new ArrayBlockingQueue<Message>(Integer.getInteger("MAX_MSG_Q_SIZE", 500));
    private Initiator initiator;
    protected int logonRetries;
    
    private MessageStoreFactory sessionMessageStoreFactory;
    private SessionSettings sessionSettings;
    private LogFactory sessionLogFactory;
    private MessageFactory sessionMessageFactory;
    
    /**
     * @deprecated Use {@link #ATestSession(String,String,int,String,String,String,String,String,String,String,String,int)} instead
     */
    @Deprecated
    protected ATestSession(@Nullable String partyId, String host, int port, String senderCompId, String targetCompId, String dataDictionary, @Nullable String fixVersion, @Nullable String rsaKeyType, @Nullable String password, @Nullable String fileStorePath, @Nullable String resetSeqNum) throws Exception{
        this(partyId, host, port, senderCompId, targetCompId, dataDictionary,
                fixVersion, rsaKeyType, password, fileStorePath, resetSeqNum,
                DEFAULT_LOGON_RETRIES);
    }

    protected ATestSession(@Nullable String partyId, String host, int port, String senderCompId, String targetCompId, String dataDictionary, @Nullable String fixVersion, @Nullable String rsaKeyType, @Nullable String password, @Nullable String fileStorePath, @Nullable String resetSeqNum, String logonRetries) throws Exception{
        this.host = host;
        this.port = port;
        this.senderCompId = senderCompId;
        this.targetCompId = targetCompId;
        this.partyId = partyId;
        this.fixVersion = firstNonNull(fixVersion, DEFAULT_FIX_VERSION);
        this.fileStorePath = fileStorePath;
        this.logonRetries = Integer.parseInt(logonRetries);
        isRunning = true;

        this.password = firstNonNull(password, DEFAULT_PASSWORD);
        //check if user uses E2EE, encrypt password if applicable.
        if (rsaKeyType != null) {
            String rsaKey;
            if (rsaKeyType.equals("QA")){
                rsaKey = rsaKeyQA;
            } else if (rsaKeyType.equals("BRET")){
                rsaKey = rsaKeyBRET;
            } else if (rsaKeyType.equals("PRET")){
                rsaKey = rsaKeyPRET;
            } else {
                throw new IllegalArgumentException("unsupported RSA key type: " + rsaKeyType);
            }
            System.out.println("m_rsaKey = " + rsaKey);
            HsmSecurity.SetKeyValue(rsaKey);
            IE2EEClient e2EEClient = E2EEClientImpl.getInstance();
            password = HsmSecurity.EncryptPassword(password, e2EEClient.getRandomStringBlocking(senderCompId, null).m_randomStr);
        }
        this.password = password;

        StringBuilder qConfig = new StringBuilder();
        qConfig.append("[DEFAULT]\n");
        qConfig.append("ScreenDontLogMsgTypes=").append(System.getProperty("ScreenDontLogMsgTypes", "X1"));
        qConfig.append("\n");
        qConfig.append("[SESSION]\n");
        qConfig.append("ConnectionType=initiator\n");
        qConfig.append("BeginString=FIX.").append(this.fixVersion).append("\n");
        qConfig.append("SenderCompID=").append(senderCompId).append("\n");
        qConfig.append("TargetCompID=").append(targetCompId).append("\n");
        qConfig.append("StartTime=00:00:00\n");
        qConfig.append("EndTime=00:00:00\n");
        qConfig.append("HeartBtInt=30\n");
        qConfig.append("SocketReceiveBufferSize=65536\n");
        qConfig.append("SocketSendBufferSize=65536\n");
        qConfig.append("SocketTcpNoDelay=Y\n");
        qConfig.append("HeartBtInt=30\n");
        qConfig.append("SocketConnectPort=").append(port).append("\n");
        qConfig.append("SocketConnectHost=").append(host).append("\n");
        qConfig.append("DataDictionary=").append(dataDictionary).append("\n");
        qConfig.append("UseDataDictionary=Y\n");
        qConfig.append("ScreenDontLogMsgTypes=").append(System.getProperty("ScreenDontLogMsgTypes", "X1")).append("\n");

        if (fileStorePath != null){
            qConfig.append("FileStorePath=").append(this.fileStorePath).append("\n");
        }

        if (resetSeqNum != null && resetSeqNum.equals("false")){
            System.out.println("Persist on");
            qConfig.append("ResetOnLogon=").append("N\n");
            qConfig.append("ResetOnLogout=").append("N\n");
            qConfig.append("ResetOnDisconnect=").append("N\n");
            qConfig.append("RefreshOnLogon=").append("N\n");
            qConfig.append("PersistMessages=").append("Y\n");
        }

        qConfig.append("ReconnectEnabled=N").append("\n");
        ByteArrayInputStream configStream = new ByteArrayInputStream(qConfig.toString().getBytes("UTF-8"));
        SessionSettings settings = new SessionSettings(configStream);
        settings.setString("BeginString","FIX."+ this.fixVersion); // TODO: is this redundant?
        System.out.println("The beginstring is " + settings.getString("BeginString"));
        MessageStoreFactory messageStoreFactory = null;
        if (this.fileStorePath == null){
            messageStoreFactory = QFSeqNumbersOnlyMemoryStoreFactory.getInstance(settings);
        } else {
            messageStoreFactory = new FileStoreFactory(settings);
        }

        LogFactory logFactory = new TestScreenLogFactory(settings);
        MessageFactory messageFactory = new DefaultMessageFactory();
        initiator = new QFThreadedSocketInitiator(this, messageStoreFactory, settings, logFactory, messageFactory);
        
        sessionMessageStoreFactory = messageStoreFactory;
        sessionSettings = settings;
        sessionLogFactory = logFactory;
        sessionMessageFactory = messageFactory;
    }
    
    private void refreshInitiator() throws Exception{
        
        initiator = new QFThreadedSocketInitiator(this, sessionMessageStoreFactory, sessionSettings, sessionLogFactory, sessionMessageFactory);
    }
    
    
    public void refresh() throws Exception{
        msgQ.clear();
    }

    public @Nullable String getPartyId(){
        return partyId;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String getSenderCompId() {
        return senderCompId;
    }

    public String getTargetCompId() {
        return targetCompId;
    }

    public String getFixVersion() {
        return fixVersion;
    }

    public Message getNextFIXMessage(long timeout) {
        Message msg = null;
        try {
            if (timeout > 0) {
                msg = msgQ.poll(timeout, TimeUnit.MILLISECONDS);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getNextFIXMessage(String type, long timeout) {
        long recvTime = System.currentTimeMillis();
        Message msg = getNextFIXMessage(timeout);
        while (msg != null && !msg.getStringFieldValue(Constants.TAGMsgType).equals(type)) {
            long newTimeout = timeout - (System.currentTimeMillis() - recvTime);
            msg = getNextFIXMessage(newTimeout);
            recvTime = System.currentTimeMillis();
        }
        return msg;
    }

    @Deprecated
    public void setSenderCompId(String compId) {
        senderCompId = compId;
    }

    @Deprecated
    public boolean logon(String password, long timeout, boolean waitForTradingStatus) throws Exception {
        this.password = password;
        return logon();
    }
    
    public boolean logon(String password, int heartbeatInterval) throws Exception {
        this.password = password;
        this.heartbeatInterval = heartbeatInterval;
        return logon();
    }

    public boolean logon() throws Exception {
        boolean result = false;

        System.out.println("User " + senderCompId + " is logging on");
        System.out.println("HOST: "+ host + "; PORT: " + port);
        int retry = this.logonRetries;
        
        for(int i=1;i<=retry;i++){
            System.out.println("Logon "+senderCompId+", trying: "+i+" time(s)");
            try{
                System.out.println("initiator.getSessions().size() = "+initiator.getSessions().size());
                if(initiator.getSessions().size()==0){
                    this.refreshInitiator();
                    System.out.println("after refresh, initiator.getSessions().size() = "+initiator.getSessions().size());
                }
                initiator.start();
                } catch (Exception e){
                    e.printStackTrace();
                }
            System.out.println("socket initiator started");
            session.logon();
            int waitTime = 0;
            
            while(waitTime<10000){
                if (session.isLoggedOn()){
                    result = true;
                    System.out.println("quickfix session logon successful");
                    return result;
                }
                Thread.sleep(100);
                waitTime+=100;
            }
        }

        System.out.println("quickfix session logon unsuccessful");

        return result;
    }

    abstract public void onFixMessage(Message message) throws Exception;

    public void sendFixMessage(Message msg) throws Exception {
        if (!isRunning) {
            throw new IllegalStateException("cannot send message because the fix session is not active");
        }
        String type = msg.getStringFieldValue(Constants.TAGMsgType);
//        if (!isLoggedOn() && !type.equals(Constants.MSGLogon)) {
//            throw new IllegalStateException("cannot send message because the fix session is not logged on");
//        }
        session.send(msg.getMessage());

    }

    public boolean isLoggedOn() {
        return session.isLoggedOn();
    }

    public void logout() {
        session.logout();
        System.out.println("logout called");
    }

    public boolean logoutAndVerifyResponse() {
        assertTrue(session.isLoggedOn());
        initiator.stop();
        session.logout();
        System.out.println("logout called");
        return session.isLogoutSent();
    }

    //
    // Application implementation
    //

    @Override
    public void onCreate(SessionID sessionID) {
        System.out.println("onCreate called");
        this.session = Session.lookupSession(sessionID);

    }

    @Override
    public void onLogon(SessionID sessionID) {
        System.out.println("onLogon called");
        this.session = Session.lookupSession(sessionID);

    }

    @Override
    public void onLogout(SessionID sessionID) {
        this.logout();
    }

    @Override
    public void toAdmin(quickfix.Message msg, SessionID sessionID) {
        System.out.println("toAdmin called here");
        if (isMessageOfType(msg,MsgType.LOGON)){
            addLogonField(msg);
        }
    }

    @Override
    public void fromAdmin(quickfix.Message msg, SessionID sessionID){ /*throws FieldNotFound,
            IncorrectDataFormat, IncorrectTagValue, RejectLogon {*/
        try {

            Message message = new Message(msg, sessionID.getSenderCompID(), sessionID.getTargetCompID());
            if (message.getMsgType().equals(Constants.MSGReject)){
                System.out.println("checkpoint");
                onFixMessage(message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void toApp(quickfix.Message msg, SessionID sessionID) throws DoNotSend {
    }

    @Override
    public void fromApp(quickfix.Message msg, SessionID sessionID) throws FieldNotFound,
            IncorrectDataFormat, IncorrectTagValue, UnsupportedMessageType
    {
        try {
            Message message = new Message(msg, sessionID.getSenderCompID(), sessionID.getTargetCompID());

            onFixMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addLogonField(quickfix.Message message) {
        //message.getHeader().setField(new SenderSubID(senderCompId));
        message.setField(new StringField(FixTagConstants.TAGResetSeqNumFlag, "Y"));
        if (password != null) {
            message.setField(new StringField(FixTagConstants.TAGPassword, password));
        }
        if (this.heartbeatInterval!=30){
            message.setInt(FixTagConstants.TAGHeartBtInt, heartbeatInterval);
        }
        
        if (this.getClass().equals(TakerTestSession.class)){
//            message.setField(new StringField(FixTagConstants.TAGText, "onezero"));
//            message.setField(new StringField(FixTagConstants.TAGDefaultApplExtID, "IPHONE#IOS7.1.2"));
//            message.setField(new StringField(FixTagConstants.TAGDefaultAppVerID, "cxmobile_enterprise#1.0.24"));
//            message.setField(new StringField(FixTagConstants.TAGSourceIpMSF, "10.100.2.238"));
            //////////////////////////////////////////////////////////////////////////////////////
//            message.setField(new StringField(FixTagConstants.TAGDefaultAppVerID, "b2b#0.1"));//"I.O.S.7.0.2"));
//            message.setField(new StringField(FixTagConstants.TAGDefaultApplExtID, "IPHONE#IOS5.0.0"));
//            message.setField(new StringField(FixTagConstants.TAGText, "placeholder"));
        }
    }

    protected boolean isMessageOfType(quickfix.Message message, String type) {
        try {
            return type.equals(message.getHeader().getField(new MsgType()).getValue());
        } catch (FieldNotFound e) {
            logErrorToSessionLog(message, e);
            return false;
        }
    }

    private void logErrorToSessionLog(quickfix.Message message, FieldNotFound e) {
        LogUtil.logThrowable(MessageUtils.getSessionID(message), e.getMessage(), e);
    }
    
    public void submitUserRequestPasswordReset(String currentPassword, String newPassword) throws Exception {
        Message msg = new Message(Constants.MSGUserRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGUserRequestID, "UR"+System.currentTimeMillis());
        msg.setField(Constants.TAGUserRequestType, "3");
        msg.setField(Constants.TAGUsername, this.getSenderCompId());
        msg.setField(Constants.TAGPassword, currentPassword);
        msg.setField(Constants.TAGNewPassword, newPassword);
        sendFixMessage(msg);
    }
    
    public void doAssertionCheckForReject(Message reject, String refMsgType, String refTagID, 
            String sessionRejectReason, String text) throws Exception
    {
        assertNotNull(this.getSenderCompId()+" didnt receive reject", reject);
        validateTag(Constants.TAGMsgType, Constants.MSGReject, reject.getStringFieldValue(Constants.TAGMsgType));
        validateTagNotNull(Constants.TAGRefSeqNum, reject.getStringFieldValue(Constants.TAGRefSeqNum));
        if(refTagID!=null) {
            validateTag(Constants.TAGRefTagID, refTagID, reject.getStringFieldValue(Constants.TAGRefTagID));
        }
        if(refMsgType!=null) {
            validateTag(Constants.TAGRefMsgType, refMsgType, reject.getStringFieldValue(Constants.TAGRefMsgType));
        }
        validateTag(Constants.TAGSessionRejectReason, sessionRejectReason,
                reject.getStringFieldValue(Constants.TAGSessionRejectReason));
        validateTag(Constants.TAGText, text, reject.getStringFieldValue(Constants.TAGText));
    }
    
    public void doAssertionCheckForBusinessMessageReject(Message bmr, String refMsgType, String businessRejectRefID, 
            String businessRejectReason, String text) throws Exception
    {
        assertNotNull("Maker didnt receive BusinessMessageReject", bmr);
        validateTag(Constants.TAGMsgType, Constants.MSGBusinessMessageReject, bmr.getStringFieldValue(Constants.TAGMsgType));
        validateTag(Constants.TAGRefMsgType, refMsgType, bmr.getStringFieldValue(Constants.TAGRefMsgType));
        if(businessRejectRefID!=null) {
            validateTag(Constants.TAGBusinessRejectRefID, businessRejectRefID, bmr.getStringFieldValue(Constants.TAGBusinessRejectRefID));
        }
        validateTag(Constants.TAGBusinessRejectReason, businessRejectReason, bmr.getStringFieldValue(Constants.TAGBusinessRejectReason));
        validateTagNotNull(Constants.TAGRefSeqNum, bmr.getStringFieldValue(Constants.TAGRefSeqNum));
        validateTag(Constants.TAGText, text, bmr.getStringFieldValue(Constants.TAGText));
    }
}
