package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Constants;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.MsgHandler;
import currenex.time.MicroInstant;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.handler.codec.frame.CorruptedFrameException;
import org.jboss.netty.handler.codec.frame.FrameDecoder;
import org.jboss.netty.handler.codec.frame.TooLongFrameException;

/** A copy of ItchFrameDecoder but with logic to move timestamp as early as possible */
public class ItchTestFrameDecoder extends FrameDecoder implements Constants {
    private static final CxLogger log = CxLogger.getCxLogger(ItchTestFrameDecoder.class);

    @Override protected Object decode(ChannelHandlerContext ctx, Channel channel, ChannelBuffer buf) throws Exception {
        MicroInstant microInstant = MicroInstant.now();

        if (buf.readableBytes() < MSG_TYPE_BYTE_OFFSET + 2) return null;
        buf.markReaderIndex();

        if (buf.readByte() != START) {
            if (buf.readableBytes() < MAX_MSG_LENGTH) return null;
            Channels.fireExceptionCaught(ctx.getChannel(), new TooLongFrameException(
                    "frame length exceeds " + MAX_MSG_LENGTH + ": " + buf.readableBytes() + " - discarded"));
        }

        buf.skipBytes(MSG_TYPE_BYTE_OFFSET);
        byte type = buf.readByte();
        int length = -1;

        try {
            length = MsgHandler.getMessageLength(type) + 2;
        } catch (Exception e) {
            log.warningf("Exception decoding itch message: %s", e.getMessage());
            Channels.fireExceptionCaught(ctx.getChannel(), new CorruptedFrameException(
                    " frame corrupted: message type=" + type + ": " + buf.readableBytes() + " bytes discarded"));
        }

        buf.resetReaderIndex();
        if (buf.readableBytes() < length) {
            buf.resetReaderIndex();
            return null;
        }

        ChannelBuffer frame = buf.readBytes(length - 1);
        byte end = buf.readByte();
        if (end != END) {
            Channels.fireExceptionCaught(ctx.getChannel(), new CorruptedFrameException(" frame corrupted due to last byte of the message not END: " + end +
                    ": " + length + " - discarded, msgType="+(char)type));
        }

        return new DecodedFrame(microInstant, frame);
    }

    class DecodedFrame {
        private final MicroInstant microInstant;
        private final ChannelBuffer buffer;

        DecodedFrame(MicroInstant microInstant, ChannelBuffer buffer) {
            this.microInstant = microInstant;
            this.buffer = buffer;
        }

        MicroInstant getMicroInstant() {
            return microInstant;
        }

        ChannelBuffer getBuffer() {
            return buffer;
        }
    }
}
