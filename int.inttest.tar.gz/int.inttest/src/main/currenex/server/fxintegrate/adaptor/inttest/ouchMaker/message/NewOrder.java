package currenex.server.fxintegrate.adaptor.inttest.ouchMaker.message;

import java.util.Date;

public class NewOrder {
    
    private int clOrdID;
    private String instrumentID;
    private byte side;
    private long orderMinAmt;
    private long orderAmt;
    private String streamReferenceID;
    private int quoteID;
    private int price;
    private byte orderType;
    private String clientID;
    private byte isBaseSpecified;
    private String executingFirm;
    private long settlementDate;
    
    public NewOrder(int clOrdID, String instrumentID, byte side,
            long orderMinAmt, long orderAmt, String streamReferenceID,
            int quoteID, int price, byte orderType, String clientID,
            byte isBaseSpecified, String executingFirm, long settlementDate) {
        super();
        this.clOrdID = clOrdID;
        this.instrumentID = instrumentID;
        this.side = side;
        this.orderMinAmt = orderMinAmt;
        this.orderAmt = orderAmt;
        this.streamReferenceID = streamReferenceID;
        this.quoteID = quoteID;
        this.price = price;
        this.orderType = orderType;
        this.clientID = clientID;
        this.isBaseSpecified = isBaseSpecified;
        this.executingFirm = executingFirm;
        this.settlementDate = settlementDate;
    }

    public int getClOrdID() {
        return clOrdID;
    }

    public void setClOrdID(int clOrdID) {
        this.clOrdID = clOrdID;
    }

    public String getInstrumentID() {
        return instrumentID;
    }

    public void setInstrumentID(String instrumentID) {
        this.instrumentID = instrumentID;
    }

    public byte getSide() {
        return side;
    }

    public void setSide(byte side) {
        this.side = side;
    }

    public long getOrderMinAmt() {
        return orderMinAmt;
    }

    public void setOrderMinAmt(long orderMinAmt) {
        this.orderMinAmt = orderMinAmt;
    }

    public long getOrderAmt() {
        return orderAmt;
    }

    public void setOrderAmt(long orderAmt) {
        this.orderAmt = orderAmt;
    }

    public String getStreamReferenceID() {
        return streamReferenceID;
    }

    public void setStreamReferenceID(String streamReferenceID) {
        this.streamReferenceID = streamReferenceID;
    }

    public int getQuoteID() {
        return quoteID;
    }

    public void setQuoteID(int quoteID) {
        this.quoteID = quoteID;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public byte getOrderType() {
        return orderType;
    }

    public void setOrderType(byte orderType) {
        this.orderType = orderType;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public byte getIsBaseSpecified() {
        return isBaseSpecified;
    }

    public void setIsBaseSpecified(byte isBaseSpecified) {
        this.isBaseSpecified = isBaseSpecified;
    }

    public String getExecutingFirm() {
        return executingFirm;
    }

    public void setExecutingFirm(String executingFirm) {
        this.executingFirm = executingFirm;
    }

    public long getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(long settlementDate) {
        this.settlementDate = settlementDate;
    }
    
    @Override
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append("NewOrder: ");
        sb.append("clOrdId="+clOrdID);
        sb.append(",instrumentID="+instrumentID);
        sb.append(",side="+(char)side);
        sb.append(",orderMinAmt="+orderMinAmt);
        sb.append(",orderAmt="+orderAmt);
        sb.append(",streamReferenceID="+streamReferenceID);
        sb.append(",quoteID="+quoteID);
        sb.append(",price="+price);
        sb.append(",orderType="+(char)orderType);
        sb.append(",clientID="+clientID);
        sb.append(",isBaseSpecified="+(char)isBaseSpecified);
        sb.append(",executingFirm="+executingFirm);
        sb.append(",settlementDate="+new Date(settlementDate));
        return sb.toString();
    }

}
