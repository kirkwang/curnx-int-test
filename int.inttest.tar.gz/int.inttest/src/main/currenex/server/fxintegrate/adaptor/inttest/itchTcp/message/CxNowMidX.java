package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class CxNowMidX {
    
    private short instrumentIndex;
    private char activityIndicator;
    
    public CxNowMidX(short instrumentIndex, char activityIndicator) {
        super();
        this.instrumentIndex = instrumentIndex;
        this.activityIndicator = activityIndicator;
    }

    public short getInstrumentIndex() {
        return instrumentIndex;
    }

    public void setInstrumentIndex(short instrumentIndex) {
        this.instrumentIndex = instrumentIndex;
    }

    public char getActivityIndicator() {
        return activityIndicator;
    }

    public void setActivityIndicator(char activityIndicator) {
        this.activityIndicator = activityIndicator;
    }
    
    

}
