package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.*;
import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import com.google.common.collect.MapMaker;

import currenex.server.fxintegrate.adaptor.inttest.fix.messages.*;
import currenex.server.fxintegrate.adaptor.fix.gateway.session.IFixGroup;
import currenex.server.fxintegrate.adaptor.fix.gateway.session.quickfix.QFMsgParser;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.FixTagConstants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.ao.NewOrderSingle;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.Allocation;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.InstrumentParty;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntry;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntryForIOI;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntryForSecurityID;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntryForTicker;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.Party;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.RFQLeg;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.SecurityListGroup;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession.Subscription;

/**
 * @author Leo Zhou <lzhou@currenex.com>
 */
public class TakerTestSession extends ATestSession implements Cloneable {
    public Set<String> clordidset = new HashSet<String>();
    public Set<String> rejectReasonSet = new HashSet<String>();
    public boolean isMobile = false;
    public final Map<String, Long> idToTimeMapForFill = new MapMaker().makeMap();
    public final Map<String, Long> idToTimeMapForAck = new MapMaker().makeMap();
    public final Map<String, String> clientIDToOrderIDMap = new MapMaker().makeMap();
    private final Map<String, String> submittedPricesMap = new MapMaker().makeMap();
    private final Collection fillDiffCollection = new ArrayList();
    private final Collection ackDiffCollection = new ArrayList();
    private boolean recordRoundTripTime = false;
    private Long minAckTime = Long.valueOf(0L);
    private Long maxAckTime = 0L;
    public String outFile;
    public final Map<String, BlockingQueue<Message>> orderMsgMap = Collections.synchronizedMap(new HashMap<String, BlockingQueue<Message>>());
    public final Map<String, BlockingQueue<Message>> priceMsgMap = Collections.synchronizedMap(new HashMap<String, BlockingQueue<Message>>());
    public final Map<String, BlockingQueue<MDEntry>> mdEntryMap = Collections.synchronizedMap(new HashMap<String, BlockingQueue<MDEntry>>());
    public final BlockingQueue<Message> rejectQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> listQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> quoteAckQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> quoteQueue = new ArrayBlockingQueue<Message>(1);
    private final BlockingQueue<Message> userResponseQueue = new ArrayBlockingQueue<Message>(100);
    public final BlockingQueue<Message> posreportQueue = new ArrayBlockingQueue<Message>(40000);
    public final BlockingQueue<Message> apQueue = new ArrayBlockingQueue<Message>(6000);
    public final BlockingQueue<Message> journalQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> collateralResponseQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> userPropertyReportQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> securityDefnQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> partyDetailListReportQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> serverNotificationMessageQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> serverNotificationSubscriptionRejectQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> executionReportQueue = new ArrayBlockingQueue<Message>(600000);
    private final BlockingQueue<Message> puQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> priceAlertConfirmQueue = new ArrayBlockingQueue<Message>(10);
    private final BlockingQueue<Message> priceAlertUpdatedQueue = new ArrayBlockingQueue<Message>(6000);
    private final BlockingQueue<Message> quoteReqRejectQueue = new ArrayBlockingQueue<Message>(100);
    private final BlockingQueue<Message> tickerQueue = new ArrayBlockingQueue<Message>(100);
    private final BlockingQueue<Message> orderMassCancelReportQueue = new ArrayBlockingQueue<Message>(10);
    private final BlockingQueue<Message> tradeQueue = new ArrayBlockingQueue<Message>(10000);
    private final BlockingQueue<MDEntry> mdEntryQueue = new ArrayBlockingQueue<MDEntry>(10000);
    private ArrayList<SecurityListGroup> slGroupList;
    
    public BlockingQueue<Message> getPriceAlertUpdatedQueue() {
        return priceAlertUpdatedQueue;
    }

    public int ii = 0;
    private final boolean isStream;
    private final boolean isProcessByClOrdId;
    public final boolean isRoutingTaker;
    public final boolean isRoutedTaker;
    private final boolean isTrade;
    private final boolean isTicker;
    private final boolean isRetail;
    private final String allocAccount;

    public static String routedUserIds = null;

    private static final String MSGMassStatusRequest = "AF";
    static final String TAGStopSide = "7534";
    static final String TAGTrailByRate = "7587";
    static final String TAGMaxSlippage = "7588";
    private final long DEFAULT_WAIT_TIME = 8000;
    private static final String TAGExpireSeconds = "7558";
    public static final String GoodForSeconds = "X";
    static final String ALL_OPEN_ORDERS = "OPEN_ORDER";
    private static final String MsgUserPropertyRequest = "U13";
    private static final String MsgUserPropertyReport = "U14";
    private static final String MsgUserPropertyUpdateRequest = "U15";
    private final SimpleDateFormat m_format = new SimpleDateFormat("yyyyMMdd");

    public long accumulatedFillResponseTime = 0;
    public long accumulatedAckResponseTime = 0;
    public int numberMessagesFilled = 0;
    public int numberMessagesCancelled = 0;
    public int numberMessagesAcked = 0;
    public int numberMessagesRejected = 0;
    
    private long firstOrderWentOutTime = 0;
    private long lastAckCameInTime = 0;
    private int totalOrdersSubmitted = 0;
    //for retail users
    private String type;

    public TakerTestSession(Properties props) throws Exception {
        super(props.getProperty(PARTYID),
              props.getProperty(HOST),
              Integer.parseInt(props.getProperty(PORT)),
              props.getProperty(SENDERCOMPID),
              props.getProperty(TARGETCOMPID),
              props.getProperty(DATADICTIONARY),
              props.getProperty(FIXVERSION),
              props.getProperty(RSAKEYTYPE),
              props.getProperty(PASSWORD, DEFAULT_PASSWORD),
              props.getProperty(FILESTOREPATH),
              props.getProperty(RESETSEQNUM),
              props.getProperty(LOGONRETRIES, "3")
              );
        //add an entry with UNKNOWN, this can be useful for negative tests eg: null ClOrdId
        orderMsgMap.put("UNKNOWN", new ArrayBlockingQueue<Message>(6000));

        allocAccount = props.getProperty(ALLOCACCOUNT);
        isStream = Boolean.parseBoolean(props.getProperty(STREAMUSER));
        isTrade = Boolean.parseBoolean(props.getProperty(TRADEUSER));
        isTicker = Boolean.parseBoolean(props.getProperty(TICKERUSER));
        isRetail = Boolean.parseBoolean(props.getProperty(RETAILUSER));
        isProcessByClOrdId = Boolean.parseBoolean(props.getProperty(CLIENTORDERIDPROCESS));
        isRoutingTaker = Boolean.parseBoolean(props.getProperty(ROUTINGTAKER));
        isRoutedTaker = Boolean.parseBoolean(props.getProperty(ROUTEDTAKER));
        setType(props.getProperty(TYPE));
    }

    public TakerTestSession(String partyID, String host, String port,
            String senderCompID, String targetCompID, String dataDictionary,
            String fixVersion, String rsaKeyType, String password,
            String fileStorePath, String resetSeqNum, String allocAccount,
            boolean streamUser, boolean tradeUser, boolean tickerUser,
            boolean retailUser, boolean clientOrderIDProcess, String type)
            throws Exception {
        super(partyID,
                host,
              Integer.parseInt(port),
              senderCompID,
              targetCompID,
              dataDictionary,
              fixVersion,
              rsaKeyType,
              password,
              fileStorePath,
              resetSeqNum);
        //add an entry with UNKNOWN, this can be useful for negative tests eg: null ClOrdId
        orderMsgMap.put("UNKNOWN", new ArrayBlockingQueue<Message>(6000));

        this.allocAccount = allocAccount;
        isStream = streamUser;
        isTrade = tradeUser;
        isTicker = tickerUser;
        isRetail = retailUser;
        isProcessByClOrdId = clientOrderIDProcess;
        isRoutingTaker = false;
        isRoutedTaker = false;
        setType(type);
    }



    public interface IOrderListener {
        public void orderAccepted(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal amount, String ccyPair,
                String buySell);

        public void orderRejected(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal amount, String ccyPair,
                String buySell);

        public void orderFilled(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal filledAmount, BigDecimal totalFilledAmount,
                BigDecimal leftAmount, String ccyPair, String buySell);

        public void orderCancelled(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal cancelledAmount,
                String ccyPair, String buySell);

        public void orderReplaced(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal amount, String ccyPair,
                String buySell);

        public void orderCancelFailed(String orderID, String clientOrderID);

        public void orderReplaceFailed(String orderID, String clientOrderID);

        public void orderStatus(String orderID, String clientOrderID,
                BigDecimal limitRate, BigDecimal amount, String ccyPair,
                String buySell);

        public void orderStatusFailed(String orderID, boolean isAllOrder);
    }
    
    /**
     * sinlge currency pair price update listener
     *
     * @author lzhou
     */

    public interface IPriceListener {
        public void priceRequestRejected(String ccyPair, String rejectReason);
    }
    @Override
    public void refresh() throws Exception {
        orderMsgMap.clear();
        //add an entry with UNKNOWN, this can be useful for negative tests eg: null ClOrdId
        orderMsgMap.put("UNKNOWN", new ArrayBlockingQueue<Message>(6000));
        priceMsgMap.clear();
        mdEntryMap.clear();
        submittedPricesMap.clear();
        rejectQueue.clear();
        listQueue.clear();
        quoteAckQueue.clear();
        quoteQueue.clear();
        userResponseQueue.clear();
        posreportQueue.clear();
        apQueue.clear();
        journalQueue.clear();
        collateralResponseQueue.clear();
        userPropertyReportQueue.clear();
        securityDefnQueue.clear();
        partyDetailListReportQueue.clear();
        serverNotificationMessageQueue.clear();
        serverNotificationSubscriptionRejectQueue.clear();
        executionReportQueue.clear();
        quoteReqRejectQueue.clear();
    }

    public void submitPriceAlertSubscriptionRequest(final String MDReqID) throws Exception{
        Message msg = new Message(Constants.MSGPriceAlertSubscriptionRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, MDReqID);
        msg.setField(Constants.TAGSubscriptionRequestType, "1");
        sendFixMessage(msg);
    }
    
    
    public void submitPriceAlertRequest(final String MDReqID, final String MDEntryID, final String execType, final String symbol, final String side, final String price) throws Exception{
        Message msg = new Message(Constants.MSGPriceAlertRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, MDReqID);
        msg.setField(Constants.TAGMDEntryID, MDEntryID);
        msg.setField(Constants.TAGExecType, execType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGPrice, price);
        sendFixMessage(msg);
    }
    
    public void submitTradingSessionStatusRequest(String tradSesReqID) throws Exception{
        Message msg = new Message(Constants.MSGTradingSessionStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGTradSesReqID, tradSesReqID);
        msg.setField(Constants.TAGTradingSessionID, "HUB_AGREEMENT");
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Snapshot);
        sendFixMessage(msg);
    }
    
    public void submitOrder(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                            BigDecimal amount, String ccyPair, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, text);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderFillOrKill(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, amount); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodForSeconds);
        msg.setField(Constants.TAGExpireSecondsOrMillis, 30);
        msg.setField(Constants.TAGText, text);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    public void submitOrderEspFwdMarket(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String buySell, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdMarket");
        
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdStopLoss(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String stopPx, String stopSide, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Stop);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdStopLoss");
        msg.setField(Constants.TAGStopSide, stopSide);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdStopLimit(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String price, String stopPx, String stopSide, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Stoplimit);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdStopLimit");
        msg.setField(Constants.TAGStopSide, stopSide);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdLimit(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String price, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdLimit");
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdPegged(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Pegged);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdPegged");
        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdDiscretionary(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String price, String discretionOffset, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_DiscretionaryOrder);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdDiscretionary");
        msg.setField(FixTagConstants.TAGDiscretionInst, "0");
        msg.setField(FixTagConstants.TAGDiscretionOffset, discretionOffset);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdSliced(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String price, String expTime, String numStrategyParams, String[] params, String[] values
            , String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Sliced);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodForSeconds);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdSliced");
        
        if (numStrategyParams != null) {
            msg.setField(Constants.TAGNoStrategyParameters, numStrategyParams);
            for (int num = 0; num < Integer.parseInt(numStrategyParams); num++) {
                if (params[num] != null) {
                    msg.addField(Constants.TAGStrategyParameterName, params[num]);
                }
                if (values[num] != null) {
                    msg.addField(Constants.TAGStrategyParameterValue, values[num]);
                }
            }
        }
        
        msg.setField(FixTagConstants.TAGExpireSeconds, "30");
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }

    public void submitOrderEspFwdTrailingStop(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String price, String stopSide, String trailBy, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_TrailingStop);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdTrailingStop");
        msg.setField(Constants.TAGStopSide, stopSide);
        msg.setField(FixTagConstants.TAGStopTrailByRate, trailBy);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdOCO(final String clientOrderID, BigDecimal amount, String ccyPair, 
            String symbolSfx, String side, String OCOLeg1LimitRate, String OCOLeg2Type, String OCOLeg2StopRate,
            String OCOLeg2StopSide, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_OCO);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdOCO");
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, OCOLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, OCOLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, OCOLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, OCOLeg2StopSide);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdIFD(final String clientOrderID, BigDecimal amount, String price, String ccyPair, 
            String symbolSfx, String side, String IFDThenType, String IFDThenSide, String IFDIfStopRate,
            String IFDThenPrStopRate, String IFDThenPrStopSide, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_IFD);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdIFD");
        msg.setField(FixTagConstants.TAGIFDThenType, IFDThenType);
        msg.setField(FixTagConstants.TAGIFDThenSide, IFDThenSide);
        msg.setField(FixTagConstants.TAGIFDIfStopRate, IFDIfStopRate);
        msg.setField(FixTagConstants.TAGIFDThenPrStopRate, IFDThenPrStopRate);
        msg.setField(FixTagConstants.TAGIFDThenPrStopSide, IFDThenPrStopSide);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdIFDOCO(final String clientOrderID, BigDecimal amount, String price, String ccyPair, 
            String symbolSfx, String side, String stopSide, String IFDThenType, String IFDThenSide, String IFDIfStopRate,
            String IFDThenPrStopRate, String OCOLeg1LimitRate, String OCOLeg2Type, String OCOLeg2StopRate, String OCOLeg2StopSide
            , String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_IFDOCO);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdIFDOCO");
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(FixTagConstants.TAGIFDThenType, IFDThenType);
        msg.setField(FixTagConstants.TAGIFDThenSide, IFDThenSide);
        msg.setField(FixTagConstants.TAGIFDIfStopRate, IFDIfStopRate);
        msg.setField(FixTagConstants.TAGIFDThenPrStopRate, IFDThenPrStopRate);
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, OCOLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, OCOLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, OCOLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, OCOLeg2StopSide);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrderEspFwdIceberg(final String clientOrderID, BigDecimal amount, String price, String ccyPair, 
            String symbolSfx, String side, String maxShow, String onBehalf) throws Exception {
Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Iceberg);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGText, "submitOrderEspFwdIceberg");
        msg.setField(Constants.TAGMaxShow, maxShow);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }
    
    public void submitOrder(final String clientOrderID, final String posMaintRpt, final String onBehalfOf, BigDecimal limitRate,
                            BigDecimal amount, String ccyPair, String buySell) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGSecondaryClOrdID, posMaintRpt);

        msg.setField(Constants.TAGHandlInst, "1");
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderGoodForMS(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                                     BigDecimal amount, String ccyPair, String buySell, String text, String expireMillis) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodForMS);
        msg.setField(Constants.TAGExpireSecondsOrMillis, expireMillis);
        msg.setField(Constants.TAGText, text);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderIOC(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                               BigDecimal amount, String ccyPair, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_ImmediateOrCancel);
        msg.setField(Constants.TAGText, text);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderFOK(final String clientOrderID, final String onBehalfOf,  BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if(onBehalfOf!=null)
        {
            if(getFixVersion().endsWith("4.4"))
            {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            }
            else
            {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, amount.toString()); // set min to zero allows
                                                // partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
    }
    public void submitOrderWithMinAmount(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, String text, String minQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate.toString());
        }
        else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_FillOrKill);
        if (text != null) {
            msg.setField(Constants.TAGText, text);
        }
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrder(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                            BigDecimal amount, String ccyPair, String symSfx, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGClientID, onBehalfOf);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }

        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);

        msg.setField(Constants.TAGText, text);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitOrder(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                            BigDecimal amount, String ccyPair, String buySell) throws Exception {
        clordidset.add(clientOrderID);
        submitOrder(clientOrderID, onBehalfOf, limitRate, amount, ccyPair, buySell, null);
        if (this.recordRoundTripTime) {
            totalOrdersSubmitted++;
            if(firstOrderWentOutTime==0) {
                firstOrderWentOutTime = System.currentTimeMillis();
            }
            this.idToTimeMapForAck.put(clientOrderID, System.nanoTime());
        }


    }

    public void submitOrderFillOrKill(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell) throws Exception {
        submitOrderFillOrKill(clientOrderID, onBehalfOf, limitRate,
                amount, ccyPair, buySell, null);
        if (this.recordRoundTripTime) {
            this.idToTimeMapForAck.put(clientOrderID, System.nanoTime());
        }

    }
    //used for base trading
    public void submitOrder(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                            String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate,
                            BigDecimal maxSlippage) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, "additionalTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitMidMatchOrder(String clOrdId, String buySell, String ccyPair, String amount, Character expiry,
            String midMatchTriggerRate, String mttl, String mttlMatchingPreference) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGCurrency, (ccyPair!=null) ? ccyPair.split("/")[0]:null);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_MidMatch);
        msg.setField(Constants.TAGTimeInForce, expiry);
        msg.setField(Constants.TAGMidMatchTriggerRate, midMatchTriggerRate);
        msg.setField(Constants.TAGMinTimeToLive, mttl);
        msg.setField(Constants.TAGMttlMatchingPreference, mttlMatchingPreference);
        msg.setField(Constants.TAGFinalRatePreference, "2");
        
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitMidMatchTreasuryOrder(NewOrderSingle midTOrder) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, midTOrder.getClOrdId());
        msg.setField(Constants.TAGAccount, null);
        msg.setField(Constants.TAGHandlInst, midTOrder.getHandlInst());
        msg.setField(Constants.TAGSymbol, midTOrder.getSymbol());
        msg.setField(Constants.TAGSymbolSfx, midTOrder.getSymbolSfx());
        msg.setField(Constants.TAGProduct, midTOrder.getProduct());
        msg.setField(Constants.TAGSecurityType, midTOrder.getSecurityType());
        msg.setField(Constants.TAGSide, midTOrder.getSide());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, midTOrder.getOrderQty());
        msg.setField(Constants.TAGOrdType, midTOrder.getOrdType());
        msg.setField(Constants.TAGTimeInForce, midTOrder.getTimeInForce());
        msg.setField(Constants.TAGCurrency, midTOrder.getCurrency());
        msg.setField(Constants.TAGMidMatchTriggerRate, midTOrder.getMidMatchTriggerRate());
        
        orderMsgMap.put(midTOrder.getClOrdId(), new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitOrderReplaceMidMatchTreasury(Message acceptedER, NewOrderSingle midTOrder) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGOrderID, acceptedER.getStringFieldValue(Constants.TAGOrderID));
        msg.setField(Constants.TAGOrigClOrdID, acceptedER.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGClOrdID, midTOrder.getClOrdId());
        msg.setField(Constants.TAGHandlInst, midTOrder.getHandlInst());
        msg.setField(Constants.TAGSymbol, midTOrder.getSymbol());
        msg.setField(Constants.TAGSymbolSfx, midTOrder.getSymbolSfx());
        msg.setField(Constants.TAGProduct, midTOrder.getProduct());
        msg.setField(Constants.TAGSecurityType, midTOrder.getSecurityType());
        msg.setField(Constants.TAGSide, midTOrder.getSide());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, midTOrder.getOrderQty());
        msg.setField(Constants.TAGOrdType, midTOrder.getOrdType());
        msg.setField(Constants.TAGMidMatchTriggerRate, midTOrder.getMidMatchTriggerRate());
        msg.setField(Constants.TAGText, "testOrderReplace");
        
        orderMsgMap.put(midTOrder.getClOrdId(), new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    //used for terms trading
    public void submitOrderTerms(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                 String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[1]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, "additionalTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitOrderExpiryInSeconds(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount,
                                           String ccyPair, String buySell, String orderType, BigDecimal minQty, String stopSide,
                                           BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String expiration,
                                           Integer time) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce, expiration);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.HOUR, 7);//GMT time
        c.add(Calendar.SECOND, time);
        Date d = c.getTime();
        if (expiration != null && expiration.equals("6")) {
            msg.setField(126, dateFormat.format(d));
        }
        msg.setField(Constants.TAGText, "additionalTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderTestDev20425(String comment, String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                        String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGText, comment);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderGTD(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount,
                               String ccyPair, String buySell, String orderType, BigDecimal minQty, String stopSide,
                               BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String expiryDate) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillDate);
        msg.setField(Constants.TAGExpireDate, expiryDate);
        msg.setField(Constants.TAGText, "additionalTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitOrder(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                            String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String ccy) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, "additionalTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);

    }

    public void submitRfqDraftUpload(String clientOrderID, String noPartyIds, String[] partyIds, String settlDate, String symbol, String symSfx, String side,
                                     String orderQty, String priceType, String ccy, String text, String orderQty2, String settDate2) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        if (noPartyIds != null) {
            msg.setField(Constants.TAGNoPartyIDs, noPartyIds);
            int numPartyIds = Integer.parseInt(noPartyIds);
            for (int i = 0; i < numPartyIds; i++) {
                msg.addField(Constants.TAGPartyID, partyIds[i]);
            }
        }
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGText, text);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_DraftUpload);
        
        msg.setField(Constants.TAGSettlDate, settlDate);
        //msg.setField(Constants.TAGExecInst, execInst);
        msg.setField(Constants.TAGOrderQty2, orderQty2);
        msg.setField(Constants.TAGSettlDate2, settDate2);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRfqDraftUploadStatus(String reqId) throws Exception {
        Message msg = new Message(Constants.MSGOrderMassStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMassStatusReqID, reqId);
        msg.setField(Constants.TAGMassStatusReqType, Constants.MASSSTATUSREQTYPE_RequestAllActiveDrafts);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_DraftUpload);
        sendFixMessage(msg);
    }

    public void submitRfqDraftUploadCancel(String clOrdId, String orderId, String side, String orderQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_DraftUpload);
        sendFixMessage(msg);
    }

    public void submitGFSOrder(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                               String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String expiry, String expSeconds) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce, expiry);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrder(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                            String orderType, BigDecimal minQty, String currency) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGClientID, onBehalfOf);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);

    }

    public void submitSlicedOrder(String clOrdId, String currency, String side, String symbol, String symSfx,
            String amount, String ordType, String account, String onBehalfOf, String price, String expiration,
            String expDate, String expTime, String minQty, String numStrategyParams, String[] params,
            String[] values, String numBanks, String[] banks) throws Exception {
        submitSlicedOrder(clOrdId, currency, side, symbol, symSfx,
                amount, ordType, account, onBehalfOf, price, expiration,
                expDate, expTime, minQty, numStrategyParams, params,
                values, numBanks, banks,
                null);
    }

    public void submitSlicedOrder(String clOrdId, String currency, String side, String symbol, String symSfx,
            String amount, String ordType, String account, String onBehalfOf, String price, String expiration,
            String expDate, String expTime, String minQty, String numStrategyParams, String[] params,
            String[] values, String numBanks, String[] banks, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGAccount, account);
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, expiration);
        if (expiration.equals("X")) {
            msg.setField(Constants.TAGExpireSecondsOrMillis, "30");
        }
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        if (numStrategyParams != null) {
            msg.setField("957", numStrategyParams);
            for (int num = 0; num < Integer.parseInt(numStrategyParams); num++) {
                if (params[num] != null) {
                    msg.addField("958", params[num]);
                }
                if (values[num] != null) {
                    msg.addField("960", values[num]);
                }
            }
        }

        if (numBanks != null) {
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, minQty);
        }
        if (banks != null) {
            for (String bank : banks) {
                msg.addField(FixTagConstants.TAGBrokerMatchID, bank);
            }
        }
        msg.setField(Constants.TAGVenueType, venueType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);


    }


    public void submitSlicedOrderNDF(String clOrdId, String currency, String side, String symbol, String symSfx, String amount, String ordType, String account,
                                  String onBehalfOf, String price, String expiration, String expDate, String expTime, String minQty, String numStrategyParams, String[] params, String[] values, String numBanks, String[] banks
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGAccount, account);
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FXNDF");
        msg.setField(Constants.TAGTimeInForce, expiration);
        if (expiration.equals("X")) {
            msg.setField(7558, "30");
        }
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        if (numStrategyParams != null) {
            msg.setField("957", numStrategyParams);
            for (int num = 0; num < Integer.parseInt(numStrategyParams); num++) {
                if (params[num] != null) {
                    msg.addField("958", params[num]);
                }
                if (values[num] != null) {
                    msg.addField("960", values[num]);
                }
            }
        }

        if (numBanks != null) {
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, minQty);
        }
        if (banks != null) {
            for (String bank : banks) {
                msg.addField(FixTagConstants.TAGBrokerMatchID, bank);
            }
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);


    }

    public void submitSlicedOrderFixedSlice(String clOrdId, String currency, String side, String symbol, String symSfx, String amount, String ordType, String account,
            String onBehalfOf, String price, String expiration, String expDate, String minQty, String sliceAmt, String numBanks, String[] banks, String sliceTimeInSeconds) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGAccount, account);
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTimeInForce, expiration);
        if (expiration.equals("X")) {
            msg.setField(7558, "30");
        }
        msg.setField(Constants.TAGExpireDate, expDate);

        Calendar c = Calendar.getInstance();
        int times = Integer.parseInt(amount)/Integer.parseInt(sliceAmt);

        c.add(Calendar.SECOND, Integer.parseInt(sliceTimeInSeconds) * times);//GMT time
        String date = dateFormat.format(c.getTime());
        msg.setField(FixTagConstants.TAGExpireTime, date);

        msg.setField(Constants.TAGExpireTime, date);
        msg.setField(Constants.TAGMinQty, minQty);
        if (sliceAmt != null) {
            msg.setField("957", "2");

            msg.addField("958", "0");
            msg.addField("960", "1");

            msg.addField("958", "3");
            msg.addField("960", sliceAmt);


        }

        if (numBanks != null) {
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, minQty);
        }
        if (banks != null) {
            for (String bank : banks) {
                msg.addField(FixTagConstants.TAGBrokerMatchID, bank);
            }
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);


    }

    public void submitStagedOrder(String clOrdId, String settlType,
                                  String symbol, String product, String side, String amount,
                                  String orderType, String currency) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
//        msg.setField(Constants.TAGSettlType, settlType); // required
        msg.setField(Constants.TAGSymbolSfx, settlType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);

    }


    public void submitRetailOrder(String clOrdId, String secClordId, String symbol, String product, String side,
                                  String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                                  String expDate, String expTime, String minQty, String expSeconds, String stopSide,
                                  String trailBy, String maxSlippage) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        //testing for dev-13522, remove
//        msg.setField("7589", "1.502011");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailOrderBroker(String clOrdId, String secClordId, String symbol, String product, String side,
                                        String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                                        String expDate, String expTime, String minQty, String expSeconds, String stopSide,
                                        String trailBy, String maxSlippage, String broker) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);


        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "1");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, broker);


        //testing for dev-13522, remove
//        msg.setField("7589", "1.502011");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);

    }

    public void submitRetailOrder(String clOrdId, String secClordId, String symbol, String product, String side,
                                  String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                                  String expDate, String expTime, String minQty, String expSeconds, String stopSide,
                                  String trailBy, String maxSlippage, String comment) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGText, comment);
        //testing for dev-13522, remove
//        msg.setField("7589", "1.502011");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitMMOrder(String clOrdId, String symbol, String product, String side,
                              String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                              String minQty, String stopSide, String[] allocAccount, String[] allocQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        if (allocAccount != null) {
            msg.setField(Constants.TAGNoAllocs, allocAccount.length);
            for (int i = 0; i < allocAccount.length; i++) {
                msg.addField(Constants.TAGAllocAccount, allocAccount[i]);
                msg.addField(Constants.TAGAllocQty, allocQty[i]);
            }
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitRetailOrderOnBehalf(String clOrdId, String onBehalf, String symbol, String product, String side,
                                          String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                                          String expDate, String expTime, String minQty, String expSeconds) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailOrderOnBehalf(String clOrdId, String secClordId, String symbol, String product, String side,
                                          String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
                                          String expDate, String expTime, String minQty, String expSeconds, String stopSide,
                                          String trailBy, String maxSlippage, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
            String expDate, String expTime, String securityType, String minQty, String expSeconds, String stopSide,
            String trailBy, String maxSlippage, String onBehalf) throws Exception {
        submitRetailOrderOnBehalf(clOrdId, secClordId, symbol, symbolSfx, product, side,
                currency, ordQty, ordType, price, stopPx, expiration,
                expDate, expTime, securityType, minQty, expSeconds, stopSide,
                trailBy, maxSlippage, onBehalf, null/*venueType*/);
    }

    public void submitRetailOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
            String expDate, String expTime, String securityType, String minQty, String expSeconds, String stopSide,
            String trailBy, String maxSlippage, String onBehalf, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        //testing for dev-13522, remove
        //msg.setField("7589", "1.502011");
        msg.setField(Constants.TAGVenueType, venueType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        
        sendFixMessage(msg);
        this.idToTimeMapForAck.put(clOrdId, System.nanoTime());
        this.idToTimeMapForFill.put(clOrdId, System.nanoTime());
    }
    
    public Message submitEspOrder(NewOrderSingle newOrder) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, newOrder.getClOrdId()); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, newOrder.getCurrency());
        msg.setField(Constants.TAGSide, newOrder.getSide());
        msg.setField(Constants.TAGSymbol, newOrder.getSymbol());
        msg.setField(Constants.TAGSymbolSfx, newOrder.getSymbolSfx());
        msg.setField(Constants.TAGProduct, newOrder.getProduct());
        msg.setField(Constants.TAGSecurityType, newOrder.getSecurityType());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, newOrder.getOrderQty());
        msg.setField(Constants.TAGOrdType, newOrder.getOrdType());
        msg.setField(Constants.TAGPrice, newOrder.getPrice());
        msg.setField(Constants.TAGTimeInForce, newOrder.getTimeInForce());
        msg.setField(Constants.TAGMinQty, newOrder.getMinQty());
        msg.setField(Constants.TAGText, "test additional Terms");
        msg.setField(Constants.TAGStopSide, newOrder.getStopSide());
        msg.setField(Constants.TAGTrailBy, newOrder.getTrailBy());
        
        if (newOrder.getTraderUser() != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, newOrder.getTraderUser());
            msg.addField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);
        }
        
        msg.setField(Constants.TAGAccount, newOrder.getAccount());
        
        orderMsgMap.put(newOrder.getClOrdId(), new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        return msg;
    }

    public void submitRetailOrderOnBehalfFwd(String clOrdId, String secClordId, String symbol, String symbolSfx, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String expiration,
            String expDate, String expTime, String securityType, String minQty, String expSeconds, String stopSide,
            String trailBy, String maxSlippage, String bidForwardPoint, String offerForwardPoint, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGBidForwardPoints, bidForwardPoint);
        msg.setField(Constants.TAGOfferForwardPoints, offerForwardPoint);
        
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        //testing for dev-13522, remove
        //msg.setField("7589", "1.502011");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitDiscretionaryOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String DiscretionInst, String DiscretionOffset,
            String maxShow, String expiration, String expDate, String expTime, String securityType, String minQty,
            String expSeconds, String stopSide, String trailBy, String maxSlippage, String onBehalf) throws Exception {

        submitDiscretionaryOrderOnBehalf(clOrdId, secClordId, symbol, symbolSfx, product, side,
                currency, ordQty, ordType, price, stopPx, DiscretionInst, DiscretionOffset,
                maxShow, expiration, expDate, expTime, securityType, minQty,
                expSeconds, stopSide, trailBy, maxSlippage, onBehalf,
                null);
    }

    public void submitDiscretionaryOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product, String side,
            String currency, String ordQty, String ordType, String price, String stopPx, String DiscretionInst, String DiscretionOffset,
            String maxShow, String expiration, String expDate, String expTime, String securityType, String minQty,
            String expSeconds, String stopSide, String trailBy, String maxSlippage, String onBehalf,
            String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGiDiscretionInst, DiscretionInst);
        msg.setField(Constants.TAGiDiscretionOffset, DiscretionOffset);
        msg.setField(Constants.TAGMaxShow, maxShow);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        msg.setField(FixTagConstants.TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailBy);
        msg.setField(TAGMaxSlippage, maxSlippage);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGVenueType, venueType);
        //testing for dev-13522, remove
        //msg.setField("7589", "1.502011");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitCROrderOutright(String clOrdId, String symbol, String side,
            String currency, String ordQty, String ordType, String timeInForce, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGSettlType, "6");
        msg.setField(Constants.TAGSettlDate, "20121227");
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoAllocs, "1");
            msg.addField(Constants.TAGAllocAccount, onBehalf);
            msg.addField(Constants.TAGAllocQty, "1460000");//client
        }
        msg.setField(Constants.TAGExDestination, "XOTC");
        msg.setField(Constants.TAGCFICode, "MRCXXX");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitCROrderSwap(String clOrdId) throws Exception {
        Message msg = new Message("AB", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
//        if (onBehalf != null) {
//            msg.setField(Constants.TAGNoPartyIDs, "1");
//            msg.addField(Constants.TAGPartyID, onBehalf);
//            msg.addField(Constants.TAGPartyIDSource, "C");//client
//        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGExDestination, "XOTC");
        msg.setField(Constants.TAGSide, "1");
        msg.setField(Constants.TAGSymbol, "EUR/USD");
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGNoLegs, "2");
        msg.addField(Constants.TAGLegSymbol, "EUR/USD");
        msg.addField(Constants.TAGLegProduct, "4");
        msg.addField(Constants.TAGLegSecurityType, "FOR");
        msg.addField(Constants.TAGLegSide, "1");
        msg.addField(Constants.TAGLegCurrency, "EUR");
        msg.addField(Constants.TAGLegQty, "2000000");
        msg.addField(Constants.TAGNoLegAllocs, "1");
        msg.addField(Constants.TAGLegAllocAccount, "1316TEST");
        msg.addField(Constants.TAGLegAllocQty, "2000000");
        msg.addField(Constants.TAGLegSettlType, "6");
        msg.addField(Constants.TAGLegSettlDate, "20121221");

        msg.addField(Constants.TAGLegSymbol, "EUR/USD");
        msg.addField(Constants.TAGLegProduct, "4");
        msg.addField(Constants.TAGLegSecurityType, "FOR");
        msg.addField(Constants.TAGLegSide, "2");
        msg.addField(Constants.TAGLegCurrency, "EUR");
        msg.addField(Constants.TAGLegQty, "2000000");
        msg.addField(Constants.TAGNoLegAllocs, "1");
        msg.addField(Constants.TAGLegAllocAccount, "1316TEST");
        msg.addField(Constants.TAGLegAllocQty, "2000000");
        msg.addField(Constants.TAGLegSettlType, "6");
        msg.addField(Constants.TAGLegSettlDate, "20121228");

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, "0");
        msg.setField(Constants.TAGOrdType, "1");
        msg.setField(Constants.TAGCurrency, "EUR");
        msg.setField(7567, "1");
        msg.addField(7561, "regressionMaker_DO_NOT_CHANGE");
        msg.setField(Constants.TAGTimeInForce, "1");
        msg.setField(Constants.TAGMultiLegRptTypeReq, "2");


        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitCRCancelOrder(String origClOrdID, String orderID, String newClOrdID, String symbol, String maturityDate, String side, String ordQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdID);
        msg.setField(Constants.TAGOrderID, orderID);
        msg.setField(Constants.TAGClOrdID, newClOrdID); // required
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGCFICode, "FFCNNO");
        msg.setField(Constants.TAGMaturityDate, maturityDate);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        orderMsgMap.put(newClOrdID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }



    public void submitRetailIcebergOrder(String clOrdId, String secClordId, String symbol, String product, String side,
                                         String currency, String ordQty, String ordType, String price, String maxShow) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGMaxShow, maxShow);
//        msg.setField(Constants.TAGMinQty, "0");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailIcebergOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product,
            String side, String currency, String ordQty, String ordType, String price, String securityType,
            String maxShow, String onBehalf) throws Exception {
        submitRetailIcebergOrderOnBehalf(clOrdId, secClordId, symbol, symbolSfx, product,
                side, currency, ordQty, ordType, price, securityType,
                maxShow, onBehalf, null);
    }


    public void submitRetailIcebergOrderOnBehalf(String clOrdId, String secClordId, String symbol, String symbolSfx, String product,
            String side, String currency, String ordQty, String ordType, String price, String securityType,
            String maxShow, String onBehalf, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        msg.setField(Constants.TAGMaxShow, maxShow);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGVenueType, venueType);

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailIcebergOrderOnBehalfExpiration(String clOrdId, String secClordId, String symbol, String symbolSfx, String product,
            String side, String currency, String ordQty, String ordType, String price, String securityType,
            String maxShow, String expiration, String expDate, String expTime, String expSeconds, String onBehalf) throws Exception {
         Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
         msg.setField(Constants.TAGClOrdID, clOrdId); // required
         msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
         msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
         msg.setField(Constants.TAGSymbol, symbol);
         if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
         msg.setField(Constants.TAGProduct, product);
         msg.setField(Constants.TAGSide, side);
         msg.setField(Constants.TAGCurrency, currency);
         msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
         msg.setField(Constants.TAGOrderQty, ordQty);
         msg.setField(Constants.TAGOrdType, ordType);
         msg.setField(Constants.TAGPrice, price);
         if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
         msg.setField(Constants.TAGMaxShow, maxShow);
         msg.setField(Constants.TAGTimeInForce, expiration);
         msg.setField(Constants.TAGExpireDate, expDate);
         msg.setField(Constants.TAGExpireTime, expTime);
         msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
         if (onBehalf != null) {
             msg.setField(Constants.TAGNoPartyIDs, "1");
             msg.addField(Constants.TAGPartyID, onBehalf);
             msg.addField(Constants.TAGPartyRole, "3");//client
         }
         //testing for dev-13522, remove
         //msg.setField("7589", "1.502011");
         orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
         sendFixMessage(msg);
    }

    public void submitIcebergOrder(String clOrdId, String symbol, String side,
                                   String currency, String ordQty, String ordType, String price, String maxShow) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGMaxShow, maxShow);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIcebergOrder(String clOrdId, String onBehalfOf, String symbol, String side,
                                   String currency, String ordQty, String ordType, String price, String maxShow) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGMaxShow, maxShow);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitFXPeggedOrder(String clOrdId, String secClordId, String symbol, String side,
                                    String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
                                    String peggedOrdOffset, String peggedOrdDiscretion) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        msg.setField(Constants.TAGMinQty, "0");
//        //TODO:
//        msg.setField(FixTagConstants.TAGTimeInForce, "X");
//        msg.setField(FixTagConstants.TAGExpireSeconds, "5");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitPeggedOrder(String clOrdId, String symbol, String side,
                                  String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
                                  String peggedOrdOffset, String peggedOrdDiscretion) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);

    }

    public void submitPeggedOrder(String clOrdId, String onBehalfOf, String symbol, String side,
                                  String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
                                  String peggedOrdOffset, String peggedOrdDiscretion) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitPeggedOrderGoodForSeconds(String clOrdId, String onBehalfOf, String symbol, String side,
            String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String seconds) throws Exception {
        submitPeggedOrderGoodForSeconds(clOrdId, onBehalfOf, symbol, side,
                currency, ordQty, ordType, peggedOrdType, peggedOrdSide,
                peggedOrdOffset, peggedOrdDiscretion, seconds, null);
    }

    public void submitPeggedOrderGoodForSeconds(String clOrdId, String onBehalfOf, String symbol, String side,
            String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String seconds, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodForSeconds);
        msg.setField(Constants.TAGExpireSecondsOrMillis, seconds);

        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        msg.setField(Constants.TAGVenueType, venueType);

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitPeggedOrderGoodForSecondsFwd(String clOrdId, String onBehalfOf, String symbol, String symbolSfx, 
            String side, String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String seconds) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGTimeInForce, "X");
        msg.setField(Constants.TAGExpireSecondsOrMillis, seconds);

        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitPeggedOrderGoodForSecondsNDF(String clOrdId, String onBehalfOf, String symbol, String symbolSfx, String side,
            String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String seconds, String securityType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGTimeInForce, "X");
        msg.setField(Constants.TAGExpireSecondsOrMillis, seconds);

        msg.setField(Constants.TAGSecurityType, securityType);

        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    //complex IOC not supported, only use in negative test cases
    public void submitPeggedOrderGoodForSecondsIOC(String clOrdId, String onBehalfOf, String symbol, String side,
            String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
            String peggedOrdOffset, String peggedOrdDiscretion, String seconds) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGTimeInForce, "3");

        msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitComplexOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                   String orderType, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide,
                                   String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide,
                                   BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGText, "additionalTermsComplex");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitComplexOrderGTD(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                      String orderType, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide,
                                      String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide,
                                      BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide,
                                      String product, String ifDoneIfLimitRate, String positionId, BigDecimal ifDoneThenLimitRate,
                                      String expiryDate) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);

        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillDate);
        msg.setField(Constants.TAGExpireDate, expiryDate);
//removing these lines since partial fills are now supported in IFD and IFDOCO
//        if(orderType.equals("Y") || orderType.equals("X"))
        msg.setField(Constants.TAGMinQty, "0");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitComplexOrderIOC(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String orderType, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide,
            String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide,
            BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide,
            String product, String ifDoneIfLimitRate, String positionId, BigDecimal ifDoneThenLimitRate
            ) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);

        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_ImmediateOrCancel);
        //removing these lines since partial fills are now supported in IFD and IFDOCO
        //if(orderType.equals("Y") || orderType.equals("X"))
        msg.setField(Constants.TAGMinQty, "0");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitComplexOrderReplaceGTD(String orderId, String onBehalfOf, String origClordId, String clOrdId, String symbol, String product,
                                             String orderQty, String ordType, String price, String stopPx,
                                             String ccy, String positionId, String ifDoneIfType, String ifDoneIfSide, String ifDoneIfStopRate, String ifDoneIfStopSide,
                                             String ifDoneThenType, String ifDoneThenSide, String ifDoneThenStopRate, String ifDoneThenStopSide,
                                             String ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, String ocoLeg2StopRate, String ocoLeg2stopSide,
                                             String ifDoneIfLimitRate, String expiryDate) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillDate);
        msg.setField(Constants.TAGExpireDate, expiryDate);
        sendFixMessage(msg);
    }
    
    public void submitOrderRFQLD(Subscription sub, Message quote, String clOrdId) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSecondaryClOrdID, quote.getStringFieldValue(Constants.TAGQuoteReqID));
        msg.setField(Constants.TAGSymbol, quote.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_MoneyMarket);
        msg.setField(Constants.TAGSide, sub.side);
        msg.setField(Constants.TAGOrderQty, sub.amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGQuoteID, quote.getStringFieldValue(Constants.TAGQuoteID));      
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitOrderRFQ(Subscription sub, Message quote) throws Exception {
        doSubmitOrderRFQ(sub, quote, sub.side, null);
    }
    
    public void submitOrderRFQ(Subscription sub, Message quote, String side) throws Exception {
        
        doSubmitOrderRFQ(sub, quote, side, null);
    }
    
    public void submitOrderRFQ(Subscription sub, Message quote, String side, TakerTestSession routedTaker) throws Exception {
        
        doSubmitOrderRFQ(sub, quote, side, routedTaker);
    }
    
    private void doSubmitOrderRFQ(Subscription sub, Message quote, String side, TakerTestSession routedTaker) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, quote.getStringFieldValue(Constants.TAGQuoteReqID));
        
        if(routedTaker!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedTaker.getUserName());
            msg.setField(Constants.TAGPartyRole, "3");
        }
        
        msg.setField(Constants.TAGAccount, sub.account);
        msg.setField(Constants.TAGSymbol, quote.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGSecurityType, sub.securityType);
        
        // Component <InstrumentParties> (for Cleared NDF)
        if(sub.instrumentParties!=null){
            msg.setField(Constants.TAGNoInstrumentParties, "1");
            for(InstrumentParty instParty:sub.instrumentParties){
                if(instParty.instrumentPartyRole.equals("21")){ // 21 = Clearing Organization (DCO)
                    msg.setField(Constants.TAGInstrumentPartyID, instParty.instrumentPartyID);
                    msg.setField(Constants.TAGInstrumentPartyIDSource, instParty.instrumentPartyIDSource);
                    msg.setField(Constants.TAGInstrumentPartyRole , instParty.instrumentPartyRole);
                    break;
                }
            }
        }
        
        side = (side.equals(Constants.SIDE_Buy) || side.equals(Constants.SIDE_TwoWayBuy))?Constants.SIDE_Buy:Constants.SIDE_Sell;
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFutSettDate, quote.getStringFieldValue(Constants.TAGFutSettDate));
        msg.setField(Constants.TAGOrderQty, sub.amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
        String price = null;
        
        if((!termsTrading && Constants.SIDE_Buy.equals(side)) || 
        (termsTrading && Constants.SIDE_Sell.equals(side))) {
            price = quote.getStringFieldValue(Constants.TAGOfferPx);
        } else if((!termsTrading && Constants.SIDE_Sell.equals(side)) || 
                (termsTrading && Constants.SIDE_Buy.equals(side))) {
            price = quote.getStringFieldValue(Constants.TAGBidPx);
        }

        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, sub.currency);
        msg.setField(Constants.TAGQuoteID, quote.getStringFieldValue(Constants.TAGQuoteID));
        
        if(sub.amount2!=null){
            msg.setField(Constants.TAGOrderQty2, sub.amount2);
            
            String price2 = null;
            
            if((!termsTrading && Constants.SIDE_Buy.equals(side)) || 
            (termsTrading && Constants.SIDE_Sell.equals(side))) {
                price2 = quote.getStringFieldValue(Constants.TAGBidPxFar);
            } else if((!termsTrading && Constants.SIDE_Sell.equals(side)) || 
                    (termsTrading && Constants.SIDE_Buy.equals(side))) {
                price2 = quote.getStringFieldValue(Constants.TAGOfferPxFar);
            }

            msg.setField(Constants.TAGPrice2, price2);
        }
        
        //add for MTF, only supported value "M" can be get from quote msg.
        msg.setField(Constants.TAGVenueType, quote.getStringFieldValue(Constants.TAGVenueType));
        
        orderMsgMap.put(quote.getStringFieldValue(Constants.TAGQuoteReqID), new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
        
        submittedPricesMap.put(sub.requestId, price);
    }

    
    public void submitOrderRFQMultiLeg(Subscription sub, Message quote, TakerTestSession routedTaker) throws Exception {
        Message msg = new Message(Constants.MSGNewOrderMultileg, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, quote.getStringFieldValue(Constants.TAGQuoteReqID));
        
        if(routedTaker!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, routedTaker.getUserName());
            msg.setField(Constants.TAGPartyRole, "3");
        }

        msg.setField(Constants.TAGSymbol, quote.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGProduct, sub.product);
        msg.setField(Constants.TAGSecurityType, sub.securityType);

        // Component <LegOrdGrp> (for RFQ Multi-Leg)
        validateTag(Constants.TAGNoLegs, sub.noLegs, quote.getStringFieldValue(Constants.TAGNoLegs));
        
        IFixGroup[] legs = quote.getParser().getDynamicGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);
        msg.setField(Constants.TAGNoLegs, quote.getStringFieldValue(Constants.TAGNoLegs));

        for(IFixGroup leg:legs){
            msg.setField(Constants.TAGLegSymbol, leg.getStringValFor(Constants.TAGiLegSymbol));
            msg.setField(Constants.TAGLegSide, leg.getStringValFor(Constants.TAGiLegSide));
            msg.setField(Constants.TAGLegCurrency, leg.getStringValFor(Constants.TAGiLegCurrency));

            msg.setField(Constants.TAGLegQty, leg.getStringValFor(Constants.TAGiLegQty));
            msg.setField(Constants.TAGLegRefID,leg.getStringValFor(Constants.TAGiLegRefID));
            msg.setField(Constants.TAGLegPrice, calculateLegPrice(quote, leg.getStringValFor(Constants.TAGiLegRefID)));
            msg.setField(Constants.TAGLegSettlDate, leg.getStringValFor(Constants.TAGiLegSettlDate));
        }


        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGQuoteID, quote.getStringFieldValue(Constants.TAGQuoteID));
        
        orderMsgMap.put(quote.getStringFieldValue(Constants.TAGQuoteReqID), new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    
    private String calculateLegPrice(Message quote, String legRefID) throws Exception{
        
        if(quote.getStringFieldValue(Constants.TAGNoLegs)==null || 
                quote.getStringFieldValue(Constants.TAGNoLegs).equals("0")){
            fail("Incorrect number of legs in Quote");
        }
        
        validateTagNotNull(Constants.TAGBidSpotRate, quote.getStringFieldValue(Constants.TAGBidSpotRate));
        validateTagNotNull(Constants.TAGOfferSpotRate, quote.getStringFieldValue(Constants.TAGOfferSpotRate));
        
        IFixGroup[] legs = quote.getParser().getDynamicGroupDataFor(Constants.TAGiNoLegs, Constants.TAGiLegSymbol);

        for(IFixGroup leg:legs){
            
            if(leg.getStringValFor(Constants.TAGiLegRefID)!=null &&
                    leg.getStringValFor(Constants.TAGiLegRefID).equals(legRefID)){
                
                String legSide = leg.getStringValFor(Constants.TAGiLegSide);
                String legFwdPoints = null;
                
                if(legSide.equals(Constants.SIDE_Buy)){
                    legFwdPoints = leg.getStringValFor(Constants.TAGiLegBidForwardPoints);
                }else if(legSide.equals(Constants.SIDE_Sell)){
                    legFwdPoints = leg.getStringValFor(Constants.TAGiLegOfferForwardPoints);
                }else{
                    fail("Incorrect value of legSide in Quote: "+legSide);
                }
                
                double legFwdPointsInDouble = (legFwdPoints==null)? 0 : Double.valueOf(legFwdPoints);
                double spotRateInDouble = legSide.equals(Constants.SIDE_Buy)? 
                        Double.valueOf(quote.getStringFieldValue(Constants.TAGBidSpotRate)):
                            Double.valueOf(quote.getStringFieldValue(Constants.TAGOfferSpotRate));                
                double price = spotRateInDouble + (legFwdPointsInDouble/100);
                
                return String.valueOf(price);
            }
        }
        
        fail("Error calculating price from Quote");
        return null;
    }
    
    
    
    
    
    public void submitOrderRFQ(String clientOrderID, String valueDate, String handleInstr,
                               String symbol, String side, String amount,
                               String ordType, String quoteReqId, String price, String currency,
                               String quoteId, String securityType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQBroker(String clientOrderID, String valueDate, String handleInstr,
                                     String symbol, String side, String amount,
                                     String ordType, String quoteReqId, String price, String currency,
                                     String quoteId, String expiration, String broker) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "1");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, broker);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }


    public void submitOrderRFQOnBehalf(String clientOrderID, String accountId, String onBehalfOf,
                                       String valueDate, String handleInstr,
                                       String symbol, String side, String amount,
                                       String ordType, String quoteReqId, String price, String currency,
                                       String quoteId, String expiration) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGAccount, accountId);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGClientID, onBehalfOf);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }


    public void submitOrderLDRFQ(String clientOrderID, String quoteRequestID,
                                 String symbol, String product, String side,
                                 String transactTime, String orderQty, String ordType,
                                 String quoteId) throws Exception {
        submitOrderLDRFQ(clientOrderID, quoteRequestID, symbol, product, side, transactTime, 
                orderQty, ordType, quoteId, null, null);
    }
    
    public void submitOrderLDRFQ(String clientOrderID, String quoteRequestID,
            String symbol, String product, String side,
            String transactTime, String orderQty, String ordType,
            String quoteId, String onBehalfOf, String account) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGSecondaryClOrdID, quoteRequestID);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, transactTime);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteID, quoteId);
        
        if(onBehalfOf!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.setField(Constants.TAGPartyID, onBehalfOf);
            msg.setField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);
        }
        
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitRetailComplexOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                         String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
                                         BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
                                         BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate, String positionId,
            BigDecimal ifDoneThenLimitRate) throws Exception {
        submitRetailComplexOrder(clOrdId, onBehalfOf, amount, ccyPair,
                symbolSfx, securityType, orderType, ifDoneIfType, ifDoneIfSide,
                ifDoneIfStopRate, ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide,
                ifDoneThenStopRate, ifDoneThenStopSide, ocoLeg1LimitRate, ocoLeg2Type,
                ocoLeg2Side, ocoLeg2StopRate, ocoLeg2stopSide, product,
                ifDoneIfLimitRate, positionId, ifDoneThenLimitRate, null);
    }

    public void submitRetailComplexOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate, String positionId,
            BigDecimal ifDoneThenLimitRate, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }

        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
//removing these lines since partial fills are now supported in IFD and IFDOCO
//        if(orderType.equals("Y") || orderType.equals("X"))
        msg.setField(Constants.TAGMinQty, "0");
        msg.setField(Constants.TAGVenueType, venueType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailComplexOrderGFS(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate,
            String positionId, BigDecimal ifDoneThenLimitRate, String expiration, String expDate, String expTime, String expSeconds) throws Exception {
              Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
              msg.setField(Constants.TAGClOrdID, clOrdId); // required
              if (onBehalfOf != null) {
                  msg.setField(Constants.TAGNoPartyIDs, "1");
                  msg.addField(Constants.TAGPartyID, onBehalfOf);
                  msg.addField(Constants.TAGPartyRole, "3");//client
                  }
              msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
              msg.setField(Constants.TAGSymbol, ccyPair);
              if(symbolSfx!=null) {
                msg.setField(Constants.TAGSymbolSfx, symbolSfx);
            }
              if(securityType!=null) {
                msg.setField(Constants.TAGSecurityType, securityType);
            }

              msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
              msg.setField(Constants.TAGOrderQty, amount);
              msg.setField(Constants.TAGOrdType, orderType);
              msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);

              // If Leg
              if (ifDoneIfType != null) {
                 msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
                 msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
                 msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
                 msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
                 msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
                 // IfDoneThen side
                 msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
                 msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
                 msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
                 msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
                 }
                 msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
                 msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
                 msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
                 msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
                 msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
                 msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
                 msg.setField(Constants.TAGProduct, product);
                 msg.setField(Constants.TAGSecondaryClOrdID, positionId);
                 msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
                 msg.setField(Constants.TAGTimeInForce, expiration);
                 msg.setField(Constants.TAGExpireDate, expDate);
                 msg.setField(Constants.TAGExpireTime, expTime);
                 msg.setField(Constants.TAGMinQty, "0");
                 msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
                 orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
                 sendFixMessage(msg);
      }

    public void submitIfDoneOcoOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                     String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
                                     BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
                                     BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate, String positionId,
            BigDecimal ifDoneThenLimitRate) throws Exception {

        submitIfDoneOcoOrder(clOrdId, onBehalfOf, amount, ccyPair,
                symbolSfx, securityType, orderType, ifDoneIfType, ifDoneIfSide,
                ifDoneIfStopRate, ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide,
                ifDoneThenStopRate, ifDoneThenStopSide, ocoLeg1LimitRate, ocoLeg2Type, ocoLeg2Side,
                ocoLeg2StopRate, ocoLeg2stopSide, product, ifDoneIfLimitRate, positionId,
                ifDoneThenLimitRate, null);
    }

    public void submitIfDoneOcoOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate, String positionId,
            BigDecimal ifDoneThenLimitRate, String venueType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }

        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0");
        msg.setField(Constants.TAGVenueType, venueType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIfDoneOcoOrderGFS(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate,
            String positionId, BigDecimal ifDoneThenLimitRate, String expiration, String expDate, String expTime, String expSeconds) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);

        // If Leg
        if (ifDoneIfType != null) {
        msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
        msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
        msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
        msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
        msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
        // IfDoneThen side
        msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
        msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
        msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
        msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, "0");
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }


    public void submitOcoOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                               String symbolSfx, String securityType, String orderType, String ifDoneIfType, String ifDoneIfSide,
                               BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
                               BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
                               BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String product, String ifDoneIfLimitRate, String positionId, BigDecimal ifDoneThenLimitRate) throws Exception {

        submitOcoOrder(clOrdId, onBehalfOf, amount, ccyPair, symbolSfx, ifDoneIfType, ifDoneIfSide, ifDoneIfStopRate, 
                ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide, ifDoneThenStopRate, ifDoneThenStopSide,
                ocoLeg1LimitRate, ocoLeg2Type,
                ocoLeg2Side, ocoLeg2StopRate, ocoLeg2stopSide, ifDoneIfLimitRate, ifDoneThenLimitRate, 
                Constants.TIMEINFORCE_GoodTillCancel, null, null);
    }
    
    public void submitOcoOrderIceberg(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, 
            String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, 
            BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, 
            String ifDoneIfLimitRate, BigDecimal ifDoneThenLimitRate, String maxShowAmt) throws Exception {
        submitOcoOrderIceberg(clOrdId, onBehalfOf, amount, ccyPair,
                symbolSfx, ifDoneIfType, ifDoneIfSide, ifDoneIfStopRate, ifDoneIfStopSide,
                ifDoneThenType, ifDoneThenSide, ifDoneThenStopRate, ifDoneThenStopSide,
                ocoLeg1LimitRate, ocoLeg2Type, ocoLeg2Side, ocoLeg2StopRate, ocoLeg2stopSide,
                ifDoneIfLimitRate, ifDoneThenLimitRate, maxShowAmt,
                null);
    }

    public void submitOcoOrderIceberg(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, 
            String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, 
            BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, 
            String ifDoneIfLimitRate, BigDecimal ifDoneThenLimitRate, String maxShowAmt, String venueType) throws Exception {

        submitOcoOrder(clOrdId, onBehalfOf, amount, ccyPair, symbolSfx, ifDoneIfType, ifDoneIfSide, ifDoneIfStopRate,
                ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide, ifDoneThenStopRate, ifDoneThenStopSide,
                ocoLeg1LimitRate, ocoLeg2Type,
                ocoLeg2Side, ocoLeg2StopRate, ocoLeg2stopSide, ifDoneIfLimitRate, ifDoneThenLimitRate,
                Constants.TIMEINFORCE_GoodTillCancel, null, maxShowAmt, venueType);
    }

    public void submitOcoOrderGFS(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String ifDoneIfLimitRate,
            BigDecimal ifDoneThenLimitRate, String expSeconds, String maxShowAmt) throws Exception {
        
        submitOcoOrder(clOrdId, onBehalfOf, amount, ccyPair, symbolSfx, ifDoneIfType, ifDoneIfSide, ifDoneIfStopRate, 
                ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide, ifDoneThenStopRate, ifDoneThenStopSide, ocoLeg1LimitRate, ocoLeg2Type, 
                ocoLeg2Side, ocoLeg2StopRate, ocoLeg2stopSide, ifDoneIfLimitRate, ifDoneThenLimitRate, 
                Constants.TIMEINFORCE_GoodForSeconds, expSeconds, maxShowAmt);
    }
    
    public void submitOcoOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String ifDoneIfLimitRate,
            BigDecimal ifDoneThenLimitRate, String expiration, String expSeconds, String maxShowAmt) throws Exception {
        submitOcoOrder(clOrdId, onBehalfOf, amount, ccyPair,
                symbolSfx, ifDoneIfType, ifDoneIfSide,
                ifDoneIfStopRate, ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide,
                ifDoneThenStopRate, ifDoneThenStopSide, ocoLeg1LimitRate, ocoLeg2Type, ocoLeg2Side,
                ocoLeg2StopRate, ocoLeg2stopSide, ifDoneIfLimitRate,
                ifDoneThenLimitRate, expiration, expSeconds, maxShowAmt,
                null);
    }
    
    public void submitOcoOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
            String symbolSfx, String ifDoneIfType, String ifDoneIfSide,
            BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide, BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide, String ifDoneIfLimitRate,
            BigDecimal ifDoneThenLimitRate, String expiration, String expSeconds, String maxShowAmt,
            String venueType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, ocoLeg2Side);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_OCO);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGMinQty, "0");
        msg.setField(Constants.TAGMaxShow, maxShowAmt);
        msg.setField(Constants.TAGExpireSecondsOrMillis, expSeconds);
        
        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        
        //msg.setField(Constants.TAGSecondaryClOrdID, positionId); //Retail only
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGVenueType, venueType);
        
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitMmComplexOrder(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                     String orderType, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide,
                                     String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide,
                                     BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide,
                                     String product, String ifDoneIfLimitRate, String positionId, BigDecimal ifDoneThenLimitRate, String[] allocAccount, String[] allocQty) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
            msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
            msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, "0");

        if (allocAccount != null) {
            msg.setField(Constants.TAGNoAllocs, allocAccount.length);
            for (int i = 0; i < allocAccount.length; i++) {
                msg.addField(Constants.TAGAllocAccount, allocAccount[i]);
                msg.addField(Constants.TAGAllocQty, allocQty[i]);
            }
        }
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrder(final Message orderMsg) throws Exception {
        if (!orderMsg.getMsgType().equals(Constants.MSGOrderSingle)) {
            throw new IllegalArgumentException("submit none order msg");
        }
        String clOrdId = orderMsg.getStringFieldValue(Constants.TAGClOrdID);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(orderMsg);
    }


    public void clearOrderUpdateMsgQueue(String clOrdID, long timeout) {
        BlockingQueue<Message> msgQ = orderMsgMap.get(clOrdID);
        if (msgQ == null) {
            throw new IllegalArgumentException("order does not exist " + clOrdID);
        }
        while (msgQ.size() > 0) {
            try {
                msgQ.poll(timeout, TimeUnit.MILLISECONDS);
                this.msgQ.poll();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Message getOrderUpdateMsg(String clOrdID, long timeout) {
        BlockingQueue<Message> msgQ = orderMsgMap.get(clOrdID);
        if (msgQ == null) {
            throw new IllegalArgumentException("order does not exist " + clOrdID);
        }
        Message msg = null;
        try {
            msg = msgQ.poll(timeout, TimeUnit.MILLISECONDS);
            this.msgQ.poll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return msg;
    }

    public Message getPriceUpdateMsg(String requestId, long timeout) {
        BlockingQueue<Message> msgQ = priceMsgMap.get(requestId);

        if (msgQ == null) {
            throw new IllegalArgumentException("price request does not exist " + requestId);
        }
        Message msg = null;
        try {
            msg = msgQ.poll(timeout, TimeUnit.MILLISECONDS);
            this.msgQ.poll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }
    
    public MDEntry getMDEntryByReqId(String requestId, long timeout) {
        BlockingQueue<MDEntry> mdEntryQ = mdEntryMap.get(requestId);
        if (mdEntryQ == null) {
            throw new IllegalArgumentException("MarketDataRequest doesn't exist for:" + requestId);
        }
        MDEntry mdEntry = null;
        try {
            mdEntry = mdEntryQ.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return mdEntry;
    }

    public void submitQuoteResponseIrsRFQ(String quoteRespId, String quoteId, String quoteRespType, String clOrdId, String account,
                                          String bidPx, String offerPx, String priceType) throws Exception {
        Message msg = new Message(Constants.MSGQuoteResponse, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteRespID, quoteRespId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGQuoteRespType, quoteRespType);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGOfferPx, offerPx);
        msg.setField(Constants.TAGPriceType, priceType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        System.out.println();
        System.out.println("sending out a quote response to hit");
        System.out.println();
        sendFixMessage(msg);
    }

    public void submitQuoteResponseRFQLE(String quoteRespId, String quoteId, String quoteRespType, String clOrdId, String account,
            String bidPx, String offerPx, Party[] parties) throws Exception {
        Message msg = new Message(Constants.MSGQuoteResponse, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGQuoteRespID, quoteRespId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGQuoteRespType, quoteRespType);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        
        if(parties!=null && parties.length>0){
            msg.setField(Constants.TAGNoPartyIDs, parties.length);
            for(Party party:parties){
                msg.setField(Constants.TAGPartyID, party.partyID);
                msg.setField(Constants.TAGPartyIDSource, party.partyIDSource);
                msg.setField(Constants.TAGPartyRole, party.partyRole);
            }
        }
        
        msg.setField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Government);
        
        msg.setField(Constants.TAGSecurityType, "TNOTE");
        msg.setField(Constants.TAGAccount, account);        
        msg.setField(Constants.TAGBidPx, bidPx);
        msg.setField(Constants.TAGPriceType, Constants.PRICETYPE_Price);
        sendFixMessage(msg);
    }


    public void submitOrderRFQ(String clientOrderID, String valueDate, String handleInstr,
                               String symbol, String side, String amount,
                               String ordType, String quoteReqId, String price, String currency,
                               String quoteId, String expiration, String valueDate2) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGOrderQty2, amount);
        msg.setField(Constants.TAGPrice2, price);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGFutSettDate2, valueDate2);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQSwapOnBehalf(String clientOrderID, String onBehalfOf, String valueDate,
                                           String handleInstr, String symbol, String side, String amount,
                                           String ordType, String quoteReqId, String price, String currency,
                                           String quoteId, String expiration, String valueDate2) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGFutSettDate2, valueDate2);
        msg.setField(Constants.TAGOrderQty2, amount);
        msg.setField(Constants.TAGPrice2, price);
        msg.setField(Constants.TAGClientID, onBehalfOf);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIRSwapQuoteRequestRFQ(String reqId, String originCode, String ctiCode,
                                            String zCode, String cfad, String maturityDate, String interestDate, String side, String orderQty,
                                            String account, String priceType) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, reqId);
        msg.setField(Constants.TAGOrderCapacity, originCode);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGSecurityID, zCode);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGMaturityDate, maturityDate);
        msg.setField(Constants.TAGDatedDate/*TAGCashFlowAlignmentDate*/, cfad);
        msg.setField(Constants.TAGInterestAccrualDate, interestDate);
        msg.setField(Constants.TAGQuoteType, "1");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGCustOrderCapacity, ctiCode);
        sendFixMessage(msg);
    }
    
    public void submitOrder(final String clientOrderID, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, int expirationType) throws Exception {
        
        this.submitOrder(clientOrderID, limitRate, amount, ccyPair, buySell, expirationType, false);
        }

    public void submitOrder(final String clientOrderID, BigDecimal limitRate,
                            BigDecimal amount, String ccyPair, String buySell, int expirationType, boolean fullFillOnly) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        }
        msg.setField(Constants.TAGTimeInForce, expirationType);
        msg.setField(Constants.TAGMinQty, (fullFillOnly)?amount:"0"); // set min to zero to allow partial fills
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitMarketOrderAndValidate(String clOrdId, String amt, String symbol, String side, boolean fullFillOnly) throws Exception{
        
        submitOrder(clOrdId,
                null,
                new BigDecimal(amt),
                symbol,
                side,
                Integer.parseInt(Constants.TIMEINFORCE_GoodTillCancel),
                fullFillOnly);

        // get back execution report to taker        
        Message acceptedER = this.getOrderUpdateMsg(clOrdId, 5000);
        assertNotNull(this.getUserName() + " didnt get ER(accepted)", acceptedER);
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New,
                acceptedER.getStringFieldValue(Constants.TAGExecType));
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New,
                acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
    }
    
    public Message submitLimitOrderAndValidate(String clOrdId, String amt, String symbol, String side, String limitRate, boolean fullFillOnly) throws Exception{
        
        submitOrder(clOrdId,
                new BigDecimal(limitRate),
                new BigDecimal(amt),
                symbol,
                side,
                Integer.parseInt(Constants.TIMEINFORCE_GoodTillCancel),
                fullFillOnly);
     
        Message acceptedER = this.getOrderUpdateMsg(clOrdId, 5000);
        assertNotNull(this.getUserName() + " didnt get ER(accepted)", acceptedER);
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New,
                acceptedER.getStringFieldValue(Constants.TAGExecType));
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New,
                acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        
        return acceptedER;
    }
    
    public void submitMarketOrderOBOAndValidate(String clOrdId, String amt, String symbol, String side, boolean fullFillOnly,
            String routedTaker, String positionRefId) throws Exception{       
        
        submitRetailOrderOnBehalf(clOrdId,
                positionRefId,
                symbol,
                Constants.PRODUCT_Currency,
                side,
                symbol.split("/")[0],
                amt,
                Constants.ORDTYPE_ForexMarket,
                null,
                null,
                Constants.TIMEINFORCE_GoodTillCancel,
                null,
                null,
                fullFillOnly ? amt : "0",// set min to zero to allow partial fills
                null,
                null,
                null,
                null,
                routedTaker);
        
        // get back execution report to taker        
        Message acceptedER = this.getOrderUpdateMsg(clOrdId, 5000);
        assertNotNull(this.getUserName() + " didnt get ER(accepted)", acceptedER);
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New,
                acceptedER.getStringFieldValue(Constants.TAGExecType));
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New,
                acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
    }
    
    public void submitOrderEspFwd(final String clientOrderID, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, int expirationType, String symbolSfx) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
        Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSecurityType, "FOR");
        
        //testing, remove
        //msg.setField("460", "4");
        //msg.setField("7567", "1");
        //msg.setField("7561", "mgfixhub-mgfixmaker");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
        msg.setField(Constants.TAGPrice, limitRate);
        } else {
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        
        }
        
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
        expirationType);
        msg.setField(Constants.TAGMinQty, "0");
        System.out.println("The fix version is " + getFixVersion());
        if (getFixVersion().endsWith("4.4")) {
        msg.setField(Constants.TAGProduct, "4");
        }
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitOrderEspFwdNDF(final String clientOrderID, BigDecimal limitRate,
            BigDecimal amount, String ccyPair, String buySell, int expirationType, String symbolSfx) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
        Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSecurityType, "FXNDF");
        
        //testing, remove
        //msg.setField("460", "4");
        //msg.setField("7567", "1");
        //msg.setField("7561", "mgfixhub-mgfixmaker");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        if (limitRate != null) {
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
        msg.setField(Constants.TAGPrice, limitRate);
        } else {
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexMarket);
        
        }
        
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
        expirationType);
        msg.setField(Constants.TAGMinQty, "0");
        System.out.println("The fix version is " + getFixVersion());
        if (getFixVersion().endsWith("4.4")) {
        msg.setField(Constants.TAGProduct, "4");
        }
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String symbol, String symbolSfx,
                                    BigDecimal limitRate,
                                    BigDecimal orderQty, String buySell, String expType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Limit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Market);
        }
        msg.setField(Constants.TAGTimeInForce, expType);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOnBehalfOrder(String clientOrderID, String symbol, String symbolSfx,
                                            BigDecimal limitRate,
                                            BigDecimal orderQty, String buySell, String expType, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Limit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Market);
        }
        msg.setField(Constants.TAGTimeInForce, expType);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String symbol, String symbolSfx,
                                    BigDecimal limitRate, String ordType,
                                    String orderQty, String buySell, String expType, String minAmount) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMinQty, minAmount);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String symbol, String symbolSfx,
                                    BigDecimal limitRate, String ordType,
                                    String orderQty, String buySell, String expType) throws Exception {
        
        submitTreasuryOrderOnBehalfOf(clientOrderID, symbol, symbolSfx,
                limitRate, ordType, orderQty, buySell, expType, null, null, null);
    }
    
    public void submitTreasuryOrderOnBehalfOf(String clientOrderID, String symbol, String symbolSfx,
            BigDecimal limitRate, String ordType, String orderQty, String buySell, String expType, String expSeconds, String minAmt, String onBehalfOf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if(this.getFixVersion()!=null && this.getFixVersion().equals("4.2")){
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }else{
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);//client
        }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Government);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGMinQty, minAmt);
        msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);

        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }


    public void submitIrSwapOrder(String clientOrderID, String symbol, String symbolSfx,
                                  String limitRate, String ordType,
                                  String orderQty, String buySell, String expType, String orderCapacity,
                                  int custOrderCapacity, String priceType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        msg.setField(Constants.TAGCurrency, "USD");
        
        if(ordType.equals(Constants.ORDTYPE_Stop) || ordType.equals(Constants.ORDTYPE_Stoplimit)) {
            msg.setField(Constants.TAGStopPx, limitRate);
            msg.setField(Constants.TAGStopSide, Constants.SIDE_Sell);
        }
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIrSwapOrderOnBehalf(String clientOrderID, String onBehalf, String symbol, String symbolSfx,
                                          String limitRate, String ordType,
                                          String orderQty, String buySell, String expType, String orderCapacity,
                                          int custOrderCapacity, String priceType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIrSwapOrderFundSub(String clientOrderID, String fundSub, String symbol, String symbolSfx,
                                         String limitRate, String ordType,
                                         String orderQty, String buySell, String expType, String orderCapacity,
                                         int custOrderCapacity, String priceType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGAccount, fundSub); //the fundSub is same as partyID
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIrSwapIcebergOrder(String clientOrderID, String symbol, String symbolSfx,
                                         String limitRate, String ordType,
                                         String orderQty, String buySell, String expType, String orderCapacity,
                                         int custOrderCapacity, String maxShow, String priceType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        msg.setField(FixTagConstants.TAGMaxShow, maxShow);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIrSwapStopOrder(String clientOrderID, String symbol, String symbolSfx,
                                      String limitRate, String ordType,
                                      String orderQty, String buySell, String expType, String orderCapacity, int custOrderCapacity,
                                      String stopPx, String stopSide, String priceType) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(7534, stopSide);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitIrSwapSecurityListRequest(String reqId, String reqType, String subType) throws Exception {

        Message msg = new Message(Constants.MSGSecurityListRequest, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGSecurityReqID, reqId); // required
        msg.setField(Constants.TAGSecurityListRequestType,
                reqType);
        msg.setField(Constants.TAGSubscriptionRequestType, subType);
        sendFixMessage(msg);
        
        priceMsgMap.put(reqId, new ArrayBlockingQueue<Message>(6000));
    }

    public void submitSecurityListRequest(String reqId) throws Exception {

        Message msg = new Message(Constants.MSGSecurityListRequest, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGSecurityReqID, reqId); // required
        msg.setField(Constants.TAGSecurityListRequestType, Constants.SECURITYLISTREQUESTTYPE_Symbol);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        sendFixMessage(msg);
    }

    // Added for 10.4.1 SuperCLOB
    public void submitIrSwapSecurityDefinitionRequest(String reqId,
                                                      String symbol, String securityId, String contractMultiplier,
                                                      String couponRate, String priceType, String cfad,
                                                      String effectiveDate) throws Exception {
        submitIrSwapSecurityDefinitionRequest(reqId,
                symbol, securityId, contractMultiplier,
                couponRate, priceType, cfad,
                effectiveDate, null/*issueDate*/);
    }
    
    // Added for 10.4.7
    public void submitIrSwapSecurityDefinitionRequest(String reqId,
                                                      String symbol, String securityId, String contractMultiplier,
                                                      String couponRate, String priceType, String cfad,
                                                      String effectiveDate, String issueDate) throws Exception {
        Message msg = new Message(Constants.MSGSecurityDefinitionRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGSecurityReqID, reqId); // required
        msg.setField(Constants.TAGSecurityRequestType, "0");
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, "CLOB");
        msg.setField(Constants.TAGSecurityID, securityId);
        msg.setField(Constants.TAGSecurityIDSource, "Eris");
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGContractMultiplier, contractMultiplier);
        msg.setField(Constants.TAGIssueDate, issueDate);
        msg.setField(Constants.TAGCouponRate, couponRate);
        msg.setField(Constants.TAGCPRegType, priceType);
        msg.setField(Constants.TAGDatedDate, cfad);
        msg.setField(Constants.TAGInterestAccrualDate, effectiveDate);
        sendFixMessage(msg);
    }

    // Added for 10.4.2 Generic Instruments
    public void submitIrSwapGenericInstrSecurityDefinitionRequest(String reqId,
                                                                  String symbol, String securityId, String contractMultiplier,
                                                                  String couponRate, String priceType, String cfad,
                                                                  String effectiveDate) throws Exception {

        Message msg = new Message(Constants.MSGSecurityDefinitionRequest, getSenderCompId(), getTargetCompId(),
                getFixVersion());

        msg.setField(Constants.TAGSecurityReqID, reqId); // required
        msg.setField(Constants.TAGSecurityRequestType, "0");
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, "CLOB");
        msg.setField(Constants.TAGSecurityID, securityId);
        msg.setField(Constants.TAGSecurityIDSource, "CME");
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGContractMultiplier, contractMultiplier);
        msg.setField(Constants.TAGCouponRate, couponRate);
        msg.setField(Constants.TAGCPRegType, priceType);
        msg.setField(Constants.TAGDatedDate, cfad);
        msg.setField(Constants.TAGInterestAccrualDate, effectiveDate);
        sendFixMessage(msg);
    }

    public void submitTreasuryIcebergOrder(String clientOrderID, String symbol,
                                           String symbolSfx, BigDecimal limitRate, String ordType,
                                           String orderQty, String buySell, String expType, String showAmt) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMaxShow, showAmt);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryIcebergOrder(String clientOrderID, String symbol, String symbolSfx,
                                           BigDecimal limitRate, String ordType,
                                           String orderQty, String buySell, String expType, String showAmt, String minAmount) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMaxShow, showAmt);
        msg.setField(Constants.TAGMinQty, minAmount);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }


    public void submitTreasuryStopOrder(String clientOrderID, String symbol, String symbolSfx,
                                        BigDecimal limitRate, String ordType,
                                        String orderQty, String buySell, String stopSide, BigDecimal stopPx, String expType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(Constants.TAGTimeInForce, expType);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryStopOrder(String clientOrderID, String symbol, String symbolSfx,
                                        BigDecimal limitRate, String ordType,
                                        String orderQty, String buySell, String stopSide, BigDecimal stopPx, String expType,
                                        String minAmount) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMinQty, minAmount);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String currency, String side, String symbol,
                                    String symbolSfx, String product, String orderQty, String ordType, String price, String expType
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMinQty, "0");
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String currency, String side, String symbol,
                                    String symbolSfx, String orderQty, String ordType, String price,
                                    String acccount
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGAccount, acccount);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrder(String clientOrderID, String currency, String side, String symbol,
                                    String symbolSfx, String product, String orderQty, String ordType, String price, String expType,
                                    String minQty
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGMinQty, minQty);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderGFS(String clientOrderID, String currency, String side, String symbol,
                                       String symbolSfx, String product, String orderQty, String ordType, String price,
                                       String stopPx, String stopSide, String expSeconds
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(Constants.TAGTimeInForce, GoodForSeconds);
        msg.setField(TAGExpireSeconds, expSeconds);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }


    public void submitTreasuryOrder(String clientOrderID, String currency, String side, String symbol,
                                    String symbolSfx, String product, String orderQty, String ordType, String price, String expType,
                                    String expDate, String expTime
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGTimeInForce, expType);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }


    public void submitBadTreasuryOrder(String clientOrderID, String symbol, String symbolSfx,
                                       BigDecimal limitRate,
                                       BigDecimal orderQty, String buySell, String expType, String handlInst, String minQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst, handlInst);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGMinQty, minQty);
        if (limitRate != null) {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Limit);
            msg.setField(Constants.TAGPrice, limitRate);
        } else {
            msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Market);
        }
        msg.setField(Constants.TAGTimeInForce, expType);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitDSOrderUSTUST(String clientOrderID, String symbol,
                                    String symbolSfx, String buySell, String orderQty, String ordType,
                                    String priceType, String limitRate, String stopPx, String timeInForce,
                                    String maxShow, String stopSide) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "MLEG");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, timeInForce);
        msg.setField(FixTagConstants.TAGMaxShow, maxShow);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(7534, stopSide);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitNewOrderErisSpread(String clientOrderID, String symbol,
            String symbolSfx, String buySell, String orderQty, String ordType,
            String priceType, String limitRate, String stopPx, String timeInForce, String orderCapacity,
            int custOrderCapacity, String minQty, String stopSide, String onBehalf) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.setField(Constants.TAGHandlInst,
        Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_MultiLegContract);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, timeInForce);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        msg.setField(Constants.TAGMinQty, minQty);
        if(ordType!=null && ordType.equals(Constants.ORDTYPE_Iceberg)){
        msg.setField(FixTagConstants.TAGMaxShow, orderQty);
        }
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(7534, stopSide);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitDSOrderOtherCombinations(String clientOrderID, String symbol,
                                               String symbolSfx, String buySell, String orderQty, String ordType,
                                               String priceType, String limitRate, String stopPx, String timeInForce, String orderCapacity,
                                               int custOrderCapacity, String minQty, String stopSide) throws Exception {
        
        submitNewOrderErisSpread(clientOrderID,
                symbol,
                symbolSfx,
                buySell,
                orderQty,
                ordType,
                priceType,
                limitRate,
                stopPx,
                timeInForce,
                orderCapacity,
                custOrderCapacity,
                minQty,
                stopSide,
                null);//onBehalf
    }

    public void submitOrderCancelRequestErisSpread(Message previousER, String clOrdID, String onBehalf) throws Exception{
        
        submitDSOrderCancelReqOtherCombinations(
                previousER.getStringFieldValue(Constants.TAGOrderID),
                clOrdID,
                previousER.getStringFieldValue(Constants.TAGClOrdID),
                onBehalf,
                previousER.getStringFieldValue(Constants.TAGOrdType),
                previousER.getStringFieldValue(Constants.TAGSide),
                previousER.getStringFieldValue(Constants.TAGSymbol),
                previousER.getStringFieldValue(Constants.TAGSymbolSfx));
    }

    public void submitDSOrderCancelReqOtherCombinations(String orderId, String clOrdId,
                                                        String origClientOrderId, String onBehalf, String orderType, String side,
                                                        String symbol, String symbolFx) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "MLEG");
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitDSOrderReplaceOtherCombinations(String orderId, String clOrdId,
                                                      String origClOrdId, String symbol, String symbolFx, String buySell, String amount,
                                                      String orderType, String price, String stopPx, String minQty, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPublicBrokerOK);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "MLEG");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGMinQty, minQty);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGCurrency, "USD");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitTreasuryMarketDataRequest(String requestId, String symbol,
                                                String symbolSfx, String aggregatedBook, String marketDepth) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIrSwapZCodeMarketDataRequest(String requestId, String symbol,
                                                   String marketDepth, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        if (subReqType != null && subReqType.equals("1")) {
            msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        }
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, "3");
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIrSwapZCodeMarketDataRequest(String requestId, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, "0");
        if (subReqType != null && subReqType.equals(Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe)) {
            msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        }
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_SecurityID);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGSymbolSfx, "NA");
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIrSwapIOIMarketDataRequest(String requestId, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, "0");
        if (subReqType != null && subReqType.equals(Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe)) {
            msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        }
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_IOI);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGSymbolSfx, "NA");
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    /* added an extra argument that takes the subscription request type. If it is
     * set to 1 then we need to set the MDUpdateType to 1 */
    public void submitIrSwapMarketDataRequest(String requestId, String symbol,
                                              String symbolSfx, String aggregatedBook, String marketDepth, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        if (subReqType != null && subReqType.equals("1")) {
            msg.setField(Constants.TAGMDUpdateType, "1");
        }
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitBadTreasuryMarketDataRequest(String requestId, String symbol,
                                                   String symbolSfx, String aggregatedBook, String marketDepth, String numEntry, String entry1, String entry2) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, numEntry);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.addField(Constants.TAGMDEntryType, entry2);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitTreasuryMarketDataRequest(String requestId, String subReqType,
                                                String marketDepth, String updateType,
                                                String aggregatedBook, String noRelatedSymbol, String symbol,
                                                String symbolSfx, String product) throws Exception {
        submitTreasuryMarketDataRequest(requestId, subReqType,
                marketDepth, updateType,
                aggregatedBook, noRelatedSymbol, symbol,
                symbolSfx, product, "TNOTE");
    }
    
    public void submitTreasuryMarketDataRequest(String requestId, String subReqType,
            String marketDepth, String updateType,
            String aggregatedBook, String noRelatedSymbol, String symbol,
            String symbolSfx, String product, String securityType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        if (subReqType != null && subReqType.equals("1")) {
            msg.setField(Constants.TAGMDUpdateType, updateType);
        }
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSymbol);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void unsubscribeMarketDataRequest(String requestId, String baseCurrencyCode,
                                             String termsCurrencyCode, String aggregratedBook, String marketDepth) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Unsubscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/" + termsCurrencyCode);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void unsubscribeTreasuryMarketDataRequest(String requestId, String symbol,
                                                     String symbolSfx, String aggregratedBook, String marketDepth) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Unsubscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitMarketDataRequestCXNow(String requestId, boolean isSubscribe, boolean subscribeDepthOfBook, boolean subscribeTicker,
            boolean subscribeWAMR, boolean subscribeMidX, boolean subscribeL1, String symbol, String symbolSfx) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 
                isSubscribe ? Constants.SUBSCRIPTIONREQUESTTYPE_CxNow : Constants.SUBSCRIPTIONREQUESTTYPE_CxNowUnsubscribe);
        msg.setField(Constants.TAGMarketDepth, "0");
        
        int MDEntryTypes = 0;
        if(subscribeDepthOfBook) {
            MDEntryTypes++;
        }
        if(subscribeTicker) {
            MDEntryTypes++;
        }
        if(subscribeWAMR) {
            MDEntryTypes++;
        }
        if(subscribeMidX) {
            MDEntryTypes++;
        }       
        if(subscribeL1) {
            MDEntryTypes++;
        }
        
        msg.setField(Constants.TAGNoMDEntryTypes, MDEntryTypes);
        msg.addField(Constants.TAGMDEntryType, subscribeDepthOfBook ? Constants.MDENTRYTYPE_NOW_DepthOfBook : null);
        msg.addField(Constants.TAGMDEntryType, subscribeTicker ? Constants.MDENTRYTYPE_NOW_Ticker : null);
        msg.addField(Constants.TAGMDEntryType, subscribeWAMR ? Constants.MDENTRYTYPE_NOW_WAMR : null);
        msg.addField(Constants.TAGMDEntryType, subscribeMidX ? Constants.MDENTRYTYPE_NOW_MidX : null);
        msg.addField(Constants.TAGMDEntryType, subscribeL1 ? Constants.MDENTRYTYPE_NOW_L1 : null);
        
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitMarketDataRequestCXNowL1(String requestId, boolean isSubscribe, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 
                isSubscribe ? Constants.SUBSCRIPTIONREQUESTTYPE_CxNow : Constants.SUBSCRIPTIONREQUESTTYPE_CxNowUnsubscribe);
        msg.setField(Constants.TAGMarketDepth, "1");
        
        msg.setField(Constants.TAGNoMDEntryTypes, "1");
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_NOW_L1);
        
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitMarketDataRequestCXView(String requestId, boolean isSubscribe, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 
                isSubscribe ? Constants.SUBSCRIPTIONREQUESTTYPE_CxView : Constants.SUBSCRIPTIONREQUESTTYPE_CxViewUnsubscribe);
        msg.setField(Constants.TAGMarketDepth, "0");
        
        msg.setField(Constants.TAGNoMDEntryTypes, "2");
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_VIEW_MarketData);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_PAID_GIVEN_MarketData);
        
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitMarketDataRequest(String requestId, String baseCurrencyCode,
            String termsCurrencyCode, String aggregratedBook, String marketDepth) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/" + termsCurrencyCode);
        if (getFixVersion().endsWith("4.4")) {
        msg.setField(Constants.TAGSymbolSfx, "SP");
        }
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitFixTradeTickerSubscriptionRequest(String requestId,
            String baseCurrencyCode, String termsCurrencyCode, String symbolSfx, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest,
                getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType,
                Constants.SUBSCRIPTIONREQUESTTYPE_Ticker);
        msg.setField(Constants.TAGMarketDepth, Constants.MARKETDEPTH_TopOfBook);
        msg.setField(Constants.TAGMDUpdateType,
                Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Trade);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/"
                + termsCurrencyCode);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGVenueType, venueType);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    public void submitFixTradeTickerSubscriptionRequestRFQ(String requestId, @Nullable String venueType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest,
                getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType,
                Constants.SUBSCRIPTIONREQUESTTYPE_Ticker);
        msg.setField(Constants.TAGMarketDepth, Constants.MARKETDEPTH_TopOfBook);
        msg.setField(Constants.TAGMDUpdateType,
                Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Trade);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, "NA");
        if (venueType != null) {
            msg.setField(Constants.TAGVenueType, venueType);
        }
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitMarketDataRequestFwdSwap(String requestId, String baseCurrencyCode,
            String termsCurrencyCode, String aggregratedBook, String marketDepth, String symbolSfx) throws Exception {
        submitMarketDataRequestFwdSwap(requestId, baseCurrencyCode,
                termsCurrencyCode, aggregratedBook, marketDepth, symbolSfx,
                null);
    }

    public void submitMarketDataRequestFwdSwap(String requestId, String baseCurrencyCode,
            String termsCurrencyCode, String aggregratedBook, String marketDepth, String symbolSfx,
            String venueType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/" + termsCurrencyCode);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGVenueType, venueType);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        }

    public void submitMarketDataRequestFullBookNewType(String requestId,
            String baseCurrencyCode, String termsCurrencyCode) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest,
                getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType,
                Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, "0");
        msg.setField(Constants.TAGMDUpdateType,
                Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, "Y");
        msg.setField(Constants.TAGNoMDEntryTypes, 5);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_TradingSessionHighPrice);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_TradingSessionLowPrice);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_TradingSessionVWAPPrice);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/"
                + termsCurrencyCode);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGSymbolSfx, "SP");
        }
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitNDFMarketDataRequest(String requestId, String baseCurrencyCode,
            String termsCurrencyCode, String symSfx, String aggregratedBook, String marketDepth,
            String securityType, String attributedPrices) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Subscribe);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/" + termsCurrencyCode);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGAttributedPrices, attributedPrices);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    public void submitMarketDataRequestSpread(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
            String aggregatedBook, String noRelatedSym, String symbol, String symbolSfx,
            String attributedPrices) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, "5");
        msg.addField(Constants.TAGMDEntryType, "0");
        msg.addField(Constants.TAGMDEntryType, "1");
        msg.addField(Constants.TAGMDEntryType, "7");
        msg.addField(Constants.TAGMDEntryType, "8");
        msg.addField(Constants.TAGMDEntryType, "9");
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGAttributedPrices, attributedPrices);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
        
    }
    public void submitMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                        String aggregatedBook, String noMdEntryTypes, String entry1, String entry2, String noRelatedSym, String symbol,
                                        String attributedPrices) throws Exception {
        submitMarketDataRequest(requestId, subscriptionRequestType, marketDepth, mdUpdateType,
                aggregatedBook, noMdEntryTypes, entry1, entry2, noRelatedSym, symbol,
                null, null, attributedPrices);
    }

    public void submitMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                        String aggregatedBook, String noMdEntryTypes, String entry1, String entry2, String noRelatedSym, String symbol,
                                        String symbolSfx, String venueType, String attributedPrices) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.addField(Constants.TAGMDEntryType, entry2);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGVenueType, venueType);
        msg.setField(Constants.TAGAttributedPrices, attributedPrices);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitTickerMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                              String noMdEntryTypes, String mdEntryType, String noRelatedSym, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, mdEntryType);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitTickerMarketDataRequest(String requestId, String subscriptionRequestType, String symbol) throws Exception {
        submitTickerMarketDataRequest(requestId, subscriptionRequestType, Constants.MARKETDEPTH_TopOfBook,
                Constants.MDUPDATETYPE_IncrementalRefresh, "1", Constants.MDENTRYTYPE_Trade, "1", symbol);
    }

    public void submitTreasTickerMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                                   String noMdEntryTypes, String entry1, String noRelatedSym, String symbol, String symSfx,
                                                   String product) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGProduct, product);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitIrSwapTickerMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                                    String noMdEntryTypes, String entry1, String noRelatedSym, String symbol,
                                                    String product, String secType, String secIdSrc) throws Exception {
        submitIrSwapTickerMarketDataRequest(requestId, subscriptionRequestType, marketDepth, mdUpdateType,
                noMdEntryTypes, entry1, noRelatedSym, symbol, null, product, secType, secIdSrc);
    }

    public void submitIrSwapTickerMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                                    String noMdEntryTypes, String entry1, String noRelatedSym, String symbol, String symbolFx,
                                                    String product, String secType, String secIdSrc) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGSecurityIDSource, secIdSrc);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, secType);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitDSTickerMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth,
                                                String mdUpdateType, String noMdEntryTypes, String entry1, String noRelatedSym,
                                                String symbol, String symbolFx, String product, String secType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, secType);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailMarketDataRequest(String requestId, String subscriptionRequestType, String marketDepth, String mdUpdateType,
                                              String aggregatedBook, String noMdEntryTypes, String entry1, String entry2, String entry3,
                                              String entry4, String entry5, String noRelatedSym, String symbol1, String symbol2) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionRequestType);
        msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, mdUpdateType);
        msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, noMdEntryTypes);
        msg.addField(Constants.TAGMDEntryType, entry1);
        msg.addField(Constants.TAGMDEntryType, entry2);
        msg.addField(Constants.TAGMDEntryType, entry3);
        msg.addField(Constants.TAGMDEntryType, entry4);
        msg.addField(Constants.TAGMDEntryType, entry5);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol1);
        msg.addField(Constants.TAGSymbol, symbol2);
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitCancelAllOrdersRequest() throws Exception{
        submitOrderCancelRequest("OPEN_ORDER",
                "OPEN_ORDER",
                "OPEN_ORDER",
                this.getUserName(),
                null,//ordType
                Constants.SIDE_Buy,
                "NA");//symbol
    }

    public void submitCancelAllOrdersRequestOnBehalf(String accountID) throws Exception{
        submitOrderCancelRequest("OPEN_ORDER", "OPEN_ORDER", "OPEN_ORDER", accountID, null, Constants.SIDE_Buy, "NA");

    }

    public void submitRetailSecurityListRequest(String requestId, String requestType) throws Exception {
        Message msg = new Message(Constants.MSGSecurityListRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGSecurityReqID, requestId);
        msg.setField(Constants.TAGSecurityListRequestType, requestType);
        sendFixMessage(msg);
    }

    public void submitOrderRFQNDF(String clientOrderID, String handlInst, String symbol,
            String settlDate, String product, String securityType, String side, String amount, String ordType,
            String price, String cumQty, String currency, String quoteId) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, handlInst);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSettlDate, settlDate);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCumQty, cumQty);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQNDFOnBehalf(String clientOrderID, String handlInst, String symbol,
            String settlDate, String product, String securityType, String side, String amount, String ordType,
            String price, String cumQty, String currency, String quoteId, String onBehalfOf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.addField(Constants.TAGNoPartyIDs, "1");
        msg.addField(Constants.TAGPartyID, onBehalfOf);
        msg.addField(Constants.TAGPartyRole, "3");
        msg.setField(Constants.TAGHandlInst, handlInst);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSettlDate, settlDate);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCumQty, cumQty);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitQuoteRequestRFQ(String requestId, String onBehalf, String noRelatedSym, String symbol, String product,
                                      String securityType, String side, String orderQty, String valueDt, String orderQty2,
                                      String currency, String account, String noPartyIds, String partyId,
                                      String partyRole, String valueDt2, String fixingDate, String fixingDate2
    ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.addField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.addField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGNoPartyIDs,  noPartyIds);
        msg.setField(Constants.TAGPartyID, partyId);
        msg.setField(Constants.TAGPartyRole, partyRole);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGFixingDate, fixingDate);
        msg.addField(Constants.TAGFixingDate2, fixingDate2);
        sendFixMessage(msg);
    }

    public void submitOrderCancelRequest(String orderId, String clOrdId, String origClientOrderId, String onBehalf, String orderType, String side, String ccyPair) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clOrdId);
        
        orderId = orderId==null ? this.clientIDToOrderIDMap.get(origClientOrderId):orderId;
        msg.setField(Constants.TAGOrderID, orderId);
        
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGAccount, onBehalf);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }
    
    
    
    public void submitOrderCancelRequestMidT(Message acceptedER, String clOrdId, boolean cancelAllOpenOrders) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        if(cancelAllOpenOrders){
            msg.setField(Constants.TAGOrigClOrdID, "OPEN_ORDER");
            msg.setField(Constants.TAGOrderID, "OPEN_ORDER");
            msg.setField(Constants.TAGClOrdID, "OPEN_ORDER");
        }else{
            msg.setField(Constants.TAGOrigClOrdID, acceptedER.getStringFieldValue(Constants.TAGClOrdID));
            msg.setField(Constants.TAGOrderID, acceptedER.getStringFieldValue(Constants.TAGOrderID));
            msg.setField(Constants.TAGClOrdID, clOrdId);
        }
        
        msg.setField(Constants.TAGSymbol, acceptedER.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGSymbolSfx, acceptedER.getStringFieldValue(Constants.TAGSymbolSfx));
        msg.setField(Constants.TAGProduct, acceptedER.getStringFieldValue(Constants.TAGProduct)==null ? 
                Constants.PRODUCT_Currency : acceptedER.getStringFieldValue(Constants.TAGProduct));
        msg.setField(Constants.TAGSecurityType, acceptedER.getStringFieldValue(Constants.TAGSecurityType));
        msg.setField(Constants.TAGSide, acceptedER.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGText, null);
        msg.setField(Constants.TAGOrdType, acceptedER.getStringFieldValue(Constants.TAGOrdType));
        msg.setField(FixTagConstants.TAGOpenOrders, (cancelAllOpenOrders)?"Y":null);
        
        BlockingQueue<Message> msgQ = orderMsgMap.get(acceptedER.getStringFieldValue(Constants.TAGClOrdID));
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitOrderListSingleCancelRequest(String listID, String orderId, String clOrdId, String origClientOrderId, String onBehalf, String orderType, String side, String ccyPair) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        msg.setField(Constants.TAGListID, listID);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGAccount, onBehalf);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }
    
    
    public void submitIrSwapOrderCancelRequest(Message previousER, String clOrdId) throws Exception {
        submitIrSwapOrderCancelRequest(previousER.getStringFieldValue(Constants.TAGOrderID),
                clOrdId,
                previousER.getStringFieldValue(Constants.TAGClOrdID),
                null,
                previousER.getStringFieldValue(Constants.TAGOrdType),
                previousER.getStringFieldValue(Constants.TAGSide),
                previousER.getStringFieldValue(Constants.TAGSymbol),
                previousER.getStringFieldValue(Constants.TAGSymbolSfx));
    }

    public void submitIrSwapOrderCancelRequest(String orderId, String clOrdId, String origClientOrderId, String onBehalf, String orderType, String side, String symbol, String symbolFx) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitIrSwapOrderCancelRequest(String orderId, String clOrdId, String origClientOrderId, String onBehalf, String orderType, String side, String symbol) throws Exception {
        submitIrSwapOrderCancelRequest(orderId, clOrdId, origClientOrderId, onBehalf, orderType, side, symbol, null);

    }

    public void submitRetailOrderCancelRequest(String origClientOrderId, String orderId, String clOrdId,
                                               String symbol, String product, String side, String orderType, String positionId) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrdType, orderType);
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        //for pegged orders
        if (orderType != null && orderType.equals("P")) {
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitRetailOrderCancelRequestOnBehalf(String origClientOrderId, String orderId, String clOrdId,
            String symbol, String symbolSfx, String product, String securityType, String side, String orderType,
            String positionId, String onBehalf) throws Exception {
        submitRetailOrderCancelRequestOnBehalf(origClientOrderId, orderId, clOrdId,
                symbol, symbolSfx, product, securityType, side, orderType, positionId, onBehalf,
                null);
    }


    public void submitRetailOrderCancelRequestOnBehalf(String origClientOrderId, String orderId, String clOrdId,
             String symbol, String symbolSfx, String product, String securityType, String side, String orderType,
                String positionId, String onBehalf, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        if (symbolSfx != null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGProduct, product);
        if (securityType != null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrdType, orderType);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGVenueType, venueType);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitOrderCancelRequestForIFD(Message takerOrderUpdate, String clOrdId, String IFDCancelType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, takerOrderUpdate.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGOrderID, takerOrderUpdate.getStringFieldValue(Constants.TAGOrderID));
        msg.setField(Constants.TAGSymbol, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGSymbolSfx, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbolSfx));
        msg.setField(Constants.TAGProduct, takerOrderUpdate.getStringFieldValue(Constants.TAGProduct));
        msg.setField(Constants.TAGSecurityType, takerOrderUpdate.getStringFieldValue(Constants.TAGSecurityType));
        msg.setField(Constants.TAGSide, takerOrderUpdate.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrdType, takerOrderUpdate.getStringFieldValue(Constants.TAGOrdType));
        msg.setField(Constants.TAGIFDCancelType, IFDCancelType);
        sendFixMessage(msg);
    }
    
    public void submitOrderCancelRequest(Message takerOrderUpdate, String clOrdId) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGOrigClOrdID, takerOrderUpdate.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGOrderID, takerOrderUpdate.getStringFieldValue(Constants.TAGOrderID));
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGSymbolSfx, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbolSfx));
        String product = takerOrderUpdate.getStringFieldValue(Constants.TAGProduct)==null?Constants.PRODUCT_Currency:
            takerOrderUpdate.getStringFieldValue(Constants.TAGProduct);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, takerOrderUpdate.getStringFieldValue(Constants.TAGSecurityType));
        msg.setField(Constants.TAGSide, takerOrderUpdate.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGSecondaryClOrdID, null);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrdType, takerOrderUpdate.getStringFieldValue(Constants.TAGOrdType));
        sendFixMessage(msg);
    }
    
    public void submitOrderReplaceRequest(Message takerOrderUpdate, String clOrdId, String newOrderQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGOrderID, takerOrderUpdate.getStringFieldValue(Constants.TAGOrderID));
        msg.setField(Constants.TAGOrigClOrdID, takerOrderUpdate.getStringFieldValue(Constants.TAGClOrdID));
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGSymbolSfx, takerOrderUpdate.getStringFieldValue(Constants.TAGSymbolSfx));
        msg.setField(Constants.TAGProduct, takerOrderUpdate.getStringFieldValue(Constants.TAGProduct));
        msg.setField(Constants.TAGSecurityType, takerOrderUpdate.getStringFieldValue(Constants.TAGSecurityType));
        msg.setField(Constants.TAGSide, takerOrderUpdate.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, newOrderQty);
        msg.setField(Constants.TAGOrdType, takerOrderUpdate.getStringFieldValue(Constants.TAGOrdType));
        msg.setField(Constants.TAGPrice, takerOrderUpdate.getStringFieldValue(Constants.TAGPrice));
        
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderCancelRequest(String origClOrdId, String clOrdId, String orderId,
                                                 String symbol, String symbolSfx, String product, String side, String ordType, String openOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderCancelRequestOnBehalf(String origClOrdId, String clOrdId, String orderId,
                                                         String symbol, String symbolSfx, String product, String side, String ordType, String openOrders,
                                                         String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        sendFixMessage(msg);
    }

    public void cancelAllOpenOrdersRetail() throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, "testorigClOrdId");
        msg.setField(Constants.TAGOrderID, ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGClOrdID, ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGSymbol, "EUR/USD");
        msg.setField(Constants.TAGSide, "1");
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        msg.setField(FixTagConstants.TAGAccount, getPartyName());

        sendFixMessage(msg);
    }


    public void submitUserRequestPasswordReset(String userReqId, String userReqType,
                                               String userName, String currentPassword, String newPassword) throws Exception {
        Message msg = new Message(Constants.MSGUserRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGUserRequestID, userReqId);
        msg.setField(Constants.TAGUserRequestType, userReqType);
        msg.setField(Constants.TAGUsername, userName);
        msg.setField(Constants.TAGPassword, currentPassword);
        msg.setField(Constants.TAGNewPassword, newPassword);
        sendFixMessage(msg);
    }

    public void submitOrderStatusRequest(String orderId, String clOrdId, String origClientOrderId,
            String onBehalf, String orderType, String side, String ccyPair, String symbolSfx, String product) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, ccyPair);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitOrderStatusRequestNDF(String orderId, String clOrdId, String origClientOrderId,
            String onBehalf, String orderType, String side, String ccyPair, String symbolSfx, String product) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSecurityType, "FXNDF");
        
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }
    
    public void submitIrSwapOrderStatusRequest(String orderId, String clOrdId, String onBehalf, String orderType, String side, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        if (null != onBehalf) {
            msg.setField(Constants.TAGClientID, onBehalf);
        }
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        BlockingQueue<Message> msgQ = orderMsgMap.get(clOrdId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }

    public void submitOrderStatusRequest(String orderId, String clOrdId, String symbol,
                                         String side, String ordType, String openOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        sendFixMessage(msg);
    }
    
    public void submitAllOpenOrderStatusRequest()throws Exception {
        submitOrderStatusRequest("OPEN_ORDER", "OPEN_ORDER", "N/A", Constants.SIDE_Undisclosed, null, "Y");
    }
    
    public void submitAllOpenOrderStatusRequestOnBehalf(String onBehalf)throws Exception {
        submitOrderStatusRequest("OPEN_ORDER", "OPEN_ORDER", "N/A", Constants.SIDE_Undisclosed, null, "Y", onBehalf);
    }


    public void submitOrderStatusRequest(String orderId, String clOrdId, String symbol,
                                         String side, String ordType, String openOrders, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        if (onBehalf != null) {
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.setField(FixTagConstants.TAGNoPartyIDs, "1");
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, onBehalf);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, Constants.PARTYROLE_Client);
        }
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        }
        sendFixMessage(msg);
    }
    
    public void submitOrderStatusRequest(Message lastER) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());;
        msg.setField(Constants.TAGOrderID, lastER.getStringFieldValue(Constants.TAGOrderID));
        msg.setField(Constants.TAGClOrdID, lastER.getStringFieldValue(Constants.TAGOrigClOrdID));
        msg.setField(Constants.TAGSymbol, lastER.getStringFieldValue(Constants.TAGSymbol));
        msg.setField(Constants.TAGSide, lastER.getStringFieldValue(Constants.TAGSide));
        msg.setField(Constants.TAGOrdType, lastER.getStringFieldValue(Constants.TAGOrdType));
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        }
        sendFixMessage(msg);
    }

    public void submitMassOrderCancelRequest(String clOrdId) throws Exception {
        Message msg = new Message(Constants.MSGOrderMassCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGMassCancelRequestType, "7");//cancel all orders and positions
        msg.setField(Constants.TAGTradingSessionID, this.getPartyId());
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);

    }

    public void submitMassOrderCanceRequestOnBehalf(String clOrdId, String partyID, String userID) throws Exception {
        Message msg = new Message(Constants.MSGOrderMassCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGMassCancelRequestType, "7");//cancel all orders and positions
        msg.setField(Constants.TAGTradingSessionID, partyID);
        msg.setField(Constants.TAGTradingSessionSubID, userID);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);

    }

    public void submitMassOrderStatusRequestFor(String massStatusReqId, String massStatusReqType,
                                                String party, Date transactTime) throws Exception {
        Message msg = new Message(Constants.MSGOrderMassStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMassStatusReqID, massStatusReqId);
        msg.setField(Constants.TAGMassStatusReqType, massStatusReqType);
        if (party != null) {
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.setField(FixTagConstants.TAGNoPartyIDs, "1");
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, party);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        }
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        msg.setField(Constants.TAGTransactTime, dateFormat.format(transactTime));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderStatusRequest(String orderId, String clOrdId, String symbol,
                                                 String symbolSfx, String product, String side,
                                                 String orderType, String openOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        sendFixMessage(msg);
    }

    public void submitOrderReplace(String orderId, String clOrdId, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                   String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String cancelOnReplace) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, clOrdId); // required

        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGForexReq, cancelOnReplace);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, "addTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderReplaceExpiryInSeconds(String orderId, String clOrdId, BigDecimal price,
                                                  BigDecimal amount, String ccyPair, String buySell, String orderType, BigDecimal minQty,
                                                  String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage,
                                                  String cancelOnReplace, Integer newTime) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGForexReq, cancelOnReplace);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        Calendar c = Calendar.getInstance();
        c.add(Calendar.HOUR, 7);//GMT time
        c.add(Calendar.SECOND, newTime);
        Date d = c.getTime();
        msg.setField(126, dateFormat.format(d));

        msg.setField(Constants.TAGText, "addTerms");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderReplace(String orderId, String clOrdId, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                   String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage) throws Exception {
        submitOrderReplace(orderId, clOrdId, price, amount, ccyPair, buySell,
                orderType, minQty, stopSide, stopRate, trailByRate, maxSlippage, null);
    }

    public void submitOrderReplaceGTD(String orderId, String clOrdId, BigDecimal price, BigDecimal amount,
                                      String ccyPair, String buySell, String orderType, BigDecimal minQty, String stopSide,
                                      BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String expiryDate) throws Exception {
        submitOrderReplaceGTD(orderId, clOrdId, price, amount, ccyPair, buySell,
                orderType, minQty, stopSide, stopRate, trailByRate, maxSlippage, null, expiryDate);
    }

    public void submitOrderReplaceGTD(String orderId, String clOrdId, BigDecimal price, BigDecimal amount,
                                      String ccyPair, String buySell, String orderType, BigDecimal minQty, String stopSide,
                                      BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String cancelOnReplace,
                                      String expiryDate) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGForexReq, cancelOnReplace);
        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillDate);
        msg.setField(Constants.TAGExpireDate, expiryDate);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderReplaceOnBehalf(String orderId, String clOrdId, String origClOrdId, BigDecimal price,
                                           String amount, String ccyPair, String buySell, String orderType, String minQty, String onBehalf) throws Exception {
        submitOrderReplace(orderId, clOrdId, origClOrdId, price, amount, ccyPair, buySell, orderType, minQty, null,
                null, null, null, onBehalf);
    }

    //should not be used outside of testing; good for ms orders can't be replaced
    public void submitOrderReplaceGoodForMS(String orderId, String clOrdId, String origClOrdId, BigDecimal price,
            String amount, String ccyPair, String buySell, String orderType, String minQty, String onBehalf, String ms) throws Exception {

        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        if(orderId != null)
         {
            msg.setField(Constants.TAGOrderID, orderId); // required
        }
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required






        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (minQty != null) {
            msg.setField(Constants.TAGMinQty, minQty.toString());
        }

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, new SimpleDateFormat("yyyyMMdd-HH:mm:ss").format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());
        msg.setField(Constants.TAGOrdType, orderType);
        if (price != null) {
            msg.setField(Constants.TAGPrice, price.toString());
        }
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodForMS);
        msg.setField(Constants.TAGExpireSecondsOrMillis, ms);
        if(null != onBehalf) {
            if(getFixVersion().endsWith("4.4"))
            {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            }
            else
            {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
            }

        if(getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message> (6000));
        sendFixMessage(msg);




    }



    public void submitOrderReplace(String orderId, String clOrdId, String origClOrdId, BigDecimal price,
                                   String amount, String ccyPair, String buySell, String orderType, String minQty, String stopSide,
                                   BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        if (ccyPair != null) {
            msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        }
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitOrderReplaceMissingTransactTime(String orderId, String clOrdId, String origClOrdId, BigDecimal price,
            String amount, String ccyPair, String buySell, String orderType, String minQty, String stopSide,
            BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    public void submitOrderReplaceWrongCurrency(String orderId, String clOrdId, String origClOrdId, BigDecimal price,
            String amount, String ccyPair, String buySell, String orderType, String minQty, String stopSide,
            BigDecimal stopRate, BigDecimal trailByRate, BigDecimal maxSlippage, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[1]);
        msg.setField(Constants.TAGStopPx, stopRate);
        msg.setField(TAGStopSide, stopSide);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }

        if (getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    public void submitIrSwapOrderReplace(String orderId, String clOrdId, String origClOrdId, String symbol, String symbolFx,
                                         String buySell, String amount, String orderType, String price, String stopPx, String minQty, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required

        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGMinQty, minQty);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPublicBrokerOK);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitIrSwapOrderReplace(Message previousER, String clOrdId, String newOrderAmount,
            String newPrice) throws Exception {
        
        submitIrSwapOrderReplace(
                previousER.getStringFieldValue(Constants.TAGOrderID),
                clOrdId,
                previousER.getStringFieldValue(Constants.TAGClOrdID), 
                previousER.getStringFieldValue(Constants.TAGSymbol), 
                previousER.getStringFieldValue(Constants.TAGSymbolSfx), 
                previousER.getStringFieldValue(Constants.TAGSide), 
                newOrderAmount,
                previousER.getStringFieldValue(Constants.TAGOrdType),
                newPrice, 
                previousER.getStringFieldValue(Constants.TAGStopSide),
                previousER.getStringFieldValue(Constants.TAGMinQty),
                previousER.getStringFieldValue(Constants.TAGClientID));
    }


    public void submitRetailOrderReplace(String orderId, String origClordId, String clOrdId, String symbol, String product,
                                         String side, String orderQty, String ordType, String price, String stopPx,
                                         String ccy, String expDate, String expTime, String minQty, String trailByRate,
                                         String maxSlippage, String positionId) throws Exception {
        
        submitRetailOrderReplaceOnBehalf(orderId, origClordId, clOrdId, symbol, null, product, null, side, 
                orderQty, ordType, price, stopPx, ccy, expDate, expTime, minQty, trailByRate, maxSlippage, positionId,
                null);
    }

    public void submitRetailOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        //msg.setField(Constants.TAGForexReq, "Y");
        //msg.setField(Constants.TAGTrailBy, trailByRate);
        //msg.setField(TAGMaxSlippage, maxSlippage);
        //msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitRetailOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String onBehalf, String forexRfq
            ) throws Exception {
        submitRetailOrderReplaceOnBehalf(orderId, origClordId, clOrdId, symbol, symbolSfx,
                product, securityType, side, orderQty, ordType,
                price, stopPx, ccy, expDate, expTime,
                minQty, trailByRate, maxSlippage, positionId, onBehalf, forexRfq,
                null);
    }

    public void submitRetailOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String onBehalf, String forexRfq,
            String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        //msg.setField(Constants.TAGForexReq, "Y");
        //msg.setField(Constants.TAGTrailBy, trailByRate);
        //msg.setField(TAGMaxSlippage, maxSlippage);
        //msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(Constants.TAGForexReq, forexRfq);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGVenueType, venueType);

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitDiscretionaryOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String DiscretionInst, String DiscretionOffset,
            String maxShow, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGProduct, product);
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGiDiscretionInst, DiscretionInst);
        msg.setField(Constants.TAGiDiscretionOffset, DiscretionOffset);
        msg.setField(Constants.TAGMaxShow, maxShow);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        sendFixMessage(msg);
    }


    public void submitRetailStopOrderReplace(String orderId, String origClordId, String clOrdId, String symbol, String product,
                                             String side, String orderQty, String ordType, String price, String stopPx,
                                             String ccy, String expDate, String expTime, String minQty, String trailByRate,
                                             String maxSlippage, String positionId, String stopSide) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField("7534", stopSide);
        sendFixMessage(msg);
    }

    public void submitRetailStopOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
                                                     String product, String securityType, String side, String orderQty, String ordType,
                                                     String price, String stopPx, String ccy, String expDate, String expTime,
                                                     String minQty, String trailByRate, String maxSlippage, String positionId, String stopSide, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        if(symbolSfx!=null) {
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        }
        msg.setField(Constants.TAGProduct, product);
        if(securityType!=null) {
            msg.setField(Constants.TAGSecurityType, securityType);
        }
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField("7534", stopSide);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        sendFixMessage(msg);
    }

    
    public void submitStopOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String side, String orderQty, String ordType,
            String price, String stopPx, String ccy, String expDate, String expTime,
            String minQty, String trailByRate, String maxSlippage, String positionId, String stopSide, String onBehalf, String account) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField("7534", stopSide);
        if (onBehalf != null) {
        msg.setField(Constants.TAGNoPartyIDs, "1");
        msg.addField(Constants.TAGPartyID, onBehalf);
        msg.addField(Constants.TAGPartyRole, "3");//client
        }
        sendFixMessage(msg);
    }

    //added second parameter onBehalfOf, if not needed, then set it as null when you call this method
    public void submitRetailComplexOrderReplace(String orderId, String onBehalfOf, String origClordId, String clOrdId, String symbol, String symbolSfx,
                                                String product, String securityType, String orderQty, String ordType,
                                                String price, String stopPx, String ccy, String positionId, String ifDoneIfType, String ifDoneIfSide,
                                                String ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
                                                String ifDoneThenStopRate, String ifDoneThenStopSide, String ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
                                                String ocoLeg2StopRate, String ocoLeg2stopSide, String ifDoneIfLimitRate) throws Exception {
        
        submitRetailComplexOrderReplace(orderId, onBehalfOf, origClordId, clOrdId, symbol, symbolSfx,
                product, securityType, orderQty, ordType,
                price, stopPx, ccy, positionId, ifDoneIfType, ifDoneIfSide,
                ifDoneIfStopRate, ifDoneIfStopSide, ifDoneThenType, ifDoneThenSide,
                ifDoneThenStopRate, ifDoneThenStopSide, ocoLeg1LimitRate, ocoLeg2Type, ocoLeg2Side,
                ocoLeg2StopRate, ocoLeg2stopSide, ifDoneIfLimitRate, null);
    }
    
    
    public void submitRetailComplexOrderReplace(String orderId, String onBehalfOf, String origClordId, String clOrdId, String symbol, String symbolSfx,
            String product, String securityType, String orderQty, String ordType,
            String price, String stopPx, String ccy, String positionId, String ifDoneIfType, String ifDoneIfSide,
            String ifDoneIfStopRate, String ifDoneIfStopSide, String ifDoneThenType, String ifDoneThenSide,
            String ifDoneThenStopRate, String ifDoneThenStopSide, String ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side,
            String ocoLeg2StopRate, String ocoLeg2stopSide, String ifDoneIfLimitRate, String maxShowAmt) throws Exception {
        
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        if (onBehalfOf != null) {
        msg.setField(Constants.TAGNoPartyIDs, "1");
        msg.addField(Constants.TAGPartyID, onBehalfOf);
        msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGMaxShow, maxShowAmt);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        // If Leg
        if (ifDoneIfType != null) {
        msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
        msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
        msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate);
        msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
        msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
        // IfDoneThen side
        msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
        msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
        msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate);
        msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate);
        msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        if (ocoLeg2Side != null && ifDoneIfSide == null) {
        msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);
        }
        msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate);
        msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitRetailIcebergOrderReplace(String orderId, String origClordId, String clOrdId, String symbol, String product,
                                                String side, String orderQty, String ordType, String price, String stopPx,
                                                String ccy, String expDate, String expTime, String minQty, String trailByRate,
                                                String maxSlippage, String positionId, String maxShow) throws Exception {
        submitRetailIcebergOrderReplaceMTF(orderId, origClordId, clOrdId, symbol, product,
                side, orderQty, ordType, price, stopPx,
                ccy, expDate, expTime, minQty, trailByRate,
                maxSlippage, positionId, maxShow, null);
    }

    public void submitRetailIcebergOrderReplaceOnBehalf(String orderId, String origClordId, String clOrdId, String symbol,
            String symbolSfx, String product, String securityType,
            String side, String orderQty, String ordType, String price, String stopPx,
            String ccy, String expDate, String expTime, String minQty, String trailByRate,
            String maxSlippage, String positionId, String maxShow, String onBehalf) throws Exception {
        submitRetailIcebergOrderReplaceOnBehalfMTF(orderId, origClordId, clOrdId, symbol,
                symbolSfx, product, securityType,
                side, orderQty, ordType, price, stopPx,
                ccy, expDate, expTime, minQty, trailByRate,
                maxSlippage, positionId, maxShow, onBehalf, null);
    }

    public void submitRetailIcebergOrderReplaceMTF(String orderId, String origClordId, String clOrdId, String symbol, String product,
                                                String side, String orderQty, String ordType, String price, String stopPx,
                                                String ccy, String expDate, String expTime, String minQty, String trailByRate,
                                                String maxSlippage, String positionId, String maxShow, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(Constants.TAGMaxShow, maxShow);
        msg.setField(Constants.TAGVenueType, venueType);
        sendFixMessage(msg);
    }

    public void submitRetailIcebergOrderReplaceOnBehalfMTF(String orderId, String origClordId, String clOrdId, String symbol,
            String symbolSfx, String product, String securityType,
            String side, String orderQty, String ordType, String price, String stopPx,
            String ccy, String expDate, String expTime, String minQty, String trailByRate,
            String maxSlippage, String positionId, String maxShow, String onBehalf, String venueType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGOrigClOrdID, origClordId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGCurrency, ccy);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(TAGTrailByRate, trailByRate);
        msg.setField(TAGMaxSlippage, maxSlippage);
        msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        msg.setField(Constants.TAGMaxShow, maxShow);
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGVenueType, venueType);
        sendFixMessage(msg);
     }

    public void submitRetailMassStatusRequest(String requestId, String requestType) throws Exception {
        Message msg = new Message(MSGMassStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMassStatusReqID, requestId);
        msg.setField(Constants.TAGMassStatusReqType, requestType);
        //temp sleep for delaying end time
        
        msg.setField(Constants.TAGTransactTime, dateFormat.format(oneMinuteAgo()));
        sendFixMessage(msg);
    }

    public void submitRetailMassStatusRequest(String requestId, String requestType, int daysAgo, int hoursAgo, int minutesAgo) throws Exception {
        submitRetailMassStatusRequest(requestId, requestType, daysAgo, hoursAgo, minutesAgo, null);
    }

    public void submitRetailMassStatusRequest(String requestId, String requestType, int daysAgo, int hoursAgo, int minutesAgo, String onBehalfOf) throws Exception {
        Message msg = new Message(MSGMassStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMassStatusReqID, requestId);
        msg.setField(Constants.TAGMassStatusReqType, requestType);
        if (onBehalfOf != null) {
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, onBehalfOf);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        }
        //temp sleep for delaying end time
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MINUTE, -minutesAgo);
        c.add(Calendar.HOUR, -hoursAgo);
        c.add(Calendar.DATE, -daysAgo);
        c.add(Calendar.HOUR, 7);//GMT time

        /////
        Date d = c.getTime();
        msg.setField(Constants.TAGTransactTime, dateFormat.format(d));
        sendFixMessage(msg);
    }

    public void submitRetailRequestForPositionsBackwardsCompatible(String requestId,
                                                                   String subReqType, String account, String accType, String startDate) throws Exception {
        Message msg = new Message(Constants.MSGRequestForPositions, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGPosReqID, requestId);
        msg.setField(Constants.TAGPosReqType, "0");
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGAccountType, accType);
        msg.setField(Constants.TAGClearingBusinessDate, startDate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void submitRetailRequestForPositions(String requestId, String requestType,
                                                String subReqType, String account, String accType, String startDate) throws Exception {
        Message msg = new Message(Constants.MSGRequestForPositions, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGPosReqID, requestId);
        msg.setField(Constants.TAGPosReqType, requestType);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        if (account != null) {
            msg.setField(Constants.TAGAccount, account);
            msg.setField(FixTagConstants.TAGNoPartyIDs, 1);
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, account);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        }
        msg.setField(Constants.TAGAccountType, accType);
        msg.setField(Constants.TAGClearingBusinessDate, startDate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void submitRetailRequestForPositionsBadAccount(String requestId, String requestType,
                                                          String subReqType, String account, String accType, String startDate) throws Exception {
        Message msg = new Message(Constants.MSGRequestForPositions, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGPosReqID, requestId);
        msg.setField(Constants.TAGPosReqType, requestType);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        if (account != null) {
            msg.setField(Constants.TAGAccount, "^&*(");
            msg.setField(FixTagConstants.TAGNoPartyIDs, 1);
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, account);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        }
        msg.setField(Constants.TAGAccountType, accType);
        msg.setField(Constants.TAGClearingBusinessDate, startDate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void submitRetailRequestForPositionsOnBehalf(String requestId, String requestType,
                                                        String subReqType, String hubAccount, String accType, String startDate) throws Exception {
        Message msg = new Message(Constants.MSGRequestForPositions, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGPosReqID, requestId);
        msg.setField(Constants.TAGPosReqType, requestType);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGAccount, hubAccount);
        msg.setField(FixTagConstants.TAGNoPartyIDs, 1);
        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, hubAccount);
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        msg.setField(Constants.TAGAccountType, accType);
        msg.setField(Constants.TAGClearingBusinessDate, startDate);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderReplace(String origClOrdId, String clOrdId, String ordId,
                                           String symbol, String symbolSfx,
                                           String product, String side, String orderQty, String ordType, String price, String stopPx,
                                           String expDate, String expTime, String minQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, ordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitTreasuryOrderReplaceOnBehalf(String origClOrdId, String clOrdId, String ordId,
                                                   String symbol, String symbolSfx,
                                                   String product, String side, String orderQty, String ordType, String price, String stopPx,
                                                   String expDate, String expTime, String minQty, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrderID, ordId);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    public void submitBadTreasuryOrderReplace(String origClOrdId, String ordId, String handlInstr,
                                              String symbol, String symbolSfx,
                                              String orderQty, String price, String stopPx,
                                              String expDate, String expTime, String minQty) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId);
        msg.setField(Constants.TAGClOrdID, "testNewClOrdId");
        msg.setField(Constants.TAGOrderID, ordId);
        msg.setField(Constants.TAGHandlInst, handlInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGSide, Constants.SIDE_Buy);
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_Market);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGExpireDate, expDate);
        msg.setField(Constants.TAGExpireTime, expTime);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put("testNewClOrdId", new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    /**
     * Submit a request to view entity trades
     *
     * @param requestId
     * @throws Exception
     */
    public void submitViewAllEntityTradesRequest(String requestId) throws Exception {
        Message msg = new Message("U11", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 1);
        sendFixMessage(msg);
    }

    /**
     * Submit a server notification request
     *
     * @param requestId
     * @throws Exception
     */
    public void submitServerNotificationMessage(String requestId) throws Exception {
        Message msg = new Message("U8", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 1);
        msg.setField(FixTagConstants.TAGNoRelatedServerAlertType, "2");
        msg.addField(FixTagConstants.TAGServerAlertType, "0");
        msg.addField(FixTagConstants.TAGServerAlertType, "1");
        sendFixMessage(msg);
    }

    /**
     * Submit a server notification request
     *
     * @param requestId
     * @throws Exception
     */
    public void submitServerNotificationMessageUnsubscribe(String requestId) throws Exception {
        Message msg = new Message("U8", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, 2);
        msg.setField(FixTagConstants.TAGNoRelatedServerAlertType, "2");
        msg.addField(FixTagConstants.TAGServerAlertType, "0");
        msg.addField(FixTagConstants.TAGServerAlertType, "1");
        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQSwap(String requestId, String noRelatedSym, String symbol,
                                      String side, String orderQty, String orderQty2, String valueDt, String farValueDt,
                                      String account, String currency, String bank1, String bank2
    ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, farValueDt);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "2");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank1);
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }
    
    private void submitQuoteRequestRFQ(String requestId, String symbol, String quoteType, String side, String orderQty,
            String valueDt, String account, String currency, String valueDt2, String orderQty2,
            String securityType, String fixingDate, String product, Party[] parties, Allocation[] allocations) throws Exception {

        submitQuoteRequestRFQ(requestId, symbol, quoteType, side, orderQty,
                valueDt, account, currency, valueDt2, orderQty2,
                securityType, fixingDate, product, parties, allocations, null);
    }

    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQ(String requestId, String symbol, String quoteType, String side, String orderQty,
            String valueDt, String account, String currency, String valueDt2, String orderQty2, 
            String securityType, String fixingDate, String product, Party[] parties, Allocation[] allocations,
            String venueType) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGQuoteType, quoteType);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        
        if(parties!=null && parties.length>0){
            msg.setField(Constants.TAGNoPartyIDs, parties.length);
            for(Party party:parties){
                msg.setField(Constants.TAGPartyID, party.partyID);
                msg.setField(Constants.TAGPartyIDSource, party.partyIDSource);
                msg.setField(Constants.TAGPartyRole, party.partyRole);
            }
        }
        
        if(allocations!=null && allocations.length>0){
            msg.setField(Constants.TAGNoAllocs, allocations.length);
            for(Allocation allocation:allocations){
                msg.setField(Constants.TAGAllocAccount, allocation.allocAccount);
                msg.setField(Constants.TAGIndividualAllocID, allocation.individualAllocID);
                msg.setField(Constants.TAGAllocQty, allocation.allocQty);
                msg.setField(Constants.TAGSettlCurrAmt, allocation.settlCurrAmt);
            }
        }
        
        msg.setField(Constants.TAGVenueType, venueType);
        msg.setField(Constants.TAGFixingDate, fixingDate);

        sendFixMessage(msg);
    }
    
    
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestLE(String requestId, String orderQty, Party[] parties) throws Exception {
        
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, "NA");
        msg.addField(Constants.TAGSymbolSfx, "NA");
        msg.addField(Constants.TAGSymbolSfx, "NA");
        msg.addField(Constants.TAGSecurityID, "912828Q94");
        msg.addField(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Cusip);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Government);
        msg.setField(Constants.TAGSecurityType, "TNOTE");
        msg.setField(Constants.TAGMaturityDate, "20180430");
        msg.setField(Constants.TAGIssueDate, "20160502");
        msg.addField(Constants.TAGQuoteType, Constants.QUOTETYPE_Tradable);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGSettlDate, "20161013");
        msg.addField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGPriceType, Constants.PRICETYPE_Price);
        
        if(parties!=null && parties.length>0){
            msg.setField(Constants.TAGNoPartyIDs, parties.length);
            for(Party party:parties){
                msg.setField(Constants.TAGPartyID, party.partyID);
                msg.setField(Constants.TAGPartyIDSource, party.partyIDSource);
                msg.setField(Constants.TAGPartyRole, party.partyRole);
            }
        }

        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQMultiLeg(String requestId, String symbol, RFQLeg[] rfqLegs, Party[] parties) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_MultiLegContract);
        
        if(rfqLegs!=null && rfqLegs.length>0){
            msg.setField(Constants.TAGNoLegs, rfqLegs.length);
            for(RFQLeg rfqLeg:rfqLegs){
                msg.setField(Constants.TAGLegSymbol, rfqLeg.legSymbol);
                msg.setField(Constants.TAGLegSide, rfqLeg.legSide);
                msg.setField(Constants.TAGLegCurrency, rfqLeg.legCurrency);
                
                if(rfqLeg.allocations!=null && rfqLeg.allocations.length>0){
                    msg.setField(Constants.TAGNoLegAllocs, rfqLeg.allocations.length);
                    for(Allocation allocation:rfqLeg.allocations){
                        msg.setField(Constants.TAGLegAllocAccount, allocation.allocAccount);
                        msg.setField(Constants.TAGLegIndividualAllocID, allocation.individualAllocID);
                        msg.setField(Constants.TAGLegAllocQty, allocation.allocQty);
                    }
                }
                msg.setField(Constants.TAGLegQty, rfqLeg.legOrderQty);
                msg.setField(Constants.TAGLegFutSettDate, rfqLeg.legSettlDate);
                msg.setField(Constants.TAGLegRefID, rfqLeg.legRefID);
            }
        }
                
        if(parties!=null && parties.length>0){
            msg.setField(Constants.TAGNoPartyIDs, parties.length);
            for(Party party:parties){
                msg.setField(Constants.TAGPartyID, party.partyID);
                msg.setField(Constants.TAGPartyIDSource, party.partyIDSource);
                msg.setField(Constants.TAGPartyRole, party.partyRole);
            }
        }
        
        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQ(String requestId, String noRelatedSym, String symbol, String product,
                                      String securityType, String side, String orderQty, String valueDt, String orderQty2,
                                      String currency, String account, String noPartyIds, String partyId,
                                      String partyRole, String valueDt2
    ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.addField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.addField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGNoPartyIDs, noPartyIds);
        msg.setField(Constants.TAGPartyID, partyId);
        msg.setField(Constants.TAGPartyRole, partyRole);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestClearedRFQ(String requestId, String symbol, String product,
                                      String securityType, String side, String orderQty, String valueDt, String orderQty2,
                                      String currency, String account, String makerPartyId, String lei,
                                      String valueDt2, String fixingDate
    ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.addField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGNoInstrumentParties, "1");
        msg.setField(Constants.TAGInstrumentPartyID, "LCH");
        msg.setField(Constants.TAGInstrumentPartyIDSource, "D");
        msg.setField(Constants.TAGInstrumentPartyRole, "21");
        
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGSettlDate2, valueDt2);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        
        msg.addField(Constants.TAGCurrency, currency);
        msg.addField(Constants.TAGAccount, account);
        
        int NoPartyIDs = 0;
        if(makerPartyId!=null) {
            NoPartyIDs++;
        }
        if(lei!=null) {
            NoPartyIDs++;
        }
        
        msg.setField(Constants.TAGNoPartyIDs,  Integer.toString(NoPartyIDs));
        if(makerPartyId!=null){
        msg.setField(Constants.TAGPartyID, makerPartyId);
        msg.setField(Constants.TAGPartyRole, "1");
        }
        if(lei!=null){
        msg.setField(Constants.TAGPartyID, lei);
        msg.setField(Constants.TAGPartyIDSource, "N");
        msg.setField(Constants.TAGPartyRole, "4");
        }
        
        msg.addField(Constants.TAGFixingDate, fixingDate);
        
        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQ(String requestId, String noRelatedSym, String symbol,
                                      String side, String orderQty, String valueDt, String account, String currency,
                                      String bank1, String bank2
    ) throws Exception {
//        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
//        msg.setField(Constants.TAGQuoteReqID, requestId);
//        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
//        msg.addField(Constants.TAGSymbol, symbol);
//        msg.addField(Constants.TAGSide, side);
//        msg.addField(Constants.TAGOrderQty, orderQty);
//        msg.addField(Constants.TAGFutSettDate, valueDt);
//        msg.addField(Constants.TAGCurrency, currency);
//        msg.setField(Constants.TAGAccount, account);
//        msg.setField(Constants.TAGNoPartyIDs, "2");
//        msg.setField(Constants.TAGPartyID, bank1);
//        msg.setField(Constants.TAGPartyRole, Constants.PARTYROLE_ExecutingFirm);
//        msg.setField(Constants.TAGPartyID, bank2);
//        msg.setField(Constants.TAGPartyRole, Constants.PARTYROLE_ExecutingFirm);
        Party[] parties = new Party[2];
        parties[0] = new Party(bank1, null, Constants.PARTYROLE_ExecutingFirm);
        parties[1] = new Party(bank2, null, Constants.PARTYROLE_ExecutingFirm);
        
      submitQuoteRequestRFQ(requestId, symbol, null/*quoteType*/, side, orderQty,
              valueDt, account, currency, null /*valueDt2*/, null /*orderQty2*/,
              null /*securityType*/, null /*fixingDate*/, null /*product*/, parties, null);
        
        //sendFixMessage(msg);
    }
    
    public void submitQuoteRequestRFQOnBehalf(String requestId, String noRelatedSym, String symbol, String product,
            String securityType, String side, String orderQty, String valueDt, String orderQty2,
            String currency, String account, String noPartyIds, String partyId,
            String partyRole, String partyId2, String partyRole2, String valueDt2 
            ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.addField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.addField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGNoPartyIDs, noPartyIds);
        msg.setField(Constants.TAGPartyID, partyId);
        msg.setField(Constants.TAGPartyRole, partyRole);
        msg.addField(Constants.TAGPartyID, partyId2);
        msg.setField(Constants.TAGPartyRole, partyRole2);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        sendFixMessage(msg);
    }

    public void submitOrderRFQFwd(String clientOrderID, String valueDate, String securityType,
            String symbol, String side, String amount,
            String ordType, String quoteReqId, String price, String currency,
            String quoteId, String expiration, String noRegIds, String regTradeId, String regTradeIdSource) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    public void submitOrderRFQFwd(String clientOrderID, String valueDate, String handleInstr,
            String symbol, String side, String amount,
            String ordType, String quoteReqId, String price, String currency,
            String quoteId, String expiration, String compId) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGComplianceID, compId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQFwdNDF(String clientOrderID, String valueDate, String handleInstr,
            String symbol, String symbolSfx, String side, String securityType, String amount,
            String ordType, String quoteReqId, String price, String currency,
            String quoteId, String expiration, String noRegIds, String regTradeId, String regTradeIdSource) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQFwdNDF(String clientOrderID, String valueDate, String handleInstr,
            String symbol, String symbolSfx, String side, String securityType, String amount,
            String ordType, String quoteReqId, String price, String currency,
            String quoteId, String expiration) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGFutSettDate, valueDate);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGQuoteReqID, quoteReqId);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTimeInForce, expiration);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitOrderRFQFwdClearedNDF(String clientOrderID, String symbol, String side, String amount,
            String price, String currency,String quoteId) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchangeNDF);
        msg.setField(Constants.TAGNoInstrumentParties, "1");
        msg.setField(Constants.TAGInstrumentPartyID, "LCH");
        msg.setField(Constants.TAGInstrumentPartyIDSource, "D");
        msg.setField(Constants.TAGInstrumentPartyRole, "21");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitQuoteRequestOnBehalf(String requestId, String noRelatedSym, String symbol, String product, String securityType,
            String side, String orderQty, String valueDt, String currency, String noPartyIds, String partyId, String partyRole,
            String partyId2, String partyRole2
    ) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGSecurityType, securityType);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoPartyIDs,  noPartyIds);
        msg.addField(Constants.TAGPartyID, partyId);
        msg.addField(Constants.TAGPartyRole, partyRole);
        msg.addField(Constants.TAGPartyID, partyId2);
        msg.addField(Constants.TAGPartyRole, partyRole2);
        sendFixMessage(msg);
    }

    public void submitOrderOnBehalf(String clientOrderID, String noPartyIds, String partyId, String partyRole,
            String handleInstr, String symbol, String product, String securityType, String side, String amount,
            String ordType, String price, String currency, String quoteId
            ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGNoPartyIDs,  noPartyIds);
        msg.addField(Constants.TAGPartyID, partyId);
        msg.addField(Constants.TAGPartyRole, partyRole);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQSwap(String clientOrderID, String handleInstr, String product,
            String symbol, String side, String amount,
            String ordType, String price, String currency,
            String quoteId, String orderQty2) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGOrderQty2, amount);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    public void submitOrderRFQSwap(String clientOrderID, String securityType, String product,
            String symbol, String side, String amount,
            String ordType, String price, String currency,
            String quoteId, String orderQty2, String noRegIds, String regTradeId,
            String regTradeIdSource, String regTradeIdType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_PreviouslyQuoted);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGOrderQty2, amount);
        
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        msg.setField(Constants.TAGRegulatoryTradeIDType, regTradeIdType);
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitOrderRFQSwapClearedNDF(String clientOrderID, String product,
            String symbol, String securityType, String side, String amount,
            String ordType, String price, String currency,
            String quoteId, String orderQty2, String price2) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        
        msg.setField(Constants.TAGNoPartyIDs, "1");
        msg.setField(Constants.TAGPartyID, "LCH");
        msg.setField(Constants.TAGPartyRole, "21");
        
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGOrderQty2, orderQty2);
        msg.setField(Constants.TAGPrice2, price2);
        
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitOrderRFQSwapOnBehalf(String clientOrderID, String handleInstr, String product,
            String symbol, String side, String amount,
            String ordType, String price, String currency,
            String quoteId, String orderQty2, String noRegIds, String regTradeId,
            String regTradeIdSource, String regTradeIdType, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID);
        msg.addField(Constants.TAGNoPartyIDs, "1");
        msg.addField(Constants.TAGPartyID, onBehalf);
        msg.addField(Constants.TAGPartyRole, "3");
        msg.setField(Constants.TAGHandlInst, handleInstr);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGOrderQty2, amount);
        msg.setField(Constants.TAGNoRegulatoryTradeIDs, noRegIds);
        msg.setField(Constants.TAGRegulatoryTradeID, regTradeId);
        msg.setField(Constants.TAGRegulatoryTradeIDSource, regTradeIdSource);
        msg.setField(Constants.TAGRegulatoryTradeIDType, regTradeIdType);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }

    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQSingleBank(String requestId, String noRelatedSym, String symbol,
                                      String side, String orderQty, String valueDt, String account, String currency,
                                      String bank1) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "1");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank1);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQGvx(String requestId, String partyID, String partyRole) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, "NA");
        msg.addField(Constants.TAGSymbolSfx, "NA");
        msg.addField(Constants.TAGIDSource, "1");
        msg.addField(Constants.TAGProduct, "6");
        msg.addField(Constants.TAGSecurityType, "TNOTE");
        msg.addField(Constants.TAGMaturityDate, "20161231");
        msg.addField(Constants.TAGIssueDate, "20141231");
        msg.addField(Constants.TAGQuoteType, "1");
        msg.addField(Constants.TAGOrderQty, "1000000");
        msg.setField(Constants.TAGSettlDate, "20150120");
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGPriceType, "1");
        msg.setField(Constants.TAGNoPartyIDs, "1");
        msg.setField(Constants.TAGPartyID, partyID);
        msg.setField(Constants.TAGPartyIDSource, "D");
        msg.setField(Constants.TAGPartyRole, partyRole);
        sendFixMessage(msg);
    }

    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQSingleBankSwap(String requestId, String noRelatedSym, String symbol,
                                      String side, String orderQty, String valueDt, String account, String currency,
                                      String bank1, String valueDt2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGOrderQty2, orderQty);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "1");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank1);
        sendFixMessage(msg);
    }

    public void submitQuoteRequestRFQMultiBank(String requestId, String onBehalf, String noRelatedSym, String symbol,
                                               String side, String orderQty, String valueDt, String account, String currency,
                                               String[] banks
    ) throws Exception {
        Message msg = submitQuoteRequestRFQHelper(requestId, onBehalf, noRelatedSym, symbol,
                side, orderQty, valueDt, account, currency);
        if (banks != null) {
            quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, banks.length);
            for (String bank : banks) {
                msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank);
            }
        }
        sendFixMessage(msg);
    }

    Message submitQuoteRequestRFQHelper(String requestId, String onBehalf, String noRelatedSym, String symbol,
                                        String side, String orderQty, String valueDt, String account, String currency) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        if(onBehalf!=null) {
            msg.addField(Constants.TAGClientID, onBehalf);
        }
        if(account!=null) {
            ;
        }
        msg.setField(Constants.TAGAccount, account);
        return msg;
    }

    /**
     * Submit a quote request for Loans&Deposit RFS trading
     *
     * @throws Exception
     */
    public void submitQuoteRequestLDRFQ(String requestId, String noRelatedSym, String symbol,
                                        String product, String matDate, String dayCount,
                                        String side, String orderQty, String settlDate, String noPartyIds, String partyId,
                                        String partyIdSource, String partyRole) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGMaturityDate, matDate);
        msg.addField(Constants.TAGDayCount, dayCount);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGSettlDate, settlDate);
        msg.setField(Constants.TAGNoPartyIDs, noPartyIds);
        msg.addField(Constants.TAGPartyID, partyId);
        msg.addField(Constants.TAGPartyIDSource, partyIdSource);
        if (partyRole != null) {
            msg.addField(Constants.TAGPartyRole, "1");
        }
        sendFixMessage(msg);
    }
    
    public void submitQuoteRequestLDRFQ(String requestId, String noRelatedSym, String symbol,
            String product, String matDate, String dayCount,
            String side, String orderQty, String settlDate, String makerPartyId,
            String onBehalfOf, String account) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, product);
        msg.addField(Constants.TAGMaturityDate, matDate);
        msg.addField(Constants.TAGDayCount, dayCount);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGSettlDate, settlDate);
        if(onBehalfOf!=null) {
            msg.setField(Constants.TAGNoPartyIDs, "2");
        } else {
            msg.setField(Constants.TAGNoPartyIDs, "1");
        }
        msg.addField(Constants.TAGPartyID, makerPartyId);
        msg.addField(Constants.TAGPartyIDSource, "D");
        msg.addField(Constants.TAGPartyRole, Constants.PARTYROLE_ExecutingFirm);
        
        if(onBehalfOf!=null){
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, Constants.PARTYROLE_Client);
        }
        
        msg.addField(Constants.TAGAccount, account);
        
        sendFixMessage(msg);
    }

    public void submitQuoteRequestRFQOnBehalf(String requestId, String onBehalf, String noRelatedSym, String symbol,
                                              String side, String orderQty, String valueDt, String account, String currency,
                                              String numBanks, String bank1, String bank2
    ) throws Exception {
        Message msg = submitQuoteRequestRFQHelper(requestId, onBehalf, noRelatedSym, symbol,
                side, orderQty, valueDt, account, currency);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        if(bank2!=null) {
            msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        }
        sendFixMessage(msg);
    }

    /**
     * Submit a spot RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocs(String requestId, String noRelatedSym, String symbol,
                                            String side, String orderQty, String valueDt, String account, String currency,
                                            String numAllocs, String alloc1, String allocQty1, String indivAllocId1,
                                            String alloc2, String allocQty2, String indivAllocId2,
                                            String numBanks, String bank1, String bank2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a spot RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQTwoAllocs(String requestId, String symbol,
                                            String side, String orderQty, String valueDt, String currency, String account, String onBehalfOf,
                                            String alloc1, String allocQty1, String indivAllocId1,
                                            String alloc2, String allocQty2, String indivAllocId2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.addField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        if(onBehalfOf!=null){
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGNoAllocs, "2");
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);

        sendFixMessage(msg);
    }
    
    /**
     * Submit a RFQ NDF with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocsNDF(String requestId, String symbol,
                                            String side, String orderQty, String valueDt, String account, String currency,
                                            String numAllocs, String alloc1, String allocQty1, String indivAllocId1,
                                            String alloc2, String allocQty2, String indivAllocId2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.addField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchangeNDF);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a RFQ Cleared NDF with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocsClearedNDF(String requestId, String symbol,
                                            String side, String orderQty, String valueDt, String account, String currency,
                                            String bank1, Allocation[] allocs, TakerTestSession routedTaker) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.addField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchangeNDF);
        msg.setField(Constants.TAGNoInstrumentParties, "1");
        msg.setField(Constants.TAGInstrumentPartyID, "LCH");
        msg.setField(Constants.TAGInstrumentPartyIDSource, "D");
        msg.setField(Constants.TAGInstrumentPartyRole , "21");
        
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        if(routedTaker!=null) {
            msg.addField(Constants.TAGNoPartyIDs, "2");
        } else {
            msg.addField(Constants.TAGNoPartyIDs, "1");
        }
        
        //bank
        msg.addField(Constants.TAGPartyID, bank1);
        msg.addField(Constants.TAGPartyRole, "1");
        
        if(routedTaker!=null){
            msg.addField(Constants.TAGPartyID, routedTaker.getUserName());
            msg.addField(Constants.TAGPartyRole, "3");
        }
        
        if(allocs!=null){
            msg.setField(Constants.TAGNoAllocs, allocs.length);
            
            for(Allocation alloc:allocs){
                msg.addField(Constants.TAGAllocAccount, alloc.allocAccount);
                msg.addField(Constants.TAGIndividualAllocID, alloc.individualAllocID);
                if(alloc.nestedPartyID!=null){
                    msg.addField(Constants.TAGNoNestedPartyIDs, "1");
                    msg.addField(Constants.TAGNestedPartyID, alloc.nestedPartyID);
                    msg.addField(Constants.TAGNestedPartyIDSource, "N");
                    msg.addField(Constants.TAGNestedPartyRole, "4");
                }
                msg.addField(Constants.TAGAllocQty, alloc.allocQty);
            }
        }
        sendFixMessage(msg);
    }
    
    /**
     * Submit a spot RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocsFx44(String requestId, String noRelatedSym, String symbol,
                                            String side, String orderQty, String valueDt, String account, String currency,
                                            String numAllocs, String alloc1, String allocQty1, String indivAllocId1,
                                            String alloc2, String allocQty2, String indivAllocId2,
                                            String numBanks, String bank1, String bank2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "4");
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        System.out.println("Making QuoteRequest.");
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a swap RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocsSwapFx44(String requestId, String noRelatedSym, String symbol,
                                                String side, String orderQty, String valueDt, String valueDt2, String orderQty2, String account, String currency,
                                                String numAllocs, String alloc1, String allocQty1, String farAllocQty1, String indivAllocId1,
                                                String alloc2, String allocQty2, String farAllocQty2, String indivAllocId2,
                                                String numBanks, String bank1, String bank2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGSettlCurrAmt /*AllocQty2*/, farAllocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGSettlCurrAmt /*AllocQty2*/, farAllocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a swap RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQ3AllocsSwapFx44(String requestId, String noRelatedSym, String symbol,
                                                String side, String orderQty, String valueDt, String valueDt2, String orderQty2, String account, String currency,
                                                String numAllocs, String alloc1, String allocQty1, String farAllocQty1, String indivAllocId1,
                                                String alloc2, String allocQty2, String farAllocQty2, String indivAllocId2,
                                                String alloc3, String allocQty3, String farAllocQty3, String indivAllocId3,
                                                String numBanks, String bank1, String bank2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGOrderQty2, orderQty2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGSettlCurrAmt, farAllocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGSettlCurrAmt, farAllocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        msg.addField(Constants.TAGAllocAccount, alloc3);
        msg.addField(Constants.TAGAllocQty, allocQty3);
        msg.addField(Constants.TAGSettlCurrAmt, farAllocQty3);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId3);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }
    
    /**
     * Submit a forward RFQ with pre trade allocs defined
     *
     * @throws Exception
     */
    public void submitQuoteRequestRFQAllocsFwdFx44(String requestId, String noRelatedSym, String symbol,
                                                String side, String orderQty, String valueDt, String account, String currency,
                                                String numAllocs, String alloc1, String allocQty1, String indivAllocId1,
                                                String alloc2, String allocQty2, String indivAllocId2,
                                                String numBanks, String bank1, String bank2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGNoAllocs, numAllocs);
        msg.addField(Constants.TAGAllocAccount, alloc1);
        msg.addField(Constants.TAGAllocQty, allocQty1);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId1);
        msg.addField(Constants.TAGAllocAccount, alloc2);
        msg.addField(Constants.TAGAllocQty, allocQty2);
        msg.addField(Constants.TAGIndividualAllocID, indivAllocId2);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
        msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        sendFixMessage(msg);
    }

    public void submitEmptyQuoteRequestRFQ() throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        sendFixMessage(msg);
    }

    public void submitQuoteRequestRFQSwapOnBehalf(String requestId, String onBehalf, String noRelatedSym,
                                                  String symbol, String side, String orderQty, String valueDt, String account,
                                                  String currency, String valueDt2) throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        msg.addField(Constants.TAGSymbol, symbol);
        msg.addField(Constants.TAGSide, side);
        msg.addField(Constants.TAGOrderQty, orderQty);
        msg.addField(Constants.TAGOrderQty2, orderQty);
        msg.addField(Constants.TAGFutSettDate, valueDt);
        msg.addField(Constants.TAGFutSettDate2, valueDt2);
        msg.addField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGAccount, account);
        msg.addField(Constants.TAGClientID, onBehalf);
        sendFixMessage(msg);
    }

    public void submitQuoteCancelRFQ(String requestId, String quoteId, String quoteCancelType,
                                     String noQuoteEntries, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGQuoteCancelType, quoteCancelType);
        msg.setField(Constants.TAGNoQuoteEntries, noQuoteEntries);
        if(symbol!=null) {
            msg.addField(Constants.TAGSymbol, symbol);
        }
        sendFixMessage(msg);
    }

    public void submitQuoteCancelLDRFQ(String requestId, String quoteId, String quoteCancelType, String noQuoteEntries, String symbol) throws Exception {
        Message msg = new Message(Constants.MSGQuoteCancel, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGQuoteReqID, requestId);
        msg.setField(Constants.TAGQuoteID, quoteId);
        msg.setField(Constants.TAGQuoteCancelType, quoteCancelType);
        msg.setField(Constants.TAGNoQuoteEntries, noQuoteEntries);
        msg.addField(Constants.TAGSymbol, symbol);
        sendFixMessage(msg);
    }

    public void submitMMUserPropertyRequest(String requestId, String subscriptionType) throws Exception {
        Message msg = new Message(MsgUserPropertyRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subscriptionType);
        sendFixMessage(msg);
    }

    public void submitMMUserPropertyUpdateRequest(String requestId, String propName, String propValue) throws Exception {
        Message msg = new Message(MsgUserPropertyUpdateRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(8015, propName);
        msg.setField(8016, propValue);
        sendFixMessage(msg);
    }

    public void submitCRLogon() throws Exception{
        Message msg = new Message(Constants.MSGLogon, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGEncryptMethod, "0");
        msg.setField(Constants.TAGHeartBtInt, "60");
        sendFixMessage(msg);
    }

    public void submitCRNewOrderSingleOutright(String deliverToCompID, String senderSubID, String ClOrdID, String allocAccount, String allocQty, String symbol, String side, String orderQty, String ordType, String currency, String timeInForce) throws Exception{
        Message msg = new Message("D", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField("128", deliverToCompID);
        msg.setField(Constants.TAGSenderSubID, senderSubID);
        msg.setField(Constants.TAGClOrdID, ClOrdID);

        quickfix.Group g = new quickfix.Group(FixTagConstants.TAGNoAllocs, FixTagConstants.TAGAllocAccount);
        msg.setField(FixTagConstants.TAGNoAllocs, "1");
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGAllocAccount, allocAccount);
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGAllocQty, allocQty);
        msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");

        msg.setField(Constants.TAGHandlInst, "1");
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTimeInForce, timeInForce);
    }

    /**
     * Workaround to receive entity execution reports.
     *
     * @param clientOrderID
     * @throws Exception TO-DO : Refactor to remove this.
     */
    public void addToTheQueue(final String clientOrderID) throws Exception {
        orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
    }


    public void submitNewOrderList(String listID, String bidType, String toNoOrders, String lastFragment, String[] clOrdIDs, String[] secClOrdIDs, String[] partyIDs, String symbol, String side, String[] orderQtys, String ordType, String currency, String timeInForce, String expireDate, String expireTime) throws Exception{
        Message msg = new Message("E", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGListID, listID);
        msg.setField(Constants.TAGBidType, bidType);
        msg.setField(Constants.TAGTotNoOrders, toNoOrders);
        msg.setField(Constants.TAGLastFragment, lastFragment);

        assertTrue(clOrdIDs.length == secClOrdIDs.length);
        assertTrue(secClOrdIDs.length == partyIDs.length);
        assertTrue(partyIDs.length == orderQtys.length);

        msg.setField(Constants.TAGNoOrders, clOrdIDs.length);

        for (int i = 0; i < clOrdIDs.length; i++){
            msg.addField(FixTagConstants.TAGClOrdID, clOrdIDs[i]);
            msg.addField(FixTagConstants.TAGSecondaryClOrdID, secClOrdIDs[i]);
            msg.addField(FixTagConstants.TAGListSeqNo, i+1);
            msg.addField(FixTagConstants.TAGNoPartyIDs, 1);
            msg.addField(FixTagConstants.TAGPartyID, partyIDs[i]);
            msg.addField(FixTagConstants.TAGPartyRole, 3);
            msg.addField(FixTagConstants.TAGSymbol, symbol);
            msg.addField(FixTagConstants.TAGSide, side);
            msg.addField(FixTagConstants.TAGOrderQty, orderQtys[i]);
            msg.addField(FixTagConstants.TAGOrdType, ordType);
//            msg.addField(FixTagConstants.TAGPrice, price);
            msg.addField(FixTagConstants.TAGCurrency, currency);
            msg.addField(FixTagConstants.TAGTimeInForce, timeInForce);
            msg.addField(FixTagConstants.TAGExpireDate, expireDate);
            msg.addField(FixTagConstants.TAGExpireTime, expireTime);
            orderMsgMap.put(clOrdIDs[i], new ArrayBlockingQueue<Message>(6000));
        }

        sendFixMessage(msg);
    }

    public void submitNewOrderListCancel(String listID, String symbol) throws Exception{
        Message msg = new Message("K", getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGListID, listID);
        Calendar c = Calendar.getInstance();
        Date d = c.getTime();
        msg.setField(Constants.TAGTransactTime, dateFormat.format(d));
        msg.setField(Constants.TAGText, "user cancel");
        msg.setField(Constants.TAGSymbol, symbol);
        sendFixMessage(msg);
    }
    
    public void submitIMMAdminOrder(String clientOrderID, String symbol,
            String symbolSfx, String buySell, String orderQty, String ordType,
            String priceType, String limitRate, String stopPx, String timeInForce, String orderCapacity,
            int custOrderCapacity, String minQty, String stopSide) throws Exception {

        submitNewOrderErisOutright(clientOrderID, symbol,
                symbolSfx, buySell, orderQty, ordType,
                priceType, limitRate, stopPx, timeInForce, orderCapacity,
                custOrderCapacity, minQty, stopSide, null);
     }
    
    
    public void submitNewOrderErisOutright(String clOrdID, String symbol,
            String symbolSfx, String buySell, String orderQty, String ordType,
            String priceType, String limitRate, String stopPx, String timeInForce, String orderCapacity,
            int custOrderCapacity, String minQty, String stopSide, String onBehalf) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, getSenderCompId(), getTargetCompId(), getFixVersion());

        msg.setField(Constants.TAGClOrdID, clOrdID);
        msg.setField(Constants.TAGClientID, onBehalf);
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs);
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGPriceType, priceType);
        msg.setField(Constants.TAGPrice, limitRate);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGTimeInForce, timeInForce);
        msg.setField(Constants.TAGOrderCapacity, orderCapacity);
        msg.setField(Constants.TAGCustOrderCapacity, custOrderCapacity);
        msg.setField(Constants.TAGMinQty, minQty);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGStopSide, stopSide);
        if(ordType.equals(Constants.ORDTYPE_Iceberg)){
            msg.setField(Constants.TAGMaxShow, orderQty);
        }
        orderMsgMap.put(clOrdID, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
     }
    
    public void submitOrderCancelRequestErisOutright(Message previousER, String clOrdId, String onBehalfOf) throws Exception {
        
        submitIMMAdminOrderCancelReq(
                previousER.getStringFieldValue(Constants.TAGOrderID),
                clOrdId,
                previousER.getStringFieldValue(Constants.TAGClOrdID),
                onBehalfOf,
                previousER.getStringFieldValue(Constants.TAGOrdType),
                previousER.getStringFieldValue(Constants.TAGSide),
                previousER.getStringFieldValue(Constants.TAGSymbol),
                previousER.getStringFieldValue(Constants.TAGSymbolSfx));
    }
    
    public void submitIMMAdminOrderCancelReq(String orderId, String clOrdId,
            String origClientOrderId, String onBehalf, String orderType, String side,
            String symbol, String symbolFx) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGOrigClOrdID, origClientOrderId);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, side);
        if (orderId != null && orderId.equals(ALL_OPEN_ORDERS)) {
            msg.setField(FixTagConstants.TAGOpenOrders, "Y");
        }
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        BlockingQueue<Message> msgQ = orderMsgMap.get(origClientOrderId);
        if (msgQ == null && !clOrdId.equals(ALL_OPEN_ORDERS)) {
            System.err.println("unknown order clOrdID=" + clOrdId);
            orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        }
        sendFixMessage(msg);
    }
    
    public void submitIMMAdminOrderReplace(String orderId, String clOrdId,
            String origClOrdId, String symbol, String symbolFx, String buySell, String amount,
            String orderType, String price, String stopPx, String minQty, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPublicBrokerOK);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGStopPx, stopPx);
        msg.setField(Constants.TAGMinQty, minQty);
        if (null != onBehalf) {
            if (getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        msg.setField(Constants.TAGCurrency, "USD");
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public void submitIMMAdminMarketDataRequest(String requestId, String symbol,
            String symbolSfx, String aggregatedBook, String marketDepth, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
    msg.setField(Constants.TAGMarketDepth, marketDepth);
    if (subReqType != null && subReqType.equals("1")) {
        msg.setField(Constants.TAGMDUpdateType, "1");
    }
    msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
    msg.setField(Constants.TAGNoMDEntryTypes, 2);
    msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
    msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
    msg.setField(Constants.TAGNoRelatedSym, 1);
    msg.setField(Constants.TAGSymbol, symbol);
    msg.setField(Constants.TAGSymbolSfx, symbolSfx);
    msg.setField(Constants.TAGProduct, "12");
    msg.setField(Constants.TAGSecurityType, "IRS");
    priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
    sendFixMessage(msg);
    }
    
    public void submitErisMarketDataRequestSecruityID(String requestId,
            String subReqType) throws Exception {
        submitErisMarketDataRequestSecIDorIOI(requestId, subReqType, Constants.MDENTRYTYPE_SecurityID);
    }
    
    public void submitErisMarketDataRequestIOI(String requestId,
            String subReqType) throws Exception {
        submitErisMarketDataRequestSecIDorIOI(requestId, subReqType, Constants.MDENTRYTYPE_IOI);
    }
    
    
    private void submitErisMarketDataRequestSecIDorIOI(String requestId, String subReqType, String mdEntryType) throws Exception{
        
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGMarketDepth, "0");
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGNoMDEntryTypes, 1);
        msg.addField(Constants.TAGMDEntryType, mdEntryType);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, "NA");
        msg.setField(Constants.TAGSymbolSfx, "NA");
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs);
        
        priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }
    
    public ArrayList<SecurityListGroup> getSecurityListGroups() throws Exception{
        
        if(this.slGroupList!=null){
            return slGroupList;
        }
        
        String securityListReqId = generateOrderId("testSecReq-"); 
        
        this.submitIrSwapSecurityListRequest(securityListReqId, 
                Constants.SECURITYLISTREQUESTTYPE_AllSecurities, 
                Constants.SUBSCRIPTIONREQUESTTYPE_Snapshot);
        
        Message securityList = this.getMessageFromListQueue(60000);
        assertNotNull(this.getUserName()+" didnt get SecurityList", securityList);
        
        ArrayList<SecurityListGroup> securityListGroupList = new ArrayList<SecurityListGroup>();
        
        while(securityList!=null){
            if(securityList.getStringFieldValue(Constants.TAGSecurityReqID)!=null &&
                    securityList.getStringFieldValue(Constants.TAGSecurityReqID).equals(securityListReqId)){
                
                String noRelatedSym = securityList.getStringFieldValue(Constants.TAGNoRelatedSym);
                assertNotNull("Error getting relatedSym from SecurityList", noRelatedSym);
                
                IFixGroup[] relatedSymbols = securityList.getParser().getDynamicGroupDataFor(Constants.TAGiNoRelatedSym, Constants.TAGiSymbol);
                assertNotNull("Error getting relatedSym repeating group from SecurityList", relatedSymbols);
                assertEquals("Different noRelatedSym in SecurityList", Integer.parseInt(noRelatedSym), relatedSymbols.length);
                
                for(IFixGroup relatedSymbol:relatedSymbols){
                    
                    SecurityListGroup slGroup = new SecurityListGroup(relatedSymbol.getStringValFor(Constants.TAGiSymbol),
                            relatedSymbol.getStringValFor(Constants.TAGiSymbolSfx),
                            relatedSymbol.getStringValFor(Constants.TAGiSecurityIDSource),
                            Integer.parseInt(relatedSymbol.getStringValFor(Constants.TAGiProduct)),
                            relatedSymbol.getStringValFor(Constants.TAGiSecurityType),
                            relatedSymbol.getStringValFor(Constants.TAGiFactor),
                            relatedSymbol.getStringValFor(Constants.TAGiCurrency),
                            relatedSymbol.getStringValFor(Constants.TAGiCouponRate),
                            relatedSymbol.getStringValFor(Constants.TAGiIssueDate),
                            relatedSymbol.getStringValFor(Constants.TAGiCPRegType),
                            relatedSymbol.getStringValFor(Constants.TAGiPriceType),
                            relatedSymbol.getStringValFor(Constants.TAGiDatedDate),
                            relatedSymbol.getStringValFor(Constants.TAGiInterestAccrualDate));
                    
                    slGroup.setSecurityID(relatedSymbol.getStringValFor(Constants.TAGiSecurityID));
                    
                    securityListGroupList.add(slGroup);
                }
            }
            if(securityList.getStringFieldValue(Constants.TAGLastFragment)!=null &&
                    securityList.getStringFieldValue(Constants.TAGLastFragment).equals("Y")){
                break;
            }
            securityList = this.getMessageFromListQueue(2000);
        }
        
        return securityListGroupList;
    }
    
    public String getErisSymbol(String symbolSfx, String secruityIDSrouce, String currency, boolean isSwap, String defaultSymbol)throws Exception{
        
        return getErisSymbol(symbolSfx, secruityIDSrouce, currency, isSwap, defaultSymbol, null/*tenor*/);
    }
    
    public SecurityListGroup getErisInstrument(String symbolSfx, String secruityIDSrouce, String currency, boolean isSwap, String tenor)throws Exception{
        
        if(slGroupList==null){
            slGroupList = this.getSecurityListGroups();
            assertNotNull("Error getting slGroupList from SecurityList messages for "+this.getUserName(), slGroupList);
        }
        
        List<SecurityListGroup> slGroups = null;
        
        if(!isSwap){
            slGroups = slGroupList.stream()
                    .filter(slGroup -> slGroup.getSymbolSfx().equals(symbolSfx))
                    .filter(slGroup -> slGroup.getSecurityIDSource()!=null)
                    .filter(slGroup -> slGroup.getSecurityIDSource().equals(secruityIDSrouce))
                    .filter(slGroup -> slGroup.getCurrency()!=null)
                    .filter(slGroup -> slGroup.getCurrency().equals(currency))
                    .collect(Collectors.toList());
            
            if(tenor!=null){
                slGroups = slGroups.stream()
                        .filter(slGroup -> slGroup.getSymbol().startsWith(tenor))
                        .collect(Collectors.toList());
            }
            
        }else{ // no SecurityIDSource for swap
            slGroups = slGroupList.stream()
                    .filter(slGroup -> slGroup.getSymbolSfx().equals(symbolSfx))
                    .filter(slGroup -> slGroup.getCurrency()!=null)
                    .filter(slGroup -> slGroup.getCurrency().equals(currency))
                    .collect(Collectors.toList());
            
            if(tenor!=null){
                slGroups = slGroups.stream()
                        .filter(slGroup -> slGroup.getSymbol().startsWith(tenor))
                        .collect(Collectors.toList());
            }
        }
        
        assertNotNull("Couldn't find any matching from SecurityList for "+this.getUserName(), slGroups);
        assertTrue("Couldn't find any matching from SecurityList for "+this.getUserName(), slGroups.size()>0);
        
        return slGroups.get(0);
    }
    
    public String getErisSymbol(String symbolSfx, String secruityIDSrouce, String currency, boolean isSwap, String defaultSymbol, String tenor)throws Exception{
        
        if(slGroupList==null){
            slGroupList = this.getSecurityListGroups();
            assertNotNull("Error getting slGroupList from SecurityList messages for "+this.getUserName(), slGroupList);
        }
        
        List<SecurityListGroup> slGroups = null;
        
        if(!isSwap){
            slGroups = slGroupList.stream()
                    .filter(slGroup -> slGroup.getSymbolSfx().equals(symbolSfx))
                    .filter(slGroup -> slGroup.getSecurityIDSource()!=null)
                    .filter(slGroup -> slGroup.getSecurityIDSource().equals(secruityIDSrouce))
                    .filter(slGroup -> slGroup.getCurrency()!=null)
                    .filter(slGroup -> slGroup.getCurrency().equals(currency))
                    .collect(Collectors.toList());
            
            if(tenor!=null){
                slGroups = slGroups.stream()
                        .filter(slGroup -> slGroup.getSymbol().startsWith(tenor))
                        .collect(Collectors.toList());
            }
            
        }else{ // no SecurityIDSource for swap
            slGroups = slGroupList.stream()
                    .filter(slGroup -> slGroup.getSymbolSfx().equals(symbolSfx))
                    .filter(slGroup -> slGroup.getCurrency()!=null)
                    .filter(slGroup -> slGroup.getCurrency().equals(currency))
                    .collect(Collectors.toList());
        }
        
        assertNotNull("Couldn't find any matching from SecurityList for "+this.getUserName(), slGroups);        
        
        if(slGroups.size()==0){
            assertNotNull("Symbol is null in the matching SecurityListGroup for "+this.getUserName()+" and default symbol is also null", 
                    defaultSymbol);            
            return defaultSymbol;
        }else{
            return slGroups.get(0).getSymbol();
        }
    }
    
    public void submitDSOrderStatusRequest(String orderId, String clOrdId, String symbol,
            String symbolSfx, String product, String securityType, String side,
            String orderType, String openOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        sendFixMessage(msg);
    }
    
    public void submitOrderStatusRequestEris(String orderId, String clOrdId, String symbol,
            String symbolSfx, String securityType, String side,
            String orderType, String onBehalfOf, boolean forOpenOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId);
        msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGClientID, onBehalfOf);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_IRSWAP);
        msg.setField(Constants.TAGSecurityType, securityType);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(FixTagConstants.TAGOpenOrders, forOpenOrders?"Y":null);
        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(100));
        sendFixMessage(msg);
    }
    
    public void submitDSMarketDataRequest(String requestId, String symbol,
            String symbolSfx, String aggregatedBook, String marketDepth, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, getSenderCompId(), getTargetCompId(), getFixVersion());
        msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
    msg.setField(Constants.TAGMarketDepth, marketDepth);
    if (subReqType != null && subReqType.equals("1")) {
        msg.setField(Constants.TAGMDUpdateType, "1");
    }
    msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
    msg.setField(Constants.TAGNoMDEntryTypes, 2);
    msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
    msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
    msg.setField(Constants.TAGNoRelatedSym, 1);
    msg.setField(Constants.TAGSymbol, symbol);
    msg.setField(Constants.TAGSymbolSfx, symbolSfx);
    msg.setField(Constants.TAGProduct, "12");
    msg.setField(Constants.TAGSecurityType, "MLEG");
    priceMsgMap.put(requestId, new ArrayBlockingQueue<Message>(6000));
    sendFixMessage(msg);
    }
    
    public void initiateRfsSp(String quoteRequestID, String symbol, String side, String amount)throws Exception
    {
        initiateRfsSp(quoteRequestID, symbol, side, amount, null, false, null, null, null, true);
    }

    public void initiateRfsSp(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker,
            boolean termsTrading, Allocation[] allocations)throws Exception{
        initiateRfsSp(quoteRequestID, symbol, side, amount, routedTaker, termsTrading, allocations, null, null, true);
    }
    
    public void initiateRfsSp(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker, 
            boolean termsTrading, Allocation[] allocations, String quoteType)throws Exception{
        initiateRfsSp(quoteRequestID, symbol, side, amount, routedTaker, termsTrading, allocations, quoteType, null,
                true);
    }

    public void initiateRfsSp(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker,
            boolean termsTrading, Allocation[] allocations, String quoteType, String account, boolean acceptable)throws Exception
    {
        Party[] parties = null;
        String accountSubmitted = account==null ? this.getPartyId():account;

        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            accountSubmitted = account==null ? routedTaker.getPartyId():account;
        }

        String currency = (termsTrading)?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID,
                symbol,
                quoteType,
                side,
                amount,
                "SP",
                accountSubmitted,
                currency,
                null,
                null,
                "FOR",
                null,
                Constants.PRODUCT_Currency,
                parties,
                allocations);

        if(acceptable){
            Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
            assertNotNull("no acknowledgement was received for quote requests", ack);
            validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                    , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
        }
    }
    
    public void initiateRfsFwd(String quoteRequestID, String symbol, String side, String amount)throws Exception
    {
        initiateRfsFwd(quoteRequestID, symbol, side, amount, null);
    }
    
    public void initiateRfsFwd(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker)throws Exception
    {
        initiateRfsFwd(quoteRequestID, symbol, side, amount, routedTaker, false, null);
    }

    public void initiateRfsFwd(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker,
            boolean termsTrading, Allocation[] allocations)throws Exception {
        initiateRfsFwd(quoteRequestID, symbol, side, amount, routedTaker, termsTrading, allocations, null, true);
    }
    
    public void initiateRfsFwd(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker, 
            boolean termsTrading, Allocation[] allocations, String quoteType, boolean acceptable)throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }

        String currency = (termsTrading)?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID, symbol, quoteType, side, amount, "1M", account, currency, null, null,
                null, null, null, parties, allocations);
        
        if(acceptable){
            Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
            assertNotNull("no acknowledgement was received for quote requests", ack);
            validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                    , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
        }
    }
    
    public void initiateRfsEvenSwap(String quoteRequestID, String symbol, String side, String amount)throws Exception
    {
        initiateRfsEvenSwap(quoteRequestID, symbol, side, amount, null);
    }
    
    public void initiateRfsEvenSwap(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker)throws Exception
    {
        initiateRfsEvenSwap(quoteRequestID, symbol, side, amount, routedTaker, false, null);
    }

    public void submitRfqQuoteRequestTopOfBookSWAP(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker,
            boolean termsTrading, Allocation[] allocations, String quoteType)throws Exception
    {
        String account = getPartyId();
        String currency = (termsTrading)?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID, symbol, quoteType, side, amount, "SP", account, currency,
                "1M", amount, null, null, null, null, allocations);
    }

    public void initiateRfsEvenSwap(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker,
            boolean termsTrading, Allocation[] allocations)throws Exception{
        initiateRfsEvenSwap(quoteRequestID, symbol, side, amount, routedTaker, termsTrading, allocations, null);
    }
    
    public void initiateRfsEvenSwap(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker, 
            boolean termsTrading, Allocation[] allocations, String quoteType)throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }

        String currency = (termsTrading)?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID, symbol, quoteType, side, amount, "SP", account, currency,
                "1M", amount, null, null, null, parties, allocations);

        Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
        assertNotNull("no acknowledgement was received for quote requests", ack);
        validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
        
        System.out.println("tag 56="+ack.getStringFieldValue(56));
        System.out.println("tag 297="+ack.getStringFieldValue(297));
        System.out.println("tag 131=" + ack.getStringFieldValue(131));
    }
    
    public void initiateRfsUnevenSwap(String quoteRequestID, String symbol, String side, String amount, String amount2, TakerTestSession routedTaker, 
            boolean termsTrading, Allocation[] allocations)throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }

        String currency = (termsTrading)?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "SP", account, currency,
                "1M", amount2, null, null, null, parties, allocations);

        Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
        assertNotNull("no acknowledgement was received for quote requests", ack);
        validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
    }
    
    public void initiateRfsNDFFwd(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker)throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }
        
        submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "1M", account, symbol.split("/")[0]
                , null, null, Constants.SECURITYTYPE_ForeignExchangeNDF, null, Constants.PRODUCT_Currency, parties, null);
        Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
        assertNotNull("no acknowledgement was received for quote requests", ack);
        validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
    }
    


    
    public void initiateRfsNDFSwap(String quoteRequestID, String symbol, String side, String amount, TakerTestSession routedTaker)throws Exception
    {       
        Party[] parties = null;
        String account = getPartyId();
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }
        
       submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "1W", account, symbol.split("/")[0]
               , "1M", amount, Constants.SECURITYTYPE_ForeignExchangeNDF, null, Constants.PRODUCT_Currency, parties,
               null);
       Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
       assertNotNull("no acknowledgement was received for quote requests", ack);
       validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
               , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
    }
    
    public void initiateRfsMTFSpot(String quoteRequestID, String symbol, String side,
            String amount, TakerTestSession routedTaker, boolean termsTrading, String venueType)throws Exception
    {
        initiateRfsMTF("spot", quoteRequestID, symbol, side, amount, routedTaker, termsTrading, venueType);
    }

    public void initiateRfsMTFSpotAlloc(String quoteRequestID, String symbol, String side,
            String amount, TakerTestSession routedTaker, boolean termsTrading, String venueType, Allocation[] allocations)throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();

        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }

        String currency = termsTrading?symbol.split("/")[1]:symbol.split("/")[0];
        submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "SP", account, currency
                , null, null, null, null, Constants.PRODUCT_Currency, parties, allocations, venueType);
    }

    public void initiateRfsMTFFwd(String quoteRequestID, String symbol, String side,
            String amount, TakerTestSession routedTaker, boolean termsTrading, String venueType)throws Exception
    {
        initiateRfsMTF("fwd", quoteRequestID, symbol, side, amount, routedTaker, termsTrading, venueType);
    }

    public void initiateRfsMTFSwap(String quoteRequestID, String symbol, String side, String amount,
            TakerTestSession routedTaker, boolean termsTrading, String venueType)throws Exception
    {
        initiateRfsMTF("swap", quoteRequestID, symbol, side, amount, routedTaker, termsTrading, venueType);
    }

    public void initiateRfsMTFNdf(String quoteRequestID, String symbol, String side,
            String amount, TakerTestSession routedTaker, boolean termsTrading, String venueType)throws Exception
    {
        initiateRfsMTF("ndf", quoteRequestID, symbol, side, amount, routedTaker, termsTrading, venueType);
    }

    public void initiateRfsMTF(String tradeType/*spot/fwd/swap/ndf*/,
            String quoteRequestID, String symbol, String side, String amount,
            TakerTestSession routedTaker, boolean termsTrading,
            String venueType) throws Exception
    {
        Party[] parties = null;
        String account = getPartyId();

        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
            account = routedTaker.getPartyId();
        }

        String currency = termsTrading?symbol.split("/")[1]:symbol.split("/")[0];

        switch (tradeType){
            case "spot":
                submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "SP", account, currency
                        , null, null, null, null, Constants.PRODUCT_Currency, parties, null, venueType);
                break;
            case "fwd":
                submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "1W", account, currency
                        , null, null, null, null, Constants.PRODUCT_Currency, parties, null, venueType);
                break;
            case "swap":
                submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "SP", account, currency
                        , "1W", amount, null, null, Constants.PRODUCT_Currency, parties, null, venueType);
                break;
            case "ndf":
                submitQuoteRequestRFQ(quoteRequestID, symbol, null, side, amount, "1W", account, currency
                        , null, null, Constants.SECURITYTYPE_ForeignExchangeNDF, null, Constants.PRODUCT_Currency,
                        parties, null, venueType);
                break;
            default:
                break;
        }

        Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
        if(ack!=null) {
            validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                    , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
            validateTag(Constants.TAGVenueType, venueType
                    , ack.getStringFieldValue(Constants.TAGVenueType));
        }
    }
    
    public Message initiateRfsLD(String symbol, String side, String amount, String makerPartyID) throws Exception
    {
       return initiateRfsLD(symbol, side, amount, makerPartyID, null, null);
    }
    
    
    public Message initiateRfsLD(String symbol, String side, String amount, String makerPartyID, String onBehalfOf, String account) throws Exception
    {
        String quoteRequestID = "testRfqLD-"+System.currentTimeMillis();
        
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 16);
        Calendar d = Calendar.getInstance();
        d.add(Calendar.MONTH, 1);
        d.add(Calendar.DATE, 1);

        if (c.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            c.add(Calendar.DATE, 2);
        }
        if (c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            c.add(Calendar.DATE, 1);
        }

        if (d.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            d.add(Calendar.DATE, 2);
        }
        if (d.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            d.add(Calendar.DATE, 1);
        }

        submitQuoteRequestLDRFQ(quoteRequestID, "1", symbol, Constants.PRODUCT_MoneyMarket, m_format.format(d.getTime()), "ACT/360",
                side, amount, m_format.format(c.getTime()), makerPartyID, onBehalfOf, account);
        
        //check holiday
        Message reject = getQuoteReqRejectMsg(3000);
        int retryTimes = 0;
        
        while(reject!=null && retryTimes < 10){
            String rejectReason = reject.getStringFieldValue(Constants.TAGText);
            
            if(rejectReason.startsWith("initiate rfq failed: startDateIsHoliday_tse")){
                c.add(Calendar.DATE, 1);
                submitQuoteRequestLDRFQ(quoteRequestID, "1", symbol, Constants.PRODUCT_MoneyMarket, m_format.format(d.getTime()), "ACT/360",
                        side, amount, m_format.format(c.getTime()), makerPartyID, onBehalfOf, account);
            }else if(rejectReason.startsWith("initiate rfq failed: endDateIsHoliday_tse")){
                d.add(Calendar.DATE, 1);
                submitQuoteRequestLDRFQ(quoteRequestID, "1", symbol, Constants.PRODUCT_MoneyMarket, m_format.format(d.getTime()), "ACT/360",
                        side, amount, m_format.format(c.getTime()), makerPartyID, onBehalfOf, account);
            }else{
                fail("QuoteRequest got rejected: "+rejectReason);
            }
            retryTimes++;
            reject = getQuoteReqRejectMsg(DEFAULT_WAIT_TIME);
        }
        
       Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
       assertNotNull("no acknowledgement was received for quote requests", ack);
       validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
               , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
       
       return ack;
    }
    
    
    public void initiateRfsMultiLeg(String quoteRequestID, String symbol, RFQLeg[] rfqLegs, TakerTestSession routedTaker)throws Exception
    {        
        Party[] parties = null;
        
        if(routedTaker!=null){
            parties = new Party[1];
            parties[0] = new Party(routedTaker.getUserName(), null, Constants.PARTYROLE_Client);
        }
        
        submitQuoteRequestRFQMultiLeg(quoteRequestID, symbol, rfqLegs, parties);

        Message ack = getQuoteAckMsg(DEFAULT_WAIT_TIME);
        assertNotNull("no acknowledgement was received for quote requests", ack);
        validateTag(Constants.TAGQuoteAckStatus, Constants.QUOTEACKSTATUS_Accepted
                , ack.getStringFieldValue(Constants.TAGQuoteAckStatus));
    }
    
    public void doAssertionCheckForQuoteRfqSpot(Message msg, Subscription sub, MakerTestSession maker, String quoteRequestId, 
            String bidSpotRate, String offerSpotRate, String midPx) throws Exception
    {
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
        
        if((!termsTrading && Constants.SIDE_Buy.equals(sub.side)) || 
        (termsTrading && Constants.SIDE_Sell.equals(sub.side))) {
            bidSpotRate = null;
        } else if((!termsTrading && Constants.SIDE_Sell.equals(sub.side)) || 
                (termsTrading && Constants.SIDE_Buy.equals(sub.side))) {
            offerSpotRate = null;
        }
        
        doAssertionCheckForQuote(msg, sub, maker, quoteRequestId, bidSpotRate, offerSpotRate, bidSpotRate,
                offerSpotRate,
                null, null, null, null, midPx, null, null, null);
    }
    
    public void doAssertionCheckForQuoteRfqFwd(Message msg, Subscription sub, MakerTestSession maker, String quoteRequestId, 
            String bidPx, String offerPx, String bidSpotRate, String offerSpotRate,
            String bidForwardPoints, String offerForwardPoints, String midPx) throws Exception
    {
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
        
        if((!termsTrading && Constants.SIDE_Buy.equals(sub.side)) || 
        (termsTrading && Constants.SIDE_Sell.equals(sub.side))) {
            bidPx = bidSpotRate = bidForwardPoints = null;
        } else if((!termsTrading && Constants.SIDE_Sell.equals(sub.side)) || 
                (termsTrading && Constants.SIDE_Buy.equals(sub.side))) {
            offerPx = offerSpotRate = offerForwardPoints = null;
        }
        
        doAssertionCheckForQuote(msg, sub, maker, quoteRequestId, bidPx, offerPx, bidSpotRate, 
                offerSpotRate, bidForwardPoints, offerForwardPoints, null, null, midPx, null, null, null);
    }
    
    public void doAssertionCheckForQuoteRfqSwap(Message msg, Subscription sub, MakerTestSession maker, String quoteRequestId, 
            String bidPx, String offerPx, String bidSpotRate, String offerSpotRate, String bidForwardPoints, String offerForwardPoints,
            String bidForwardPoints2, String offerForwardPoints2, String midPx, String midPx2, String bidPxFar, String offerPxFar) throws Exception
    {
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
        
        if((!termsTrading && Constants.SIDE_Buy.equals(sub.side)) || 
        (termsTrading && Constants.SIDE_Sell.equals(sub.side))) {
            bidPx = bidSpotRate = bidForwardPoints = offerForwardPoints2 = offerPxFar = null;
        } else if((!termsTrading && Constants.SIDE_Sell.equals(sub.side)) || 
                (termsTrading && Constants.SIDE_Buy.equals(sub.side))) {
            offerPx = offerSpotRate = offerForwardPoints = bidForwardPoints2 = bidPxFar = null;
        }
        
        doAssertionCheckForQuote(msg, sub, maker, quoteRequestId, bidPx, offerPx, bidSpotRate, 
                offerSpotRate, bidForwardPoints, offerForwardPoints, 
                bidForwardPoints2, offerForwardPoints2, midPx, midPx2, bidPxFar, offerPxFar);
    }
    
    
    private void doAssertionCheckForQuote(Message msg, Subscription sub, MakerTestSession maker, String quoteRequestId, 
            String bidPx, String offerPx, String bidSpotRate, String offerSpotRate,
            String bidForwardPoints, String offerForwardPoints, String bidForwardPoints2, String offerForwardPoints2,
            String midPx, String midPx2, String bidPxFar, String offerPxFar) throws Exception
    {
        assertNotNull("no quote submission msg was received", msg);
        
        validateTag(Constants.TAGQuoteReqID, quoteRequestId, msg.getStringFieldValue(Constants.TAGQuoteReqID));
        validateTagNotNull(Constants.TAGQuoteID, msg.getStringFieldValue(Constants.TAGQuoteID));
        validateTag(Constants.TAGNoPartyIDs, "1", msg.getStringFieldValue(Constants.TAGNoPartyIDs));
        IFixGroup[] parties = msg.getParser().getDynamicGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID);
//        validateTag(Constants.TAGPartyID, maker.getPartyId(), parties[0].getStringValFor(Constants.TAGiPartyID));
        validateTag(Constants.TAGPartyRole, "1", parties[0].getStringValFor(Constants.TAGiPartyRole));
        validateTag(Constants.TAGSymbol, sub.symbol, msg.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGProduct, sub.product, msg.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSecurityType, sub.securityType, msg.getStringFieldValue(Constants.TAGSecurityType));
        
        if(sub.instrumentParties!=null){
            validateTag(Constants.TAGNoInstrumentParties, "1", msg.getStringFieldValue(Constants.TAGNoInstrumentParties)); //Always 1
            IFixGroup[] instrumentPartyGrps = msg.getParser().
                    getDynamicGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID);
            assertNotNull("Error getting InstrumentParties component in Quote", instrumentPartyGrps);
            assertTrue(instrumentPartyGrps.length==Integer.valueOf(msg.getStringFieldValue(Constants.TAGNoInstrumentParties)));
            validateTag(Constants.TAGiInstrumentPartyID, sub.instrumentParties[0].instrumentPartyID
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyID));
            validateTag(Constants.TAGiInstrumentPartyIDSource, sub.instrumentParties[0].instrumentPartyIDSource
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyIDSource));
            validateTag(Constants.TAGiInstrumentPartyRole, sub.instrumentParties[0].instrumentPartyRole
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyRole));
        }
        
        validateTag(Constants.TAGSettlDate, sub.valueDate, msg.getStringFieldValue(Constants.TAGSettlDate));
        validateTag(Constants.TAGSettlDate2, sub.valueDate2, msg.getStringFieldValue(Constants.TAGSettlDate2));
        validatePrice(Constants.TAGBidPx, bidPx, msg.getStringFieldValue(Constants.TAGBidPx));
        validatePrice(Constants.TAGOfferPx, offerPx, msg.getStringFieldValue(Constants.TAGOfferPx));
        validatePrice(Constants.TAGBidSpotRate, bidSpotRate, msg.getStringFieldValue(Constants.TAGBidSpotRate));
        validatePrice(Constants.TAGOfferSpotRate, offerSpotRate, msg.getStringFieldValue(Constants.TAGOfferSpotRate));
        validatePrice(Constants.TAGBidForwardPoints, bidForwardPoints, msg.getStringFieldValue(Constants.TAGBidForwardPoints));
        validatePrice(Constants.TAGOfferForwardPoints, offerForwardPoints, msg.getStringFieldValue(Constants.TAGOfferForwardPoints));
        validatePrice(Constants.TAGBidForwardPoints2, bidForwardPoints2, msg.getStringFieldValue(Constants.TAGBidForwardPoints2));
        validatePrice(Constants.TAGOfferForwardPoints2, offerForwardPoints2, msg.getStringFieldValue(Constants.TAGOfferForwardPoints2));
        validatePrice(Constants.TAGMidPx, midPx, msg.getStringFieldValue(Constants.TAGMidPx));
        validatePrice(Constants.TAGMidPx2, midPx2, msg.getStringFieldValue(Constants.TAGMidPx2));
        validatePrice(Constants.TAGBidPxFar, bidPxFar, msg.getStringFieldValue(Constants.TAGBidPxFar));
        validatePrice(Constants.TAGOfferPxFar, offerPxFar, msg.getStringFieldValue(Constants.TAGOfferPxFar));
        validateTag(Constants.TAGFixingDate, sub.fixingDate, msg.getStringFieldValue(Constants.TAGFixingDate));
        validateTag(Constants.TAGFixingDate2, sub.fixingDate2, msg.getStringFieldValue(Constants.TAGFixingDate2));
    }
    
    public void doAssertionCheckForERAccepted(NewOrderSingle newOrder, Message acceptedER) throws Exception
    {
        assertNotNull("No ER(accepted) msg was received", acceptedER);
        
        String clOrdID = newOrder.getClOrdId();
        String symbol = newOrder.getSymbol();
        String product = newOrder.getProduct();
        String side = newOrder.getSide();
        String amount = newOrder.getOrderQty();
        String ordType = newOrder.getOrdType();
        String price = newOrder.getPrice();
        String currency = newOrder.getCurrency();
        String minQty = newOrder.getMinQty();
        
        doAssertionCheckForExecutionReport(acceptedER, null, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                null/*Parties*/, null, Constants.EXECTYPE_New/*execType*/,
                Constants.ORDSTATUS_New/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, symbol/*symbol*/,
                null/*symbolSfx*/, null/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/, ordType,
                price/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERAcceptedMidT(NewOrderSingle newOrder, Message acceptedER) throws Exception
    {
        assertNotNull("No ER(MidT-accepted) msg was received", acceptedER);
        
        String clOrdID = newOrder.getClOrdId();
        String symbol = newOrder.getSymbol();
        String symbolSfx = newOrder.getSymbolSfx();
        String product = newOrder.getProduct();
        String side = newOrder.getSide();
        String amount = newOrder.getOrderQty();
        String ordType = newOrder.getOrdType();
        String price = newOrder.getPrice();
        String currency = newOrder.getCurrency();
        String minQty = newOrder.getMinQty();
        
        doAssertionCheckForExecutionReport(acceptedER, null, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                null/*Parties*/, null, Constants.EXECTYPE_New/*execType*/,
                Constants.ORDSTATUS_New/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, symbol/*symbol*/,
                symbolSfx/*symbolSfx*/, null/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/, ordType, price/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, null/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, null/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
        
        //Additional validations for MidT
        validateTag(Constants.TAGExecTransType, this.getFixVersion().equals("4.2")?Constants.EXECTRANSTYPE_New:null, 
                acceptedER.getStringFieldValue(Constants.TAGExecTransType));
        validateTag(Constants.TAGAccount, this.getPartyId(), 
                acceptedER.getStringFieldValue(Constants.TAGAccount));
        validateTag(Constants.TAGMidMatchTriggerRate, newOrder.getMidMatchTriggerRate(), 
                acceptedER.getStringFieldValue(Constants.TAGMidMatchTriggerRate));
    }
    
    public void doAssertionCheckForERCancelledMidT(Message acceptedER, Message cancelledER, String cancelClOrdId) throws Exception
    {
        assertNotNull("No ER(MidT-cancelled) msg was received", cancelledER);
        
        String clOrdID = cancelClOrdId==null?acceptedER.getStringFieldValue(Constants.TAGClOrdID):cancelClOrdId;
        String origClOrdID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String product = acceptedER.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String ordType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String price = acceptedER.getStringFieldValue(Constants.TAGPrice);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        String minQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
        String execTransType = acceptedER.getStringFieldValue(Constants.TAGExecTransType);
        String account = acceptedER.getStringFieldValue(Constants.TAGAccount);
        String midMatchTriggerRate = acceptedER.getStringFieldValue(Constants.TAGMidMatchTriggerRate);
        
        doAssertionCheckForExecutionReport(cancelledER, null, clOrdID/*clOrdId*/, origClOrdID/*origClOrderId*/,
                null/*Parties*/, null, Constants.EXECTYPE_Cancelled/*execType*/,
                Constants.ORDSTATUS_Cancelled/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, symbol/*symbol*/,
                symbolSfx/*symbolSfx*/, null/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/, ordType, price/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, null/*LastQty*/, null/*LastPx*/,
                null/*Leaves Qty*/, "0"/*cum Qty*/, null/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
        
        //Additional validations for MidT
        validateTag(Constants.TAGExecTransType, execTransType, 
                cancelledER.getStringFieldValue(Constants.TAGExecTransType));
        validateTag(Constants.TAGAccount, account, 
                cancelledER.getStringFieldValue(Constants.TAGAccount));
        validateTag(Constants.TAGMidMatchTriggerRate, midMatchTriggerRate, 
                cancelledER.getStringFieldValue(Constants.TAGMidMatchTriggerRate));
    }
    
    public void doAssertionCheckForERReplacedMidT(NewOrderSingle newMidMatchOrder, Message acceptedER, Message replacedER) throws Exception
    {
        assertNotNull("No ER(MidT-replaced) msg was received", replacedER);
        
        String clOrdID = newMidMatchOrder.getClOrdId();
        String origClOrdID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String symbol = newMidMatchOrder.getSymbol();
        String symbolSfx = newMidMatchOrder.getSymbolSfx();
        String product = newMidMatchOrder.getProduct();
        String side = newMidMatchOrder.getSide();
        String amount = newMidMatchOrder.getOrderQty();
        String ordType = newMidMatchOrder.getOrdType();
        String price = newMidMatchOrder.getPrice();
        String currency = newMidMatchOrder.getCurrency();
        String minQty = newMidMatchOrder.getMinQty();
        
        doAssertionCheckForExecutionReport(replacedER, null, clOrdID/*clOrdId*/, origClOrdID/*origClOrderId*/,
                null/*Parties*/, null, Constants.EXECTYPE_Replaced/*execType*/,
                Constants.ORDSTATUS_Replaced/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, symbol/*symbol*/,
                symbolSfx/*symbolSfx*/, null/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/, ordType, price/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, null/*LastQty*/, null/*LastPx*/,
                null/*Leaves Qty*/, "0"/*cum Qty*/, null/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
        
        //Additional validations for MidT
        validateTag(Constants.TAGExecTransType, this.getFixVersion().equals("4.2")?Constants.EXECTRANSTYPE_New:null, 
                acceptedER.getStringFieldValue(Constants.TAGExecTransType));
        validateTag(Constants.TAGAccount, this.getPartyId(), 
                acceptedER.getStringFieldValue(Constants.TAGAccount));
        validateTag(Constants.TAGMidMatchTriggerRate, newMidMatchOrder.getMidMatchTriggerRate(), 
                acceptedER.getStringFieldValue(Constants.TAGMidMatchTriggerRate));
    }
    
    public void doAssertionCheckForERAcceptedRouting(NewOrderSingle newOrder, Message acceptedER,
            String routedParty, String routingUser) throws Exception
    {
        assertNotNull("No ER(accepted) msg was received", acceptedER);
        
        String clOrdID = newOrder.getClOrdId();
        String symbol = newOrder.getSymbol();
        String product = newOrder.getProduct();
        String side = newOrder.getSide();
        String amount = newOrder.getOrderQty();
        String ordType = newOrder.getOrdType();
        String price = newOrder.getPrice();
        String currency = newOrder.getCurrency();
        String minQty = newOrder.getMinQty();
        Party[] parties;
        
        if(routedParty!=null && routingUser!=null){
            parties = new Party[2];
            parties[0] = new Party(routedParty, null, Constants.PARTYROLE_Client);
            parties[1] = new Party(routingUser, null, Constants.PARTYROLE_OrderOriginationTrader);
        }else if(routedParty!=null){
            parties = new Party[1];
            parties[0] = new Party(routedParty, null, Constants.PARTYROLE_Client);
        }else if(routingUser!=null){
            parties = new Party[1];
            parties[0] = new Party(routingUser, null, Constants.PARTYROLE_OrderOriginationTrader);
        }else{
            parties=null;
        }
        
        doAssertionCheckForExecutionReport(acceptedER, null, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                parties/*Parties*/, null, Constants.EXECTYPE_New/*execType*/,
                Constants.ORDSTATUS_New/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, symbol/*symbol*/,
                null/*symbolSfx*/, null/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/, ordType,
                price/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERFullFilled(Message acceptedER, Message filledER, Message makerOrder, MakerTestSession maker) throws Exception
    {
        assertNotNull("No ER(filled) msg was received", filledER);
        
        String orderId = acceptedER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String execId = makerOrder.getStringFieldValue(Constants.TAGExecID);
        String execType = Constants.EXECTYPE_Trade;
        String ordStatus = Constants.ORDSTATUS_Filled;
        String SettlDate = makerOrder.getStringFieldValue(Constants.TAGSettlDate);
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = acceptedER.getStringFieldValue(Constants.TAGSecurityType);
        String product = makerOrder.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String minQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
        String orderType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String price = acceptedER.getStringFieldValue(Constants.TAGPrice);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        
        Party[] parties = {new Party(maker.getPartyId(), null, Constants.PARTYROLE_ExecutingFirm)};
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, clOrderID/*origClOrderId*/,
                parties, execId, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, price/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, amount/*LastQty*/,
                price/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, price/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERFullFilledWithSpread(Message acceptedER, Message filledER, Message makerOrder, MakerTestSession maker,
            double spread) throws Exception
    {
        assertNotNull("No ER(filled) msg was received", filledER);
        
        String orderId = acceptedER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String execId = makerOrder.getStringFieldValue(Constants.TAGExecID);
        String execType = Constants.EXECTYPE_Trade;
        String ordStatus = Constants.ORDSTATUS_Filled;
        String SettlDate = makerOrder.getStringFieldValue(Constants.TAGSettlDate);
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = acceptedER.getStringFieldValue(Constants.TAGSecurityType);
        String product = makerOrder.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String orderType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String price = acceptedER.getStringFieldValue(Constants.TAGPrice);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        
        double lastPx = Double.valueOf(makerOrder.getStringFieldValue(Constants.TAGPrice));
        
        if(side.equals(Constants.SIDE_Buy)) {
            lastPx = lastPx + spread;
        } else {
            lastPx = lastPx - spread;
        }
        
        Party[] parties = {new Party(maker.getPartyId(), null, Constants.PARTYROLE_ExecutingFirm)};
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, clOrderID/*origClOrderId*/,
                parties, execId, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/,
                side/*side*/, amount/*orderQty*/,
                orderType, price/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/,
                amount/*LastQty*/,
                Double.toString(lastPx)/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, Double.toString(lastPx)/*AvgPx*/,
                amount/*min Qty*/,
                null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERMidTT0Filled(Message acceptedER, Message filledER, boolean partialFilled, String partialFilledAmt) throws Exception
    {
        assertNotNull("No ER(T0-filled) msg was received", filledER);
        
        String orderId = acceptedER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String origClOrdID = acceptedER.getStringFieldValue(Constants.TAGOrigClOrdID);
        String execType = Constants.EXECTYPE_MidMatchT0Trade;
        String ordStatus = partialFilled? Constants.ORDSTATUS_PartiallyFilled:Constants.ORDSTATUS_Filled;
        String SettlDate = null;
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = acceptedER.getStringFieldValue(Constants.TAGSecurityType);
        String product = acceptedER.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String minQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
        String orderType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        String account = acceptedER.getStringFieldValue(Constants.TAGAccount);
        String lastQty = partialFilled? partialFilledAmt:amount;
        
        //Party[] parties = {new Party(maker.getPartyId(), null, Constants.PARTYROLE_ExecutingFirm)};
        Party[] parties = null;
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, origClOrdID/*origClOrderId*/,
                parties, null /*execId*/, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, null/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, lastQty/*LastQty*/,
                null/*LastPx*/, "0"/*Leaves Qty*/, lastQty/*cum Qty*/, null/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
        
        
        //Additional validations for MidT
//        validateTag(Constants.TAGNoContraBrokers, "1", filledER.getStringFieldValue(Constants.TAGNoContraBrokers));
//        IFixGroup[] brokers = filledER.getParser().getDynamicGroupDataFor(Constants.TAGiNoContraBrokers, Constants.TAGiContraBroker);
//        assertEquals("Incorrect number of brokers in T0 ER", 1, brokers.length);
        
        validateTag(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_Status, filledER.getStringFieldValue(Constants.TAGExecTransType));
        validateTag(Constants.TAGAccount, account, filledER.getStringFieldValue(Constants.TAGAccount));
        validateTagNotNull(Constants.TAGLastPx, filledER.getStringFieldValue(Constants.TAGLastPx));
        validateTagNotNull(Constants.TAGTradeDate, filledER.getStringFieldValue(Constants.TAGTradeDate));
        validateTagNotNull(Constants.TAGYield, filledER.getStringFieldValue(Constants.TAGYield));
    }
    
    public void doAssertionCheckForERMidTTnFilled(Message t0filledER, Message filledER, boolean partialFilled, String partialFilledAmt) throws Exception
    {
        assertNotNull("No ER(Tn-filled) msg was received", filledER);
        
        String orderId = t0filledER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = t0filledER.getStringFieldValue(Constants.TAGClOrdID);
        String origClOrdID = t0filledER.getStringFieldValue(Constants.TAGOrigClOrdID);
        String execType = Constants.EXECTYPE_MidMatchTNTrade;
        String ordStatus = partialFilled? Constants.ORDSTATUS_PartiallyFilled:Constants.ORDSTATUS_Filled;
        String SettlDate = t0filledER.getStringFieldValue(Constants.TAGFutSettDate);
        String symbol = t0filledER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = t0filledER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = t0filledER.getStringFieldValue(Constants.TAGSecurityType);
        String product = t0filledER.getStringFieldValue(Constants.TAGProduct);
        String side = t0filledER.getStringFieldValue(Constants.TAGSide);
        String amount = t0filledER.getStringFieldValue(Constants.TAGOrderQty);
        String minQty = t0filledER.getStringFieldValue(Constants.TAGMinQty);
        String orderType = t0filledER.getStringFieldValue(Constants.TAGOrdType);
        String currency = t0filledER.getStringFieldValue(Constants.TAGCurrency);
        String account = t0filledER.getStringFieldValue(Constants.TAGAccount);
        String tradeDate = t0filledER.getStringFieldValue(Constants.TAGTradeDate);
        String initialMatchRate = t0filledER.getStringFieldValue(Constants.TAGLastPx);
        String execRefId = t0filledER.getStringFieldValue(Constants.TAGExecID);
        
        //Party[] parties = {new Party(maker.getPartyId(), null, Constants.PARTYROLE_ExecutingFirm)};
        Party[] parties = null;
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, origClOrdID/*origClOrderId*/,
                parties, null /*execId*/, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, null/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, amount/*LastQty*/,
                null/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, null/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
        
        
        //Additional validations for MidT
//        validateTag(Constants.TAGNoContraBrokers, "1", filledER.getStringFieldValue(Constants.TAGNoContraBrokers));
//        IFixGroup[] brokers = filledER.getParser().getDynamicGroupDataFor(Constants.TAGiNoContraBrokers, Constants.TAGiContraBroker);
//        assertEquals("Incorrect number of brokers in T0 ER", 1, brokers.length);
        
        validateTag(Constants.TAGExecTransType, Constants.EXECTRANSTYPE_Status, filledER.getStringFieldValue(Constants.TAGExecTransType));
        validateTag(Constants.TAGAccount, account, filledER.getStringFieldValue(Constants.TAGAccount));
        validateTagNotNull(Constants.TAGLastPx, filledER.getStringFieldValue(Constants.TAGLastPx));
        validateTag(Constants.TAGTradeDate, tradeDate, filledER.getStringFieldValue(Constants.TAGTradeDate));
        validateTagNotNull(Constants.TAGYield, filledER.getStringFieldValue(Constants.TAGYield));
        validateTag(Constants.TAGInitialMatchRate, initialMatchRate,
                filledER.getStringFieldValue(Constants.TAGInitialMatchRate));
        validateTagNotNull(Constants.TAGInitialMatchTime, filledER.getStringFieldValue(Constants.TAGInitialMatchTime));
        validateTag(Constants.TAGExecRefID, execRefId, filledER.getStringFieldValue(Constants.TAGExecRefID));
    }
    
    public void doAssertionCheckForEROrderStatus(Message lastER, Message statusER, Message makerOrder) throws Exception
    {
        assertNotNull("No ER(status) msg was received", statusER);
        
        String orderId = lastER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = lastER.getStringFieldValue(Constants.TAGOrigClOrdID);
        String execId = (makerOrder==null)?null:makerOrder.getStringFieldValue(Constants.TAGExecID);
        String execType = Constants.EXECTYPE_OrderStatus;
        String ordStatus = lastER.getStringFieldValue(Constants.TAGOrdStatus);
        String SettlDate = null/*makerOrder.getStringFieldValue(Constants.TAGSettlDate)*/;//TODO
        String symbol = lastER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = lastER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = lastER.getStringFieldValue(Constants.TAGSecurityType);
        String product = (makerOrder==null)?Constants.PRODUCT_Currency:makerOrder.getStringFieldValue(Constants.TAGProduct);
        String side = lastER.getStringFieldValue(Constants.TAGSide);
        String amount = lastER.getStringFieldValue(Constants.TAGOrderQty);
        String orderType = lastER.getStringFieldValue(Constants.TAGOrdType);
        String price = lastER.getStringFieldValue(Constants.TAGPrice);
        String currency = lastER.getStringFieldValue(Constants.TAGCurrency);
        String leavesQty = lastER.getStringFieldValue(Constants.TAGLeavesQty);
        String cumQty = lastER.getStringFieldValue(Constants.TAGCumQty);
        
        if(ordStatus.equals(Constants.ORDSTATUS_Cancelled)) {
            leavesQty = amount;
        }
        
        Party[] parties = {new Party(this.getUserName(), null, Constants.PARTYROLE_Client)};
                
        doAssertionCheckForExecutionReport(statusER, orderId, clOrderID/*clOrdId*/, null/*origClOrderId*/,
                parties, execId, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, price/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, "0"/*LastQty*/,
                price/*LastPx*/, leavesQty/*Leaves Qty*/, cumQty/*cum Qty*/, price/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERPartialFilled(Message acceptedER, Message filledER, Message makerOrder, MakerTestSession maker) throws Exception
    {
        assertNotNull("No ER(filled) msg was received", filledER);
        
        String orderId = acceptedER.getStringFieldValue(Constants.TAGOrderID);
        String clOrderID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String execId = makerOrder.getStringFieldValue(Constants.TAGExecID);
        String execType = Constants.EXECTYPE_Trade;
        String ordStatus = Constants.ORDSTATUS_PartiallyFilled;
        String SettlDate = makerOrder.getStringFieldValue(Constants.TAGSettlDate);
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = acceptedER.getStringFieldValue(Constants.TAGSecurityType);
        String product = makerOrder.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String minQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
        String lastQty = makerOrder.getStringFieldValue(Constants.TAGOrderQty);
        String orderType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String price = acceptedER.getStringFieldValue(Constants.TAGPrice);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        
        Party[] parties = {new Party(maker.getPartyId(), null, Constants.PARTYROLE_ExecutingFirm)};
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, clOrderID/*origClOrderId*/,
                parties, execId, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, SettlDate/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, price/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, lastQty/*LastQty*/,
                price/*LastPx*/, lastQty/*Leaves Qty*/, lastQty/*cum Qty*/, price/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, null/*text*/);
    }
    
    public void doAssertionCheckForERCancelled(Message acceptedER, Message filledER, String clOrderID, String cumQty) throws Exception
    {
        assertNotNull("No ER(filled) msg was received", filledER);
        
        String orderId = acceptedER.getStringFieldValue(Constants.TAGOrderID);
        //String clOrderID = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String origClOrderId = acceptedER.getStringFieldValue(Constants.TAGClOrdID);
        String execType = Constants.EXECTYPE_Cancelled;
        String ordStatus = Constants.ORDSTATUS_Cancelled;
        String symbol = acceptedER.getStringFieldValue(Constants.TAGSymbol);
        String symbolSfx = acceptedER.getStringFieldValue(Constants.TAGSymbolSfx);
        String securityType = acceptedER.getStringFieldValue(Constants.TAGSecurityType);
        String product = acceptedER.getStringFieldValue(Constants.TAGProduct);
        String side = acceptedER.getStringFieldValue(Constants.TAGSide);
        String amount = acceptedER.getStringFieldValue(Constants.TAGOrderQty);
        String orderType = acceptedER.getStringFieldValue(Constants.TAGOrdType);
        String price = acceptedER.getStringFieldValue(Constants.TAGPrice);
        String currency = acceptedER.getStringFieldValue(Constants.TAGCurrency);
        String minQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
                
        doAssertionCheckForExecutionReport(filledER, orderId, clOrderID/*clOrdId*/, origClOrderId/*origClOrderId*/,
                null/*Parties*/, null, execType/*execType*/,
                ordStatus/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/,
                symbol/*symbol*/, symbolSfx/*symbolSfx*/, securityType/*securityType*/, product/*Product*/, side/*side*/, amount/*orderQty*/,
                orderType, price/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, currency/*currency*/, "0"/*LastQty*/,
                null/*LastPx*/, "0"/*Leaves Qty*/, cumQty/*cum Qty*/, price/*AvgPx*/, minQty/*min Qty*/, null/*stopSide*/, "user cancel");
    }
    
    public void doAssertionCheckForERCancelled(Message acceptedER, Message filledER, String clOrderID) throws Exception
    {
        String cumQty = acceptedER.getStringFieldValue(Constants.TAGMinQty);
        doAssertionCheckForERCancelled(acceptedER, filledER, clOrderID, cumQty);
    }
    
    private void doAssertionCheckForExecutionReport(Message msg, String orderId, String clOrderID,
            String origClOrderID, Party[] parties, String execId, String
            execType, String orderStatus, String OrdRejReason, String SettlDate, String symbol, String symbolSfx, String securityType,
            String product, String sellBuySide, String orderAmt, String orderType, String price, String stopPx, String trailBy,
            String maxSlippage, String currenecy, String lastQty, String lastPx, String leavesQty, String cumQty,
            String AvgPx, String minQty, String stopSide, String text) throws Exception
    {        
        if(orderId!=null) {
            validateTag(Constants.TAGOrderID, orderId, msg.getStringFieldValue(Constants.TAGOrderID));
        } else {
            validateTagNotNull(Constants.TAGOrderID, msg.getStringFieldValue(Constants.TAGOrderID));
        }
        
        
        validateTag(Constants.TAGClOrdID, clOrderID, msg.getStringFieldValue(Constants.TAGClOrdID));
        validateTag(Constants.TAGOrigClOrdID, origClOrderID, msg.getStringFieldValue(Constants.TAGOrigClOrdID));
        
//        int validatedParties = 0;
//
//        if(parties!=null){
//        
//            validateTag(Constants.TAGNoPartyIDs, Integer.toString(parties.length), msg.getStringFieldValue(Constants.TAGNoPartyIDs));
//            
//            IFixGroup[] partyGroups = msg.getParser().getDynamicGroupDataFor(Constants.TAGiNoPartyIDs, Constants.TAGiPartyID);
//            
//            for(IFixGroup partyGroup:partyGroups){
//                for(Party party:parties){
//                    if(party.partyRole.equals(partyGroup.getStringValFor(Constants.TAGiPartyRole))){
//                        validateTag(Constants.TAGPartyID, party.partyID, partyGroup.getStringValFor(Constants.TAGiPartyID));
//                        validatedParties++;
//                    }
//                }
//            }
//            assertTrue("Party validation failed: not all the parties are validated", validatedParties==parties.length);
//        }
        
        if(execId!=null) {
            validateTag(Constants.TAGExecID, execId, msg.getStringFieldValue(Constants.TAGExecID));
        } else {
            validateTagNotNull(Constants.TAGExecID, msg.getStringFieldValue(Constants.TAGExecID));
        }
        
        validateTag(Constants.TAGExecType, execType, msg.getStringFieldValue(Constants.TAGExecType));
        validateTag(Constants.TAGOrdStatus, orderStatus, msg.getStringFieldValue(Constants.TAGOrdStatus));

        if(OrdRejReason!=null) {
            validateTag(Constants.TAGOrdRejReason, OrdRejReason, msg.getStringFieldValue(Constants.TAGOrdRejReason));
        }

        if(SettlDate!=null) {
            validateTag(Constants.TAGSettlDate, SettlDate, msg.getStringFieldValue(Constants.TAGSettlDate));
        }

        validateTag(Constants.TAGSymbol, symbol, msg.getStringFieldValue(Constants.TAGSymbol));
        if(symbolSfx!=null) {
            validateTag(Constants.TAGSymbolSfx, symbolSfx, msg.getStringFieldValue(Constants.TAGSymbolSfx));
        }
        if(securityType!=null) {
            validateTag(Constants.TAGSecurityType, securityType, msg.getStringFieldValue(Constants.TAGSecurityType));
        }
        
        validateTag(Constants.TAGProduct, product, msg.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSide, sellBuySide, msg.getStringFieldValue(Constants.TAGSide));
        validateTag(Constants.TAGOrderQty, orderAmt, msg.getStringFieldValue(Constants.TAGOrderQty));
        validateTag(Constants.TAGOrdType, orderType, msg.getStringFieldValue(Constants.TAGOrdType));

        if(price!=null){
            validatePrice(Constants.TAGPrice, price, msg.getStringFieldValue(Constants.TAGPrice));
        }

        validateTag(Constants.TAGCurrency, currenecy, msg.getStringFieldValue(Constants.TAGCurrency));
        validateTag(Constants.TAGLastQty, lastQty, msg.getStringFieldValue(Constants.TAGLastQty));
        validateTag(Constants.TAGLeavesQty, leavesQty, msg.getStringFieldValue(Constants.TAGLeavesQty));
        //validateTag(Constants.TAGCumQty, cumQty, msg.getStringFieldValue(Constants.TAGCumQty));//TODO
        validateTagNotNull(Constants.TAGCumQty, msg.getStringFieldValue(Constants.TAGCumQty));

        if(lastPx!=null){
            validatePrice(Constants.TAGLastPx, lastPx, msg.getStringFieldValue(Constants.TAGLastPx));
        }
        if(AvgPx!=null){
            validatePrice(Constants.TAGAvgPx, AvgPx, msg.getStringFieldValue(Constants.TAGAvgPx));
        }
        
        validateTag(Constants.TAGMinQty, minQty, msg.getStringFieldValue(Constants.TAGMinQty));
        
        if(text!=null) {
            validateTag(Constants.TAGText, text, msg.getStringFieldValue(Constants.TAGText));
        }
        
    }
    
    
    public void doAssertionCheckForERFullFilledRFQ(Subscription sub, Message quote, Message filledER, 
            Message makerOrder, MakerTestSession maker, String account, Allocation[] allocations, boolean hubTrade, double priceImprovement) throws Exception
    {
        assertNotNull("No ER(filled) msg was received", filledER);
        
        String orderId = sub.requestId;
        String clOrderID = quote.getStringFieldValue(Constants.TAGQuoteReqID);
        String execType = Constants.EXECTYPE_Filled;
        String ordStatus = Constants.ORDSTATUS_Filled;
        String SettlDate = sub.valueDate;
        String symbol = sub.symbol;
        String securityType = sub.securityType;
        String product = sub.product;
        String side = makerOrder.getStringFieldValue(Constants.TAGSide);
        String amount = makerOrder.getStringFieldValue(Constants.TAGOrderQty);
        //String price = makerOrder.getStringFieldValue(Constants.TAGPrice);
        String venueType = makerOrder.getStringFieldValue(Constants.TAGVenueType);
        
        String price = (this.submittedPricesMap.get(sub.requestId)==null)?
                makerOrder.getStringFieldValue(Constants.TAGPrice):
                    this.submittedPricesMap.get(sub.requestId);                
        String finalPrice = String.format("%.5f", Double.valueOf(price) + priceImprovement); //with price improvements

        String currency = makerOrder.getStringFieldValue(Constants.TAGCurrency);
        String quoteId = quote.getStringFieldValue(Constants.TAGQuoteID);
        
        boolean termsTrading = (sub.currency.equals(sub.symbol.split("/")[1]));
            
        String lastSpotRate = ((!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)))?
                quote.getStringFieldValue(Constants.TAGOfferSpotRate):
                quote.getStringFieldValue(Constants.TAGBidSpotRate);
        String finalSpotRate = String.format("%.5f", Double.valueOf(lastSpotRate) + priceImprovement); //with price improvements
                
        String lastForwardPoints = ((!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)))?
                quote.getStringFieldValue(Constants.TAGOfferForwardPoints):
            quote.getStringFieldValue(Constants.TAGBidForwardPoints);
        
        lastForwardPoints = (lastForwardPoints==null)?"0.0000":lastForwardPoints;
        account = (account==null)?this.getPartyId():account;
        
        String settlDate2 = sub.valueDate2;
        String orderAmt2 = makerOrder.getStringFieldValue(Constants.TAGOrderQty2);
        String lastForwardPoints2 = ((!termsTrading && side.equals(Constants.SIDE_Buy)) || (termsTrading && side.equals(Constants.SIDE_Sell)))?
                quote.getStringFieldValue(Constants.TAGBidForwardPoints2):
            quote.getStringFieldValue(Constants.TAGOfferForwardPoints2);
        String price2 = makerOrder.getStringFieldValue(Constants.TAGPrice2);
        String midPx = quote.getStringFieldValue(Constants.TAGMidPx);
        String midPx2 = quote.getStringFieldValue(Constants.TAGMidPx2);
        
        String fixingDate = sub.fixingDate;
        String fixingDate2 = sub.fixingDate2;
                
        doAssertionCheckForExecutionReportRFQ(filledER, orderId, clOrderID,
                "1"/*NoPartyIds*/, maker.getPartyId()/*PartyID*/, "1"/*PartyRole*/, execType,
                ordStatus, null/*OrdRejReason*/, account, SettlDate, symbol, securityType, product, side, amount,
                finalPrice, currency, finalSpotRate, lastForwardPoints, "0"/*Leaves Qty*/, amount/*cum Qty*/, quoteId,
                settlDate2, orderAmt2, lastForwardPoints2, price2, midPx, midPx2, fixingDate, fixingDate2, allocations, hubTrade, sub.instrumentParties, venueType);
    }
    
    
    private void doAssertionCheckForExecutionReportRFQ(Message msg, String orderId, String clOrderID,
            String NoPartyIds, String PartyId, String PartyRole, String execType, 
            String orderStatus, String OrdRejReason, String account, String SettlDate, String symbol, String securityType,
            String product, String sellBuySide, String orderAmt, String price, String currenecy, String lastSpotRate, String lastForwardPoints,
            String leavesQty, String cumQty, String quoteId, String settlDate2, String orderAmt2, String lastForwardPoints2,
            String price2, String midPx, String midPx2, String fixingDate, String fixingDate2, Allocation[] allocations, boolean hubTrade,
            InstrumentParty[] instParties, String venueType) throws Exception
    {
        validateTag(Constants.TAGOrderID, orderId, msg.getStringFieldValue(Constants.TAGOrderID));
        validateTag(Constants.TAGClOrdID, clOrderID, msg.getStringFieldValue(Constants.TAGClOrdID));

        if(NoPartyIds!=null){ //TODO
        
            validateTagNotNull(Constants.TAGNoPartyIDs, msg.getStringFieldValue(Constants.TAGNoPartyIDs));
        /*
            if(PartyId!=null){
                System.out.println(136);
                assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyID,
                        PartyId, Constants.MSGExecutionReport));
            }
            
            if(PartyRole!=null){
                System.out.println(137);
                assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyRole,
                        PartyRole, Constants.MSGExecutionReport));
            }*/
        }
        
        validateTagNotNull(Constants.TAGExecID, msg.getStringFieldValue(Constants.TAGExecID));
        
      //DEV-30518 ("execId"+ExecID was set in MakerTestSession.orderReplyFilledRFQ)
        String bankExecId = hubTrade?null:"execId"+msg.getStringFieldValue(Constants.TAGExecID);
        validateTag(Constants.TAGSecondaryExecID, bankExecId, msg.getStringFieldValue(Constants.TAGSecondaryExecID)); 

        validateTag(Constants.TAGExecType, execType, msg.getStringFieldValue(Constants.TAGExecType));
        validateTag(Constants.TAGOrdStatus, orderStatus, msg.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGOrdRejReason, OrdRejReason, msg.getStringFieldValue(Constants.TAGOrdRejReason));
        validateTag(Constants.TAGAccount, account, msg.getStringFieldValue(Constants.TAGAccount));
        validateTag(Constants.TAGSettlDate, SettlDate, msg.getStringFieldValue(Constants.TAGSettlDate));
        validateTag(Constants.TAGSymbol, symbol, msg.getStringFieldValue(Constants.TAGSymbol));
        validateTag(Constants.TAGSecurityType, securityType, msg.getStringFieldValue(Constants.TAGSecurityType));
        
        if(instParties!=null){
            validateTag(Constants.TAGNoInstrumentParties, "1", msg.getStringFieldValue(Constants.TAGNoInstrumentParties)); //Always 1
            IFixGroup[] instrumentPartyGrps = msg.getParser().
                    getDynamicGroupDataFor(Constants.TAGiNoInstrumentParties, Constants.TAGiInstrumentPartyID);
            assertNotNull("Error getting InstrumentParties component in Quote", instrumentPartyGrps);
            assertTrue(instrumentPartyGrps.length==Integer.valueOf(msg.getStringFieldValue(Constants.TAGNoInstrumentParties)));
            validateTag(Constants.TAGiInstrumentPartyID, instParties[0].instrumentPartyID
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyID));
            validateTag(Constants.TAGiInstrumentPartyIDSource, instParties[0].instrumentPartyIDSource
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyIDSource));
            validateTag(Constants.TAGiInstrumentPartyRole, instParties[0].instrumentPartyRole
                    ,instrumentPartyGrps[0].getStringValFor(Constants.TAGiInstrumentPartyRole));
        }
        
        validateTag(Constants.TAGProduct, product, msg.getStringFieldValue(Constants.TAGProduct));
        validateTag(Constants.TAGSide, sellBuySide, msg.getStringFieldValue(Constants.TAGSide));
        validateTag(Constants.TAGOrderQty, orderAmt, msg.getStringFieldValue(Constants.TAGOrderQty));
        validateTag(Constants.TAGPrice, Double.valueOf(price), Double.valueOf(msg.getStringFieldValue(Constants.TAGPrice)));
        validateTag(Constants.TAGCurrency, currenecy, msg.getStringFieldValue(Constants.TAGCurrency));
        validatePrice(Constants.TAGLastSpotRate, lastSpotRate, msg.getStringFieldValue(Constants.TAGLastSpotRate));
        validateTag(Constants.TAGLastForwardPoints, lastForwardPoints, msg.getStringFieldValue(Constants.TAGLastForwardPoints));
        validateTag(Constants.TAGLeavesQty, leavesQty, msg.getStringFieldValue(Constants.TAGLeavesQty));
        validateTag(Constants.TAGCumQty, cumQty, msg.getStringFieldValue(Constants.TAGCumQty));
        validateTag(Constants.TAGAvgPx, Double.valueOf(price), Double.valueOf(msg.getStringFieldValue(Constants.TAGAvgPx)));
        validateTagNotNull(Constants.TAGTradeDate, msg.getStringFieldValue(Constants.TAGTradeDate));
        validateTagNotNull(Constants.TAGTransactTime, msg.getStringFieldValue(Constants.TAGTransactTime)); 
        boolean termsTrading = (currenecy.equals(symbol.split("/")[1]));
        double settlCurrAmt = (termsTrading)? 
                (new BigDecimal(orderAmt).divide(new BigDecimal(price), 2, BigDecimal.ROUND_HALF_UP).doubleValue()):
            (Double.valueOf(price) * Double.valueOf(orderAmt));
        validateTag(Constants.TAGSettlCurrAmt, settlCurrAmt, Double.valueOf(
                msg.getStringFieldValue(Constants.TAGSettlCurrAmt)));
        validateTag(Constants.TAGQuoteID, quoteId, msg.getStringFieldValue(Constants.TAGQuoteID));
        
        //Tags for RFQ Swap
        validateTag(Constants.TAGSettlDate2, settlDate2, msg.getStringFieldValue(Constants.TAGSettlDate2));
        validateTag(Constants.TAGOrderQty2, orderAmt2, msg.getStringFieldValue(Constants.TAGOrderQty2));
        validateTag(Constants.TAGLastForwardPoints2, lastForwardPoints2, msg.getStringFieldValue(Constants.TAGLastForwardPoints2));
        validateTag(Constants.TAGPrice2, price2, msg.getStringFieldValue(Constants.TAGPrice2));
        if(price2!=null && orderAmt2!=null){
        double settlCurrAmt2 = (termsTrading)? 
                (new BigDecimal(orderAmt2).divide(new BigDecimal(price2), 2, BigDecimal.ROUND_HALF_UP).doubleValue()):
            (Double.valueOf(price2) * Double.valueOf(orderAmt2));
        validateTag(Constants.TAGSettlCurrAmt2, settlCurrAmt2, Double.valueOf(msg.getStringFieldValue(Constants.TAGSettlCurrAmt2)));
        }
        //comment out for now, Dev32611 is on it. once it's fixed, uncomment it.
        //validateTag(Constants.TAGMidPx, midPx, msg.getStringFieldValue(Constants.TAGMidPx));
        //validateTag(Constants.TAGMidPx2, midPx2, msg.getStringFieldValue(Constants.TAGMidPx2));
        
        validateTag(Constants.TAGFixingDate, fixingDate, msg.getStringFieldValue(Constants.TAGFixingDate));
        validateTag(Constants.TAGFixingDate2, fixingDate2, msg.getStringFieldValue(Constants.TAGFixingDate2));
        
        boolean isSwap = (price2!=null);
        
        boolean isMTF = msg.getStringFieldValue(Constants.TAGVenueType) != null &&
                msg.getStringFieldValue(Constants.TAGVenueType).equals("M");
        if(securityType.equals(Constants.SECURITYTYPE_ForeignExchangeNDF) && !hubTrade && !isMTF){
            
            int checkedRegulatoryTradeIDs = 0;
            boolean hasNearLegID = false;
            boolean hasFarLegID = false;
            
            IFixGroup[] regulatoryTradeIDs = msg.getParser()
                    .getDynamicGroupDataFor(Constants.TAGiNoRegulatoryTradeIDs, Constants.TAGiRegulatoryTradeID);
            
            if(isSwap){
                validateTag(Constants.TAGNoRegulatoryTradeIDs, "2", msg.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
                assertTrue("Unexpected regulatory Trade ID size in maker received order", regulatoryTradeIDs.length==2);
            }else{
                validateTag(Constants.TAGNoRegulatoryTradeIDs, "1", msg.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
                assertTrue("Unexpected regulatory Trade ID size in maker received order", regulatoryTradeIDs.length==1);
            }
            
            for(IFixGroup regulatoryTradeID:regulatoryTradeIDs){
                if(regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDType).equals("1")){
                    checkedRegulatoryTradeIDs++;
                    hasNearLegID = true;
                    validateTagNotNull(Constants.TAGiRegulatoryTradeID, regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeID));
                    validateTag(Constants.TAGiRegulatoryTradeIDSource, "1010000276", regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDSource));
                }else if(regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDType).equals("3")){
                    checkedRegulatoryTradeIDs++;
                    hasFarLegID = true;
                    validateTagNotNull(Constants.TAGiRegulatoryTradeID, regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeID));
                    validateTag(Constants.TAGiRegulatoryTradeIDSource, "1010000276", regulatoryTradeID.getStringValFor(Constants.TAGiRegulatoryTradeIDSource));
                }
            }
            if(isSwap){
                assertTrue("Missing partyID", checkedRegulatoryTradeIDs==2);
                assertTrue("Missing regulatoryTradeID for Far Leg", hasFarLegID);
            } else {
                assertTrue("Missing partyID", checkedRegulatoryTradeIDs==1);
            }
            assertTrue("Missing regulatoryTradeID for Near Leg", hasNearLegID);
        } else {
            validateTag(Constants.TAGNoRegulatoryTradeIDs, null, msg.getStringFieldValue(Constants.TAGNoRegulatoryTradeIDs));
        }
        
        //VenueType=R only appears in Maker's NewOrderSingle
        if(venueType!=null && !venueType.equals(Constants.VENUETYPE_RegisteredMarket)){
            validateTag(Constants.TAGVenueType, venueType, msg.getStringFieldValue(Constants.TAGVenueType));
        }else{
            validateTag(Constants.TAGVenueType, null, msg.getStringFieldValue(Constants.TAGVenueType));
        }
        
        
        //Allocation validation
        if(allocations!=null){
            validateTag(Constants.TAGiNoAllocs, Integer.toString(allocations.length), 
                    msg.getStringFieldValue(Constants.TAGiNoAllocs));
            
            IFixGroup[] allocsInER = msg.getParser()
                    .getDynamicGroupDataFor(Constants.TAGiNoAllocs, Constants.TAGiAllocAccount);
            assertNotNull("Error in allocation component in ExecutionReport", allocsInER);
            assertTrue(allocations.length==allocsInER.length);
            int checkedAllocs = 0;
            for(IFixGroup allocER:allocsInER){
                for(Allocation submittedAlloc:allocations){
                    if(allocER.getStringValFor(Constants.TAGiIndividualAllocID).equals(submittedAlloc.individualAllocID)){
                        validateTag(Constants.TAGiAllocAccount, submittedAlloc.allocAccount, 
                                allocER.getStringValFor(Constants.TAGiAllocAccount));
                        validateTag(Constants.TAGAllocQty, Double.valueOf(submittedAlloc.allocQty), 
                                Double.valueOf(allocER.getStringValFor(Constants.TAGiAllocQty)));
                        if(isSwap) {
                            validateTag(Constants.TAGSettlCurrAmt, Double.valueOf(submittedAlloc.settlCurrAmt), 
                                    Double.valueOf(allocER.getStringValFor(Constants.TAGiSettlCurrAmt)));
                        }
                        
                        if(submittedAlloc.nestedPartyID!=null){
                            IFixGroup[] nestedPartyIDs = allocER.getDynamicSubGroupDataFor(Constants.TAGiNoNestedPartyIDs, Constants.TAGiNestedPartyID);
                            assertNotNull("Error in NestedPartyID component in ExecutionReport", nestedPartyIDs);
                            assertTrue("Unexpected NoNestedPartyIDs", nestedPartyIDs.length == 1);
                            validateTag(Constants.TAGiNoNestedPartyIDs, "1", allocER.getStringValFor(Constants.TAGiNoNestedPartyIDs));
                            validateTag(Constants.TAGiNestedPartyID, submittedAlloc.nestedPartyID, nestedPartyIDs[0].getStringValFor(Constants.TAGiNestedPartyID));
                            validateTag(Constants.TAGiNestedPartyIDSource, "N", nestedPartyIDs[0].getStringValFor(Constants.TAGiNestedPartyIDSource));
                            validateTag(Constants.TAGiNestedPartyRole, "4", nestedPartyIDs[0].getStringValFor(Constants.TAGiNestedPartyRole));
                        }
                        
                        if(instParties!=null){
                            
                            boolean hasNearLegUsiUtiCode = false;
                            boolean hasFarLegUsiUtiCode = false;
                            
                            String noAllocRegulatoryTradeIDs = (isSwap)?"2":"1";
                            validateTag(Constants.TAGiNoAllocRegulatoryTradeIDs, noAllocRegulatoryTradeIDs,
                                    allocER.getStringValFor(Constants.TAGiNoAllocRegulatoryTradeIDs));

                            IFixGroup[] allocRegTradeIDs = allocER.getDynamicSubGroupDataFor(Constants.TAGiNoAllocRegulatoryTradeIDs, 
                                    Constants.TAGiAllocRegulatoryTradeID);
                            assertNotNull("Error getting AllocRegulatoryTradeIDs in NewOrderSingle",allocRegTradeIDs);
                            assertTrue("Incorrect number of AllocRegulatoryTradeIDs",allocRegTradeIDs.length==Integer.valueOf(noAllocRegulatoryTradeIDs));
                            
                            for(IFixGroup allocRegTradeID:allocRegTradeIDs){
                                validateTagNotNull(Constants.TAGiAllocRegulatoryTradeID, 
                                        allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeID));
                                validateTag(Constants.TAGiAllocRegulatoryTradeIDSource, "1010000276",
                                        allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDSource));
                                validateTagNotNull(Constants.TAGiAllocRegulatoryTradeIDType, 
                                        allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType));
                                if(allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType).equals("1")) {
                                    hasNearLegUsiUtiCode = true;
                                } else if(allocRegTradeID.getStringValFor(Constants.TAGiAllocRegulatoryTradeIDType).equals("3")) {
                                    hasFarLegUsiUtiCode = true;
                                }
                            }
                            
                            assertTrue("Missing near leg Usi/Uti code", hasNearLegUsiUtiCode);
                            if(isSwap) {
                                assertTrue("Missing far leg Usi/Uti code", hasFarLegUsiUtiCode);
                            }

                        }
                        
                        
                        
                        checkedAllocs++;
                    }
                }
            }
            assertTrue("Error in allocation detail in NewOrderSingle", checkedAllocs==allocations.length);
        }
    }
    
    public void doAssertionCheckForMDR(String mdrId, Message marketData, String bidPx, String offerPx) throws Exception{
        
        assertNotNull("No Price received", marketData);
        
        IFixGroup[] prices = marketData.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        assertTrue("No price in MarketData",prices.length>0);
        
        boolean hasBidPrice = false;
        boolean hasOfferPrice = false;
        
        for(IFixGroup price:prices){
            
            if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)) {
                continue;
            }
            
            if(price.getStringValFor(Constants.TAGiMDEntryType).equals("0")){ //Bid
                validateTag(Constants.TAGiMDEntryPx, bidPx, price.getStringValFor(Constants.TAGiMDEntryPx)); //1.2732+0.0006
                hasBidPrice = true;
            }
            if(price.getStringValFor(Constants.TAGiMDEntryType).equals("1")){ //Offer
                validateTag(Constants.TAGiMDEntryPx, offerPx, price.getStringValFor(Constants.TAGiMDEntryPx)); //1.2737+0.0008
                hasOfferPrice = true;
            }
        }
        
        if(prices.length<2){
            marketData = getPriceUpdateMsg(mdrId, 5000);
            assertNotNull("No Price received", marketData);
            
            IFixGroup[] prices2 = marketData.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
            assertTrue("No price in MarketData",prices2.length>0);
            
            for(IFixGroup price:prices2){
                if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)) {
                    continue;
                }
                
                if(price.getStringValFor(Constants.TAGiMDEntryType).equals("0")){ //Bid
                    validateTag(Constants.TAGiMDEntryPx, bidPx, price.getStringValFor(Constants.TAGiMDEntryPx)); //1.2732+0.0006
                    hasBidPrice = true;
                }
                if(price.getStringValFor(Constants.TAGiMDEntryType).equals("1")){ //Offer
                    validateTag(Constants.TAGiMDEntryPx, offerPx, price.getStringValFor(Constants.TAGiMDEntryPx)); //1.2737+0.0008
                    hasOfferPrice = true;
                }
            }
        }
        
        assertTrue("Didn't receive bid price", hasBidPrice);
        assertTrue("Didn't receive offer price", hasOfferPrice);
    }
    
    public void doAssertionCheckForMDRCancelPrice(String mdrId, Message marketData) throws Exception{
        
        assertNotNull("No MarketDataIncrementalRefresh received", marketData);
        
        IFixGroup[] prices = marketData.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        assertTrue("No price in MarketData",prices.length>0);
        
        boolean hasBidPriceCancel = false;
        boolean hasOfferPriceCancel = false;
        
        for(IFixGroup price:prices){
            if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)
                    && price.getStringValFor(Constants.TAGiMDEntryType).equals("0")) { //Bid
                hasBidPriceCancel = true;
            }else if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)
                    && price.getStringValFor(Constants.TAGiMDEntryType).equals("1")) { //Offer
                hasOfferPriceCancel = true;
            }
        }
        
        if(prices.length<2){
            marketData = getPriceUpdateMsg(mdrId, 5000);
            assertNotNull("No Price received", marketData);
            
            IFixGroup[] prices2 = marketData.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
            assertTrue("No price in MarketData",prices2.length>0);
            
            for(IFixGroup price:prices2){
                if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)
                        && price.getStringValFor(Constants.TAGiMDEntryType).equals("0")) { //Bid
                    hasBidPriceCancel = true;
                }else if(price.getStringValFor(Constants.TAGiMDUpdateAction).equals(Constants.MDUPDATEACTION_Delete)
                        && price.getStringValFor(Constants.TAGiMDEntryType).equals("1")) { //Offer
                    hasOfferPriceCancel = true;
                }
            }
        }
        
        assertTrue("Didn't receive bid price cancel", hasBidPriceCancel);
        assertTrue("Didn't receive offer price cancel", hasOfferPriceCancel);
    }
    
    
    public void doAssertionCheckForTickerMDIR(Message ticker, String symbol, String symbolSfx, 
            String mdEntryPx, String currency, String tickerType) throws Exception{
        
        assertNotNull("No Ticker received", ticker);
        
        assertEquals("1", ticker.getStringFieldValue(Constants.TAGNoMDEntries));
        IFixGroup[] MDEntries = ticker.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        assertTrue("Incorrect number of MDEntries in Ticker MDIR", MDEntries.length==1);
        
        validateTag(Constants.TAGiMDUpdateAction, Constants.MDUPDATEACTION_New, MDEntries[0].getStringValFor(Constants.TAGiMDUpdateAction));
        validateTag(Constants.TAGiMDEntryType, Constants.MDENTRYTYPE_Trade, MDEntries[0].getStringValFor(Constants.TAGiMDEntryType));
        validateTag(Constants.TAGiSymbol, symbol, MDEntries[0].getStringValFor(Constants.TAGiSymbol));
        validateTag(Constants.TAGiSymbolSfx, symbolSfx, MDEntries[0].getStringValFor(Constants.TAGiSymbolSfx));
        validateTag(Constants.TAGiMDEntryPx, mdEntryPx, MDEntries[0].getStringValFor(Constants.TAGiMDEntryPx));
        validateTag(Constants.TAGiCurrency, currency, MDEntries[0].getStringValFor(Constants.TAGiCurrency));
        validateTag(FixTagConstants.TAGMDTickerType, tickerType,
                MDEntries[0].getStringValFor(FixTagConstants.TAGMDTickerType));
        validateTagNotNull(Constants.TAGiTransactTime, MDEntries[0].getStringValFor(Constants.TAGiTransactTime));
    }
    
    public void doAssertionCheckForMDIR(Message mdir, String mdEntryType, String symbol, 
            String mdEntryPx, String mdEntrySize) throws Exception{
        
        assertNotNull("No Ticker received", mdir);
        
        assertEquals("1", mdir.getStringFieldValue(Constants.TAGNoMDEntries));
        IFixGroup[] MDEntries = mdir.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        assertTrue("Incorrect number of MDEntries in Ticker MDIR", MDEntries.length == 1);
        
        validateTag(Constants.TAGiMDUpdateAction, Constants.MDUPDATEACTION_New, MDEntries[0].getStringValFor(Constants.TAGiMDUpdateAction));
        validateTag(Constants.TAGiMDEntryType, mdEntryType, MDEntries[0].getStringValFor(Constants.TAGiMDEntryType));
        validateTagNotNull(Constants.TAGiMDEntryID, MDEntries[0].getStringValFor(Constants.TAGiMDEntryID));
        validateTag(Constants.TAGiSymbol, symbol, MDEntries[0].getStringValFor(Constants.TAGiSymbol));
        validateTag(Constants.TAGiMDEntryOriginator, "NA", MDEntries[0].getStringValFor(Constants.TAGiMDEntryOriginator));
        validateTag(Constants.TAGiMDEntryPx, mdEntryPx, MDEntries[0].getStringValFor(Constants.TAGiMDEntryPx));
        validateTag(Constants.TAGiMDEntrySize, mdEntrySize, MDEntries[0].getStringValFor(Constants.TAGiMDEntrySize));
    }
    
    public void doAssertionCheckForListStatus(Message listStatus, int noOrders) throws Exception{
        
        assertNotNull("taker didnt received ListStatus", listStatus);
        
        validateTagNotNull(Constants.TAGListID, listStatus.getStringFieldValue(Constants.TAGListID));
        validateTag(Constants.TAGListStatusType, Constants.LISTSTATUSTYPE_RESPONSE, listStatus.getStringFieldValue(
                Constants.TAGListStatusType));
        validateTag(Constants.TAGNoRpts, "1", listStatus.getStringFieldValue(Constants.TAGNoRpts));
        validateTag(Constants.TAGListOrderStatus, Constants.LISTORDERSTATUS_INBIDDINGSTATUS,
                listStatus.getStringFieldValue(Constants.TAGListOrderStatus));
        validateTag(Constants.TAGRptSeq, "1", listStatus.getStringFieldValue(Constants.TAGRptSeq));
        validateTagNotNull(Constants.TAGTransactTime, listStatus.getStringFieldValue(Constants.TAGTransactTime));
        validateTag(Constants.TAGTotNoOrders, Integer.toString(noOrders), listStatus.getStringFieldValue(
                Constants.TAGTotNoOrders));
        validateTag(Constants.TAGNoOrders, Integer.toString(noOrders), listStatus.getStringFieldValue(
                Constants.TAGNoOrders));
        
        if(noOrders>0){
            IFixGroup[] orders = listStatus.getParser().getDynamicGroupDataFor(Constants.TAGiNoOrders, Constants.TAGiClOrdID);
            assertNotNull("There is no orders in ListStatus", orders);
            assertEquals("Incorrect number of orders in ListStatus", noOrders, orders.length);
            for(IFixGroup order:orders){
                validateTagNotNull(Constants.TAGiClOrdID, order.getStringValFor(Constants.TAGiClOrdID));
                validateTagNotNull(Constants.TAGiCumQty, order.getStringValFor(Constants.TAGiCumQty));
                validateTagNotNull(Constants.TAGiOrdStatus, order.getStringValFor(Constants.TAGiOrdStatus));
                validateTagNotNull(Constants.TAGiLeavesQty, order.getStringValFor(Constants.TAGiLeavesQty));
                validateTagNotNull(Constants.TAGiCxlQty, order.getStringValFor(Constants.TAGiCxlQty));
                //validateTagNotNull(Constants.TAGiTimeInForce, order.getStringValFor(Constants.TAGiTimeInForce)); //TODO
                validateTagNotNull(Constants.TAGiOrderID, order.getStringValFor(Constants.TAGiOrderID));
                validateTagNotNull(Constants.TAGiSymbol, order.getStringValFor(Constants.TAGiSymbol));
                validateTagNotNull(Constants.TAGiSide, order.getStringValFor(Constants.TAGiSide));
            }
        }
    }
    
    public void validateMarketData(MDEntry entry, String bidPx, String offerPx) throws Exception{
        
        boolean gotBidPrice = false;
        boolean gotOfferPrice = false;
        
        assertNotNull("taker didnt get any MarketData", entry);
        
        while(entry!=null){
            String mdEntryType = entry.getMDEntryType();
            assertNotNull("No MDEntryType in MDEntry", mdEntryType);
            if(mdEntryType.equals(Constants.MDENTRYTYPE_Bid)){
                validateTag(Constants.TAGMDEntryPx, bidPx, entry.getMDEntryPx());
                gotBidPrice = true;
            }else if(mdEntryType.equals(Constants.MDENTRYTYPE_Offer)){
                validateTag(Constants.TAGMDEntryPx, offerPx, entry.getMDEntryPx());
                gotOfferPrice = true;
            }
            if(gotBidPrice && gotOfferPrice){
                break;
            }
            entry = this.getMDEntryFromQueue(1000);
        }
        
        assertEquals(bidPx!=null, gotBidPrice);
        assertEquals(offerPx!=null, gotOfferPrice);
    }
    
    
    public void validateMarketDataCancel(boolean cancelBid, boolean cancelOffer) throws Exception{
        
        MDEntry entry = this.getMDEntryFromQueue(3000);
        assertNotNull("taker didnt get MD for price cancel", entry);
        
        boolean gotBidCancel = false;
        boolean gotOfferCancel = false;
        
        while(entry!=null){
            String mdEntryType = entry.getMDEntryType();
            assertNotNull("No MDEntryType in MDEntry", mdEntryType);
            if(mdEntryType.equals(Constants.MDENTRYTYPE_Bid)){
                validateTag(Constants.TAGMDUpdateAction, Constants.MDUPDATEACTION_Delete, entry.getMDUpdateAction());
                gotBidCancel = true;
            }else if(mdEntryType.equals(Constants.MDENTRYTYPE_Offer)){
                validateTag(Constants.TAGMDUpdateAction, Constants.MDUPDATEACTION_Delete, entry.getMDUpdateAction());
                gotOfferCancel = true;
            }
            if(gotBidCancel && gotOfferCancel){
                break;
            }
            entry = this.getMDEntryFromQueue(1000);
        }
        
        assertEquals(gotBidCancel, cancelBid);
        assertEquals(gotOfferCancel, cancelOffer);
    }
    
    
    private void getMDEntryFromMarketData(Message message) throws Exception{
        
        int noMDEntries = message.getParser().getIntValFor(FixTagConstants.TAGNoMDEntries);
        IFixGroup[] mdEntries = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        
        assertNotNull("Error getting mdEntry from market data", mdEntries);
        assertEquals("Incorrect number of mdEntry in market data", noMDEntries, mdEntries.length);
        
        for(IFixGroup mdEntryGroup: mdEntries){
            
            MDEntry mdEntry = new MDEntry();
            
            mdEntry.setMDUpdateAction(mdEntryGroup.getStringValFor(Constants.TAGiMDUpdateAction));
            mdEntry.setDeleteReason(mdEntryGroup.getStringValFor(Constants.TAGiDeleteReason));
            mdEntry.setMDEntryType(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryType));
            mdEntry.setMDEntryID(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryID));
            mdEntry.setSymbol(mdEntryGroup.getStringValFor(Constants.TAGiSymbol));
            mdEntry.setSymbolSfx(mdEntryGroup.getStringValFor(Constants.TAGiSymbolSfx));
            mdEntry.setSecurityType(mdEntryGroup.getStringValFor(Constants.TAGiSecurityType));
            mdEntry.setMDEntryOriginator(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryOriginator));
            mdEntry.setMDEntryPx(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryPx));
            mdEntry.setCurrency(mdEntryGroup.getStringValFor(Constants.TAGiCurrency));
            mdEntry.setMDEntrySize(mdEntryGroup.getStringValFor(Constants.TAGiMDEntrySize));
            mdEntry.setMinQty(mdEntryGroup.getStringValFor(Constants.TAGiMinQty));
            mdEntry.setNumberOfOrders(mdEntryGroup.getStringValFor(Constants.TAGiNumberOfOrders));
            mdEntry.setText(mdEntryGroup.getStringValFor(Constants.TAGiText));
            mdEntry.setMDQuoteType(mdEntryGroup.getStringValFor(Constants.TAGiMDQuoteType));

            mdEntryQueue.add(mdEntry);
            
            String indicativeRate = (mdEntry.getMDQuoteType()!=null && mdEntry.getMDQuoteType().equals("0"))?"(Indicative)":"";
            
            if(mdEntry.getMDUpdateAction()!=null && mdEntry.getMDUpdateAction().equals(Constants.MDUPDATEACTION_New)){
                System.out.println("Price Update"+indicativeRate+": "+mdEntry.getSymbol()+", entryID="+mdEntry.getMDEntryID()+", price="+mdEntry.getMDEntryPx());
            }else if(mdEntry.getMDUpdateAction()!=null && mdEntry.getMDUpdateAction().equals(Constants.MDUPDATEACTION_Delete)){
                System.out.println("Price Delete"+indicativeRate+": "+mdEntry.getSymbol()+", entryID="+mdEntry.getMDEntryID());
            }
        }
    }
    
    private void getMDEntryFromMarketDataForSecurityID(Message message) throws Exception{
        
        int noMDEntries = message.getParser().getIntValFor(FixTagConstants.TAGNoMDEntries);
        IFixGroup[] mdEntries = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        
        assertNotNull("Error getting mdEntry from market data", mdEntries);
        assertEquals("Incorrect number of mdEntry in market data", noMDEntries, mdEntries.length);
        assertEquals("Number of mdEntry in market data for SecurityID should be 1", 1, mdEntries.length);
        
        for(IFixGroup mdEntryGroup: mdEntries){
            
            MDEntryForSecurityID mdEntry = new MDEntryForSecurityID();
            
            mdEntry.setMdReqId(message.getStringFieldValue(Constants.TAGMDReqID));
            
            //required tags
            mdEntry.setMDUpdateAction(mdEntryGroup.getStringValFor(Constants.TAGiMDUpdateAction));
            mdEntry.setMDEntryType(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryType));
            mdEntry.setSymbol(mdEntryGroup.getStringValFor(Constants.TAGiSymbol));
            mdEntry.setSymbolSfx(mdEntryGroup.getStringValFor(Constants.TAGiSymbolSfx));
            mdEntry.setSecurityID(mdEntryGroup.getStringValFor(Constants.TAGiSecurityID));
            mdEntry.setSecurityIDSource(mdEntryGroup.getStringValFor(Constants.TAGiSecurityIDSource));
            mdEntry.setProduct(mdEntryGroup.getStringValFor(Constants.TAGiProduct));
            mdEntry.setSecurityType(mdEntryGroup.getStringValFor(Constants.TAGiSecurityType));
            mdEntry.setMaturityDate(mdEntryGroup.getStringValFor(Constants.TAGiMaturityDate));
            mdEntry.setIssueDate(mdEntryGroup.getStringValFor(Constants.TAGiIssueDate));
            mdEntry.setCouponRate(mdEntryGroup.getStringValFor(Constants.TAGiCouponRate));
            mdEntry.setDatedDate(mdEntryGroup.getStringValFor(Constants.TAGiDatedDate));
            mdEntry.setInterestAccrualDate(mdEntryGroup.getStringValFor(Constants.TAGiInterestAccrualDate));
            
            //non-required tags. Only sent for SecurityIDs from pricing file
            mdEntry.setDate(mdEntryGroup.getStringValFor(Constants.TAGiTradeDate));
            mdEntry.setFairCouponRate(mdEntryGroup.getStringValFor(Constants.TAGiFairCouponRate));
            mdEntry.setFirstTradeDate(mdEntryGroup.getStringValFor(Constants.TAGiFirstTradeDate));
            mdEntry.setLegRepurchaseRate(mdEntryGroup.getStringValFor(Constants.TAGiLegRepurchaseRate));
            mdEntry.setNextFixingDate(mdEntryGroup.getStringValFor(Constants.TAGiNextFixingDate));
            mdEntry.setFixedNPV(mdEntryGroup.getStringValFor(Constants.TAGiFixedNPV));
            mdEntry.setFloatNPV(mdEntryGroup.getStringValFor(Constants.TAGiFloatNPV));
            mdEntry.setNPV(mdEntryGroup.getStringValFor(Constants.TAGiNPV));
            mdEntry.setAccruedCoupons(mdEntryGroup.getStringValFor(Constants.TAGiAccruedCoupons));
            mdEntry.setDailyIncrementalErisPAI(mdEntryGroup.getStringValFor(Constants.TAGiDailyIncrementalErisPAI));
            mdEntry.setErisPai(mdEntryGroup.getStringValFor(Constants.TAGiErisPAI));
            mdEntry.setSettlementPrice(mdEntryGroup.getStringValFor(Constants.TAGiSettlementPrice));
            mdEntry.setFedFundsRate(mdEntryGroup.getStringValFor(Constants.TAGiFedFundsRate));
            mdEntry.setPriorSettlementPrice(mdEntryGroup.getStringValFor(Constants.TAGiPriorSettlementPrice));
            mdEntry.setFactor(mdEntryGroup.getStringValFor(Constants.TAGiFactor));
            mdEntry.setErisPAIDate(mdEntryGroup.getStringValFor(Constants.TAGiErisPAIDate));
            mdEntry.setFixedPayment(mdEntryGroup.getStringValFor(Constants.TAGiFixedPayment));
            mdEntry.setFloatingPayment(mdEntryGroup.getStringValFor(Constants.TAGiFloatingNPV));
            mdEntry.setNextFixedPaymentDate(mdEntryGroup.getStringValFor(Constants.TAGiNextFixedPaymentDate));
            mdEntry.setNextFixedPaymentAmount(mdEntryGroup.getStringValFor(Constants.TAGiNextFixedPaymentAmount));
            mdEntry.setLegIssueDate(mdEntryGroup.getStringValFor(Constants.TAGiLegIssueDate));
            mdEntry.setNextFloatingPaymentAmount(mdEntryGroup.getStringValFor(Constants.TAGiNextFloatingPaymentAmount));
            mdEntry.setPreviousSettlementDate(mdEntryGroup.getStringValFor(Constants.TAGiPreviousSettlementDate));
            mdEntry.setPreviousErisPAI(mdEntryGroup.getStringValFor(Constants.TAGiPreviousErisPAI));
            mdEntry.setFedFundsDate(mdEntryGroup.getStringValFor(Constants.TAGiFedFundsDate));
            mdEntry.setAccrualDays(mdEntryGroup.getStringValFor(Constants.TAGiAccrualDays));
            mdEntry.setNominal(mdEntryGroup.getStringValFor(Constants.TAGiNominal));
            mdEntry.setLegCreditRating(mdEntryGroup.getStringValFor(Constants.TAGiLegCreditRating));
            mdEntry.setLegContractMultiplier(mdEntryGroup.getStringValFor(Constants.TAGiLegContractMultiplier));
            mdEntry.setNextFloatingPaymentDate(mdEntryGroup.getStringValFor(Constants.TAGiNextFloatingPaymentDate));
            mdEntry.setSymbolTplus1(mdEntryGroup.getStringValFor(Constants.TAGiSymbolTplus1));
            mdEntry.setSymbolSfxTplus1(mdEntryGroup.getStringValFor(Constants.TAGiSymbolSfxTplus1));
            mdEntry.setOpenInterest(mdEntryGroup.getStringValFor(Constants.TAGiOpenInterest));
            mdEntry.setPV01(mdEntryGroup.getStringValFor(Constants.TAGiPV01));
            mdEntry.setShortName(mdEntryGroup.getStringValFor(Constants.TAGiShortName));
            mdEntry.setDV01(mdEntryGroup.getStringValFor(Constants.TAGiDV01));
            mdEntry.setFinalSettlementPrice(mdEntryGroup.getStringValFor(Constants.TAGiFinalSettlementPrice));
            mdEntry.setFinalSettlementNPV(mdEntryGroup.getStringValFor(Constants.TAGiFinalSettlementNPV));
            
            mdEntryQueue.add(mdEntry);
        }
    }
    
    private void getMDEntryFromMarketDataForIOI(Message message) throws Exception{
        
        int noMDEntries = message.getParser().getIntValFor(FixTagConstants.TAGNoMDEntries);
        IFixGroup[] mdEntries = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        
        assertNotNull("Error getting mdEntry from market data", mdEntries);
        assertEquals("Incorrect number of mdEntry in market data", noMDEntries, mdEntries.length);
        
        for(IFixGroup mdEntryGroup: mdEntries){
            
            MDEntryForIOI mdEntry = new MDEntryForIOI();
            
            mdEntry.setMdReqId(message.getStringFieldValue(Constants.TAGMDReqID));
            
            //required tags
            mdEntry.setMDUpdateAction(mdEntryGroup.getStringValFor(Constants.TAGiMDUpdateAction));
            mdEntry.setMDEntryType(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryType));
            mdEntry.setSymbol(mdEntryGroup.getStringValFor(Constants.TAGiSymbol));
            mdEntry.setSymbolSfx(mdEntryGroup.getStringValFor(Constants.TAGiSymbolSfx));
            mdEntry.setSecurityID(mdEntryGroup.getStringValFor(Constants.TAGiSecurityID));
            mdEntry.setSecurityIDSource(mdEntryGroup.getStringValFor(Constants.TAGiSecurityIDSource));
            mdEntry.setProduct(mdEntryGroup.getStringValFor(Constants.TAGiProduct));
            mdEntry.setSecurityType(mdEntryGroup.getStringValFor(Constants.TAGiSecurityType));
            mdEntry.setMaturityDate(mdEntryGroup.getStringValFor(Constants.TAGiMaturityDate));
            mdEntry.setIssueDate(mdEntryGroup.getStringValFor(Constants.TAGiIssueDate));
            mdEntry.setCouponRate(mdEntryGroup.getStringValFor(Constants.TAGiCouponRate));
            mdEntry.setDatedDate(mdEntryGroup.getStringValFor(Constants.TAGiDatedDate));
            mdEntry.setInterestAccrualDate(mdEntryGroup.getStringValFor(Constants.TAGiInterestAccrualDate));
            mdEntry.setMDEntrySize(mdEntryGroup.getStringValFor(Constants.TAGiMDEntrySize));
            
            mdEntryQueue.add(mdEntry);
        }
    }
    
    private void getMDEntryFromMarketDataForTicker(Message message) throws Exception{
        
        int noMDEntries = message.getParser().getIntValFor(FixTagConstants.TAGNoMDEntries);
        IFixGroup[] mdEntries = message.getParser().getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        
        assertNotNull("Error getting mdEntry from market data", mdEntries);
        assertEquals("Incorrect number of mdEntry in market data", noMDEntries, mdEntries.length);
        
        for(IFixGroup mdEntryGroup: mdEntries){
            
            MDEntryForTicker mdEntry = new MDEntryForTicker();
            
            mdEntry.setMdReqId(message.getStringFieldValue(Constants.TAGMDReqID));
            
            //required tags
            mdEntry.setMDUpdateAction(mdEntryGroup.getStringValFor(Constants.TAGiMDUpdateAction));
            mdEntry.setMDEntryType(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryType));
            mdEntry.setSymbol(mdEntryGroup.getStringValFor(Constants.TAGiSymbol));
            mdEntry.setSymbolSfx(mdEntryGroup.getStringValFor(Constants.TAGiSymbolSfx));
            mdEntry.setSecurityID(mdEntryGroup.getStringValFor(Constants.TAGiSecurityID));
            mdEntry.setSecurityIDSource(mdEntryGroup.getStringValFor(Constants.TAGiSecurityIDSource));
            mdEntry.setProduct(mdEntryGroup.getStringValFor(Constants.TAGiProduct));
            mdEntry.setSecurityType(mdEntryGroup.getStringValFor(Constants.TAGiSecurityType));
            mdEntry.setMaturityDate(mdEntryGroup.getStringValFor(Constants.TAGiMaturityDate));
            mdEntry.setIssueDate(mdEntryGroup.getStringValFor(Constants.TAGiIssueDate));
            mdEntry.setCouponRate(mdEntryGroup.getStringValFor(Constants.TAGiCouponRate));
            mdEntry.setDatedDate(mdEntryGroup.getStringValFor(Constants.TAGiDatedDate));
            mdEntry.setInterestAccrualDate(mdEntryGroup.getStringValFor(Constants.TAGiInterestAccrualDate));
            mdEntry.setMDEntryPx(mdEntryGroup.getStringValFor(Constants.TAGiMDEntryPx));
            mdEntry.setTransacTime(mdEntryGroup.getStringValFor(Constants.TAGiTransactTime));
            mdEntry.setMDEntrySize(mdEntryGroup.getStringValFor(Constants.TAGiMDEntrySize));
            mdEntry.setLastParPrice(mdEntryGroup.getStringValFor(Constants.TAGiLastParPx));
            
            mdEntryQueue.add(mdEntry);
        }
    }

    @Override
    public void onFixMessage(Message message) throws Exception {
        String type = message.getStringFieldValue(Constants.TAGMsgType);

//        //venueType should be absent in all messages(Non-MTF)
//        boolean isMtfVenueTypePresent = message.toString().indexOf("1430=M")>0?true:false;
//        assertFalse("the message contains 1430=M the message is:"+message.toString(), isMtfVenueTypePresent);

        if (type.equals(Constants.MSGExecutionReport)) {
            handleExecutionReport(message);
        } else if (type.equals(Constants.MSGOrderCancelReject)) {
            handleOrderCancelReject(message);
        } else if (type.equals(Constants.MSGBusinessMessageReject)) {
            handleBusinessMessageReject(message);
        } else if (type.equals(Constants.MSGMarketDataRequestReject)) {
            handleMarketDataRequestReject(message);
        } else if (type.equals(Constants.MSGMarketDataIncrementalRefresh)) {
            handleMarketData(message);
        } else if (type.equals(Constants.MSGSecurityList)) {
            handleSecurityList(message);
        } else if (type.equals(Constants.MSGSecurityStatus)) {
            handleSecurityStatus(message);
        } else if (type.equals(Constants.MSGListStatus)) {
            handleListStatus(message);
        } else if (type.equals(Constants.MSGQuote)) {
            handleQuote(message);
        } else if (type.equals(Constants.MSGReject)) {
            handleRejectMessage(message);
        } else if (type.equals(Constants.MSGRequestForPositionsAck)) {
            handlePositionRejectMessage(message);
        } else if (type.equals(Constants.MSGPositionReport)) {
            handlePositionReport(message);
        } else if (type.equals(Constants.MSGCollateralReport)) {
            handleCollateralReport(message);
        } else if (type.equals(Constants.MSGCollateralResponse)) {
            handleCollateralResponse(message);
        } else if (type.equals(Constants.MSGQuoteAcknowledgement)) {
            handleQuoteAck(message);
        } else if (type.equals(Constants.MSGMassQuoteAcknowledgement)) {
            handleQuoteAck(message);
        } else if (type.equals(Constants.MSGQuoteRequestReject)) {
            handleQuoteReqReject(message);
        }  else if (type.equals(Constants.MSGQuoteCancel)) {
            handleQuoteCancel(message);
        } else if (type.equals(MsgUserPropertyReport)) {
            handleUserPropertyReport(message);
        } else if (type.equals(Constants.MSGSecurityDefinition)) {
            handleSecurityDefinition(message);
        } else if (type.equals(Constants.MSGPartyDetailListReport)) {
            handlePartyDetailListReport(message);
        } else if (type.equals(Constants.MSGServerNotificationSubscriptionReject)) {
            handleServerNotificationSubscriptionReject(message);
        } else if (type.equals("PU")) {
            handlePeggedOrderUpdate(message);
        } else if (type.equals(Constants.MSGUserResponse)) {
            handleUserResponse(message);
        } else if (type.equals(Constants.MSGPriceAlertConfirm)){
            handlePriceAlertConfirm(message);
        } else if (type.equals(Constants.MSGPriceAlertUpdated)){
            handlePriceAlertUpdated(message);
        } else if (type.equals(Constants.MSGOrderMassCancelReport)){
            handleOrderMassCancelReportMessage(message);
        } else {
            System.err.println("unhandle FIX message from SERVER");
        }
    }

    private void handlePriceAlertConfirm(Message message) {
        priceAlertConfirmQueue.add(message);
    }
    
    private void handlePriceAlertUpdated(Message message) {
        priceAlertUpdatedQueue.add(message);
    }
    
    private void handleServerNotificationSubscriptionReject(Message message) {
        serverNotificationSubscriptionRejectQueue.add(message);
    }

    private void handlePeggedOrderUpdate(Message message) throws Exception {
        msgQ.add(message);
        puQueue.add(message);
    }

    private void handleUserResponse(Message message) throws Exception {
        userResponseQueue.add(message);
        msgQ.add(message);
    }

    private void handleMarketData(Message message) throws Exception {
        QFMsgParser parser = message.getParser();
        String requestId = message.getStringFieldValue(Constants.TAGMDReqID);
        String mdFeedType = message.getStringFieldValue(Constants.TAGMDFeedType);
        int noOfEntries = Integer.valueOf(message.getStringFieldValue(Constants.TAGNoMDEntries));
        IFixGroup[] entries = parser.getDynamicGroupDataFor(Constants.TAGiNoMDEntries, Constants.TAGiMDUpdateAction);
        assertNotNull("Null entries in MarketData", entries);
        assertEquals("Incorrect NoOfEntries in MarketData", noOfEntries, entries.length);
        BlockingQueue<Message> msgQ = priceMsgMap.get(requestId);
        String mdEntryType = entries[0].getStringValFor(Constants.TAGiMDEntryType);
        
        if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_NOW_Ticker)) {// CxNow: Ticker
            
            assertEquals("NoOfEntries should always be 1 for CxNow Ticker MD", noOfEntries, 1);
            System.out.println(this.getUserName()+" received CxNow Ticker MD, NoOfEntires:"+noOfEntries);
            
            System.out.println("Action:"+entries[0].getStringValFor(Constants.TAGiMDUpdateAction)+
                    " MDType:"+entries[0].getStringValFor(Constants.TAGiMDEntryType)+
                    " Symbol:"+entries[0].getStringValFor(Constants.TAGiSymbol)+
                    " SymbolSfx:"+entries[0].getStringValFor(Constants.TAGiSymbolSfx)+
                    " Px:"+entries[0].getStringValFor(Constants.TAGiMDEntryPx)+
                    " Size:"+entries[0].getStringValFor(Constants.TAGiMDEntrySize)+
                    " TickerType:"+entries[0].getStringValFor(Constants.TAGiMDTickerType)+
                    " Time:"+entries[0].getStringValFor(Constants.TAGiTransactTime)+
                    " OrderLife:"+entries[0].getStringValFor(Constants.TAGiOrderLife));
            
            if (msgQ == null) {
                throw new IllegalStateException("Unknown MarketDataRequest, ReqId=" + requestId);
            }
            msgQ.add(message);
            
        } else if (mdEntryType!=null && mdEntryType.equals(Constants.MDENTRYTYPE_Trade)) {// is a ticker message
            tickerQueue.add(message);
            getMDEntryFromMarketDataForTicker(message);
        } else if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_NOW_DepthOfBook)) {// CxNow: DepthOfBook
            
            System.out.println(this.getUserName()+" received CxNow DepthOfBook MD, NoOfEntires:"+noOfEntries);
            
            assertNotNull("Null entries in CxNow DepthOfBook MD", entries);
            assertEquals(noOfEntries, entries.length);
            
            for(IFixGroup entry:entries){
                System.out.println("Action: "+entry.getStringValFor(Constants.TAGiMDUpdateAction)+
                        " Depth: "+entry.getStringValFor(Constants.TAGiMarketDepth)+
                        " Side: "+entry.getStringValFor(Constants.TAGiMDEntryType)+
                        " Symbol: "+entry.getStringValFor(Constants.TAGiSymbol)+
                        " SymbolSfx: "+entry.getStringValFor(Constants.TAGiSymbolSfx)+
                        " Px: "+entry.getStringValFor(Constants.TAGiMDEntryPx)+
                        " Size: "+entry.getStringValFor(Constants.TAGiMDEntrySize));
            }
            
            
            if (msgQ == null) {
                throw new IllegalStateException("Unknown MarketDataRequest, ReqId=" + requestId);
            }
            msgQ.add(message);
            
        } else if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_NOW_WAMR)) {// CxNow: WAMR
            
            assertEquals("NoOfEntries should always be 6 for CxNow WAMR MD", noOfEntries, 6);
            System.out.println(this.getUserName()+" received CxNow WAMR MD, NoOfEntires:"+noOfEntries);
                        
            for(IFixGroup entry:entries){
                System.out.println("Action:"+entry.getStringValFor(Constants.TAGiMDUpdateAction)+
                        " Side:"+entry.getStringValFor(Constants.TAGiMDEntryType)+
                        " Symbol:"+entry.getStringValFor(Constants.TAGiSymbol)+
                        " SymbolSfx:"+entry.getStringValFor(Constants.TAGiSymbolSfx)+
                        " Px:"+entry.getStringValFor(Constants.TAGiMDEntryPx)+
                        " Px2:"+entry.getStringValFor(Constants.TAGiMDEntryPx2)+
                        " ConfFactor:"+entry.getStringValFor(Constants.TAGiMDWAMR_ConfFactor)+
                        " Time:"+entry.getStringValFor(Constants.TAGiMDEntryTime));
            }
            if (msgQ == null) {
                throw new IllegalStateException("Unknown MarketDataRequest, ReqId=" + requestId);
            }
            msgQ.add(message);
            
        } else if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_NOW_MidX)) {// CxNow: MidX
            
            assertEquals("NoOfEntries should always be 1 for CxNow MidX MD", noOfEntries, 1);
            System.out.println(this.getUserName()+" received CxNow MidX MD, NoOfEntires:"+noOfEntries);
            
            System.out.println("Action: "+entries[0].getStringValFor(Constants.TAGiMDUpdateAction)+
                    " Symbol: "+entries[0].getStringValFor(Constants.TAGiSymbol)+
                    " SymbolSfx: "+entries[0].getStringValFor(Constants.TAGiSymbolSfx)+
                    " ActivityIndicator: "+entries[0].getStringValFor(Constants.TAGiMDMidX_ActivityIndicator));
        
        }  else if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_NOW_L1)) {// CxNow: L1
            
            System.out.println(this.getUserName()+" received CxNow L1 MD, NoOfEntires:"+noOfEntries);
            for(IFixGroup entry:entries){
                System.out.println("Action: "+entry.getStringValFor(Constants.TAGiMDUpdateAction)+
                        " Depth: "+entry.getStringValFor(Constants.TAGiMarketDepth)+
                        " Side: "+entry.getStringValFor(Constants.TAGiMDEntryType)+
                        " Symbol: "+entry.getStringValFor(Constants.TAGiSymbol)+
                        " SymbolSfx: "+entry.getStringValFor(Constants.TAGiSymbolSfx)+
                        " Px: "+entry.getStringValFor(Constants.TAGiMDEntryPx));
            }
            
            if (msgQ == null) {
                throw new IllegalStateException("Unknown MarketDataRequest, ReqId=" + requestId);
            }
            msgQ.add(message);
        
        }  else if (mdFeedType != null && mdFeedType.equals(Constants.MDENTRYTYPE_VIEW_MarketData)) {// CxView: DepthOfBook
            
            String bidPx = null;
            String offerPx = null;
            for(IFixGroup entry:entries){
                if(entry.getStringValFor(Constants.TAGiMDEntryType)!=null){
                    if(entry.getStringValFor(Constants.TAGiMDEntryType).equals(Constants.MDENTRYTYPE_Bid)){
                        bidPx = entry.getStringValFor(Constants.TAGiMDEntryPx);
                    }else if(entry.getStringValFor(Constants.TAGiMDEntryType).equals(Constants.MDENTRYTYPE_Offer)){
                        offerPx = entry.getStringValFor(Constants.TAGiMDEntryPx);
                    }
                }
            }
            
            System.out.println(this.getUserName()+" received CxView depth MD for "+
                    entries[0].getStringValFor(Constants.TAGiSymbol)+"-"+entries[0].getStringValFor(Constants.TAGiSymbolSfx)+
                    " Bid:"+bidPx+
                    " Offer:"+offerPx);
            
            if (msgQ == null) {
                throw new IllegalStateException("Unknown MarketDataRequest, ReqId=" + requestId);
            }
            msgQ.add(message);
        
        } else if (entries[0].getStringValFor(Constants.TAGiMDEntryType)!=null && // MarketData for SecurityID 
                entries[0].getStringValFor(Constants.TAGiMDEntryType).equals(Constants.MDENTRYTYPE_SecurityID)) {
            
            getMDEntryFromMarketDataForSecurityID(message);
            
        } else if(entries[0].getStringValFor(Constants.TAGiMDEntryType)!=null && // MarketData for IOI
                entries[0].getStringValFor(Constants.TAGiMDEntryType).equals(Constants.MDENTRYTYPE_IOI)) {
            
            getMDEntryFromMarketDataForIOI(message);
            
        } else {
            
            if (msgQ == null) {
                throw new IllegalStateException("unknown price request id="
                        + requestId);
            }
            msgQ.add(message);
            
            getMDEntryFromMarketData(message);
            
            /**
             * TODO: process cancel
             */
            String[] fields = parser.getGroupDataFor(
                    FixTagConstants.TAGNoMDEntries,
                    FixTagConstants.TAGMDEntryType,
                    parser.getIntValFor(FixTagConstants.TAGNoMDEntries));
            String[] actionFields = parser.getGroupDataFor(
                    FixTagConstants.TAGNoMDEntries,
                    FixTagConstants.TAGMDUpdateAction,
                    parser.getIntValFor(FixTagConstants.TAGNoMDEntries));
            int bidIndex = -1;
            int offerIndex = -1;
            for (int i = 0; i < fields.length; i++) {
                if (fields[i].equals(Constants.MDENTRYTYPE_Bid)) {
                    bidIndex = i;
                    break;
                }
            }
            for (int i = 0; i < fields.length; i++) {
                if (fields[i].equals(Constants.MDENTRYTYPE_Offer)) {
                    offerIndex = i;
                    break;
                }
            }
            
            String ccyPair = null;
            
            
            String[] symbolFields = parser.getGroupDataFor(
                    FixTagConstants.TAGNoMDEntries, FixTagConstants.TAGSymbol,
                    parser.getIntValFor(FixTagConstants.TAGNoMDEntries));
            if(symbolFields.length>0){
                ccyPair = symbolFields[0];   
            }

            String bidAction = (bidIndex != -1 ? actionFields[bidIndex] : null);
            String offerAction = (offerIndex != -1 ? actionFields[offerIndex]
                    : null);
            if (bidAction != null
                    && bidAction.equals(Constants.MDUPDATEACTION_Delete)) {
                System.out.println("bidCancelled");
            }
            if (offerAction != null
                    && offerAction.equals(Constants.MDUPDATEACTION_Delete)) {
                System.out.println("offerCancelled");
            }

            String[] priceFields = parser.getGroupDataFor(
                    FixTagConstants.TAGNoMDEntries,
                    FixTagConstants.TAGMDEntryPx,
                    parser.getIntValFor(FixTagConstants.TAGNoMDEntries));
            String[] sizeFields = parser.getGroupDataFor(
                    FixTagConstants.TAGNoMDEntries,
                    FixTagConstants.TAGMDEntrySize,
                    parser.getIntValFor(FixTagConstants.TAGNoMDEntries));
            if (priceFields == null || sizeFields == null) {
                System.out.println("empty price ignored");
                return;
            }
            String bid = null;
            if (bidIndex != -1 && bidIndex < priceFields.length
                    && priceFields[bidIndex] != null) {
                bid = priceFields[bidIndex];
            }
            String offer = null;
            if (offerIndex != -1 && offerIndex < priceFields.length
                    && priceFields[offerIndex] != null) {
                offer = priceFields[offerIndex];
            }
//            System.out.println("price update: " + ccyPair + " bid=" + bid
//                    + " offer=" + offer);
            if (bidIndex != -1 && bidIndex < sizeFields.length
                    && sizeFields[bidIndex] != null) {
            }
            if (offerIndex != -1 && offerIndex < sizeFields.length
                    && sizeFields[offerIndex] != null) {
            }
//            System.out
//                    .println("MSG is added and the length of the msgQ for reqID "
//                            + requestId + " is " + msgQ.size());
        }
    }

    private void handleMarketDataRequestReject(Message message) throws Exception {
        String requestId = message.getStringFieldValue(Constants.TAGMDReqID);
        BlockingQueue<Message> msgQ = priceMsgMap.get(requestId);
        if (msgQ == null) {
            throw new IllegalStateException("unknown price request id=" + requestId);
        }
        msgQ.add(message);
        rejectQueue.add(message);
    }

    private void handleOrderCancelReject(Message message) throws Exception {
        rejectQueue.add(message);
        String orderID = message.getStringFieldValue(Constants.TAGOrderID);
        String clientOrderID = message.getStringFieldValue(Constants.TAGClOrdID);
        String originalClOrdID = message.getStringFieldValue(Constants.TAGOrigClOrdID);
        if (originalClOrdID == null) {
            throw new IllegalStateException("original clordId cannot be null");
        }
        System.out.println(this.getUserName()+" order cancel failed: orderID=" + orderID + " clOrdID=" + clientOrderID);
        if (!clientOrderID.equals("OPEN ORDER")) {
            BlockingQueue<Message> msgQ = orderMsgMap.get(originalClOrdID);
            if (msgQ == null) {
                throw new IllegalStateException("unknown order clOrdID=" + clientOrderID);
            }
        msgQ.add(message);
        }

    }

    private void handleBusinessMessageReject(Message message) throws Exception {
        rejectQueue.add(message);
        String targetCompId = message.getHeaderStringFieldValue(56);
        if (targetCompId == null) {
            throw new IllegalStateException("targetCompId cannot be null");
        }
    }

    protected void handleExecutionReport(Message message) throws Exception {
        
        String clientOrderID = message.getStringFieldValue(Constants.TAGClOrdID);
        String execType = message.getStringFieldValue(Constants.TAGExecType);
        
        Long diff = 0L;
        
        if (message.getStringFieldValue(Constants.TAGExecType) != null &&
                message.getStringFieldValue(Constants.TAGExecType).equals(Constants.EXECTYPE_New) &&
                this.recordRoundTripTime){
            diff = System.nanoTime() - this.idToTimeMapForAck.get(clientOrderID);
        }
        
        String orderID = message.getStringFieldValue(Constants.TAGOrderID);
        String text = message.getStringFieldValue(Constants.TAGText);
        String originalClOrdID = message.getStringFieldValue(Constants.TAGOrigClOrdID);
        String orderStatus = message.getStringFieldValue(Constants.TAGOrdStatus);

        BlockingQueue<Message> msgQ = orderMsgMap.get(originalClOrdID);
        if (msgQ == null) {
            msgQ = orderMsgMap.get(clientOrderID);
            if (msgQ == null) {
                msgQ = orderMsgMap.get("UNKNOWN");
            }
        }
        msgQ.add(message);
        this.executionReportQueue.add(message);
        
        lastAckCameInTime = System.currentTimeMillis();
        if (execType.equals(Constants.EXECTYPE_New)) {//new
            if (orderStatus != null && orderStatus.equals(Constants.ORDSTATUS_New)) {
                clordidset.remove(message.getStringFieldValue(Constants.TAGClOrdID));
                System.out.println(this.getUserName()+" received ER(ack): orderID=" + orderID + " clOrdID=" + clientOrderID);
                
                if (this.recordRoundTripTime){
                    //Long diff = System.nanoTime() - this.idToTimeMapForAck.get(clientOrderID);
                    System.out.println("Order ack response time is " + diff + " nanoseconds");
                    if (minAckTime == 0L || diff < minAckTime){
                        minAckTime = diff;
                    }
                    if (diff > maxAckTime){
                        maxAckTime = diff;
                    }
                    this.accumulatedAckResponseTime += diff;
                    numberMessagesAcked++;
                    getAckDiffCollection().add(diff);
                    
                    this.clientIDToOrderIDMap.put(clientOrderID, orderID);
                }
            }
        } else if (orderStatus.equals(Constants.ORDSTATUS_PartiallyFilled)) { //partial fill
            System.out.println(this.getUserName()+" received ER(partially filled): orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else if (orderStatus.equals(Constants.ORDSTATUS_Filled)) { //complete filled
            if (this.recordRoundTripTime){
                Long diffFill = System.nanoTime() - this.idToTimeMapForFill.get(clientOrderID);
                System.out.println(("Order fill response time is " + diffFill + " nanoseconds"));

                this.accumulatedFillResponseTime += diffFill;
                fillDiffCollection.add(diffFill);
                numberMessagesFilled++;
                this.idToTimeMapForFill.remove(clientOrderID);
            }
            tradeQueue.add(message);
            
            if(execType.equals(Constants.EXECTYPE_MidMatchT0Trade)){
                System.out.println(this.getUserName()+" received ER(MidMatch t0): orderID=" + orderID + " clOrdID=" + clientOrderID);
            }else if(execType.equals(Constants.EXECTYPE_MidMatchTNTrade)){
                System.out.println(this.getUserName()+" received ER(MidMatch tN): orderID=" + orderID + " clOrdID=" + clientOrderID);
            }else if(execType.equals(Constants.EXECTYPE_Suspended)){
                System.out.println(this.getUserName()+" received ER(Suspended): orderID=" + orderID + " clOrdID=" + clientOrderID);
            }else{
                System.out.println(this.getUserName()+" received ER(full filled): orderID=" + orderID + " clOrdID=" + clientOrderID);
            }
            
        } else if (execType.equals(Constants.EXECTYPE_Cancelled)) { //cancelled
            
            System.out.println(this.getUserName()+" received ER(cancelled): orderID=" + orderID + " clOrdID=" + clientOrderID);
            
            if (this.recordRoundTripTime){
                numberMessagesCancelled++;
            }
            
        } else if (execType.equals(Constants.EXECTYPE_Replaced)) { //replaced
            
            System.out.println(this.getUserName()+" received ER(replaced): orderID=" + orderID + " clOrdID=" + clientOrderID);
            
        } else if (execType.equals(Constants.EXECTYPE_Rejected)) {
            clordidset.remove(message.getStringFieldValue(Constants.TAGClOrdID));
            System.out.println(" order rejected: orderID=" + orderID + " clOrdID=" + clientOrderID + " reason=" + text);
            
            if (this.recordRoundTripTime){
                numberMessagesRejected++;
                
                if(!rejectReasonSet.contains(text)){
                    rejectReasonSet.add(text);
                }

            }

        }  else if (execType.equals(Constants.EXECTYPE_OrderStatus)) {
            
            String orderStatusName = null;
            
//            Field[] declairedOrderStatus = quickfix.field.OrderStatus.class.getDeclaredFields();
//            for(Field ordStatus:declairedOrderStatus){
//                if(ordStatus.getType().getName().equals(char.class.getName()))
//                {
//                    ordStatus.setAccessible(true);
//                    if(ordStatus.getChar(quickfix.field.OrderStatus.class) == orderStatus.charAt(0)){
//                        orderStatusName = ordStatus.getName();
//                    }
//                }
//            }
//            orderStatusName = orderStatusName==null? "":" - "+orderStatusName;
            System.out.println(this.getUserName()+" received ER(OrderStatus"+orderStatusName+"): orderID=" + orderID + " clOrdID=" + clientOrderID);
        } else {
            System.err.println("unknown exec type=" + execType);
        }
    }

    public void printAckRoundTripStats(){
        
        if(recordRoundTripTime){
            
            System.out.println("Number of orders submitted: " + totalOrdersSubmitted);
            System.out.println("Number of orders acked: " + numberMessagesAcked);
            System.out.println("Number of orders rejected: " + numberMessagesRejected);
            System.out.println("Number of orders cancelled: " + numberMessagesCancelled);
            
            System.out.println("MinAckTime: " + minAckTime + " nanoseconds");
            System.out.println("AvgAckTime: " + this.getAvgAckTimeInNano() + " nanoseconds");
            System.out.println("MaxAckTime: " + maxAckTime + " nanoseconds");
            
            System.out.println("Total RoundTrip time: "+ (this.lastAckCameInTime - this.firstOrderWentOutTime) +" milliseconds");
        }else{
            System.out.println("********* recordRoundTripTime is not set to true for the taker *********");
        }
    }
    
    public long getAvgAckTimeInNano(){
        if(recordRoundTripTime){
            return (numberMessagesAcked != 0)? (accumulatedAckResponseTime/numberMessagesAcked) : -1;
        }else{
            return -1;
        }
    }
    
    public void printRejectReasons(){
        Iterator rejectReasonIterator = rejectReasonSet.iterator();
        
        System.out.println("Number of reject reasons:"+rejectReasonSet.size());
        
        while(rejectReasonIterator.hasNext()){
            System.out.println(rejectReasonIterator.next());
        }
    }
    private void handleListStatus(Message message) throws Exception {
        listQueue.add(message);
    }

    private void handlePositionReport(Message message) throws Exception {
        posreportQueue.add(message);
        apQueue.add(message);
    }

    private void handleCollateralReport(Message message) throws Exception {
        journalQueue.add(message);
    }

    private void handleCollateralResponse(Message message) throws Exception {
        collateralResponseQueue.add(message);
    }

    private void handleQuoteAck(Message message) throws Exception {
        quoteAckQueue.add(message);
    }

    private void handleQuoteCancel(Message message) throws Exception {
        quoteAckQueue.add(message);
    }

    private void handleQuote(Message message) throws Exception {
        quoteQueue.add(message);
    }
    
    private void handleQuoteReqReject(Message message) throws Exception {
        quoteReqRejectQueue.add(message);
    }

    private void handleSecurityList(Message message) throws Exception {

        listQueue.add(message);
    }

    private void handleSecurityStatus(Message message) throws Exception {

        listQueue.add(message);
    }

    private void handleRejectMessage(Message message) {
        System.out.println("Reject message added to the reject queue;");
        rejectQueue.add(message);
    }

    private void handlePositionRejectMessage(Message message) {
        rejectQueue.add(message);
    }

    private void handleUserPropertyReport(Message message) throws Exception {
        userPropertyReportQueue.add(message);
    }

    private void handleSecurityDefinition(Message message) throws Exception {

        securityDefnQueue.add(message);
    }

    private void handlePartyDetailListReport(Message message) throws Exception {
        System.out.println("partydetailslistreport message added to queue");
        partyDetailListReportQueue.add(message);
    }

    private void handleServerNotificationMessage(Message message) throws Exception {
        serverNotificationMessageQueue.add(message);
    }
    
    private void handleOrderMassCancelReportMessage(Message message) throws Exception{
        orderMassCancelReportQueue.add(message);
    }


    public Message getMessageFromRejectQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = rejectQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromCollateralReponseQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = collateralResponseQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromPUQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = puQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromListQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = listQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromPositionQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = posreportQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromAPQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = apQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromJournalQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = journalQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromTickerQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = tickerQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromTradeQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = tradeQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getQuoteAckMsg(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = quoteAckQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getQuoteMsg(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = quoteQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getQuoteReqRejectMsg(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = quoteReqRejectQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }
    
    public Message getPriceAlertUpdate(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = this.priceAlertUpdatedQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }
    
    public Message getUserResponseMsg(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = userResponseQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getUserPropertyReport(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = userPropertyReportQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }


    public Message getMessageFromPartyDetailListReportQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = partyDetailListReportQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getSecurityDefnMessageFromQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = securityDefnQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromServerNotificationMessageQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = serverNotificationMessageQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromServerNotificationSubscriptionRejectQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = serverNotificationSubscriptionRejectQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }

    public Message getMessageFromExeuctionReportQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = executionReportQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }
    
    public Message getMessageFromOrderMassCancelReportQueue(long timeout) throws Exception {
        Message msg = null;
        try {
            msg = orderMassCancelReportQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return msg;
    }
    
    public MDEntry getMDEntryFromQueue(long timeout) throws Exception {
        MDEntry entry = null;
        try {
            entry = mdEntryQueue.poll(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return entry;
    }

    public int getPositionQueueSize() {
        return posreportQueue.size();
    }
    
    public int getAPQueueSize() {
        return apQueue.size();
    }
    
    public void clearExecutionReportQueue() {
        executionReportQueue.clear();
    }
    
    public void clearMDEntryQueue() {
        mdEntryQueue.clear();
    }

    public void clearPositionReportQueue() {
        posreportQueue.clear();
    }
    
    public void clearAPQueue() {
        apQueue.clear();
    }

    public void clearRejectQueue() {
        rejectQueue.clear();
    }

    public boolean isStream() {
        return isStream;
    }

    public boolean isTrade() {
        return isTrade;
    }

    public boolean isTicker() {
        return isTicker;
    }

    public boolean isRetail() {
        return isRetail;
    }

    public String getRoutedUserIds() {
        return routedUserIds;
    }

    public void clearAllQueues(long waitTime) throws Exception {
        
        Thread.sleep(waitTime);
        
        // get all existing position reports
        Message msg = getMessageFromPositionQueue(500);
        while (msg != null) {
            msg = getMessageFromPositionQueue(500);
        }

        msg = getMessageFromJournalQueue(500);
        while (msg != null) {
            msg = getMessageFromJournalQueue(500);
        }

        msg = getMessageFromPartyDetailListReportQueue(500);
        while (msg != null) {
            msg = getMessageFromPartyDetailListReportQueue(500);
        }

        msg = getMessageFromRejectQueue(500);
        while (msg != null) {
            msg = getMessageFromRejectQueue(500);
        }

        msg = getMessageFromCollateralReponseQueue(500);
        while (msg != null) {
            msg = getMessageFromCollateralReponseQueue(500);
        }

        msg = getMessageFromPUQueue(500);
        while (msg != null) {
            msg = getMessageFromPUQueue(500);
        }
    }

    @Override
    @Deprecated
    public Object clone() throws CloneNotSupportedException {
        TakerTestSession clone = (TakerTestSession) super.clone();
        clone.msgQ.clear();
        return clone;
    }

    public boolean isProcessByClOrdId() {
        return isProcessByClOrdId;
    }

    public String getUserName() {
        return getSenderCompId();
    }

    public String getPartyName() {
        return getPartyId();
    }

    public String getAllocAccount() {
        return allocAccount;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, BlockingQueue<Message>> getPriceMsgMap() {
        return priceMsgMap;
    }

    public SimpleDateFormat getDateFormat() {
        return dateFormat;
    }
    
    public static Date oneMinuteAgo(){
        //order status - all orders
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 7);
        calendar.add(Calendar.MINUTE, -1);
        return calendar.getTime();
    }
    public void startRecordingRoundTripTime(){
        this.recordRoundTripTime = true;
    }
    public void stopRecordingRoundTripTime(){
        this.recordRoundTripTime = false;
    }

    public Collection<Long> getAckDiffCollection() {
        return ackDiffCollection;
    }
    public Collection<Long> getFillDiffCollection() {
        return fillDiffCollection;
    }
    
    
    
    
    
    public void submitLimitOrderOnBehalf(String clOrdId, String symbol, String symbolSfx, String side,
            String currency, String ordQty, String price, String minQty, String onBehalf, String account) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, this.getSenderCompId(), this.getTargetCompId(), this.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, Constants.PRODUCT_Currency);
        msg.setField(Constants.TAGSecurityType, Constants.SECURITYTYPE_ForeignExchange);
        msg.setField(Constants.TAGTransactTime, dateFormat.format(new Date()));
        msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, Constants.ORDTYPE_ForexLimit);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGTimeInForce, Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGMinQty, minQty);

        orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

    
    public boolean hasOpenPosition(Message positionReport) throws Exception{
        IFixGroup[] positions = positionReport.getParser().getDynamicGroupDataFor(Constants.TAGiNoPositions, Constants.TAGiPosType);
        assertNotNull("No Position info in PositionReport", positions);
        assertEquals("Different number of positions in PositionReport", 
                positionReport.getStringFieldValue(Constants.TAGNoPositions), Integer.toString(positions.length));
        for(IFixGroup position:positions){
            String posType = position.getStringValFor(Constants.TAGiPosType);
            if(posType!=null && posType.equals(Constants.POSITIONTYPE_Open)){
                return true;
            }
        }
        return false;
    }

    public void newOrderSingle(currenex.server.fxintegrate.adaptor.inttest.fix.messages.NewOrderSingle order) throws Exception{
        Message msg = order.buildMessage(Constants.MSGOrderSingle, this.getSenderCompId(), this.getTargetCompId(), this.getFixVersion());
        orderMsgMap.put(order.clOrdID(), new ArrayBlockingQueue<Message>(6000));
        sendFixMessage(msg);
    }

}

