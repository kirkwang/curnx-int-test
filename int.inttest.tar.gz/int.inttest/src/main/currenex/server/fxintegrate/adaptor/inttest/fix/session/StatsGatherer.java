package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public class StatsGatherer {
    //find the value of the nth percentile of a collection of values.
    public static Long findNthPercentile(Collection<Long> source, int percentile){
        Long[] numbers = source.toArray(new Long[source.size()]);
        return findNthPercentile(numbers, percentile);
    }
    public static Long findNthPercentile(Long[] numbers, int percentile){
        Arrays.sort(numbers);
        return numbers[findIndexOfPercentile(numbers.length, percentile)];
    }
    
    //given the size of a sorted array, find out the index of the nth percentile.
    private static int findIndexOfPercentile(long size, int percentile){
        double l1 = size * percentile;
        double l2 = l1 / 100.00;
        int index = (int) (Math.ceil(l2) -1);
        return index;
    }
    
    public static Long findMinimum(Collection<Long> source){
        if (source.size() >0){
            Iterator it = source.iterator();
            Long currentMin = (Long) it.next();
            while (it.hasNext()){
                Long current = (Long) it.next();
                if (currentMin > current){
                    currentMin = current;
                }
            }
            return currentMin;
        }
        return null;
    }
    public static Long findMaximum(Collection<Long> source){
        if (source.size() >0){
            Iterator it = source.iterator();
            Long currentMax = (Long) it.next();
            while (it.hasNext()){
                Long current = (Long) it.next();
                if (currentMax < current){
                    currentMax = current;
                }
            }
            return currentMax;
        }
        return null;
    }
    public static Double findAverage(Collection<Long> source){
        if (source.size() == 0)
            return null;
        long total = 0;
        for (Long i : source){
            total += i;
        }
        return total/(double)source.size();
    }
    public static Double findMedian(Collection<Long> source){
        if (source.size() == 0)
            return null;
        
        Long[] numbers = source.toArray(new Long[source.size()]);
        Arrays.sort(numbers);
        if (source.size()%2 ==1){
            return (double)numbers[(source.size()-1)/2];
        } else if (source.size()%2 ==0){
            Long high = numbers[source.size()/2];
            Long low = numbers[source.size()/2-1];
            return (high + low)/2.00;
        }
        return null;
    }
    public static void main(String[] args){
        System.out.println(findIndexOfPercentile(1, 99));//0
        System.out.println(findIndexOfPercentile(10, 20));//2
        System.out.println(findIndexOfPercentile(10, 25));//2
        System.out.println(findIndexOfPercentile(100, 25));//24
        System.out.println(findIndexOfPercentile(10000, 77));//769

        Long[] array = {(long) 1, (long) 2, (long) 3, (long) 4, (long) 5, (long) 6, (long) 7, (long) 8, (long) 9, (long) 10};
        System.out.println(findNthPercentile(array, 80));
        
        Long[] array2 = {(long) 9, (long) 6, (long) 4, (long) 4, (long) 7, (long) 1, (long) 7, (long) 2, (long) 10, (long) 4};
        System.out.println(findNthPercentile(array2, 80));
        
        Long[] array3 = {(long) 6, (long) 4, (long) 4, (long) 7, (long) 1, (long) 7, (long) 2, (long) 10, (long) 4};
        System.out.println(findNthPercentile(array3, 100));
        
    }
}
