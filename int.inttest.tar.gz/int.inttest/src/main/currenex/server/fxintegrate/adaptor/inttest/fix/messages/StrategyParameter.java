package currenex.server.fxintegrate.adaptor.inttest.fix.messages;

/**
 * Created by dzhu on 3/15/17.
 */
public class StrategyParameter {
    public String strategyParameterName;//958
    public String strategyParameterValue;//960

    public StrategyParameter(String name, String value){
        strategyParameterName=name;
        strategyParameterValue=value;
    }
    public String getStrategyParameterName(){
        return strategyParameterName;
    }
    public String getStrategyParameterValue(){
        return strategyParameterValue;
    }

    public String toString(){
        return "strategyParameterName="+strategyParameterName+" strategyParameterValue="+strategyParameterValue;
    }
}
