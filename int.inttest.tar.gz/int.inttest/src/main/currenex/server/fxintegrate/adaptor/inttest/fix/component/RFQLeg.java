package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class RFQLeg {
    
    public String legSymbol;
    public String legSide;
    public String legCurrency;
    public Allocation[] allocations;
    public String legOrderQty;
    public String legSettlDate;
    public String legRefID;
    
    public RFQLeg(String legSymbol, String legSide, String legCurrency, Allocation[] allocations, 
            String legOrderQty, String legSettlDate, String legRefID){
        this.legSymbol = legSymbol;
        this.legSide =legSide; 
        this.legCurrency = legCurrency;
        this.allocations = allocations;
        this.legOrderQty = legOrderQty;
        this.legSettlDate = legSettlDate;
        this.legRefID = legRefID;
    }
}
