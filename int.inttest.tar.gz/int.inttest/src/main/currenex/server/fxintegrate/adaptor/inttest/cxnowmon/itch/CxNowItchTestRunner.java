package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import static currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat.MsgTypes.*;
import static currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch.CxNowItchTestRunner.SubscriptionType.*;
import static currenex.server.fxintegrate.adaptor.inttest.itch.Constants.*;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.MsgHandler;
import currenex.util.Dates;
import org.jboss.netty.channel.Channel;

@Singleton
public class CxNowItchTestRunner implements ItchMsgHandler {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchTestRunner.class);

    private final CompletableFuture<Boolean> connectionSuccessful;
    private final CompletableFuture<Boolean> loginSuccessful;
    private final MsgHandler msgCreator;
    private final ItchMsgSender itchMsgSender;

    private final String username;
    private final String password;
    private final long listenMillis;
    private final List<String> subscribedInstruments;
    private final Map<SubscriptionType, Boolean> subscriptions;
    private final CxNowTestStat cxNowTestStat = new CxNowTestStat();

    private AtomicInteger outboundSeq = new AtomicInteger(0);
    private int sessionId = -1;

    enum SubscriptionType {
        DEPTH_OF_BOOK, TICKER, WAMR, MID
    }

    @Inject CxNowItchTestRunner(MsgHandler msgCreator, ItchMsgSender itchMsgSender,
            @Named("connectionFuture") CompletableFuture<Boolean> connectionSuccessful,
            @Named("loginFuture") CompletableFuture<Boolean> loginSuccessful,
            @Named("username") String username,
            @Named("password") String password,
            @Named("listenMillis") long listenMillis,
            @Named("instruments") List<String> subscribedInstruments,
            @Named("subscriptions") Map<SubscriptionType, Boolean> subscriptions) {
        this.connectionSuccessful = connectionSuccessful;
        this.loginSuccessful = loginSuccessful;
        this.msgCreator = msgCreator;
        this.itchMsgSender = itchMsgSender;

        this.username = username;
        this.password = password;
        this.listenMillis = listenMillis;
        this.subscribedInstruments = subscribedInstruments;
        this.subscriptions = subscriptions;
    }

    /** Test logic */
    public void runTest() throws Exception {
        connectionSuccessful.get(3000, TimeUnit.SECONDS);

        logon();
        Thread.sleep(listenMillis);

        logout();
        itchMsgSender.closeChannel();
    }

    /**
     * Outgoing message handling
     */

    private void logon() throws IOException, InterruptedException, ExecutionException, TimeoutException {
        cxNowTestStat.addTime(0, LOGON);

        ByteBuffer logonBuffer = ByteBuffer.allocate(1000);
        msgCreator.setLogonMsg(logonBuffer, outboundSeq.incrementAndGet(), username, -1, password);
        itchMsgSender.send(logonBuffer);

        loginSuccessful.get(3000, TimeUnit.SECONDS);
    }

    private void logout() throws IOException {
        cxNowTestStat.addTime(0, LOGOUT);

        ByteBuffer logoutBuffer = ByteBuffer.allocate(1000);
        msgCreator.setLogoutMsg(logoutBuffer, outboundSeq.incrementAndGet(), username, sessionId, "CxNow itch test finished");
        itchMsgSender.send(logoutBuffer);
    }

    private void subscribe(short instrumentIndex) throws IOException {
        try {
            cxNowTestStat.addTime(0, SUBSCRIPTION_REQ);
            ByteBuffer subscribeBuffer = ByteBuffer.allocate(1000);
            msgCreator.setSubscriptionRequestMsg(subscribeBuffer, outboundSeq.incrementAndGet(),
                    sessionId, (byte) '0', instrumentIndex, subscriptions.get(DEPTH_OF_BOOK),
                    subscriptions.get(TICKER), subscriptions.get(WAMR), subscriptions.get(MID));
            itchMsgSender.send(subscribeBuffer);
        } catch (Exception e) {
            log.info("Caught exception: " + e);
        }
    }

    private void sendHeartbeatAck() throws IOException {
        cxNowTestStat.addTime(0, HEARTBEAT_ACK);

        ByteBuffer heartbeatBuffer = ByteBuffer.allocate(1000);
        msgCreator.setHBMsg(heartbeatBuffer, outboundSeq.incrementAndGet(), sessionId);
        itchMsgSender.send(heartbeatBuffer);
    }

    private void sendInstrumentInfoAck(short instrumentIndex) throws IOException {
        cxNowTestStat.addTime(0, INSTR_INFO_ACK);

        ByteBuffer ackBuffer = ByteBuffer.allocate(1000);
        msgCreator.setInstrAckMsg(ackBuffer, outboundSeq.incrementAndGet(), sessionId, instrumentIndex);
        itchMsgSender.send(ackBuffer);
    }

    /**
     * Incoming message handling (called by separate I/O thread)
     */

    @Override
    public synchronized void handleMsg(ByteBuffer buffer, char msgType, long microTime, int msgTime) throws Exception {
        int delayMillis = Dates.offsetFromStartOfDayUtc(microTime / 1000) - msgTime;

        switch(msgType) {
            case MSG_TYPE_LOGON:
                cxNowTestStat.addTime(delayMillis, LOGON_ACK);
                handleLogon(buffer);
                break;
            case MSG_TYPE_LOGOUT:
                cxNowTestStat.addTime(delayMillis, LOGOUT_ACK);
                break;
            case MSG_TYPE_HB:
                cxNowTestStat.addTime(delayMillis, HEARTBEAT);
                handleHeartbeat(buffer);
                break;
            case MSG_TYPE_INSTR_INFO:
                cxNowTestStat.addTime(delayMillis, INSTR_INFO);
                handleInstrInfo(buffer);
                break;
            case MSG_TYPE_SUBSCRIBE_ACK:
                cxNowTestStat.addTime(delayMillis, SUBSCRIPTION_RESP);
                handleSubscribeAck(buffer);
                break;
            case MSG_TYPE_NOW_DEPTH_OF_BOOK:
                cxNowTestStat.addTime(delayMillis, NOW_DEPTH_OF_BOOK);
                break;
            case MSG_TYPE_NOW_TICKER:
                cxNowTestStat.addTime(delayMillis, NOW_TICKER);
                handleTicker(buffer, microTime / 1000);
                break;
            case MSG_TYPE_NOW_WAMR:
                cxNowTestStat.addTime(delayMillis, NOW_WAMR);
                handleWamr(buffer, microTime);
                break;
            case MSG_TYPE_MID:
                cxNowTestStat.addTime(delayMillis, NOW_MID);
                break;
            case MSG_TYPE_REJECT:
                cxNowTestStat.addTime(delayMillis, REJECT);
                break;
            default:
                log.infof("Message type %c unhandled, ignoring", msgType);
        }
    }

    private void handleLogon(ByteBuffer buffer) {
        byte[] userId = new byte[20];
        byte[] password = new byte[20];

        buffer.get(userId, 0, 20);
        buffer.get(password, 0, 20);

        sessionId = buffer.getInt();

        log.infof("Handled logon response, userId=%s, password=%s, sessionId=%d", new String(userId), new String(password), sessionId);
        loginSuccessful.complete(true);
    }

    private void handleHeartbeat(ByteBuffer buffer) throws IOException {
        int receivedSessionId = buffer.getInt();
        if (receivedSessionId != this.sessionId) {
            log.infof("Unexpected session id: expected=%d, received=%d", sessionId, receivedSessionId);
        }

        sendHeartbeatAck();
        log.infof("Handled heartbeat message, sessionId=%d", receivedSessionId);
    }

    private void handleInstrInfo(ByteBuffer buffer) throws IOException {
        int receivedSessionId = buffer.getInt();
        if (receivedSessionId != this.sessionId) {
            log.infof("Unexpected session id: expected=%d, received=%d", sessionId, receivedSessionId);
        }

        short instrumentIndex = buffer.getShort();
        char instrumentType = (char) buffer.get();
        byte[] instrumentId = new byte[20];
        buffer.get(instrumentId, 0, 20);
        long settlementDate = buffer.getLong();

        sendInstrumentInfoAck(instrumentIndex);
        if (subscribedInstruments.contains(new String(instrumentId).trim())) subscribe(instrumentIndex);

        log.infof("Handled instrument info message, instrumentIndex=%d, instrumentType=%c, instrumentId=%s, settlementDate=%d",
                instrumentIndex, instrumentType, new String(instrumentId), settlementDate);
    }

    private void handleSubscribeAck(ByteBuffer buffer) {
        int receivedSessionId = buffer.getInt();
        if (receivedSessionId != this.sessionId) {
            log.infof("Unexpected session id: expected=%d, received=%d", sessionId, receivedSessionId);
        }

        short instrumentIndex = buffer.getShort();
        char type = (char) buffer.get();
        byte[] reason = new byte[50];
        buffer.get(reason, 0, 50);

        if (type == '1') {
            log.info("Subscription request accepted");
        } else if (type == '2') {
            log.infof("Subscription rejected, reason=%s", new String(reason));
        }
    }

    private void handleTicker(ByteBuffer buffer, long currentTimeMillis) {
        short instrumentIndex = buffer.getShort();
        byte[] rate = new byte[4];
        buffer.get(rate, 0, 4);
        char sizeIndicator = (char) buffer.get();
        char paidGivenIndicator = (char) buffer.get();
        long transactTime = buffer.getLong();

        cxNowTestStat.addTime((int) (currentTimeMillis - transactTime), TICKER_TRANSACT_TIME);
    }

    private void handleWamr(ByteBuffer buffer, long currentTimeMicros) {
        byte[] content = new byte[42];
        buffer.get(content, 0, 42);

        long timestamp = buffer.getLong();
        cxNowTestStat.addTime((int) (currentTimeMicros - timestamp), WAMR_CALC_TIME_MICROS);
    }
}
