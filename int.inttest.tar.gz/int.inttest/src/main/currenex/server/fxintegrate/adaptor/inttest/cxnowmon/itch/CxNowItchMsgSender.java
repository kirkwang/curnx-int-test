package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import static java.nio.ByteOrder.BIG_ENDIAN;

import java.nio.ByteBuffer;
import java.util.concurrent.CompletableFuture;

import com.google.common.base.Charsets;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;

class CxNowItchMsgSender implements ItchMsgSender {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchMsgSender.class);

    private final CompletableFuture<Boolean> connectionSuccessful;
    private final CompletableFuture<Boolean> loginSuccessful;

    private volatile Channel channel;

    @Inject CxNowItchMsgSender(
            @Named("connectionFuture") CompletableFuture<Boolean> connectionSuccessful,
            @Named("loginFuture") CompletableFuture<Boolean> loginSuccessful) {
        this.connectionSuccessful = connectionSuccessful;
        this.loginSuccessful = loginSuccessful;
    }

    @Override public void setChannel(Channel channel) {
        this.channel = channel;
        connectionSuccessful.complete(true);
    }

    @Override public void closeChannel() {
        if (channel != null) channel.close();
    }

    @Override public void send(ByteBuffer buffer) {
        byte[] buff = new byte[buffer.limit()];
        buffer.get(buff, 0, buffer.limit());
        buffer.flip();

        ChannelBuffer sendBuf = ChannelBuffers.copiedBuffer(buff);
        logOutgoing(sendBuf);

        channel.write(sendBuf).addListener(future -> {
            if (future.isCancelled()) {
                log.warning("ChannelFuture indicates I/O cancelled");
            } else if (future.isDone() && !future.isSuccess()) {
                log.severe("Sending message failed");
            }
        });
    }

    private static void logOutgoing(ChannelBuffer sendBuffer) {
        ByteBuffer buffer = (sendBuffer).toByteBuffer().order(BIG_ENDIAN);

        buffer.get();
        int seqNo = buffer.getInt();
        int timestamp = buffer.getInt();
        char msgType = (char) buffer.get();

        byte[] payload = new byte[buffer.remaining() - 1];
        buffer.get(payload, 0, buffer.remaining() - 1);
        log.infof("Outgoing: seqNo=%d, timestamp=%d, msgType=%c, payload=%s",
                seqNo, timestamp, msgType, new String(payload, Charsets.UTF_8));
    }
}
