package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class Price {
    
    private short instrIndex;
    private int priceId;
    private char side;
    private long maxAmount;
    private long minAmount;
    private int price;
    private char attributed;
    private String priceProvider;
    public Price(short instrIndex, int priceId, char side, long maxAmount,
            long minAmount, int price, char attributed, String priceProvider) {
        super();
        this.instrIndex = instrIndex;
        this.priceId = priceId;
        this.side = side;
        this.maxAmount = maxAmount;
        this.minAmount = minAmount;
        this.price = price;
        this.attributed = attributed;
        this.priceProvider = priceProvider;
    }
    public short getInstrIndex() {
        return instrIndex;
    }
    public void setInstrIndex(short instrIndex) {
        this.instrIndex = instrIndex;
    }
    public int getPriceId() {
        return priceId;
    }
    public void setPriceId(int priceId) {
        this.priceId = priceId;
    }
    public char getSide() {
        return side;
    }
    public void setSide(char side) {
        this.side = side;
    }
    public long getMaxAmount() {
        return maxAmount;
    }
    public void setMaxAmount(long maxAmount) {
        this.maxAmount = maxAmount;
    }
    public long getMinAmount() {
        return minAmount;
    }
    public void setMinAmount(long minAmount) {
        this.minAmount = minAmount;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public char getAttributed() {
        return attributed;
    }
    public void setAttributed(char attributed) {
        this.attributed = attributed;
    }
    public String getPriceProvider() {
        return priceProvider;
    }
    public void setPriceProvider(String priceProvider) {
        this.priceProvider = priceProvider;
    }
    
    

}
