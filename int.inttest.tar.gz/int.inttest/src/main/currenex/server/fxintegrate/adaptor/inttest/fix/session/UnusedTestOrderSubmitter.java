package currenex.server.fxintegrate.adaptor.inttest.fix.session;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.FixTagConstants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import quickfix.Group;

public class UnusedTestOrderSubmitter {
    private final TakerTestSession takerTestSession;

    public UnusedTestOrderSubmitter(TakerTestSession takerTestSession) {
        this.takerTestSession = takerTestSession;
    }

    public void unusedSubmitOrderWithSlippage(final String clientOrderID, final String onBehalfOf, BigDecimal limitRate,
                                              BigDecimal amount, String ccyPair, String buySell, String text) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        if (onBehalfOf != null) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (limitRate != null) {
            msg.setField(Constants.TAGPrice, limitRate.toString());
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows
        // partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());

        msg.setField(Constants.TAGOrdType, "T");

        if (takerTestSession.getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                "X");
        msg.setField(7558, 60);
        msg.setField(662, "0.0001");
        if (text != null)
            msg.setField(Constants.TAGText, text);
        takerTestSession.orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitOrderTime(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                      String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate,
                                      BigDecimal maxSlippage, String timeInFoce) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty.toString());

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());
        msg.setField(Constants.TAGOrdType, orderType);
        if (price != null)
            msg.setField(Constants.TAGPrice, price.toString());
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        if (stopRate != null)
            msg.setField(Constants.TAGStopPx, stopRate.toString());
        if (stopSide != null)
            msg.setField(TakerTestSession.TAGStopSide, stopSide);
        if (trailByRate != null)
            msg.setField(TakerTestSession.TAGTrailByRate, trailByRate.toString());
        if (maxSlippage != null)
            msg.setField(TakerTestSession.TAGMaxSlippage, maxSlippage.toString());

        if (takerTestSession.getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGTimeInForce,
                timeInFoce);
        msg.setField(Constants.TAGText, "additionalTerms");
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }//used for submitting order with bank lists

    public void unusedSubmitOrderBankLists(String clOrdId, String onBehalfOf, BigDecimal price, BigDecimal amount, String ccyPair, String buySell,
                                           String orderType, BigDecimal minQty, String stopSide, BigDecimal stopRate, BigDecimal trailByRate,
                                           BigDecimal maxSlippage, String numBanks, String[] banks) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty.toString());

        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());
        msg.setField(Constants.TAGOrdType, orderType);
        if (price != null)
            msg.setField(Constants.TAGPrice, price.toString());
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        if (stopRate != null)
            msg.setField(Constants.TAGStopPx, stopRate.toString());
        if (stopSide != null)
            msg.setField(TakerTestSession.TAGStopSide, stopSide);
        if (trailByRate != null)
            msg.setField(TakerTestSession.TAGTrailByRate, trailByRate.toString());
        if (maxSlippage != null)
            msg.setField(TakerTestSession.TAGMaxSlippage, maxSlippage.toString());

        if (takerTestSession.getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGProduct, "4");
        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);
        msg.setField(Constants.TAGText, "additionalTerms");
        if (numBanks != null)
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
        if (banks != null) {
            for (String bank : banks)
                msg.addField(FixTagConstants.TAGBrokerMatchID, bank);
        }
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitSlicedOrder(String clOrdId, String onBehalfOf, String currency, String side, String symbol, String symSfx, String amount, String ordType, String account,
                                        String clientId, String price, String expiration, String expDate, String expTime, String minQty, String numStrategyParams, String[] params, String[] values, String numBanks, String[] banks
    ) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (clOrdId != null)
            msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (currency != null)
            msg.setField(Constants.TAGCurrency, currency);
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (symSfx != null)
            msg.setField(Constants.TAGSymbolSfx, symSfx);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        if (amount != null)
            msg.setField(Constants.TAGOrderQty, amount);
        if (ordType != null)
            msg.setField(Constants.TAGOrdType, ordType);
        if (account != null)
            msg.setField(Constants.TAGAccount, account);
        if (clientId != null)
            msg.setField(Constants.TAGClientID, clientId);
        if (price != null)
            msg.setField(Constants.TAGPrice, price);
        msg.setField(Constants.TAGSecurityType, "FOR");
        if (expiration != null)
            msg.setField(Constants.TAGTimeInForce,
                    expiration);
        if (expDate != null)
            msg.setField(Constants.TAGExpireDate, expDate);
        if (expTime != null)
            msg.setField(Constants.TAGExpireTime, expTime);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty);
        if (numStrategyParams != null) {
            msg.setField("957", numStrategyParams);
            for (int num = 0; num < Integer.parseInt(numStrategyParams); num++) {
                if (params[num] != null)
                    msg.addField("958", params[num]);
                if (values[num] != null)
                    msg.addField("960", values[num]);
            }
        }

        if (numBanks != null)
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, minQty);
        if (banks != null) {
            for (String bank : banks)
                msg.addField(FixTagConstants.TAGBrokerMatchID, bank);
        }
        if (onBehalfOf != null) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);

    }

    public void unusedSubmitStagedOrder(String clOrdId, String onBehalfOf, String settlType,
                                        String symbol, String product, String side, String amount,
                                        String orderType, String currency) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalfOf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalfOf);
            }
        }
        if (settlType != null)
            msg.setField(Constants.TAGSettlType, settlType); // required
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGProduct, product);
        msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);

    }

    public void unusedSubmitRetailOrderWithSlippageDEV18991(String clOrdId, String secClordId, String symbol, String product, String side,
                                                            String currency, String ordQty, String price, String stopPx, String expiration,
                                                            String expDate, String expTime, String minQty, String expSeconds, String stopSide,
                                                            String trailBy, String maxSlippage) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (clOrdId != null)
            msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (secClordId != null)
            msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (product != null)
            msg.setField(Constants.TAGProduct, product);
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        if (currency != null)
            msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        if (ordQty != null)
            msg.setField(Constants.TAGOrderQty, ordQty);
        msg.setField(Constants.TAGOrdType, "T");
        if (price != null)
            msg.setField(Constants.TAGPrice, price);
        if (stopPx != null)
            msg.setField(Constants.TAGStopPx, stopPx);
        if (expiration != null)
            msg.setField(Constants.TAGTimeInForce, expiration);
        if (expDate != null)
            msg.setField(Constants.TAGExpireDate, expDate);
        if (expTime != null)
            msg.setField(Constants.TAGExpireTime, expTime);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty);
        if (expSeconds != null)
            msg.setField(FixTagConstants.TAGExpireSeconds, expSeconds);
        if (stopSide != null)
            msg.setField(FixTagConstants.TAGStopSide, stopSide);
        if (trailBy != null)
            msg.setField(TakerTestSession.TAGTrailByRate, trailBy);
        if (maxSlippage != null)
            msg.setField(TakerTestSession.TAGMaxSlippage, maxSlippage);
        msg.setField(662, "0.0001");
        //testing for dev-13522, remove
//        msg.setField("7589", "1.502011");
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);

    }

    public void unusedSubmitRetailPeggedOrder(String clOrdId, String secClordId, String symbol, String product, String side,
                                              String currency, String ordQty, String ordType, String peggedOrdType, String peggedOrdSide,
                                              String peggedOrdOffset, String peggedOrdDiscretion) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (clOrdId != null)
            msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (secClordId != null)
            msg.setField(Constants.TAGSecondaryClOrdID, secClordId);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (product != null)
            msg.setField(Constants.TAGProduct, product);
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        if (currency != null)
            msg.setField(Constants.TAGCurrency, currency);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        if (ordQty != null)
            msg.setField(Constants.TAGOrderQty, ordQty);
        if (ordType != null)
            msg.setField(Constants.TAGOrdType, ordType);
        if (peggedOrdType != null)
            msg.setField(FixTagConstants.TAGPeggedOrdType, peggedOrdType);
        if (peggedOrdSide != null)
            msg.setField(FixTagConstants.TAGPeggedOrdSide, peggedOrdSide);
        if (peggedOrdOffset != null)
            msg.setField(FixTagConstants.TAGPeggedOrdOffset, peggedOrdOffset);
        if (peggedOrdDiscretion != null)
            msg.setField(FixTagConstants.TAGPeggedOrdDiscretion, peggedOrdDiscretion);
        msg.setField(Constants.TAGMinQty, "0");

//        //TODO:
//        msg.setField(FixTagConstants.TAGTimeInForce, "X");
//        msg.setField(FixTagConstants.TAGExpireSeconds, "5");
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);

    }

    public void unusedSubmitPeggedOrderReplace(String orderId, String onBehalfOf, String origClordId,
                                               String clOrdId, String symbol, String side, String currency,
                                               String ordQty, String ordType) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (orderId != null)
            msg.setField(Constants.TAGOrderID, orderId);
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        if (origClordId != null)
            msg.setField(Constants.TAGOrigClOrdID, origClordId);
        if (clOrdId != null)
            msg.setField(Constants.TAGClOrdID, clOrdId);
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        if (currency != null)
            msg.setField(Constants.TAGCurrency, currency);
        if (ordQty != null)
            msg.setField(Constants.TAGOrderQty, ordQty);
        if (ordType != null)
            msg.setField(Constants.TAGOrdType, ordType);
        msg.setField(Constants.TAGMinQty, "0");

//        //TODO:
//        msg.setField(FixTagConstants.TAGTimeInForce, "X");
//        msg.setField(FixTagConstants.TAGExpireSeconds, "5");
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);

    }

    public void unusedSubmitComplexOrderGTC(String clOrdId, String onBehalfOf, BigDecimal amount, String ccyPair,
                                            String orderType, String ifDoneIfType, String ifDoneIfSide, BigDecimal ifDoneIfStopRate, String ifDoneIfStopSide,
                                            String ifDoneThenType, String ifDoneThenSide, BigDecimal ifDoneThenStopRate, String ifDoneThenStopSide,
                                            BigDecimal ocoLeg1LimitRate, String ocoLeg2Type, String ocoLeg2Side, BigDecimal ocoLeg2StopRate, String ocoLeg2stopSide,
                                            String product, String ifDoneIfLimitRate, String positionId, BigDecimal ifDoneThenLimitRate) throws Exception {

        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        if (onBehalfOf != null) {
            msg.setField(Constants.TAGNoPartyIDs, "1");
            msg.addField(Constants.TAGPartyID, onBehalfOf);
            msg.addField(Constants.TAGPartyRole, "3");//client
        }
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSecurityType, "FOR");

        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());
        msg.setField(Constants.TAGOrdType, orderType);
        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        if (ocoLeg2Side != null)
            msg.setField(FixTagConstants.TAGSide, ocoLeg2Side);

        // If Leg
        if (ifDoneIfType != null) {
            msg.setField(FixTagConstants.TAGIFDIfType, ifDoneIfType);
            msg.setField(FixTagConstants.TAGSide, ifDoneIfSide);
            if (ifDoneIfStopRate != null)
                msg.setField(FixTagConstants.TAGIFDIfStopRate, ifDoneIfStopRate.toString());
            if (ifDoneIfStopSide != null)
                msg.setField(FixTagConstants.TAGStopSide, ifDoneIfStopSide);
            if (ifDoneIfLimitRate != null)
                msg.setField(FixTagConstants.TAGPrice, ifDoneIfLimitRate);
            // IfDoneThen side
            msg.setField(FixTagConstants.TAGIFDThenType, ifDoneThenType);
            msg.setField(FixTagConstants.TAGIFDThenSide, ifDoneThenSide);
            if (ifDoneThenStopRate != null)
                msg.setField(FixTagConstants.TAGIFDThenPrStopRate, ifDoneThenStopRate.toString());
            if (ifDoneThenStopSide != null)
                msg.setField(FixTagConstants.TAGIFDThenPrStopSide, ifDoneThenStopSide);
        }
        if (ocoLeg1LimitRate != null)
            msg.setField(FixTagConstants.TAGOCOLeg1LimitRate, ocoLeg1LimitRate.toString());
        if (ocoLeg2Type != null)
            msg.setField(FixTagConstants.TAGOCOLeg2Type, ocoLeg2Type);
        if (ocoLeg2Side != null)
            msg.setField(FixTagConstants.TAGOCOLeg2Side, ocoLeg2Side);
        if (ocoLeg2StopRate != null)
            msg.setField(FixTagConstants.TAGOCOLeg2StopRate, ocoLeg2StopRate.toString());
        if (ocoLeg2stopSide != null)
            msg.setField(FixTagConstants.TAGOCOLeg2StopSide, ocoLeg2stopSide);
        if (product != null)
            msg.setField(Constants.TAGProduct, product);
        if (positionId != null)
            msg.setField(Constants.TAGSecondaryClOrdID, positionId);
        if (ifDoneThenLimitRate != null)
            msg.setField(FixTagConstants.TAGIFDThenPrLimitRate, ifDoneThenLimitRate.toString());

        msg.setField(Constants.TAGTimeInForce,
                Constants.TIMEINFORCE_GoodTillCancel);

        msg.setField(Constants.TAGMinQty, "0");
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitMarketOrderWithSlippage(final String clientOrderID, BigDecimal slippage,
                                                    BigDecimal amount, String ccyPair, String buySell, int expirationType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(662, slippage.toString());
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGMinQty, "0"); // set min to zero allows
        // partial fills
        msg.setField(Constants.TAGSymbol, ccyPair);
        msg.setField(Constants.TAGSymbolSfx, "SP");
        msg.setField(Constants.TAGSecurityType, "FOR");

        //testing, remove
//        msg.setField("460", "4");
//        msg.setField("7567", "1");
//        msg.setField("7561", "mgfixhub-mgfixmaker");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount.toString());

        msg.setField(Constants.TAGOrdType, "T");

        msg.setField(Constants.TAGCurrency, ccyPair.split("/")[0]);
        msg.setField(Constants.TAGTimeInForce,
                expirationType);
        msg.setField(Constants.TAGMinQty, "0");
        System.out.println("The fix version is " + takerTestSession.getFixVersion());
        if (takerTestSession.getFixVersion().endsWith("4.4")) {
            msg.setField(Constants.TAGProduct, "4");
        }
        takerTestSession.orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitTreasuryOrderFundSub(String clientOrderID, String symbol, String symbolSfx,
                                                 BigDecimal limitRate, String ordType,
                                                 String orderQty, String fundSub, String buySell, String expType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());

        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);
        if (fundSub != null)
            msg.setField(Constants.TAGAccount, fundSub);

        msg.setField(Constants.TAGOrdType, ordType);
        if (limitRate != null)
            msg.setField(Constants.TAGPrice, limitRate.toString());
        if (expType != null)
            msg.setField(Constants.TAGTimeInForce, expType);
        takerTestSession.orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitTreasuryStopOrder(
            String account, String clientOrderID, String symbol, String symbolSfx,
            BigDecimal limitRate, String ordType,
            String orderQty, String buySell, String stopSide, BigDecimal stopPx, String expType) throws Exception {
        Message msg = new Message(Constants.MSGOrderSingle, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGClOrdID, clientOrderID); // required
        msg.setField(Constants.TAGHandlInst,
                Constants.HANDLINST_AutoPrivateNoBroker);
        msg.setField(Constants.TAGCurrency, "USD");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGSymbol, symbol);
        msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, orderQty);

        msg.setField(Constants.TAGOrdType, ordType);
        if (limitRate != null)
            msg.setField(Constants.TAGPrice, limitRate.toString());
        if (stopPx != null)
            msg.setField(Constants.TAGStopPx, stopPx.toString());
        if (stopSide != null)
            msg.setField(TakerTestSession.TAGStopSide, stopSide);
        if (expType != null)
            msg.setField(Constants.TAGTimeInForce, expType);
        if (account != null)
            msg.setField(Constants.TAGAccount, account);
        takerTestSession.orderMsgMap.put(clientOrderID, new ArrayBlockingQueue<Message>(100));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitDSMarketDataRequest(String requestId, String symbol,
                                                String symbolSfx, String aggregatedBook, String marketDepth, String subReqType) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (requestId != null)
            msg.setField(Constants.TAGMDReqID, requestId);
        if (subReqType != null)
            msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        if (marketDepth != null)
            msg.setField(Constants.TAGMarketDepth, marketDepth);
        if (subReqType != null && subReqType.equals("1"))
            msg.setField(Constants.TAGMDUpdateType, "1");
        if (aggregatedBook != null)
            msg.setField(Constants.TAGAggregatedBook, aggregatedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (symbolSfx != null)
            msg.setField(Constants.TAGSymbolSfx, symbolSfx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "MLEG");
        takerTestSession.getPriceMsgMap().put(requestId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitMarketDataUnsubscribeRequest(String requestId, String baseCurrencyCode,
                                                         String termsCurrencyCode, String aggregratedBook, String marketDepth) throws Exception {
        Message msg = new Message(Constants.MSGMarketDataRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (requestId != null)
            msg.setField(Constants.TAGMDReqID, requestId);
        msg.setField(Constants.TAGSubscriptionRequestType, Constants.SUBSCRIPTIONREQUESTTYPE_Unsubscribe);
        if (marketDepth != null)
            msg.setField(Constants.TAGMarketDepth, marketDepth);
        msg.setField(Constants.TAGMDUpdateType, Constants.MDUPDATETYPE_IncrementalRefresh);
        msg.setField(Constants.TAGAggregatedBook, aggregratedBook);
        msg.setField(Constants.TAGNoMDEntryTypes, 2);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Offer);
        msg.addField(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_Bid);
        msg.setField(Constants.TAGNoRelatedSym, 1);
        msg.setField(Constants.TAGSymbol, baseCurrencyCode + "/" + termsCurrencyCode);
        if (takerTestSession.getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGSymbolSfx, "SP");
        takerTestSession.getPriceMsgMap().put(requestId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitTickerMarketDataRequest(String requestId, String symbol) throws Exception {
        takerTestSession.submitTickerMarketDataRequest(requestId, "T", "1", "1", "1", "2", "1", symbol);
    }

    public void unusedSubmitCancelAllOrdersRequest() throws Exception {
        takerTestSession.submitOrderCancelRequest("OPEN ORDER", "OPEN ORDER", "origClientOrderId", takerTestSession.getUserName(), "F", "1", "EUR/USD");

    }

    public void unusedCancelAllOpenOrders(String symbol, String symbolsfx) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGOrderID, TakerTestSession.ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGClOrdID, TakerTestSession.ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGOrigClOrdID, "testorigClOrdId");
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGSymbol, symbol);
        if (symbolsfx != null)
            msg.setField(Constants.TAGSymbolSfx, symbolsfx);
        msg.setField(Constants.TAGProduct, "6");
        msg.setField(FixTagConstants.TAGOpenOrders, "Y");

        takerTestSession.sendFixMessage(msg);
    }

    public void unusedCancelAllOpenOrders() throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGOrigClOrdID, "testorigClOrdId");
        msg.setField(Constants.TAGOrderID, TakerTestSession.ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGClOrdID, TakerTestSession.ALL_OPEN_ORDERS);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(FixTagConstants.TAGOpenOrders, "Y");

        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitViewPartyLevelTrades() throws Exception {
        Message msg = new Message("U11", takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGMDReqID, "test1234");
        msg.setField(Constants.TAGSubscriptionRequestType, "1");
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitMassOrderStatusRequestForOneUser(String massStatusReqId, String massStatusReqType,
                                                             String userID, Date transactTime) throws Exception {
        Message msg = new Message(Constants.MSGOrderMassStatusRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (massStatusReqId != null)
            msg.setField(Constants.TAGMassStatusReqID, massStatusReqId);
        if (massStatusReqType != null)
            msg.setField(Constants.TAGMassStatusReqType, massStatusReqType);
        if (userID != null) {
            Group g = new Group(FixTagConstants.TAGNoPartyIDs, FixTagConstants.TAGPartyID);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyID, userID);
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGPartyRole, "3");
        }
        if (transactTime != null)
            msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(transactTime));
        if (takerTestSession.getFixVersion().endsWith("4.4"))
            msg.setField(Constants.TAGProduct, "4");
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitRetailOrderStatusRequest(String orderId, String clOrdId, String symbol,
                                                     String side, String ordType, String openOrders) throws Exception {
        Message msg = new Message(Constants.MSGOrderStatusRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (orderId != null)
            msg.setField(Constants.TAGOrderID, orderId);
        if (clOrdId != null)
            msg.setField(Constants.TAGClOrdID, clOrdId);
        if (symbol != null)
            msg.setField(Constants.TAGSymbol, symbol);
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        if (ordType != null)
            msg.setField(Constants.TAGOrdType, ordType);
        if (openOrders != null)
            msg.setField(FixTagConstants.TAGOpenOrders, openOrders);
        msg.setField(Constants.TAGProduct, "4");
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitDSOrderReplace(String orderId, String clOrdId, String origClOrdId, String symbol, String symbolFx,
                                           String buySell, String amount, String orderType, String price, String stopPx, String minQty, String onBehalf) throws Exception {
        Message msg = new Message(Constants.MSGOrderCancelReplaceRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGOrderID, orderId); // required
        msg.setField(Constants.TAGOrigClOrdID, origClOrdId); // required
        msg.setField(Constants.TAGClOrdID, clOrdId); // required
        msg.setField(Constants.TAGHandlInst, Constants.HANDLINST_AutoPublicBrokerOK);

        msg.setField(Constants.TAGSymbol, symbol);
        if (symbolFx != null)
            msg.setField(Constants.TAGSymbolSfx, symbolFx);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "MLEG");
        msg.setField(Constants.TAGSide, buySell);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        msg.setField(Constants.TAGOrderQty, amount);
        msg.setField(Constants.TAGOrdType, orderType);
        if (price != null)
            msg.setField(Constants.TAGPrice, price);
        if (stopPx != null)
            msg.setField(Constants.TAGStopPx, stopPx);
        if (minQty != null)
            msg.setField(Constants.TAGMinQty, minQty);
        if (null != onBehalf) {
            if (takerTestSession.getFixVersion().endsWith("4.4")) {
                msg.setField(Constants.TAGNoPartyIDs, "1");
                msg.addField(Constants.TAGPartyID, onBehalf);
                msg.addField(Constants.TAGPartyRole, "3");//client
            } else {
                msg.setField(Constants.TAGClientID, onBehalf);
            }
        }
        takerTestSession.orderMsgMap.put(clOrdId, new ArrayBlockingQueue<Message>(6000));
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitRequestForPositions(String posReqId, int posReqType, int subReqType, String account, String clearingBusinessDate) throws Exception {
        Message msg = new Message(Constants.MSGRequestForPositions, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(Constants.TAGPosReqID, posReqId);
        msg.setField(Constants.TAGPosReqType, posReqType);
        msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        msg.setField(Constants.TAGNoPartyIDs, 1);
        msg.setField(Constants.TAGPartyID, account);
        msg.setField(Constants.TAGPartyRole, 3);
        msg.setField(Constants.TAGAccount, account);
        msg.setField(Constants.TAGAccountType, 1);
        if (clearingBusinessDate != null)
            msg.setField(Constants.TAGClearingBusinessDate, clearingBusinessDate);
        msg.setField(Constants.TAGTransactTime, takerTestSession.getDateFormat().format(new Date()));
        takerTestSession.sendFixMessage(msg);
    }//we don't support collateral inquiry any more!

    public void unusedSubmitRetailCollateralInquiry(String requestId, String subReqType,
                                                    String startDate) throws Exception {
        Message msg = new Message(Constants.MSGCollateralInquiry, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (requestId != null)
            msg.setField(Constants.TAGCollInquiryID, requestId);
        if (subReqType != null)
            msg.setField(Constants.TAGSubscriptionRequestType, subReqType);
        if (startDate != null)
            msg.setField(Constants.TAGClearingBusinessDate, startDate);
        takerTestSession.sendFixMessage(msg);
    }

    /**
     * Submit a quote request for RFS trading
     *
     * @throws Exception
     */
    public void unusedSubmitQuoteRequestRFQ(String requestId, String noRelatedSym, String symbol,
                                            String side, String orderQty, String valueDt, String account, String currency,
                                            String bank1
    ) throws Exception {

        Message msg = takerTestSession.submitQuoteRequestRFQHelper(requestId, null, noRelatedSym, symbol,
                side, orderQty, valueDt, account, currency);

//        Message msg = new Message(Constants.MSGQuoteRequest,m_senderCompId, m_targetCompId, fix_version);
//        if(requestId!=null)
//            msg.setField(Constants.TAGQuoteReqID, requestId);
//        if(noRelatedSym!=null)
//            msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
//        if(symbol!=null)
//            msg.addField(Constants.TAGSymbol, symbol);
//        if(side!=null)
//            msg.addField(Constants.TAGSide, side);
//        if(orderQty!=null)
//            msg.addField(Constants.TAGOrderQty, orderQty);
//        if(valueDt!=null)
//        msg.addField(Constants.TAGFutSettDate, valueDt);
//        if(currency!=null)
//            msg.addField(Constants.TAGCurrency, currency);

        if (account != null)
            msg.setField(Constants.TAGAccount, account);
//        msg.addField(Constants.TAGSymbol, symbol);
//        msg.addField(Constants.TAGSide, side);
//        msg.addField(Constants.TAGOrderQty, orderQty);
//        msg.addField(Constants.TAGFutSettDate, valueDt);
//        msg.addField(Constants.TAGCurrency, currency);

        if (bank1 != null) {
            Group g = new Group(FixTagConstants.TAGNoBrokerMatchIDs, FixTagConstants.TAGBrokerMatchID);
            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, "1");
            msg.getBuilder().setGroupData(g, FixTagConstants.TAGBrokerMatchID, bank1);
        }
//        if(numBanks!=null)
//            msg.setField(FixTagConstants.TAGNoBrokerMatchIDs, numBanks);
//        if(bank1!=null)
//            msg.addField(FixTagConstants.TAGBrokerMatchID, bank1);
//        if(bank2!=null)
//            msg.addField(FixTagConstants.TAGBrokerMatchID, bank2);
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSubmitQuoteRequestIRSwapRFQ(String requestId, String originCode, String cti, String zcode,
                                                  String effectiveDate, String maturityDate, String side, String orderQty, String account, String priceType)
            throws Exception {
        Message msg = new Message(Constants.MSGQuoteRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if (requestId != null)
            msg.setField(Constants.TAGQuoteReqID, requestId);
        if (originCode != null)
            msg.setField(Constants.TAGOrderCapacity, originCode);
        if (cti != null)
            msg.setField(Constants.TAGCustOrderCapacity, cti);
        msg.setField(Constants.TAGNoRelatedSym, "1");
        msg.setField(Constants.TAGSymbol, "NA");
        if (zcode != null)
            msg.setField(Constants.TAGSecurityID, zcode);
        msg.setField(Constants.TAGProduct, "12");
        msg.setField(Constants.TAGSecurityType, "IRS");
        if (effectiveDate != null)
            msg.setField(Constants.TAGInterestAccrualDate, effectiveDate);
        if (maturityDate != null)
            msg.setField(Constants.TAGMaturityDate, maturityDate);
        msg.setField(Constants.TAGNoUnderlyings, "2");
        msg.addField(Constants.TAGUnderlyingSymbol, "NA");
        msg.addField(Constants.TAGUnderlyingCreditRating, "30/360");
        msg.addField(Constants.TAGUnderlyingSecurityDesc, "MODFOLLOWING");
        msg.addField(Constants.TAGUnderlyingCPProgram, "6M");
        msg.addField(Constants.TAGUnderlyingCPRegType, "FIXED");
        msg.addField(Constants.TAGUnderlyingCurrency, "USD");
        msg.addField(Constants.TAGUnderlyingSymbol, "NA");
        msg.addField(Constants.TAGUnderlyingCreditRating, "ACT/360");
        msg.addField(Constants.TAGUnderlyingSecurityDesc, "MODFOLLOWING");
        msg.addField(Constants.TAGUnderlyingCPProgram, "3M");
        msg.addField(Constants.TAGUnderlyingCPRegType, "FLOAT");
        msg.addField(Constants.TAGUnderlyingCurrency, "USD");
        msg.setField(Constants.TAGQuoteType, "1");
        if (side != null)
            msg.setField(Constants.TAGSide, side);
        if (orderQty != null)
            msg.setField(Constants.TAGOrderQty, orderQty);
        if (account != null)
            msg.setField(Constants.TAGAccount, account);
        if (priceType != null)
            msg.setField(Constants.TAGPriceType, priceType);
        takerTestSession.sendFixMessage(msg);
    }

    public void unusedSendBusinessMessageRejectDEV20193() throws Exception {

        Message msg = new Message(Constants.MSGBusinessMessageReject, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        msg.setField(372, "U10");
        msg.setField(380, 0);

        takerTestSession.sendFixMessage(msg);
    }

    public void submitQuoteRequestRFQ(String requestId, String noRelatedSym, String symbol,
                                      String side, String orderQty, String valueDt, String account, String currency,
                                      String valueDt2
    ) throws Exception
    {
        Message msg = new Message(Constants.MSGQuoteRequest, takerTestSession.getSenderCompId(), takerTestSession.getTargetCompId(), takerTestSession.getFixVersion());
        if(requestId!=null)
            msg.setField(Constants.TAGQuoteReqID, requestId);
        if(noRelatedSym!=null)
            msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        if(noRelatedSym!=null)
            msg.setField(Constants.TAGNoRelatedSym, noRelatedSym);
        if(symbol!=null)
//            msg.setField(Constants.TAGSymbol, symbol);
            msg.addField(Constants.TAGSymbol, symbol);
        if(side!=null)
//            msg.setField(Constants.TAGSide, side);
            msg.addField(Constants.TAGSide, side);
        if(orderQty!=null)
        {
//            msg.setField(Constants.TAGOrderQty, orderQty);
            msg.addField(Constants.TAGOrderQty, orderQty);
            msg.addField(Constants.TAGOrderQty2, orderQty);
        }
        if(valueDt!=null)
//            msg.setField(Constants.TAGFutSettDate, valueDt);
            msg.addField(Constants.TAGFutSettDate, valueDt);
        if(valueDt2!=null)
//          msg.setField(Constants.TAGFutSettDate2, valueDt2);
            msg.addField(Constants.TAGFutSettDate2, valueDt2);
        if(currency!=null)
//            msg.setField(Constants.TAGCurrency, currency);
            msg.addField(Constants.TAGCurrency, currency);

        if(account != null)
            msg.setField(Constants.TAGAccount, account);
//        msg.addField(Constants.TAGSymbol, symbol);
//        msg.addField(Constants.TAGSide, side);
//        msg.addField(Constants.TAGOrderQty, orderQty);
//        msg.addField(Constants.TAGOrderQty2, orderQty);
//        msg.addField(Constants.TAGFutSettDate, valueDt);
//        msg.addField(Constants.TAGFutSettDate2, valueDt2);
//        msg.addField(Constants.TAGCurrency, currency);
        takerTestSession.sendFixMessage(msg);
    }

}
