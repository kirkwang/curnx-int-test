package currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.messageType;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.*;

public class NewOrderAck {
    
    private int clOrdId;
    private long orderid;
    private char status;
    private short errorCode;
    
    public NewOrderAck(int clOrdId, long orderid, char status,
            short errorCode) {
        super();
        this.clOrdId = clOrdId;
        this.orderid = orderid;
        this.status = status;
        this.errorCode = errorCode;
    }

    public int getClOrdId() {
        return clOrdId;
    }

    public void setClOrdId(int clOrdId) {
        this.clOrdId = clOrdId;
    }

    public long getOrderid() {
        return orderid;
    }

    public void setOrderid(long orderid) {
        this.orderid = orderid;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public short getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(short errorCode) {
        this.errorCode = errorCode;
    }
    
    public void doAssert(int clOrdId, char status, short errorCode) throws Exception{
        System.out.println("Validating NewOrderAck:");
        
        validateFieldLong(FIELD_CLORDERID, clOrdId, this.clOrdId);
        validateFieldNotNull(FIELD_ORDERID, Long.toString(this.orderid));
        validateFieldChar(FIELD_STATUS, status, this.status);
        validateFieldLong(FIELD_TYPE, errorCode, this.errorCode);
    }
    
    @Override
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append("NewOrderAck:");
        sb.append(" ClOrderID="+clOrdId);
        sb.append(", OrderID="+orderid);
        sb.append(", Status="+status);
        sb.append(", ErrorCode="+errorCode);
        
        return sb.toString();
    }

}
