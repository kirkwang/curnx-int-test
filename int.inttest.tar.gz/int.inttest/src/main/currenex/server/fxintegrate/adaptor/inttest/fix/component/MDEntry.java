package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class MDEntry {
    
    //from outside of MDEntry
    private String mdReqId;
    
    private String MDUpdateAction;
    private String deleteReason;
    private String MDEntryType;
    private String MDEntryID;
    private String symbol;
    private String symbolSfx; 
    private String securityType;
    private String MDEntryOriginator;
    private String MDEntryPx;
    private String currency;
    private String MDEntrySize;
    private String minQty;
    private String numberOfOrders;
    private String text;
    private String venueType;
    private String MDQuoteType;
    
    public String getMDUpdateAction() {
        return MDUpdateAction;
    }
    public void setMDUpdateAction(String mDUpdateAction) {
        MDUpdateAction = mDUpdateAction;
    }
    public String getDeleteReason() {
        return deleteReason;
    }
    public void setDeleteReason(String deleteReason) {
        this.deleteReason = deleteReason;
    }
    public String getMDEntryType() {
        return MDEntryType;
    }
    public void setMDEntryType(String mDEntryType) {
        MDEntryType = mDEntryType;
    }
    public String getMDEntryID() {
        return MDEntryID;
    }
    public void setMDEntryID(String mDEntryID) {
        MDEntryID = mDEntryID;
    }
    public String getSymbol() {
        return symbol;
    }
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
    public String getSymbolSfx() {
        return symbolSfx;
    }
    public void setSymbolSfx(String symbolSfx) {
        this.symbolSfx = symbolSfx;
    }
    public String getSecurityType() {
        return securityType;
    }
    public void setSecurityType(String securityType) {
        this.securityType = securityType;
    }
    public String getMDEntryOriginator() {
        return MDEntryOriginator;
    }
    public void setMDEntryOriginator(String mDEntryOriginator) {
        MDEntryOriginator = mDEntryOriginator;
    }
    public String getMDEntryPx() {
        return MDEntryPx;
    }
    public void setMDEntryPx(String mDEntryPx) {
        MDEntryPx = mDEntryPx;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getMDEntrySize() {
        return MDEntrySize;
    }
    public void setMDEntrySize(String mDEntrySize) {
        MDEntrySize = mDEntrySize;
    }
    public String getMinQty() {
        return minQty;
    }
    public void setMinQty(String minQty) {
        this.minQty = minQty;
    }
    public String getNumberOfOrders() {
        return numberOfOrders;
    }
    public void setNumberOfOrders(String numberOfOrders) {
        this.numberOfOrders = numberOfOrders;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
    public String getVenueType() {
        return venueType;
    }
    public String getMDQuoteType() {
        return MDQuoteType;
    }
    public void setMDQuoteType(String mDQuoteType) {
        MDQuoteType = mDQuoteType;
    }
    public String getMdReqId() {
        return mdReqId;
    }
    public void setMdReqId(String mdReqId) {
        this.mdReqId = mdReqId;
    }
    public void setVenueType(String venueType) {
        this.venueType = venueType;
    }

}
