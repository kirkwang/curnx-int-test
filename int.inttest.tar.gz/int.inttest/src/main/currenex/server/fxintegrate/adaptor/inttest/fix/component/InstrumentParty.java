package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class InstrumentParty {
    
    public final String instrumentPartyID;
    public final String instrumentPartyIDSource;
    public final String instrumentPartyRole;
    
    public InstrumentParty(String instrumentPartyID, String instrumentPartyIDSource,
            String instrumentPartyRole){
        this.instrumentPartyID = instrumentPartyID;
        this.instrumentPartyIDSource = instrumentPartyIDSource;
        this.instrumentPartyRole = instrumentPartyRole;
    }

}
