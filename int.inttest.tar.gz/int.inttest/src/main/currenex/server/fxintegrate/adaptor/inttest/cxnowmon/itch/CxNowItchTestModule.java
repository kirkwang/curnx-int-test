package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import static com.google.inject.name.Names.named;
import static currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch.CxNowItchTestRunner.SubscriptionType.*;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Semaphore;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Named;
import com.google.inject.name.Names;
import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch.CxNowItchTestRunner.SubscriptionType;
import currenex.server.fxintegrate.adaptor.inttest.govexItch.ItchEncoder;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.MsgHandler;
import currenex.util.threadpool.ThreadPoolModule;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandler;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.ChannelUpstreamHandler;
import org.jboss.netty.channel.socket.nio.NioDatagramChannelFactory;

public class CxNowItchTestModule extends AbstractModule {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchTestModule.class);
    private final JsonObject properties;

    public CxNowItchTestModule(String filePath) throws IOException {
        String rawJson = Files.toString(new File(filePath), Charsets.UTF_8);
        properties = new JsonParser().parse(rawJson).getAsJsonObject();
    }

    @Override
    protected void configure() {
        install(new ThreadPoolModule());

        bind(ClientBootstrap.class).toInstance(new ClientBootstrap(new NioDatagramChannelFactory()));
        bind(ChannelFutureListener.class).to(CxNowItchChannelListener.class);
        bind(ChannelPipelineFactory.class).to(CxNowItchPipelineFactory.class);

        bind(ChannelHandler.class).annotatedWith(named("encoder")).toInstance(new ItchEncoder());
        bind(ChannelHandler.class).annotatedWith(named("frameDecoder")).toInstance(new ItchTestFrameDecoder());
        bind(ChannelUpstreamHandler.class).annotatedWith(named("handler")).to(ItchTestDecoder.class);

        bind(Semaphore.class).annotatedWith(named("testFinished")).toInstance(new Semaphore(1));
        bind(MsgHandler.class).toInstance(new MsgHandler());

        bind(ItchMsgHandler.class).to(CxNowItchTestRunner.class);
        bind(ItchMsgSender.class).to(CxNowItchMsgSender.class);

        bind(new TypeLiteral<CompletableFuture<Boolean>>(){})
                .annotatedWith(Names.named("connectionFuture"))
                .toInstance(new CompletableFuture<>());

        bind(new TypeLiteral<CompletableFuture<Boolean>>(){})
                .annotatedWith(Names.named("loginFuture"))
                .toInstance(new CompletableFuture<>());
    }

    @Provides
    public SocketAddress remoteAddress() {
        String host = properties.get("host").getAsString();
        int port = properties.get("port").getAsInt();
        return new InetSocketAddress(host, port);
    }

    @Provides @Named("username")
    public String getUsername() {
        return properties.get("username").getAsString();
    }

    @Provides @Named("password")
    public String getPassword() {
        return properties.get("password").getAsString();
    }

    @Provides @Named("listenMillis")
    public long getListenMillis() {
        return properties.get("listenMillis").getAsLong();
    }

    @Provides @Named("instruments")
    public List<String> getInstruments() {
        List<String> instruments = new ArrayList<>();
        properties.get("instruments").getAsJsonArray().forEach(element -> instruments.add(element.getAsString()));
        return instruments;
    }

    @Provides @Named("resultsFile")
    public File getResultsFile() {
        return new File(properties.get("resultsFile").getAsString());
    }

    @Provides @Named("writeIntervalMillis")
    public long getWriteIntervalMillis() {
        return properties.get("writeIntervalMillis").getAsLong();
    }

    @Provides @Named("subscriptions")
    public Map<SubscriptionType, Boolean> getSubscriptions() {
        JsonObject jsonSubs = properties.get("subscriptions").getAsJsonObject();

        Map<SubscriptionType, Boolean> subscriptions = new EnumMap<>(SubscriptionType.class);
        subscriptions.put(DEPTH_OF_BOOK, jsonSubs.get("depthOfBook").getAsBoolean());
        subscriptions.put(TICKER, jsonSubs.get("ticker").getAsBoolean());
        subscriptions.put(WAMR, jsonSubs.get("wamr").getAsBoolean());
        subscriptions.put(MID, jsonSubs.get("mid").getAsBoolean());
        return subscriptions;
    }
}
