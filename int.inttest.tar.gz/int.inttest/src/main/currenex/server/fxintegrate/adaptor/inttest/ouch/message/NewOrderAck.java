package currenex.server.fxintegrate.adaptor.inttest.ouch.message;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.*;
import static org.junit.Assert.assertEquals;

import currenex.server.fxintegrate.adaptor.ouchtwo.taker.TakerErrorCode;

public class NewOrderAck {
    
    private int clOrdId;
    private long orderId;
    private char status;
    private TakerErrorCode errorCode;
    
    public NewOrderAck(int clOrdId, long orderId, char status, short errorCode) {
        this.clOrdId = clOrdId;
        this.orderId = orderId;
        this.status = status;
        this.errorCode = TakerErrorCode.of(errorCode);
    }

    public long getOrderId() {
        return orderId;
    }

    public void doAssert(int clOrdId, char status, TakerErrorCode errorCode) throws Exception{
        System.out.println("Validating NewOrderAck:");
        
        validateFieldLong(FIELD_CLORDERID, clOrdId, this.clOrdId);
        validateFieldNotNull(FIELD_ORDERID, Long.toString(this.orderId));
        validateFieldChar(FIELD_STATUS, status, this.status);
        assertEquals("errorCode", errorCode, this.errorCode);
    }
    
    @Override
    public String toString(){
        return "NewOrderAck:" +
                " ClOrderID=" + clOrdId +
                ", OrderID=" + orderId +
                ", Status=" + status +
                ", ErrorCode=" + errorCode;
    }
}
