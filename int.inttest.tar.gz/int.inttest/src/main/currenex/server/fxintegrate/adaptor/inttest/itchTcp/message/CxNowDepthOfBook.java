package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class CxNowDepthOfBook {
    
    
    private short instrIndex;
    private long priceId;
    private int[] bidRates;
    private long[] bidAmounts;
    private int[] offerRates;
    private long[] offerAmounts;
    
    public CxNowDepthOfBook(short instrIndex, long priceId,
            int[] bidRates, long[] bidAmounts, int[] offerRates, long[] offerAmounts) {
        super();
        this.instrIndex = instrIndex;
        this.priceId = priceId;
        this.bidRates = bidRates;
        this.bidAmounts = bidAmounts;
        this.offerRates = offerRates;
        this.offerAmounts = offerAmounts;
    }

    public short getInstrIndex() {
        return instrIndex;
    }

    public void setInstrIndex(short instrIndex) {
        this.instrIndex = instrIndex;
    }

    public long getPriceId() {
        return priceId;
    }

    public void setPriceId(long priceId) {
        this.priceId = priceId;
    }

    public int[] getBidRates() {
        return bidRates;
    }

    public void setBidRates(int[] bidRates) {
        this.bidRates = bidRates;
    }

    public int[] getOfferRates() {
        return offerRates;
    }

    public void setOfferRates(int[] offerRates) {
        this.offerRates = offerRates;
    }

    public long[] getBidAmounts() {
        return bidAmounts;
    }

    public void setBidAmounts(long[] bidAmounts) {
        this.bidAmounts = bidAmounts;
    }

    public long[] getOfferAmounts() {
        return offerAmounts;
    }

    public void setOfferAmounts(long[] offerAmounts) {
        this.offerAmounts = offerAmounts;
    }
    
    

}
