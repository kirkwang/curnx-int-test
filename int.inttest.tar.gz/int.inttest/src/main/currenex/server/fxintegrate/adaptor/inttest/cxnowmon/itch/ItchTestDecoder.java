package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import static java.nio.ByteOrder.BIG_ENDIAN;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;

import com.google.inject.Inject;
import com.google.inject.assistedinject.Assisted;
import currenex.log.jdk.CxLogger;
import currenex.util.threadpool.RunnableQueue;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.handler.codec.oneone.OneToOneDecoder;

public class ItchTestDecoder extends OneToOneDecoder {
    private static final CxLogger log = CxLogger.getCxLogger(ItchTestDecoder.class);
    private final RunnableQueue runnableQueue = RunnableQueue.newNamedThreadPoolQueue("CxNowItchTestDecoder");
    private final ItchMsgHandler msgHandler;
    private AtomicInteger inboundSeq = new AtomicInteger(0);

    public interface Factory {
        ItchTestDecoder create(ItchMsgHandler msgHandler);
    }

    @Inject ItchTestDecoder(@Assisted ItchMsgHandler msgHandler) {
        this.msgHandler = msgHandler;
    }

    @Override protected Object decode(ChannelHandlerContext ctx, Channel channel, Object msg) throws Exception {
        if (!(msg instanceof ItchTestFrameDecoder.DecodedFrame)) {
            log.warning("Requires a decoded frame object to decode, ignoring");
            return msg;
        }

        ItchTestFrameDecoder.DecodedFrame decodedFrame = (ItchTestFrameDecoder.DecodedFrame) msg;

        long microTime = decodedFrame.getMicroInstant().toMicros();
        ByteBuffer buffer = decodedFrame.getBuffer().toByteBuffer().order(BIG_ENDIAN);

        byte start = buffer.get();
        if (start != 0b01) log.infof("Expected start of header (0b01), got %b", start);

        int seqNo = buffer.getInt();
        int msgTime = buffer.getInt();
        char msgType = (char) buffer.get();

        if (seqNo != inboundSeq.incrementAndGet()) log.finef("Expected inboundSeq=%d, got %d", inboundSeq.get(), seqNo);

        runnableQueue.execute(() -> {
            try {
                msgHandler.handleMsg(buffer, msgType, microTime, msgTime);
            } catch (Exception e) {
                log.log(Level.SEVERE, "Error thrown handling msg", e);
            }
        });

        return msg;
    }
}
