package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import static java.nio.ByteOrder.BIG_ENDIAN;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;

import com.google.inject.Inject;
import currenex.log.jdk.CxLogger;
import currenex.util.threadpool.RunnableQueue;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.handler.codec.oneone.OneToOneDecoder;

public class CxNowItchTestDecoder extends OneToOneDecoder {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchTestDecoder.class);
    private final RunnableQueue runnableQueue = RunnableQueue.newNamedThreadPoolQueue("CxNowItchTestDecoder");
    private final CxNowItchTestRunner testRunner;
    private AtomicInteger inboundSeq = new AtomicInteger(0);

    @Inject CxNowItchTestDecoder(CxNowItchTestRunner testRunner) {
        this.testRunner = testRunner;
    }

    @Override protected Object decode(ChannelHandlerContext ctx, Channel channel, Object msg) throws Exception {
        if (!(msg instanceof CxNowItchFrameDecoder.DecodedFrame)) {
            log.warning("Requires a decoded frame object to decode, ignoring");
            return msg;
        }

        CxNowItchFrameDecoder.DecodedFrame decodedFrame = (CxNowItchFrameDecoder.DecodedFrame) msg;

        long microTime = decodedFrame.getMicroInstant().toMicros();
        ByteBuffer buffer = decodedFrame.getBuffer().toByteBuffer().order(BIG_ENDIAN);

        byte start = buffer.get();
        if (start != 0b01) log.infof("Expected start of header (0b01), got %b", start);

        int seqNo = buffer.getInt();
        int msgTime = buffer.getInt();
        char msgType = (char) buffer.get();

        log.infof("Incoming: seqNo=%d, timestamp=%d, msgType=%c", seqNo, msgTime, msgType);
        if (seqNo != inboundSeq.incrementAndGet()) log.finef("Expected inboundSeq=%d, got %d", inboundSeq.get(), seqNo);

        runnableQueue.execute(() -> {
            try {
                testRunner.handleMsg(buffer, msgType, microTime, msgTime);
            } catch (Exception e) {
                log.log(Level.SEVERE, "Error thrown handling msg", e);
            }
        });

        return msg;
    }
}
