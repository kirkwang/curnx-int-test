package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.fix;

import static com.google.inject.name.Names.named;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Semaphore;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import currenex.util.threadpool.ThreadPoolModule;
import org.apache.commons.io.FileUtils;
import quickfix.Application;
import quickfix.ConfigError;
import quickfix.DefaultMessageFactory;
import quickfix.FileStoreFactory;
import quickfix.Initiator;
import quickfix.MessageFactory;
import quickfix.MessageStoreFactory;
import quickfix.SessionSettings;
import quickfix.ThreadedSocketInitiator;

public class CxNowFixTestModule extends AbstractModule {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowFixTestModule.class);
    private final String propertiesFile;

    public CxNowFixTestModule(String propertiesFile) {
        this.propertiesFile = propertiesFile;
    }

    @Override protected void configure() {
        install(new ThreadPoolModule());

        bind(Application.class).to(CxNowFixTestApplication.class);
        bind(MessageFactory.class).toInstance(new DefaultMessageFactory());
        bind(Semaphore.class).annotatedWith(named("testFinished")).toInstance(new Semaphore(1));
    }

    @Provides SessionSettings getSessionSettings() {
        try {
            return new SessionSettings(propertiesFile);
        } catch (ConfigError configError) {
            log.warning("Unable to initialize session settings");
            throw new IllegalStateException(configError.getMessage());
        }
    }

    @Provides static MessageStoreFactory getMessageStoreFactory(SessionSettings sessionSettings) {
        return new FileStoreFactory(sessionSettings);
    }

    @Provides
    static Initiator getThreadedSocketInitiator(Application application, MessageStoreFactory messageStoreFactory,
            SessionSettings settings, MessageFactory messageFactory) {
        try {
            return new ThreadedSocketInitiator(application, messageStoreFactory, settings, messageFactory);
        } catch (ConfigError configError) {
            log.warning("Unable to initialize threaded socket initiator");
            throw new IllegalStateException(configError.getMessage());
        }
    }

    @Provides Properties getProperties() {
        try {
            Properties properties = new Properties();
            properties.load(FileUtils.openInputStream(new File(propertiesFile)));
            return properties;
        } catch (Exception e) {
            throw new IllegalStateException(e.getMessage());
        }
    }

    @Provides @Named("password")
    static String getPassword(Properties properties) {
        return properties.getProperty("password");
    }

    @Provides @Named("instruments")
    static List<String> getInstruments(Properties properties) {
        return Arrays.asList(properties.getProperty("instruments").split(","));
    }

    @Provides @Named("subscriptions")
    static Map<Character, Boolean> getSubscriptions(Properties properties) {
        return ImmutableMap.of('b', Boolean.parseBoolean(properties.getProperty("subscribeDepthOfBook", "true")),
                't', Boolean.parseBoolean(properties.getProperty("subscribeTicker", "true")),
                'w', Boolean.parseBoolean(properties.getProperty("subscribeWamr", "true")),
                'm', Boolean.parseBoolean(properties.getProperty("subscribeMid", "true")));
    }

    @Provides @Named("listenMillis")
    static int getListenMillis(Properties properties) {
        return Integer.parseInt(properties.getProperty("listenMillis"));
    }

    @Provides @Named("resultsFile")
    static File getResultsFile(Properties properties) {
        return new File(properties.getProperty("resultsFile"));
    }

    @Provides @Named("writeIntervalMillis")
    static long getWriteIntervalMillis(Properties properties) {
        return Long.parseLong(properties.getProperty("writeIntervalMillis"));
    }
}
