package currenex.server.fxintegrate.adaptor.inttest.fix.component;

public class MDEntryForTicker extends MDEntry{
    
    private String securityID;
    private String securityIDSource;
    private String product;
    private String maturityDate;
    private String issueDate;
    private String couponRate;
    private String datedDate;
    private String interestAccrualDate;
    private String transacTime;
    private String lastParPrice;
    public String getSecurityID() {
        return securityID;
    }
    public void setSecurityID(String securityID) {
        this.securityID = securityID;
    }
    public String getSecurityIDSource() {
        return securityIDSource;
    }
    public void setSecurityIDSource(String securityIDSource) {
        this.securityIDSource = securityIDSource;
    }
    public String getProduct() {
        return product;
    }
    public void setProduct(String product) {
        this.product = product;
    }
    public String getMaturityDate() {
        return maturityDate;
    }
    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }
    public String getIssueDate() {
        return issueDate;
    }
    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }
    public String getCouponRate() {
        return couponRate;
    }
    public void setCouponRate(String couponRate) {
        this.couponRate = couponRate;
    }
    public String getDatedDate() {
        return datedDate;
    }
    public void setDatedDate(String datedDate) {
        this.datedDate = datedDate;
    }
    public String getInterestAccrualDate() {
        return interestAccrualDate;
    }
    public void setInterestAccrualDate(String interestAccrualDate) {
        this.interestAccrualDate = interestAccrualDate;
    }
    public String getTransacTime() {
        return transacTime;
    }
    public void setTransacTime(String transacTime) {
        this.transacTime = transacTime;
    }
    public String getLastParPrice() {
        return lastParPrice;
    }
    public void setLastParPrice(String lastParPrice) {
        this.lastParPrice = lastParPrice;
    }
    
    

}
