package currenex.server.fxintegrate.adaptor.inttest.fix.messages;

import java.util.ArrayList;

import currenex.server.fxintegrate.adaptor.inttest.fix.Message;

/**
 * Created by dzhu on 3/15/17.
 */

public class Party extends Object{

    public final String partyID;//448
    public final String partyIDSource;//447
    public final String partyRole;//452



    public Party(String partyID, String partyIDSource, String partyRole){
        this.partyID = partyID;
        this.partyIDSource = partyIDSource;
        this.partyRole = partyRole;
    }

    public Party(String id, String role){
        this.partyID = id;
        this.partyIDSource = null;
        this.partyRole = role;
    }

    public String getPartyID(){
        return partyID;
    }
    public String getPartyIDSource(){
        return partyIDSource;
    }
    public String getPartyRole(){
        return partyRole;
    }

    public static Party[] buildParties(Message msg){
        if(msg==null) return null;
        String strMsg = msg.toString();
        if(strMsg.length()==0) return null;
        ArrayList<Party> arrlist = new ArrayList<>();
        int pos448 = strMsg.indexOf("448=");
        if(pos448<=0) return null;
        while(pos448>0){
            String sPartyId = strMsg.substring(pos448 + 4, strMsg.indexOf("|", pos448));
            int pos447 = strMsg.indexOf("447=", pos448);
            String sPartyIdSource = pos447<0?null:(strMsg.substring(pos447+4, strMsg.indexOf("|", pos447)));
            int pos452 = strMsg.indexOf("452=", pos448);
            String sPartyRole = pos452<0?null:(strMsg.substring(pos452+4, strMsg.indexOf("|", pos452)));

            arrlist.add(new Party(sPartyId, sPartyIdSource, sPartyRole));

            pos448 =  strMsg.indexOf("448=", pos448+4);
        }
        return arrlist.toArray(new Party[0]);
    }

    public String toString(){
        return "partyID="+partyID+" partyIDSource="+partyIDSource+" partyRole="+partyRole;
    }

    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null) return false;
        if(getClass()!=o.getClass()) return false;
        Party p = (Party)o;
        return (p.partyID!=null?p.partyID.equals(this.partyID):this.partyID==null) &&
               (p.partyIDSource!=null?p.partyIDSource.equals(this.partyIDSource):this.partyIDSource==null) &&
               (p.partyRole!=null?p.partyRole.equals(this.partyRole):this.partyRole==null);
    }

}
