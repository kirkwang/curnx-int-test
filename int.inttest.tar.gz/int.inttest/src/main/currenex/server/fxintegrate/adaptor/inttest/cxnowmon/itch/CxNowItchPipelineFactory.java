package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import org.jboss.netty.channel.ChannelHandler;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.ChannelUpstreamHandler;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.handler.codec.frame.FrameDecoder;

public class CxNowItchPipelineFactory implements ChannelPipelineFactory {
    private final ChannelHandler encoder;
    private final ChannelHandler frameDecoder;
    private final ChannelUpstreamHandler handler;

    @Inject
    CxNowItchPipelineFactory(@Named("encoder") ChannelHandler encoder,
                             @Named("frameDecoder") ChannelHandler frameDecoder,
                             @Named("handler") ChannelUpstreamHandler handler) {
        this.encoder = encoder;
        this.frameDecoder = frameDecoder;
        this.handler = handler;
    }

    @Override
    public ChannelPipeline getPipeline() throws Exception {
        ChannelPipeline pipeline = Channels.pipeline();
        pipeline.addLast("encoder", encoder);
        pipeline.addLast("frameDecoder", frameDecoder);
        pipeline.addLast("handler", handler);
        return pipeline;
    }
}
