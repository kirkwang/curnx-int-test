package currenex.server.fxintegrate.adaptor.inttest.fix.component;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTag;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTagNotNull;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;

public class MDEntryForIOI extends MDEntry{
    
    //required tags
    private String securityID;
    private String securityIDSource;
    private String product;
    private String maturityDate;
    private String issueDate;
    private String datedDate;
    private String interestAccrualDate;

    //non-required tag
    private String couponRate;

    public String getSecurityID() {
        return securityID;
    }

    public void setSecurityID(String securityID) {
        this.securityID = securityID;
    }

    public String getSecurityIDSource() {
        return securityIDSource;
    }

    public void setSecurityIDSource(String securityIDSource) {
        this.securityIDSource = securityIDSource;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getDatedDate() {
        return datedDate;
    }

    public void setDatedDate(String datedDate) {
        this.datedDate = datedDate;
    }

    public String getInterestAccrualDate() {
        return interestAccrualDate;
    }

    public void setInterestAccrualDate(String interestAccrualDate) {
        this.interestAccrualDate = interestAccrualDate;
    }

    public String getCouponRate() {
        return couponRate;
    }

    public void setCouponRate(String couponRate) {
        this.couponRate = couponRate;
    }
    
    public void validate(String mdrIdIOI, String symbol, String symbolSfx, String securityID, String mdEntrySize) throws Exception{
        
        validateTag(Constants.TAGMDReqID, mdrIdIOI, this.getMdReqId());
        validateTag(Constants.TAGMDUpdateAction, Constants.MDUPDATEACTION_New, this.getMDUpdateAction());
        validateTag(Constants.TAGMDEntryType, Constants.MDENTRYTYPE_IOI, this.getMDEntryType());
        validateTag(Constants.TAGSymbol, symbol, this.getSymbol());
        validateTag(Constants.TAGSymbolSfx, symbolSfx, this.getSymbolSfx());
        validateTag(Constants.TAGSecurityID, securityID, this.getSecurityID());
        validateTag(Constants.TAGSecurityIDSource, Constants.SECURITYIDSOURCE_Eris, this.getSecurityIDSource());
        validateTag(Constants.TAGProduct, Constants.PRODUCT_IRSWAP, this.getProduct());
        validateTag(Constants.TAGSecurityType, Constants.SECURITYTYPE_Irs, this.getSecurityType());
        validateTagNotNull(Constants.TAGMaturityDate, this.getMaturityDate());
        validateTagNotNull(Constants.TAGIssueDate, this.getIssueDate());
        validateTagNotNull(Constants.TAGDatedDate, this.getDatedDate());
        validateTagNotNull(Constants.TAGInterestAccrualDate, this.getInterestAccrualDate());
        validateTag(Constants.TAGMDEntrySize, mdEntrySize, this.getMDEntrySize());
    }
    
}
