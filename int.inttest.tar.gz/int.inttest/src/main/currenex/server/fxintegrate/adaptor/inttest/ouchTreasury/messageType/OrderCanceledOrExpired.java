package currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.messageType;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateFieldChar;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateFieldLong;
import static currenex.server.fxintegrate.adaptor.inttest.ouchTreasury.Constants.*;

public class OrderCanceledOrExpired {
    
    private int clOrdId;
    private long orderid;
    private char status;
    private short type;
    
    public OrderCanceledOrExpired(int clOrdId, long orderid, char status,
            short type) {
        super();
        this.clOrdId = clOrdId;
        this.orderid = orderid;
        this.status = status;
        this.type = type;
    }

    public int getClOrdId() {
        return clOrdId;
    }

    public void setClOrdId(int clOrdId) {
        this.clOrdId = clOrdId;
    }

    public long getOrderid() {
        return orderid;
    }

    public void setOrderid(long orderid) {
        this.orderid = orderid;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }
    
    public void doAssert(int clOrdId, long orderid, char status, short type) throws Exception{
        System.out.println("Validating OrderCanceledOrExpired:");
        
        validateFieldLong(FIELD_CLORDERID, clOrdId, this.getClOrdId());
        validateFieldLong(FIELD_ORDERID, orderid, this.getOrderid());
        validateFieldChar(FIELD_STATUS, status, this.getStatus());
        validateFieldLong(FIELD_TYPE, type, this.getType());
    }
    
    @Override
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append("OrderCanceledOrExpired:");
        sb.append(" ClOrderID="+clOrdId);
        sb.append(", OrderID="+orderid);
        sb.append(", Status="+status);
        sb.append(", Type="+type);
        
        return sb.toString();
    }

}
