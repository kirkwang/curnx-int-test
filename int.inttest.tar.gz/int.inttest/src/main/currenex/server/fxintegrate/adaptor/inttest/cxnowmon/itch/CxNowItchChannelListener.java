package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import java.util.concurrent.Semaphore;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelFutureListener;

@Singleton
class CxNowItchChannelListener implements ChannelFutureListener {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowItchChannelListener.class);
    private final ItchMsgSender itchMsgSender;
    private final Semaphore testFinished;

    @Inject
    CxNowItchChannelListener(ItchMsgSender itchMsgSender,
            @Named("testFinished") Semaphore testFinished) {
        this.itchMsgSender = itchMsgSender;
        this.testFinished = testFinished;
        this.testFinished.tryAcquire();
    }

    @Override
    public void operationComplete(ChannelFuture future) throws Exception {
        if (!(future.isSuccess() || future.isCancelled())) {
            log.info("Connection unsuccessful");
            testFinished.release();
            return;
        }

        log.info("Connection successful");
        Channel channel = future.getChannel();
        channel.getCloseFuture().addListener(closeFuture -> testFinished.release());

        itchMsgSender.setChannel(channel);
    }
}
