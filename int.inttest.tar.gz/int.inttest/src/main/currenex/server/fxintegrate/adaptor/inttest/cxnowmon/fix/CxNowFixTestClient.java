package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.fix;

import java.io.File;
import java.util.logging.Level;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import currenex.log.jdk.CxLogger;
import currenex.server.fxintegrate.adaptor.inttest.cxnowmon.CxNowTestStat;
import currenex.util.threadpool.ExclusiveTask;
import quickfix.ConfigError;
import quickfix.Initiator;

public class CxNowFixTestClient {
    private static final CxLogger log = CxLogger.getCxLogger(CxNowFixTestClient.class);
    private final Initiator initiator;
    private final int listenMillis;
    private final File resultsFile;
    private final ExclusiveTask writeTask;

    private volatile boolean writesDisabled = false;

    @Inject CxNowFixTestClient(Initiator initiator,
            ExclusiveTask.Factory exclusiveTaskFactory,
            @Named("resultsFile") File resultsFile,
            @Named("writeIntervalMillis") long writeIntervalMillis,
            @Named("listenMillis") int listenMillis) {
        this.initiator = initiator;
        this.listenMillis = listenMillis;
        this.resultsFile = resultsFile;
        this.writeTask = exclusiveTaskFactory.newTask("cxNowFixPerformance", () -> {
            while (true) {
                try {
                    Thread.sleep(writeIntervalMillis);
                    writeStatsToFile(false);
                } catch (InterruptedException e) {
                    log.log(Level.SEVERE, "writeTask threw exception", e);
                    break;
                }
            }
        });
    }

    public void run() throws ConfigError, InterruptedException {
        initiator.start();
        writeTask.poke();
        Thread.sleep(listenMillis);

        log.infof("Test finished, writing final results to file=%s", resultsFile.getAbsolutePath());
        writeStatsToFile(true);
        System.exit(0);
    }

    private synchronized void writeStatsToFile(boolean disableWrites) {
        if (writesDisabled) return;
        this.writesDisabled = disableWrites;
        new CxNowTestStat().writeStats(resultsFile);
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            log.info("Usage: <path to quickfix properties file>");
            return;
        }

        try {
            Guice.createInjector(new CxNowFixTestModule(args[0])).getInstance(CxNowFixTestClient.class).run();
        } catch (Exception e) {
            log.log(Level.SEVERE, "Exception caught while running CxNow fix test client", e);
        }
    }
}
