package currenex.server.fxintegrate.adaptor.inttest.itchTcp.message;

public class CxNowWamr {
    
    private short instrIndex;
    private int rate;
    private int[] prices;
    private long timestamp;
    
    public CxNowWamr(short instrIndex, int rate,
            int[] prices, long timestamp) {
        super();
        this.instrIndex = instrIndex;
        this.rate = rate;
        this.prices = prices;
        this.timestamp = timestamp;
    }

    public short getInstrIndex() {
        return instrIndex;
    }

    public void setInstrIndex(short instrIndex) {
        this.instrIndex = instrIndex;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int[] getPrices() {
        return prices;
    }

    public void setPrices(int[] prices) {
        this.prices = prices;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    

}
