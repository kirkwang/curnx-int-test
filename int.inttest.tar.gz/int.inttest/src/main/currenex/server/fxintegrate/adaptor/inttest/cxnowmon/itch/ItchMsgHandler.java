package currenex.server.fxintegrate.adaptor.inttest.cxnowmon.itch;

import java.nio.ByteBuffer;

public interface ItchMsgHandler {
    void handleMsg(ByteBuffer buffer, char msgType, long microTime, int msgTime) throws Exception;
}
