package currenex.testcase.regression.prodRegression.itchouch.itch.itchUdp;

import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static org.junit.Assert.*;
import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.TradeGenerator;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.itch.ItchClient;
import currenex.testcase.ATestCase;

/**
*
* Properties file: testBinaryRegression.properties
* @author mgopalakrishnan
*/
public class TestItchUdpTicker extends ATestCase {
    private ItchClient itchClient;
    private TakerTestSession taker;
    private TakerTestSession streamTaker;
    private MakerTestSession maker;

    final long DEF_WAIT_TIME = 5000;
    
    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));

    @Before
    public void setUp() throws Exception {
        
        maker = getMaker("BIxxMakerTHMU2");  
        taker = getTaker("BIxxTakerTHMU2");
        streamTaker = getTaker("BIxxTakerTHMU3");

        String userId = props().getProperty("ITCH_USER_ID");
        String host = props().getProperty("ITCH_HOST");
        int port = Integer.parseInt(props().getProperty("ITCH_PORT"));
        itchClient = new ItchClient(userId, host, port, "Test123456",
                new String[] { "EUR/USD-SP" });
    }

    @Test //DEV-21766
    public void testTicker_FullFIll() throws Exception {
        
        itchClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        assertTrue("taker is not logged on:"+taker.getUserName(),taker.logon());
        assertTrue("streamTaker is not logged on:"+streamTaker.getUserName(),streamTaker.logon());
        Thread.sleep(5000);
        
        String reqId = generateOrderId("mdrId-");
        streamTaker.submitTickerMarketDataRequest(reqId, Constants.SUBSCRIPTIONREQUESTTYPE_Ticker, "EUR/USD");
                
        TradeGenerator.doTradeForEspLimit(taker, maker);
        
        String tickerRate = (String)itchClient.getMessageFromTickerQueue(DEF_WAIT_TIME);
        assertNotNull("no ticker message received", tickerRate);
    }

    @Test //DEV-22078
    public void testTicker_PartialFill() throws Exception {
        
        itchClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        assertTrue("taker is not logged on:"+taker.getUserName(),taker.logon());
        Thread.sleep(5000);
        
        TradeGenerator.doTradeForEspLimitPartialFill(taker, maker);
        
        String tickerRate = (String)itchClient.getMessageFromTickerQueue(DEF_WAIT_TIME);
        assertNotNull("no ticker message received", tickerRate);
    }

    @After
    public void tearDown()throws Exception
    {
        itchClient.logout("bye!");
        this.logoutUsers(5000);
    }
}
