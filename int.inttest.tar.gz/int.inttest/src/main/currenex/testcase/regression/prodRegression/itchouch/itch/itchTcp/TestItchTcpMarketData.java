package currenex.testcase.regression.prodRegression.itchouch.itch.itchTcp;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.generateOrderId;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTag;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;
import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Client;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.message.Price;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.ao.NewOrderSingle;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntry;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.ATestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.testcase.ATestCase;

/**
*
* Properties file: testBinaryRegression.properties
* @author jchen
*/
public final class TestItchTcpMarketData extends ATestCase {
    Client itchTcpClient;
    private TakerTestSession takerOXO;
    private MakerTestSession maker;
    private MakerTestSession maker2;
    private MakerTestSession maker3;
    private MakerTestSession maker4;
    private MakerTestSession maker5;
    private MakerTestSession maker6;

    final String FX_TEST_INSTR = "EUR/USD";
    final String PRODUCT_CURRENCY = "4";
    final String FX_TEST_BASE_CCY = "EUR";
    final String FX_TEST_TERMS_CCY = "USD";
    final long DEF_WAIT_TIME = 3000;
    final String EURUSD_BID_PX = "1.1303";
    final String EURUSD_OFFER_PX = "1.1307";
    final String amt1M = "1000000";
    final String amt2M = "2000000";
    final String amt3M = "3000000";
    String itchUserPw = "Test123456";
    String testingTarget;
    String itchUserId;
    String itchHost;
    int itchPort;
    SimpleDateFormat dateFormat;
    
    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));

    @Before
    public void setUp() throws Exception {
        
        testingTarget = props().getProperty("RUN_STACK", "Local");
        itchPort = Integer.parseInt(props().getProperty("ITCHTCP_PORT"));

        if(testingTarget.equals("QA13")){
            itchUserId = props().getProperty("ITCHTCP_USER_ID_QA13");
            itchHost = props().getProperty("ITCHTCP_HOST_QA13");
            
            //takerOXO = getTaker("BIxxTakerTHM2U2");        
            maker = getMaker("JCxxMaker3U2");
            maker2 = getMaker("JCxxMaker3U3");
            maker3 = getMaker("JCxxMaker3U4");
            maker4 = getMaker("JCxxMaker3U5");
            
        }else{
            itchUserId = props().getProperty("ITCHTCP_USER_ID");
            itchHost = props().getProperty("ITCHTCP_HOST");
            
            takerOXO = getTaker("BIxxTakerTHM2U2");        
            maker = getMaker("BIxxMakerTHMU2");
            maker2 = getMaker("BIxxMakerTHMU3");
            maker3 = getMaker("BIxxMakerTHMU4");
            maker4 = getMaker("BIxxMakerTHMU5");
            maker5 = getMaker("BIxxMakerTHMU6");
            maker6 = getMaker("BIxxMakerTHMU7");
            
//            maker = getMaker("fixmakeru01");
//            maker2 = getMaker("fixmakeru02");
//            maker3 = getMaker("fixmakeruser1");
//            itchUserId = "fixtesttaker01";
//            itchHost = "208.89.235.191";
//            itchUserPw = "test1234";
//            takerOXO = getTaker("fixteststattakeru1");
        }
        
        itchTcpClient = new Client(itchUserId, itchHost, itchPort, itchUserPw,
                new String[] { "EUR/USD-SP", "GBP/USD-SP", "USD/CAD-SP", "EUR/JPY-SP" });
        
        dateFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");
    }

    @After
    public void tearDown() throws Exception {
        itchTcpClient.logout("bye!");
        this.logoutUsers(2000);
    }

    @Test
    public void testItchPrice_OXP() throws Exception {
        
        itchTcpClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(EURUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    //UserPriceBookProperties.FULL_BOOK_MARKET_DEPTH_CONTROL=0=USD/JPY,2=GBP/USD,3=USD/CAD
    @Test
    public void testItchPrice_DepthOfBook() throws Exception {
        
        itchTcpClient.start();
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        assertTrue(maker5.getUserName()+" is not logged on",maker5.logon());
        assertTrue(maker6.getUserName()+" is not logged on",maker6.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        maker5.initialize(10);
        maker6.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        String INSTR_USDCAD = "USD/CAD";
        String INSTR_EURUSD = "EUR/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNull("no price should be received!!", price);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
                
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
                       
        
        String USDCAD_BID_PX = "1.3123";
        String USDCAD_BID_PX2 = "1.3125";
        String USDCAD_BID_PX3 = "1.3128";
        String USDCAD_BID_PX4 = "1.3130";
        String USDCAD_BID_PX5 = "1.3132";
        
        //USD/CAD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX4, null);
        
        String price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        double receivedPrice2 = (Double.valueOf(price2))/100000;
        double submittedPrice2 = Double.valueOf(USDCAD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX3, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX5, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX2, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNull("no price should be received!!", price2);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        
        
        String EURUSD_BID_PX = "1.1123";
        String EURUSD_BID_PX2 = "1.1125";
        String EURUSD_BID_PX3 = "1.1128";
        String EURUSD_BID_PX4 = "1.1130";
        String EURUSD_BID_PX5 = "1.1132";
        String EURUSD_BID_PX6 = "1.1138";
        
        //EUR/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX6, null);
        
        String price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        double receivedPrice3 = (Double.valueOf(price3))/100000;
        double submittedPrice3 = Double.valueOf(EURUSD_BID_PX6);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX5, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX4, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX3, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker5.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX2, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker6.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
    }
    
    
    @Ignore
    @Test
    public void testItchPrice_DepthOfBookOff() throws Exception {
        
        itchTcpClient.start();
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        String INSTR_USDCAD = "USD/CAD";
        String INSTR_EURUSD = "EUR/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        
        
        
        String USDCAD_BID_PX = "1.3123";
        String USDCAD_BID_PX2 = "1.3125";
        String USDCAD_BID_PX3 = "1.3128";
        String USDCAD_BID_PX4 = "1.3130";
        String USDCAD_BID_PX5 = "1.3132";
        
        //USD/CAD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX2, null);
        
        String price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        double receivedPrice2 = (Double.valueOf(price2))/100000;
        double submittedPrice2 = Double.valueOf(USDCAD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX3, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX4, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX5, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX, null);
        
        price2 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        
        
        String EURUSD_BID_PX = "1.1123";
        String EURUSD_BID_PX2 = "1.1125";
        String EURUSD_BID_PX3 = "1.1128";
        String EURUSD_BID_PX4 = "1.1130";
        String EURUSD_BID_PX5 = "1.1132";
        
        //EUR/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX, null);
        
        String price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        double receivedPrice3 = (Double.valueOf(price3))/100000;
        double submittedPrice3 = Double.valueOf(EURUSD_BID_PX);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX2, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX3, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX4, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX5, null);
        
        price3 = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
    }
    
    
    
    @Test
    public void testItchPrice_DepthOfBookZero() throws Exception {
        
        itchTcpClient.start();
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        assertTrue(maker5.getUserName()+" is not logged on",maker5.logon());
        assertTrue(maker6.getUserName()+" is not logged on",maker6.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        maker5.initialize(10);
        maker6.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_EURJPY = "EUR/JPY";
        
        String EURJPY_OFFER_PX = "113.11";
        String EURJPY_OFFER_PX2 = "113.12";
        String EURJPY_OFFER_PX3 = "113.13";
        String EURJPY_OFFER_PX4 = "113.15";
        String EURJPY_OFFER_PX5 = "113.18";
        String EURJPY_OFFER_PX6 = "113.21";
        
        //EUR/JPY offer prices
        maker.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(EURJPY_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX4);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker5.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX5);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker6.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX6);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX6);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    
  //DEV-30088, DEV-31439, DEV-31450
    //Taker user needs 2=GBP/USD set in UserPriceBookProperties.FULL_BOOK_MKT_DEPTH_CONTROL
    @Test
    public void testItchPrice_DepthOfBookEdgeWithOXO() throws Exception {
        
        itchTcpClient.start();
        
        assertTrue(takerOXO.getUserName()+" is not logged on",takerOXO.logon());
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3084";
        
        submitPriceAndValidate(takerOXO,
                INSTR_GBPUSD,
                false /*isBidPx*/,
                GBPUSD_OFFER_PX, 
                true /*toReceive*/);
        
        submitPriceAndValidate(maker3,
                INSTR_GBPUSD,
                false /*isBidPx*/,
                GBPUSD_OFFER_PX2,
                true /*toReceive*/);
        
        submitPriceAndValidate(maker2,
                INSTR_GBPUSD,
                false /*isBidPx*/,
                GBPUSD_OFFER_PX3, 
                false /*toReceive*/);
        
        cancalAllOpenOrdersAndValidate(takerOXO);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        Integer cancelledPriceId = itchTcpClient.getCancelledPricedId(1000);
        assertNotNull("no priceCancel was received!!", cancelledPriceId);
        
        submitPriceAndValidate(takerOXO,
                INSTR_GBPUSD,
                false /*isBidPx*/,
                GBPUSD_OFFER_PX4,
                false /*toReceive*/);
        
        maker2.submitCancelAllRates(dateFormat.format(new Date()));
               
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        cancelledPriceId = itchTcpClient.getCancelledPricedId(1000);
        assertNotNull("no priceCancel was received!!", cancelledPriceId);

        submitPriceAndValidate(maker2,
                INSTR_GBPUSD,
                false /*isBidPx*/,
                GBPUSD_OFFER_PX, 
                true /*toReceive*/);
        
        cancelledPriceId = itchTcpClient.getCancelledPricedId(1000);
        assertNotNull("no priceCancel was received!!", cancelledPriceId);
        
      //Cancel the price that has been deleted already
        cancalAllOpenOrdersAndValidate(takerOXO);
        
        price = itchTcpClient.getPrice(1000);
        assertNull("no price should be received!!", price);
        
        cancelledPriceId = itchTcpClient.getCancelledPricedId(1000);
        assertNull("no priceCancel should be received!!", cancelledPriceId);
    }
    

    private void submitPriceAndValidate(ATestSession submittingUser, String instrument, boolean isBidPx, String px, 
            boolean toReceive) throws Exception{
        
        if(submittingUser instanceof MakerTestSession){
            
            MakerTestSession pricingMaker = (MakerTestSession)submittingUser;
            
            String bidPx = isBidPx?px:null;
            String offerPx = isBidPx?null:px;
            
            pricingMaker.submitQuoteEsp(amt1M, instrument, bidPx, offerPx);
            
        }else if(submittingUser instanceof TakerTestSession){
            
            TakerTestSession pricingTaker = (TakerTestSession)submittingUser;
            
            String side = isBidPx?Constants.SIDE_Buy:Constants.SIDE_Sell;
            
            String oxoClOrdId = generateOrderId("testOxO-");            
            NewOrderSingle oxoOrder = new NewOrderSingle(oxoClOrdId,
                    instrument.split("/")[0],
                    side,
                    instrument,
                    Constants.SYMBOLSFX_Spot,
                    Constants.PRODUCT_Currency, 
                    Constants.SECURITYTYPE_ForeignExchange,
                    "1000000",
                    Constants.ORDTYPE_ForexLimit, 
                    px,
                    Constants.TIMEINFORCE_Day,
                    "1000000");
            
            pricingTaker.submitEspOrder(oxoOrder);
            
            Message orderUpdateMsg = pricingTaker.getOrderUpdateMsg(oxoClOrdId, DEF_WAIT_TIME);
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, orderUpdateMsg.getStringFieldValue(Constants.TAGExecType));
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, orderUpdateMsg.getStringFieldValue(Constants.TAGOrdStatus));
        }
        
        String price = itchTcpClient.getPrice(1000);
        if(toReceive){
            assertNotNull("no price was received!!", price);
            double receivedPrice = (Double.valueOf(price))/100000;
            double submittedPrice = Double.valueOf(px);
            assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        }else{
            assertNull("no price should be received!!", price);
        }
    }
    
    
    
    
    
    
    
    @Test
    public void testItchPrice_DepthOfBookWithCancel() throws Exception {
        
        itchTcpClient.start();
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        
        maker.initialize(10);
        maker2.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
                
        maker.submitCancelAllRates(dateFormat.format(new Date()));
        String ccy = itchTcpClient.getPriceCancel(1000);
        assertNotNull("itchtcp client didnt get priceCancel", ccy);
        
        maker2.submitCancelAllRates(dateFormat.format(new Date()));
        ccy = itchTcpClient.getPriceCancel(1000);
        assertNotNull("itchtcp client didnt get priceCancel", ccy);
        
        Thread.sleep(500);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);

        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    
    
    
    //DEV-31529
    //Taker user needs 2=GBP/USD set in UserPriceBookProperties.FFULL_BOOK_MKT_DEPTH_CONTROL
    //Maker sure the taker user doesn't get the priceCancel for the price he never received 
    @Test
    public void testItchPrice_DepthOfBookWithCancel2() throws Exception {
        
        itchTcpClient.start();
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
                
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";

        //GBP/USD offer prices
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
                
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchTcpClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchTcpClient.getPrice(1000);
        assertNull("no price should be received!!", price);
        
        
        maker3.submitCancelAllRates(dateFormat.format(new Date()));
        
        String priceCancel = itchTcpClient.getPriceCancel(1000);
        assertNull("no priceCancel should be received!!", priceCancel);
        
        maker4.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchTcpClient.getPrice(1000);
        assertNull("no price should be received!!", price);
        
        maker4.submitCancelAllRates(dateFormat.format(new Date()));
        
        priceCancel = itchTcpClient.getPriceCancel(1000);
        assertNull("no priceCancel should be received!!", priceCancel);
        
        maker.submitCancelAllRates(dateFormat.format(new Date()));
        
        priceCancel = itchTcpClient.getPriceCancel(1000);
        assertNotNull("no priceCancel was received!!", priceCancel);
        
        maker2.submitCancelAllRates(dateFormat.format(new Date()));
        
        priceCancel = itchTcpClient.getPriceCancel(1000);
        assertNotNull("no priceCancel was received!!", priceCancel);
    }
    
    
    
    
    //DEV-30088, DEV-31439, DEV-31450
    //Taker user needs 2=GBP/USD set in UserPriceBookProperties.FULL_BOOK_MKT_DEPTH_CONTROL
    @Test
    public void testItchPrice_DepthOfBookAuto() throws Exception {
        
        itchTcpClient.start();
        
        assertTrue(takerOXO.getUserName()+" is not logged on",takerOXO.logon());
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        //assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        
        int marketDepth = 2; //UserPriceBookProperties.FULL_BOOK_MKT_DEPTH_CONTROL=2=GBP/USD
                
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        //maker4.initialize(10);
        Thread.sleep(5000);
        String INSTR_GBPUSD = "GBP/USD";
        String GBPUSD_OFFER_PX = "1.308";
                
        ATestSession[] sessions = new ATestSession[5];
        sessions[0]=maker;
        sessions[1]=maker2;
        sessions[2]=maker3;
        sessions[3]=takerOXO;
        sessions[4]=maker4;
        Random rd = new Random();
        
        HashMap<Integer, String> bookoPriceMap = new HashMap<Integer, String>();
        HashMap<String, String> userPriceMap = new HashMap<String, String>();
        
        for(int i=0;i<30;i++){
            
            ATestSession submittingUser = sessions[rd.nextInt(4)];
            String px = GBPUSD_OFFER_PX+rd.nextInt(6);
            userPriceMap = submitPrice(submittingUser, INSTR_GBPUSD, false, px, userPriceMap);
            
            Price receivedPrice = itchTcpClient.getPriceObj(3000);
            while(receivedPrice!=null){   
                bookoPriceMap = putPriceIntoMap(receivedPrice, bookoPriceMap);
                receivedPrice = itchTcpClient.getPriceObj(1000);
            }
            
            Integer cancelledPriceId = itchTcpClient.getCancelledPricedId(500);
            while(cancelledPriceId!=null){   
                bookoPriceMap = removePriceFromMap(cancelledPriceId, bookoPriceMap);
                cancelledPriceId = itchTcpClient.getCancelledPricedId(500);
            }
            
            for (String key: userPriceMap.keySet()){
                String value = userPriceMap.get(key).toString();
                System.out.println("UserId:"+key + ", Price:" + value);  
            }
            
            double[] sortedUserPrices = sortOfferPrices(userPriceMap);
            double[] sortedBookPrices = sortOfferPrices(bookoPriceMap);

            for (int k=0;k<sortedUserPrices.length;k++){
                System.out.println("Level "+(k+1)+" User price: "+sortedUserPrices[k]);
            }
            
            for (int k=0;k<sortedBookPrices.length;k++){
                System.out.println("Level "+(k+1)+" Book price: "+sortedBookPrices[k]);
            }
            
            if(sortedUserPrices.length>=marketDepth && sortedBookPrices.length>=marketDepth){
                for(int k=0;k<marketDepth;k++){
                    assertEquals(sortedUserPrices[k], sortedBookPrices[k], 0.000001);
                    System.out.println("Level "+(k+1)+" price is verified. User:"+sortedUserPrices[k]+", Book:"+sortedBookPrices[k]);
                }
            }
            
            if(sortedBookPrices.length>marketDepth){
                for(int k=marketDepth;k<sortedBookPrices.length;k++){
                    assertEquals(0, sortedBookPrices[k], 0.000001);
                    System.out.println("Level "+(k+1)+" Book Price is validated and the value is "+sortedBookPrices[k]);
                }
            }
        }
    }
    
    

    private double[] sortOfferPrices(HashMap priceMap) throws Exception{
        
        double[] sortedNLevelPrices = new double[priceMap.size()];
        
        for (Object key: priceMap.keySet()){
            String value = priceMap.get(key).toString();
            double price = Double.valueOf(value);
            
            for(int j=0;j<sortedNLevelPrices.length;j++){
                
                if(sortedNLevelPrices[j]!=0 && price == sortedNLevelPrices[j]){ //Price is in the book already
                    break;
                }else if(sortedNLevelPrices[j]!=0 && price > sortedNLevelPrices[j]){ // Price is larger than this level
                    continue;
                }else if(sortedNLevelPrices[j]!=0 && price < sortedNLevelPrices[j]){ // Price is smaller than this level
                    
                    double temp = sortedNLevelPrices[j];
                    sortedNLevelPrices[j] = price;
                    
                    for(int k=j+1;j<sortedNLevelPrices.length;k++){
                        double temp2 = sortedNLevelPrices[k];
                        sortedNLevelPrices[k] = temp;
                        temp = temp2;
                        if(temp2==0){
                            break;
                        }
                    }
                    break;
                }else if(sortedNLevelPrices[j]==0){
                    sortedNLevelPrices[j] = price;
                    break;
                }
            }
        }
        
        return sortedNLevelPrices;
    }
    

    private HashMap<String, String> submitPrice(ATestSession submittingUser, String instrument, boolean isBidPx, String px, 
            HashMap<String, String> userPriceMap) throws Exception{
        
        assertNotNull(userPriceMap);
        
        if(submittingUser instanceof MakerTestSession){
            
            MakerTestSession pricingMaker = (MakerTestSession)submittingUser;
            
            String bidPx = isBidPx?px:null;
            String offerPx = isBidPx?null:px;
            
            pricingMaker.submitQuoteEsp(amt1M, instrument, bidPx, offerPx);
            userPriceMap.put(submittingUser.getSenderCompId(), px);
            
        }else if(submittingUser instanceof TakerTestSession){
            
            TakerTestSession pricingTaker = (TakerTestSession)submittingUser;
            String side = isBidPx?Constants.SIDE_Buy:Constants.SIDE_Sell;
            
            Random rd = new Random();
            boolean cancelAllOrdersFirst = rd.nextBoolean();
            boolean hasTakerOrderInBook = false;
            
            for(String key:userPriceMap.keySet()){
                if(key.startsWith("testOxO")){
                    hasTakerOrderInBook = true;
                    break;
                }
            }
            
            //Cancel all open orders and remove the prices from UserBook
            if(cancelAllOrdersFirst && hasTakerOrderInBook){
                cancalAllOpenOrdersAndValidate(pricingTaker);
                HashSet<String> set = new HashSet<String>();
                for(String key:userPriceMap.keySet()){
                    if(key.startsWith("testOxO")){
                        set.add(key);
                    }
                }
                String[] keys = set.toArray(new String[set.size()]);
                for(String key:keys){
                    userPriceMap.remove(key);
                }
            }
                
            String oxoClOrdId = generateOrderId("testOxO-");            
            NewOrderSingle oxoOrder = new NewOrderSingle(oxoClOrdId,
                    instrument.split("/")[0],
                    side,
                    instrument,
                    Constants.SYMBOLSFX_Spot,
                    Constants.PRODUCT_Currency, 
                    Constants.SECURITYTYPE_ForeignExchange,
                    "1000000",
                    Constants.ORDTYPE_ForexLimit, 
                    px,
                    Constants.TIMEINFORCE_Day,
                    "1000000");
            
            pricingTaker.submitEspOrder(oxoOrder);
            
            Message orderUpdateMsg = pricingTaker.getOrderUpdateMsg(oxoClOrdId, DEF_WAIT_TIME);
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, orderUpdateMsg.getStringFieldValue(Constants.TAGExecType));
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, orderUpdateMsg.getStringFieldValue(Constants.TAGOrdStatus));
            
            userPriceMap.put(oxoClOrdId, px);
        }
        return userPriceMap;
    }
    
    private void cancalAllOpenOrdersAndValidate(TakerTestSession submittingTaker) throws Exception{
        
        submittingTaker.clearExecutionReportQueue();
        submittingTaker.submitCancelAllOrdersRequest();
        
        Message cancelledER = submittingTaker.getMessageFromExeuctionReportQueue(5000);
        assertNotNull(submittingTaker.getUserName()+" didnt get any ER(cancelled)", cancelledER);
        
        while(cancelledER!=null){
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_Cancelled, cancelledER.getStringFieldValue(Constants.TAGExecType));
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Cancelled, cancelledER.getStringFieldValue(Constants.TAGOrdStatus));
            cancelledER = submittingTaker.getMessageFromExeuctionReportQueue(2000);
        }
    }
    
    private HashMap<Integer, String> putPriceIntoMap(Price receivedPrice, HashMap<Integer, String> priceMap) throws Exception{
        
        assertNotNull(priceMap);
        String price = Double.toString(((double)receivedPrice.getPrice())/100000);
        priceMap.put(receivedPrice.getPriceId(), price); 
        
        return priceMap;
    }
    
    private HashMap<Integer, String> removePriceFromMap(int priceId, HashMap<Integer, String> priceMap) throws Exception{
        
        assertNotNull(priceMap);
        assertTrue(priceMap.containsKey(priceId));
        priceMap.remove(priceId);        
        return priceMap;
    }
    
    
    @Test
    public void testItchPrice_OXPLogout() throws Exception {
        
        itchTcpClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        Thread.sleep(5000);
        
        maker.initialize(10);
        
        itchTcpClient.logout("bye!");
        Thread.sleep(2000);
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(5000);
        assertNull("No price should be received", price);
    }
    
    @Test
    public void testItchPrice_OXO() throws Exception {
        
        itchTcpClient.start();
        assertTrue("takerOXO is not logged on:"+takerOXO.getUserName(),takerOXO.logon());
        Thread.sleep(5000);
        
        String clOrdID = "testClOrdId1";
        String amount = "50000";
        
        takerOXO.submitRetailOrderOnBehalf(clOrdID, null, FX_TEST_INSTR, null,
                PRODUCT_CURRENCY, Constants.SIDE_Buy, FX_TEST_BASE_CCY,
                amount, Constants.ORDTYPE_ForexLimit, EURUSD_BID_PX, null,
                Constants.TIMEINFORCE_Day, null, null, null, amount, null, null,
                null, null, null);
        
        Message acceptedER = takerOXO.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, acceptedER.getStringFieldValue(Constants.TAGExecType));
        
        String price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(EURUSD_BID_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    @Test
    public void testItchTcpResubscribe_owner() throws Exception {
        
        itchTcpClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        Thread.sleep(5000);

        maker.initialize(10);
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
            
        itchTcpClient.resubscribe("EUR/USD-SP");
        Thread.sleep(5000);
        
        price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
    }
    
    @Test
    public void testItchTcpResubscribeFailed_owner() throws Exception {
        
        itchTcpClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        Thread.sleep(5000);

        maker.initialize(10);
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        
        itchTcpClient.unsubscribe("EUR/USD-SP");
        
        String priceCancel = itchTcpClient.getPriceCancel(DEF_WAIT_TIME);
        assertNotNull("no priceCancel was received!!", priceCancel);
            
        itchTcpClient.resubscribe("EUR/USD-SP");
        Thread.sleep(5000);
        
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNull("No price should be received!!", price);
    }
    
    @Test
    public void testItchTcpUnsubscribe_owner() throws Exception {
        
        itchTcpClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        Thread.sleep(5000);

        maker.initialize(10);
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        
        String price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        
        itchTcpClient.unsubscribe("EUR/USD-SP");
        
        String priceCancel = itchTcpClient.getPriceCancel(DEF_WAIT_TIME);
        assertNotNull("no priceCancel was received!!", priceCancel);
        
        maker.submitQuoteEsp(amt1M, FX_TEST_INSTR, null, EURUSD_OFFER_PX);
        price = itchTcpClient.getPrice(DEF_WAIT_TIME);
        assertNull("No price should be received!!", price);
    }
}
