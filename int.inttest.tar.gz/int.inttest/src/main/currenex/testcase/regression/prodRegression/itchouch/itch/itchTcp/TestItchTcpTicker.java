package currenex.testcase.regression.prodRegression.itchouch.itch.itchTcp;

import static org.junit.Assert.*;

import currenex.server.fxintegrate.adaptor.inttest.fix.TradeGenerator;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Client;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.message.TradeTicker;
import currenex.testcase.ATestCase;

/**
*
* Properties file: testBinaryRegression.properties
* @author jchen
*/
public class TestItchTcpTicker extends ATestCase {
    private Client itchClient;
    private TakerTestSession taker;
    private MakerTestSession maker;
    final long DEF_WAIT_TIME = 5000;

    @Before
    public void setUp() throws Exception {
        
        maker = getMaker("BIxxMakerTHMU2");  
        taker = getTaker("BIxxTakerTHMU2");
        
        String userId = props().getProperty("ITCH_USER_ID");
        String host = props().getProperty("ITCH_HOST");
        int port = Integer.parseInt(props().getProperty("ITCH_PORT"));
        itchClient = new Client(userId, host, port, "Test123456",
                new String[] { "EUR/USD-SP" });
    }
    
    @Test //DEV-21766
    public void TestTicker_FullFIll() throws Exception {
        
        itchClient.start();
        Thread.sleep(10000);
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        assertTrue("taker is not logged on:"+taker.getUserName(),taker.logon());
        
        
        TradeGenerator.doTradeForEspLimit(taker, maker);
        
        TradeTicker ticker = itchClient.getMessageFromTradeTickerQueue(3000);
        assertNotNull("no ticker message received", ticker);
    }
        
    @Test //DEV-22078
    public void TestTicker_PartialFill() throws Exception {
        
        itchClient.start();
        Thread.sleep(10000);
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        assertTrue("taker is not logged on:"+taker.getUserName(),taker.logon());
        
        TradeGenerator.doTradeForEspLimitPartialFill(taker, maker);
        
        TradeTicker ticker = itchClient.getMessageFromTradeTickerQueue(3000);
        assertNotNull("no ticker message received", ticker);
    }
   
    @After
    public void tearDown()throws Exception
    {
        itchClient.stop();
        this.logoutUsers(5000);
    }
}