package currenex.testcase.regression.prodRegression.itchouch.ouch.taker;

import static org.junit.Assert.*;
import static currenex.server.fxintegrate.adaptor.inttest.ouch.Constants.*;

import java.math.BigDecimal;
import java.util.Random;

import currenex.server.fxintegrate.adaptor.ouchtwo.taker.TakerErrorCode;
import org.apache.mina.common.ByteBuffer;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.ouch.OuchClient;
import currenex.server.fxintegrate.adaptor.inttest.ouch.message.NewOrderAck;
import currenex.server.fxintegrate.adaptor.ouchtwo.taker.TakerConstants;
import currenex.testcase.ATestCase;

public final class TestOuchTakerRegression extends ATestCase implements TakerConstants {
    private final static byte ORDER_STATUS_CONFIRM='C';
    private final static byte ORDER_STATUS_REJECT='R';
    private final static short ERROR_CODE_NONE=0;

    private final static byte ORDER_CANCEL_STATUS_CANCELED='C';
    private final static byte ORDER_REPLACE_STATUS_REPLACED='P';
    private final static byte ORDER_REPLACE_STATUS_REJECTED='R';
    private final static byte ORDER_REPLACE_STATUS_CANCELED='C';

    private final static byte AGGRESSOR_YES='1';
    private final static byte AGGRESSOR_NO='2';

    private final static short ORDER_CANCEL_TYPE_USER=0;
    private final static short ORDER_CANCEL_TYPE_SYSTEM=1;
    private final static short ORDER_CANCEL_TYPE_BELOW_MIN=2;

    private final static byte TRADE_TYPE_TRADE='1';

    private OuchClient client;
    private MakerTestSession maker;
    private TakerTestSession oxoTaker;
    private TakerTestSession oxoStreamTaker;

    @Before
    public void SetUp_owner() throws Exception
    {
        String host = props().getProperty("ouchHost", "localhost");
        int port = Integer.parseInt(props().getProperty("ouchPort", "32000"));
        String userId = props().getProperty("ouchUserId", "BIxxTakerTHMOuch");
        this.client = new OuchClient(host ,port, userId);
        this.oxoTaker = getTaker("BIxxTakerTHM2U2");
        this.oxoStreamTaker = getTaker("BIxxTakerTHM2U3");
        this.maker = getMaker("BIxxMakerTHMU2");
        
        client.connect();
        client.logon();
        Thread.sleep(3000);
        client.sendInstrumentInfoRequest();
        Thread.sleep(1500);
    }
    
    //Ouch taker has TakerUserProperty.SEND_WARM_UP_INTERNAL_ORDER=true
    //DEV-32407, DEV-32453
    @Test
    public void testWarmUpOrder_owner() throws Exception
    {
        Object sc = client.getSysCancel(10000);
        assertNull(sc);
        
        String ccy = "EUR/USD-SP";
        long amount = 60000000;
        Integer rate = 123450;
        long minAmt = -1;        
        
        for(int i=0;i<5;i++){
            client.sendOrder(i, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, amount, EXPIRE_TYPE_IOC);
            NewOrderAck ack = client.getNewOrderAck(3000);
            assertNotNull(ack);
            ack.doAssert(i, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
            
            Object sysCancel = client.getSysCancel(3000);
            assertNotNull(sysCancel);
            Thread.sleep(1000);
        }
    }
    
    @Test
    public void testLimitIOCCancelled_owner() throws Exception
    {
        int myClOrdId = 6544;
        
        String ccy = "EUR/USD-SP";
        long amount = 60000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, EXPIRE_TYPE_IOC);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        long orderId = ack.getOrderId();        
        
        ByteBuffer sc = (ByteBuffer)client.getSysCancel(3000);
        assertNotNull(sc);
        sc.rewind();
        
        int scSeqNumber = sc.getInt();
        int scTimestamp = sc.getInt();
        byte scMsgType = sc.get();
        int scClordId = sc.getInt();
        long scOrderId = sc.getLong();
        byte scStatus = sc.get();
        short scType = sc.getShort();
        
        assertEquals(myClOrdId, scClordId);
        assertEquals(orderId, scOrderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, scStatus);
        assertEquals(ORDER_CANCEL_TYPE_SYSTEM, scType);
    }
    
    @Test
    public void testLimitIOCFilled_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("600000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions
        
        int myClOrdId = 6544;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 60000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = 20000000;
        

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, EXPIRE_TYPE_IOC);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        long myOrderId = ack.getOrderId();   
        
        Message order = maker.getOrder(10000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);
        
        Object message = client.getOrderFill(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
        
        ByteBuffer sc = (ByteBuffer)client.getSysCancel(2000);
        assertNull(sc);
    }

    @Test
    public void testSendNewOrder_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 6544;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 60000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //new limit
        myClOrdId = 3456;
        showAmt = -1;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
    }

    @Test
    public void testSendMarketData_owner() throws Exception
    {
        assertTrue(oxoStreamTaker.getUserName()+" is not logged on.", oxoStreamTaker.logon());
        oxoStreamTaker.submitMarketDataRequest("mdreq1234", "EUR", "USD", "N", "0");

        //new iceberg
        int myClOrdId = 1234;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 800000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 200000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        Message price = oxoStreamTaker.getPriceUpdateMsg("mdreq1234", 10000);
        assertNotNull(price);


        //new limit
        myClOrdId = 3456;
        showAmt = -1;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        price = oxoStreamTaker.getPriceUpdateMsg("mdreq1234", 10000);
        assertNotNull(price);

    }

    @Test
    public void testCancelOnDisc_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        //disconnect
        client.logout();
        client.disconnect();
        Thread.sleep(5000);
        client.connect();
        client.logon();
        Thread.sleep(5000);
        client.sendInstrumentInfoRequest();
        Thread.sleep(5000);
      
        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
    }

    @Test
    public void test2OrdersSameClOrdId_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //2nd order
        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_CL_ORD_ID);
    }


    @Test
    public void testSendGTCOrder_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //order should not expire or cancel
        Object message = client.getSysCancel(10000);
        assertNull(message);
    }

    @Test
    public void testSendIOCOrder_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        
        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, EXPIRE_TYPE_IOC);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        long myOrderId = ack.getOrderId();

        //order should get sys canceled
        Object message = client.getSysCancel(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
      assertEquals(ORDER_CANCEL_TYPE_SYSTEM, cancelType);
    }

    @Test
    public void testOrderCancelLimit_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        long myOrderId = ack.getOrderId(); 
        
        int newClOrdId = 8765;
        //cancel order
        client.sendOrderCancel(newClOrdId, myClOrdId, ccy);
        Object message = client.getSysCancel(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_USER, cancelType);
    }

    @Test
    public void testOrderCancelIceberg_owner() throws Exception
    {
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        long myOrderId = ack.getOrderId(); 

        int newClOrdId = 8765;
        //cancel order
        client.sendOrderCancel(newClOrdId, myClOrdId, ccy);
        Object message = client.getSysCancel(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_USER, cancelType);
    }

    @Test
    public void testOrderReplaceLimit_owner() throws Exception
    {
        int myClOrdId = 3456;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //replace order limit rate and amount
        int newClOrdId = 6543;
        int newAmount = 500000000;
        Integer newRate = 345670;
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        Object message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_REPLACED, status);
        assertEquals(ERROR_OK, errorCode);
    }

    @Test
    public void testOrderReplaceIceberg_owner() throws Exception
    {
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 50000000;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, orderType, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        //replace order limit rate and amount
        int newClOrdId = 2345;
        int newAmount = 600000000;
        Integer newRate = 345670;
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        Object message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();
        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId); //TODO: after fixed
        assertEquals(ORDER_REPLACE_STATUS_REPLACED, status);
        assertEquals(ERROR_OK, errorCode);
    }

    @Test
    public void testSendNewOrderOrdType_owner() throws Exception
    {
        //bad order type
        int myClOrdId = 5678;
        byte orderType='M';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_NEW_ORDER_TYPE);
    }

    @Test
    public void testSendNewOrderSide_owner() throws Exception
    {
        //invalid order side
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'Y';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_SIDE);
    }

    @Test
    public void testSendNewOrderAmount_owner() throws Exception
    {
        //invalid amount
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        
        long amount = -1;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_AMT);

        amount = 0;
        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_SPECIFIED_AMT);
        
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_REJECTED, status);
//        assertEquals(TakerErrorCode.INVALID_SPECIFIED_AMT, errorCode);
        //should be 15; will be fixed
    }

    @Test
    public void testSendNewOrderRate_owner() throws Exception
    {
        //negative rate
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = -12345;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_PRICE);

        //exceed ccy pair scale
        rate = 1234567891;
        ccy = "EUR/JPY-SP";
        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.EXCEED_CCY_PAIR_SCALE);
    }

    @Test
    public void testSendNewOrderCcy_owner() throws Exception
    {
        //negative rate
        int myClOrdId = 5678;
        
        String ccy = "GBP/JPY-1W";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = -12345;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_INSTRUMENT);
    }
    
    //DEV-30249
    //If use SMT, you need to add EUR/BRL-1M in devmon and taker needs to subscribe to it.
    @Test
    public void testSendNewOrderNdfCcy_owner() throws Exception
    {
        int myClOrdId = new Random().nextInt(1000);
        
        String ccy = "EUR/BRL-1M";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 12345;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.SEF_VALIDATION_FAILED);
    }

    @Test
    public void testSendNewOrderMinAmt_owner() throws Exception
    {
        //bmin amt > amt
        int myClOrdId = new Random().nextInt(1000);
        
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = 200000000;
        long showAmt = -1;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.UNEXPECTED);
        //should be 99; will be fixed
    }

    @Test
    public void testSendNewOrderShowAmt_owner() throws Exception
    {
        //show amt > amt
        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 200000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.UNEXPECTED);
    }

    @Test
    public void testSendNewOrderExpiry_owner() throws Exception
    {
        //invalid expiry
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'B';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_REJECTED, TakerErrorCode.INVALID_EXPIRY);
    }

    @Test
    public void testOrderCancelOrigClOrdId_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        int newClOrdId = 8765;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        //cancel order - with bad origclordid
        client.sendOrderCancel(newClOrdId, myClOrdId+1, ccy);
        Object message = client.getOrderCancelAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int oldClOrdId = msgBuff.getInt();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myClOrdId+1, oldClOrdId);
        assertEquals(TakerErrorCode.ORDER_NOT_ACTIVE, TakerErrorCode.of(errorCode));
    }

    /*
     * DEV-20456
     * Make sure "Allow Client Order Id Process" is checked for this user
     */
    @Test
    public void testOrderCancelAndSubmitWithSameClOrdId_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        int newClOrdId = 8765;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        myOrderId = ack.getOrderId();
        
        //cancel order - with new clOrdId
        client.sendOrderCancel(newClOrdId, myClOrdId, ccy);
        Object message = client.getSysCancel(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);

        //send new order with clOrdId same as the one used to cancel order
        client.sendOrder(newClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack2 = client.getNewOrderAck(3000);
        assertNotNull(ack2);
        ack2.doAssert(newClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
    }
    
    @Test
    public void testOrderCancelCcy_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        int newClOrdId = 8765;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //cancel order - with bad ccy
        ccy = "GBP/JPY-1W";
        client.sendOrderCancel(newClOrdId, myClOrdId, ccy);
        Object message = client.getOrderCancelAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int oldClOrdId = msgBuff.getInt();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myClOrdId, oldClOrdId);
        assertEquals(TakerErrorCode.INVALID_INSTRUMENT, TakerErrorCode.of(errorCode));
    }

    @Test
    public void testOrderReplaceOrigClOrdId_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        NewOrderAck ack = client.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(myClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);

        //replace order - invalid origClOrdId
        int newClOrdId = 2345;
        int newAmount = 5000000;
        Integer newRate = 345670;
        client.sendOrderReplace(newClOrdId, myClOrdId+1, ccy, newAmount, newRate);
        Object message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int origId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId+1, origId);
        assertEquals(ORDER_REPLACE_STATUS_REJECTED, status);
        assertEquals(TakerErrorCode.ORDER_NOT_ACTIVE, TakerErrorCode.of(errorCode));
    }

    @Test
    public void testOrderReplaceOrderAmt_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        //replace order - invalid order amount
        int newClOrdId = 2345;
        int newAmount = 10;
        Integer newRate = 345670;
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getInt();
        status = msgBuff.get();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_REJECTED, status);
        assertEquals(TakerErrorCode.INVALID_SPECIFIED_AMT, TakerErrorCode.of(errorCode));
    }

    @Test
    public void testOrderReplacePrice_owner() throws Exception
    {
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        long amount = 100000000;
        Integer rate = 12345;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, side, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        TakerErrorCode errorCode = TakerErrorCode.of(msgBuff.getShort());

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        //replace order - invalid price
        int newClOrdId = 2345;
        int newAmount = 5000000;
        Integer newRate = -1;
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getInt();
        status = msgBuff.get();
        errorCode = TakerErrorCode.of(msgBuff.getShort());

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_REJECTED, status);
        assertEquals(TakerErrorCode.INVALID_LIMIT_RATE, errorCode);
    }

    @Test
    public void testOrderFillBuyLimit_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("1000000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 9764;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(10000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);//TODO:
        System.out.println("The field is "+ execBroker);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    @Test
    public void testOrderCancelAfterFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", "EUR/USD", "1.4051", "1.4054");
        
        Thread.sleep(1000);

        int myClOrdId = 9764;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myOrderId2;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer orderAck = client.getOrderAck(10000);
        assertNotNull(orderAck);
        ByteBuffer msgBuff = (ByteBuffer) orderAck;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order1 = maker.getOrder(10000);
        assertNotNull("null order received", order1);

        int cancelClOrdId = 9990;
        int cancelClOrdId2 = 9991;
        
        //Submit two OrderCancel
        client.sendOrderCancel(cancelClOrdId, myClOrdId, ccy);
        Thread.sleep(100);
        client.sendOrderCancel(cancelClOrdId2, myClOrdId, ccy);
        
        //Get the CancelReject for the 2nd OrderCancel
        Object cancelAck = client.getOrderCancelAck(10000);
        assertNotNull(cancelAck);
        
        msgBuff = (ByteBuffer) cancelAck;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        int newClOrdId = msgBuff.getInt();
        int prevClOrdId = msgBuff.getInt();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, cancelClOrdId2);
        assertEquals(prevClOrdId, clOrdId);
        assertEquals(ERROR_UNEXPECTED, errorCode);
        
        
        //Submit 2nd NewOrder using the same client order id as the 2nd OrderCancel
        client.sendOrder(cancelClOrdId2, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer orderAck2 = client.getOrderAck(10000);
        assertNotNull(orderAck2);
        ByteBuffer msgBuff2 = (ByteBuffer) orderAck2;
        msgBuff2.rewind();
        int seqNumber2 = msgBuff2.getInt();
        int timestamp2 = msgBuff2.getInt();
        byte msgType2 = msgBuff2.get();
        int clOrdId2 = msgBuff2.getInt();
        long orderId2 = msgBuff2.getLong();
        byte status2 = msgBuff2.get();
        short errorCode2 = msgBuff2.getShort();
        myOrderId2 = orderId2;

        assertNotNull(orderId2);
        assertEquals(clOrdId2, cancelClOrdId2);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status2);
        assertEquals(ERROR_OK, errorCode2);

        //Maker fills the 1st order
      maker.orderReplyFilled(order1);

      orderAck = client.getOrderFill(10000);
      assertNotNull(orderAck);
      msgBuff = (ByteBuffer) orderAck;
      msgBuff.rewind();
      seqNumber = msgBuff.getInt();
      timestamp = msgBuff.getInt();
      msgType = msgBuff.get();

      clOrdId = msgBuff.getInt();
      orderId = msgBuff.getLong();
      short instIndex = msgBuff.getShort();
      byte side = msgBuff.get();
      long fillAmt = msgBuff.getLong();
      int fillRate = msgBuff.getInt();
      String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
      String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
      byte tradeType = msgBuff.get();
      long settleDate = msgBuff.getLong();
      long tradeDate = msgBuff.getLong();
      long transactTime = msgBuff.getLong();
      long leftAmt = msgBuff.getLong();
      byte aggressor = msgBuff.get();

      assertEquals(myClOrdId, clOrdId);
      assertEquals(myOrderId, orderId);
      assertNotNull(instIndex); //TODO:
      assertEquals(mySide, side);
      assertEquals(amount, fillAmt);
      assertEquals(rate.intValue(), fillRate);
      assertEquals(0, leftAmt);
      assertEquals(AGGRESSOR_YES, aggressor);
      assertNotNull(transactTime);
      assertNotNull(tradeDate);
      assertNotNull(settleDate);
      assertNotNull(tradeId);//TODO:
      System.out.println("The field is "+ execBroker);
      assertEquals("Hub", execBroker);//TODO:
      assertEquals(TRADE_TYPE_TRADE, tradeType);
      
      
      
      //Get CancelReject for the 1st OrderCancel
      Object cancelAck2 = client.getOrderCancelAck(10000);
      assertNotNull(cancelAck2);
      
      msgBuff = (ByteBuffer) cancelAck2;
      msgBuff.rewind();
      seqNumber = msgBuff.getInt();
      timestamp = msgBuff.getInt();
      msgType = msgBuff.get();

      int newClOrdId2 = msgBuff.getInt();
      int prevClOrdId2 = msgBuff.getInt();
      errorCode = msgBuff.getShort();

      assertEquals(newClOrdId2, cancelClOrdId);
      assertEquals(prevClOrdId2, clOrdId);
      assertEquals(ERROR_UNEXPECTED, errorCode);
      
      
      
      //Maker fills the 2nd order
      maker.submitQuoteEsp("1000000", "EUR/USD", "1.4051", "1.4054");
      
      Message order2 = maker.getOrder(10000);
      assertNotNull("null order received", order2);
      
      maker.orderReplyFilled(order2);

      orderAck2 = client.getOrderFill(10000);
      assertNotNull(orderAck2);
      msgBuff = (ByteBuffer) orderAck2;
      msgBuff.rewind();
      seqNumber = msgBuff.getInt();
      timestamp = msgBuff.getInt();
      msgType = msgBuff.get();

      clOrdId2 = msgBuff.getInt();
      orderId2 = msgBuff.getLong();
      instIndex = msgBuff.getShort();
      side = msgBuff.get();
      fillAmt = msgBuff.getLong();
      fillRate = msgBuff.getInt();
      execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
      tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
      tradeType = msgBuff.get();
      settleDate = msgBuff.getLong();
      tradeDate = msgBuff.getLong();
      transactTime = msgBuff.getLong();
      leftAmt = msgBuff.getLong();
      aggressor = msgBuff.get();

      assertEquals(clOrdId2, cancelClOrdId2);
      assertEquals(myOrderId2, orderId2);
      assertNotNull(instIndex); //TODO:
      assertEquals(mySide, side);
      assertEquals(amount, fillAmt);
      assertEquals(rate.intValue(), fillRate);
      assertEquals(0, leftAmt);
      assertEquals(AGGRESSOR_NO, aggressor);
      assertNotNull(transactTime);
      assertNotNull(tradeDate);
      assertNotNull(settleDate);
      assertNotNull(tradeId);//TODO:
      System.out.println("The field is "+ execBroker);
      assertEquals("Hub", execBroker);//TODO:
      assertEquals(TRADE_TYPE_TRADE, tradeType);
        
    }

    @Test
    public void testOrderFillOxo_owner() throws Exception
    {
        assertTrue(oxoTaker.getUserName()+" is not logged on.", oxoTaker.logon());

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        oxoTaker.submitOrder("fixClOrdId", null, BigDecimal.valueOf(1.4054), new BigDecimal("1000000"), "EUR/USD", "2");
        Message msg = oxoTaker.getOrderUpdateMsg("fixClOrdId", 10000);
        assertNotNull(msg);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);//TODO:
        assertEquals("Hub", execBroker);//TODO:
        assertEquals(TRADE_TYPE_TRADE, tradeType);
        msg = oxoTaker.getOrderUpdateMsg("fixClOrdId", 10000);
        assertNotNull(msg);
    }
    
    /*
     * DEV-21309
     * UserFixSessionProperties.FIX_IS_SHOW_END_MAKER=Hub is set for the ouch taker 
     * The Hub party's Hub code should be set to 'Hub'
     * Relationship: Taker1-Hub-Taker2
     */
    @Test
    public void testOrderFillOxoShowEndMaker_owner() throws Exception
    {
        TakerTestSession tradeTaker = oxoTaker;
        assertTrue(tradeTaker.getUserName()+" is not logged on.", tradeTaker.logon());

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        tradeTaker.submitOrder("fixClOrdId", null, BigDecimal.valueOf(1.4054), new BigDecimal("1000000"), "EUR/USD", "2");
        Message msg = tradeTaker.getOrderUpdateMsg("fixClOrdId", 10000);
        assertNotNull(msg);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);//TODO:
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
        msg = tradeTaker.getOrderUpdateMsg("fixClOrdId", 10000);
        assertNotNull(msg);
    }

    @Test
    public void testOrderFillSellLimit_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("100000000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    @Test//for this to pass you need to check "Cancel out Trades" for the hub.
    public void testOrderTimeoutLimit_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("100000000", "EUR/USD", "1.4051", "1.4054");        
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        //timeout

    }

    @Test
    public void testOrderFillBuyIceberg_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("100000000", "EUR/USD", "1.4051", "1.4054");   
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = 100000000;//since we are testing out a full fill right now
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, orderType, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    @Test
    public void testOrderFillSellIceberg_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("100000000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = 100000000;//since we are testing out a full fill right now
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, orderType, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    @Test
    public void testOrderTimeoutIceberg_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("100000000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = 100000000;//since we are testing out a full fill right now
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, orderType, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        //timeout

    }

    @Test
    public void testOrderPartialFillBelowMin_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("500000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = 60000000;//first set min amt > price, verify that no rfe is sent to maker
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 40000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNull("no order should be received", order);

        //now submit new quote for 600k, should be filled        
        maker.submitQuoteEsp("600000", "EUR/USD", "1.4051", "1.4054");  

        order = maker.getOrder(5000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(minAmt, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        //remaining order is below min, should be canceled
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_SYSTEM, cancelType);
    }

    @Test
    public void testOrderPartialFillBelowSystemMin_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("500000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 50000001;
        Integer rate = 140510;
        long minAmt = 0;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 1;
        long myFillAmount = 50000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(5000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myFillAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertNotNull(aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        //remaining order is below sys min, should be canceled
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_BELOW_MIN, cancelType);
    }

    @Test
    public void testOrderPartialFillLimit_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 60000000;
        long myFillAmount = 40000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myFillAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
//        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        myLeftAmount = 20000000;
        
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");  

        order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        instIndex = msgBuff.getShort();
        side = msgBuff.get();
        fillAmt = msgBuff.getLong();
        fillRate = msgBuff.getInt();
        execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        tradeType = msgBuff.get();
        settleDate = msgBuff.getLong();
        tradeDate = msgBuff.getLong();
        transactTime = msgBuff.getLong();
        leftAmt = msgBuff.getLong();
        aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myFillAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        maker.submitQuoteEsp("20000000", "EUR/USD", "1.4051", "1.4054");  
        
        order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        instIndex = msgBuff.getShort();
        side = msgBuff.get();
        fillAmt = msgBuff.getLong();
        fillRate = msgBuff.getInt();
        execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        tradeType = msgBuff.get();
        settleDate = msgBuff.getLong();
        tradeDate = msgBuff.getLong();
        transactTime = msgBuff.getLong();
        leftAmt = msgBuff.getLong();
        aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myLeftAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }
    
    //T-H-M order will never time out
    @Test
    public void testNotAllowOrderPartialReplyLimit_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 60000000;
        long myFillAmount = 40000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyPartiallyFilled(order, "200000");
        
        Message reject = maker.getMessageFromRejectQueue(3000);
        assertNotNull("Maker didnt get BusinessMessageReject", reject);
        assertTrue("Unexpected reject reason", 
                reject.getStringFieldValue(Constants.TAGText).startsWith("Confirmation has invalid LeavesQty(151) amount"));
                
        //OrderTimeOut after 8 seconds
        Message orderTimeOut = maker.getMessageFromRejectQueue(10000);
        assertNotNull("Maker didnt get OrderTimeOut", orderTimeOut);

        message = client.getOrderFill(3000);
        assertNull("Ouch taker will not get any time out msg as it's T-H-M setup", message);
    }
    
    @Test
    public void testOrderPartialFillIceberg_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("200000", "EUR/USD", "1.4051", "1.4054");  
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 60000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 40000000;
        long myFillAmount = 20000000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myFillAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
        myLeftAmount = 20000000;
        
        maker.submitQuoteEsp("200000", "EUR/USD", "1.4051", "1.4054");  
        
        order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        instIndex = msgBuff.getShort();
        side = msgBuff.get();
        fillAmt = msgBuff.getLong();
        fillRate = msgBuff.getInt();
        execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        tradeType = msgBuff.get();
        settleDate = msgBuff.getLong();
        tradeDate = msgBuff.getLong();
        transactTime = msgBuff.getLong();
        leftAmt = msgBuff.getLong();
        aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myFillAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        maker.submitQuoteEsp("200000", "EUR/USD", "1.4051", "1.4054");  
        
        order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        instIndex = msgBuff.getShort();
        side = msgBuff.get();
        fillAmt = msgBuff.getLong();
        fillRate = msgBuff.getInt();
        execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        tradeType = msgBuff.get();
        settleDate = msgBuff.getLong();
        tradeDate = msgBuff.getLong();
        transactTime = msgBuff.getLong();
        leftAmt = msgBuff.getLong();
        aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(myLeftAmount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals("Hub", execBroker);
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    @Test
    public void testOrderCancelOnPartialFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);        
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 600000;
        long myFillAmount = 400000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        int newClOrdId = 8765;

        client.sendOrderCancel(newClOrdId, clOrdId, ccy);
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        status = msgBuff.get();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);//TODO: add back after fix
    }

    @Test//not passing, got 14 instead of 13
    public void testOrderCancelOnFullFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 40000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        int newClOrdId = 8765;

        client.sendOrderCancel(newClOrdId, clOrdId, ccy);
        message = client.getOrderCancelAck(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        int oldClOrdId = msgBuff.getInt();
        orderId = msgBuff.getInt();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, oldClOrdId);
        assertEquals(clOrdId, orderId);
//        assertEquals(TakerErrorCode.INVALID_NEW_CL_ORD_ID, errorCode);
        //still being decided should be 13 or 14
    }

    @Test
    public void testOrderReplaceOnPartialFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions
        
        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);

        int newClOrdId = 2345;
        int newAmount = 150000000;
        Integer newRate = 140510;

        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);

        //also get back cancel msg
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        clOrdId = msgBuff.getInt();
        long ordId = msgBuff.getLong();
        status = msgBuff.get();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertNotNull(ordId);//TODO:
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);
    }
    
    @Test
    public void testOrderReplaceOnFullFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);

        int newClOrdId = 2345;
        int newAmount = 150000000;
        Integer newRate = 140510;

        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_CANCELED, status);
        assertEquals(0, errorCode);
    }
    
    @Test
    public void testOrderReplaceNonExistent_owner() throws Exception
    {


        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;


        int newClOrdId = 2345;
        int newAmount = 150000000;
        Integer newRate = 140510;
        System.out.println("Sending replace");
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        Object message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
      assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_REJECTED, status);
        System.out.println("Error code = " + errorCode);
    }

    @Test//not passing, getting wrong error code 15
    public void testOrderReplaceOnPendingFill_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 600000;
        long myFillAmount = 400000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        int newClOrdId = 2345;
        int newAmount = 1500000;
        Integer newRate = 140510;

        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        Thread.sleep(2000);
        maker.orderReplyFilled(order);

        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);
        //should not be 0; will be fixed
        
        //also get back cancel msg
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        clOrdId = msgBuff.getInt();
        long ordId = msgBuff.getLong();
        status = msgBuff.get();
        errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertNotNull(ordId);//TODO:
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ERROR_OK, errorCode);
        //something is wrong here
    }

    //per spec: Customers connected to hubs are never subject to time outs
    @Test
    public void testOrderReplaceOnTimeout_THM() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 600000;
        long myFillAmount = 400000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        
        //OrderTimeOut after 8 seconds
        Message orderTimeOut = maker.getMessageFromRejectQueue(10000);
        assertNotNull("Maker didnt get OrderTimeOut", orderTimeOut);
                
        int newClOrdId = 2345;
        long newAmount = 150000000;
        Integer newRate = 140510;
        client.sendOrderReplace(newClOrdId, myClOrdId, ccy, newAmount, newRate);
        message = client.getOrderReplaceAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        msgBuff.getInt();
        msgBuff.getInt();
        msgBuff.get();

        int clOrdId = msgBuff.getInt();
        int orderId = msgBuff.getInt();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();

        assertEquals(newClOrdId, clOrdId);
        assertEquals(myClOrdId, orderId);
        assertEquals(ORDER_REPLACE_STATUS_REPLACED, status);
        assertEquals(ERROR_OK, errorCode);
     }

    @Test
    public void testOrderReplaceOnMakerDeny_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("400000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 600000;
        long myFillAmount = 400000;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyRejected(order);
        int newClOrdId = 2345;
        int newAmount = 1500000;
        Integer newRate = 140510;
        client.sendOrderReplace(myClOrdId, newClOrdId, ccy, newAmount, newRate);
        Thread.sleep(5000);//TODO: check what msg is expected and add back
     }


    /*
     * DEV-19244
     */
    //In this test the order is filled for 999,999.95 and the remaining amount is 5 cents.
    //The orders gets canceled since its below minimum. This is a special case since there
    //are two messages sent to the user to say that this small amount is canceled.
    @Test
    public void testOrderPartialFillBelowMinSpecialCase_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("500000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 140510;
        long minAmt = 99999900;//first set min amt > price, verify that no rfe is sent to maker
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 100;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNull("no order should be received", order);

        //now submit new quote for 600k, should be filled        
        maker.submitQuoteEsp("999999", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        order = maker.getOrder(5000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(minAmt, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_NO, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        //remaining order is below min, should be canceled
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_SYSTEM, cancelType);
    }


    /*
     * DEV-21309
     * UserFixSessionProperties.FIX_IS_SHOW_END_MAKER is set so the execBroker should be
     * 'mgf2' or whatever thats set for the maker party's Bank code when the relation is
     * Taker-Hub-Maker
     */
    @Test
    public void testOrderFillBuyLimitShowEndMaker_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", "EUR/USD", "1.4051", "1.4054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 9764;
        
        String ccy = "EUR/USD-SP";
        byte mySide = 'B';
        long amount = 100000000;
        Integer rate = 140540;
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(3000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(amount, fillAmt);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(0, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);//TODO:
        assertEquals("Hub", execBroker);//or whatever the Bank code is for that maker
        assertEquals(TRADE_TYPE_TRADE, tradeType);
    }

    /*
     * DEV-21430
     */
    @Ignore @Test
    public void testOrderPartialFillCancelLessThanToleranceAmount_owner() throws Exception
    {
        assertTrue(maker.getUserName()+" is not logged on.", maker.logon());
        maker.initialize(10);
      //now submit new quote for 999999.40, should be partially filled   
        maker.submitQuoteEsp("999999.40", "EUR/USD", "13.3051", "13.3054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        int myClOrdId = 5678;
        
        String ccy = "USD/MXN-SP";
        byte mySide = 'S';
        long amount = 100000000;
        Integer rate = 1330510;
        long minAmt = 0;
        long showAmt = -1;
        byte expiry = 'G';
        long myOrderId;
        long myLeftAmount = 60;

        client.sendOrder(myClOrdId, ORDER_TYPE_LIMIT, ccy, mySide, amount, rate, minAmt, showAmt, expiry);
        ByteBuffer message = client.getOrderAck(10000);
        assertNotNull(message);
        ByteBuffer msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        int seqNumber = msgBuff.getInt();
        int timestamp = msgBuff.getInt();
        byte msgType = msgBuff.get();

        int clOrdId = msgBuff.getInt();
        long orderId = msgBuff.getLong();
        byte status = msgBuff.get();
        short errorCode = msgBuff.getShort();
        myOrderId = orderId;

        assertEquals(myClOrdId, clOrdId);
        assertNotNull(orderId);
        assertEquals(NEW_ORDER_STATUS_CONFIRMED, status);
        assertEquals(ERROR_OK, errorCode);

        Message order = maker.getOrder(10000);
        assertNotNull("null order received", order);
        maker.orderReplyFilled(order);

        //now submit new quote, should not get filled
        maker.submitQuoteEsp("10000", "EUR/USD", "13.3051", "13.3054");
        Thread.sleep(1000);//this is to prevent aggressor confusions

        message = client.getOrderFill(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        short instIndex = msgBuff.getShort();
        byte side = msgBuff.get();
        long fillAmt = msgBuff.getLong();
        int fillRate = msgBuff.getInt();
        String execBroker = msgBuff.getString(LENGTH_EXEC_BROKER, client.f_charDecoder).trim();
        String tradeId = msgBuff.getString(LENGTH_TRADE_ID, client.f_charDecoder).trim();
        byte tradeType = msgBuff.get();
        long settleDate = msgBuff.getLong();
        long tradeDate = msgBuff.getLong();
        long transactTime = msgBuff.getLong();
        long leftAmt = msgBuff.getLong();
        byte aggressor = msgBuff.get();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertNotNull(instIndex); //TODO:
        assertEquals(mySide, side);
        assertEquals(rate.intValue(), fillRate);
        assertEquals(myLeftAmount, leftAmt);
        assertEquals(AGGRESSOR_YES, aggressor);
        assertNotNull(transactTime);
        assertNotNull(tradeDate);
        assertNotNull(settleDate);
        assertNotNull(tradeId);
        assertEquals(TRADE_TYPE_TRADE, tradeType);

        //remaining order is below min, should be canceled
        message = client.getSysCancel(10000);
        assertNotNull(message);
        msgBuff = (ByteBuffer) message;
        msgBuff.rewind();
        seqNumber = msgBuff.getInt();
        timestamp = msgBuff.getInt();
        msgType = msgBuff.get();

        clOrdId = msgBuff.getInt();
        orderId = msgBuff.getLong();
        status = msgBuff.get();
        short cancelType = msgBuff.getShort();

        assertEquals(myClOrdId, clOrdId);
        assertEquals(myOrderId, orderId);
        assertEquals(ORDER_CANCEL_STATUS_CANCELED, status);
        assertEquals(ORDER_CANCEL_TYPE_SYSTEM, cancelType);

        Thread.sleep(30000);
    }
    
    
    //DEV-31119
    @Test
    public void testNewOrderAndDisconnect_owner() throws Exception
    {
        //new iceberg
        int myClOrdId = 6544;
        byte orderType='Z';
        String ccy = "EUR/USD-SP";
        
        long amount = 60000000;
        Integer rate = 123450;
        long minAmt = -1;
        long showAmt = 20000000;
        byte expiry = 'G';

        client.sendOrder(myClOrdId, orderType, ccy, SIDE_SELL, amount, rate, minAmt, showAmt, expiry);
        client.disconnect();
        
        Thread.sleep(15000);
    }

    
    @After
    public void tearDown()throws Exception
    {
        if(client.isConnected()){
            client.logout();
            client.disconnect();
        }
        this.logoutUsers(2000);
    }
}
