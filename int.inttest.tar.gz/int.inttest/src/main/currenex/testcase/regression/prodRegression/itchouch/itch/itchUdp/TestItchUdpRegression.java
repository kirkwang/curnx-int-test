package currenex.testcase.regression.prodRegression.itchouch.itch.itchUdp;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateSecondTagWithinRepeatedGroup;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.validateTagWithinRepeatedGroup;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.itch.ItchClient;
import currenex.testcase.ATestCase;

/**
 *
 * use testBinaryRegression.properties
 * @author mgopalakrishnan
 */
public final class TestItchUdpRegression extends ATestCase {
    ItchClient itchClient;
    private MakerTestSession maker;
    private TakerTestSession oxoTaker;
    private TakerTestSession oxo2Taker;
    private TakerTestSession hubTaker;
    final String FX_TEST_BASE_CCY = "EUR";
    final String FX_TEST_TERMS_CCY = "JPY";
    final long DEF_WAIT_TIME = 10000;

    final String FX_TEST_INSTR = "EUR/JPY";
    final String PRODUCT_CURRENCY = "4";
    
    // spread 0.4 on both bid and offer
    final String BID_PX_MAKER = "131.625";
    final String BID_PX_TAKER = "131.619";
    final String BID_PX_MATCH = "131.621";
    
    final String OFFER_PX_MAKER = "131.685";
    final String OFFER_PX_TAKER = "131.692";
    final String OFFER_PX_MATCH = "131.689";
    final String OFFER_PX_MATCH2 = "131.688";
    
    final String amount = "1000000";
    final String ordType = Constants.ORDTYPE_ForexLimit;

    @Before
    public void setUp() throws Exception {

        String userId = props().getProperty("ITCH_USER_ID");
        String host = props().getProperty("ITCH_HOST");
        int port = Integer.parseInt(props().getProperty("ITCH_PORT"));
        itchClient = new ItchClient(userId, host, port, "Test123456",
                new String[] { FX_TEST_INSTR+"-SP" });
        
        hubTaker = getTaker("BIxxHubTHMcust");
        oxoTaker = getTaker("BIxxTakerTHMU2");
        oxo2Taker = getTaker("BIxxTakerTHM2U2");
        maker = getMaker("BIxxMakerTHMU2");    
        }

    @After
    public void tearDown() throws Exception {
        itchClient.logout("bye!");
        this.logoutUsers(5000);
    }
    
    @Ignore
    @Test
    public void testItchLargeLogon_owner() throws Exception {
        
        String userId = props().getProperty("ITCH_USER_ID");
        String host = props().getProperty("ITCH_HOST");
        int port = Integer.parseInt(props().getProperty("ITCH_PORT"));
        
        long waitTimeMiliSec = Long.valueOf(props().getProperty("WAIT_TIME_MILISEC", "100"));
        int logonTimes = Integer.valueOf(props().getProperty("LARGE_LOGON_TIMES", "1"));
        
        ItchClient[] clients = new ItchClient[logonTimes];
        
        for(int i=0;i<logonTimes;i++){
            
            System.out.println("logon time:"+(i+1));
            
            clients[i] = new ItchClient(userId, host, port, "test1234",
                    new String[] { FX_TEST_INSTR+"-SP" });
            
            clients[i].start();
            Thread.sleep(waitTimeMiliSec);
        }
        
        Thread.sleep(10000);
        
        for(int i=0;i<logonTimes;i++){
            clients[i].logout("");;
        }    
    }

    @Test
    public void testItchMarketData_owner() throws Exception {
        
        itchClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        
        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX_MAKER);

        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("itchClient didnt receive price", price);
        assertEquals("different price", "13168900", price);
    }


    /* DEV-21758 */
    /* Make sure we have a spread applied for the hub with this taker
     * Here we have a 0.4 spread applied for taker*/
    @Test
    public void testItchTickerOXPSell_owner() throws Exception{
        
        itchClient.start();
        assertTrue("taker is not logged on:"+oxoTaker.getUserName(),oxoTaker.logon());
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        maker.initialize(10);
        Thread.sleep(5000);
        
        maker.submitQuoteEsp(amount, FX_TEST_INSTR, BID_PX_MAKER, OFFER_PX_MAKER);
        Thread.sleep(1000);
        
            Message msg = null;
            String clOrdID = "testClOrdId1";
            String hubParty = hubTaker.getPartyName();
            String takerParty = oxoTaker.getPartyName();

            // submit order
            //the limit rate is 1.3009 and any rate from bank above this rate
            //on the BID side will get the order filled
            oxoTaker.submitRetailOrder(clOrdID, null, FX_TEST_INSTR,
                    PRODUCT_CURRENCY, Constants.SIDE_Sell, FX_TEST_BASE_CCY,
                    amount, ordType, BID_PX_TAKER, null,
                    Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                    null, null);

            msg = oxoTaker.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
            String orderId = msg.getStringFieldValue(Constants.TAGOrderID);
            String execId = msg.getStringFieldValue(Constants.TAGExecID);

            //do assertion check for the execution report when order is accepted
            doAssertionCheckForExecutioReport(msg, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                    null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId, "0"/*execType*/,
                    "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                    PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/, ordType, BID_PX_TAKER/*price*/,
                    null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                    amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

            Message order = maker.getOrder(10000);
            //do assertion check for the order maker receives
            doAssertionCheckForMakerReceivingOrder(order, "2"/*NoPartyIds*/, oxoTaker.getUserName()/*partyId1*/,
                    "3"/*partyRole1*/, takerParty/*partyId2*/, "1"/*partyRole2*/, "2"/*HandlInst*/,
                    FX_TEST_INSTR/*symbol*/, "SP"/*SymbolSfx*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/,
                    amount/*orderQty*/, "H"/*ordType*/, BID_PX_MAKER/*Price*/, FX_TEST_BASE_CCY/*currency*/,
                    "4"/*TimeInForce*/, "Y"/*AggressorIndicator*/, "PS0"/*StreamReference*/);

            maker.orderReplyFilled(order);
            Message execReport = oxoTaker.getOrderUpdateMsg(clOrdID, 10000);
            assertEquals(msg.getStringFieldValue(Constants.TAGOrderID),
                    execReport.getStringFieldValue(Constants.TAGOrderID));

            //the ticker rate or the rate at which the order is filled in 1.30126 as there
            //is a spread of 0.4 applied on the hub for this taker
            //do assertion check for the execution report when order is full filled
            doAssertionCheckForExecutioReport(execReport, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                    "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId, "F"/*execType*/,
                    "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                    FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/,
                    ordType, BID_PX_TAKER/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                    BID_PX_MATCH/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, BID_PX_MATCH/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

            //the itch ticker msg will see the clean rate, not the spread rate
            String price = itchClient.getTicker(10000);
            assertNotNull("no ticker msg was received!!", price);
            assertEquals("different rate received!", "13162100", price);
    }


    /* DEV-21758 */
    /* Make sure we have a spread applied for the hub with this taker
     * Here we have a 0.4 spread applied for taker*/
    @Test
    public void testItchTickerOXPBuy() throws Exception{
        
        itchClient.start();
        assertTrue("taker is not logged on:"+oxoTaker.getUserName(),oxoTaker.logon());
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        maker.initialize(10);
        Thread.sleep(5000);
        
            Message msg = null;
            String clOrdID = "testClOrdId1";
            String hubParty = hubTaker.getPartyName();
            String takerParty = oxoTaker.getPartyName();

            // submit order
            //the limit rate is 1.3019 and any rate from bank below this rate
            //on the OFFER side will get the order filled
            oxoTaker.submitRetailOrder(clOrdID, null, FX_TEST_INSTR,
                    PRODUCT_CURRENCY, Constants.SIDE_Buy, FX_TEST_BASE_CCY,
                    amount, ordType, OFFER_PX_TAKER, null,
                    Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                    null, null);

            msg = oxoTaker.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
            String orderId = msg.getStringFieldValue(Constants.TAGOrderID);
            String execId = msg.getStringFieldValue(Constants.TAGExecID);

            //do assertion check for the execution report when order is accepted
            doAssertionCheckForExecutioReport(msg, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                    null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId, "0"/*execType*/,
                    "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                    PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/, ordType, OFFER_PX_TAKER/*price*/,
                    null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                    amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

            //quote submitted after the order            
            maker.submitQuoteEsp(amount, FX_TEST_INSTR, BID_PX_MAKER, OFFER_PX_MAKER);

            Message order = maker.getOrder(10000);
            //do assertion check for the order maker receives
            //order is aggressed
            doAssertionCheckForMakerReceivingOrder(order, "2"/*NoPartyIds*/, oxoTaker.getUserName()/*partyId1*/,
                    "3"/*partyRole1*/, takerParty/*partyId2*/, "1"/*partyRole2*/, "2"/*HandlInst*/,
                    FX_TEST_INSTR/*symbol*/, "SP"/*SymbolSfx*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/,
                    amount/*orderQty*/, "H"/*ordType*/, OFFER_PX_MAKER/*Price*/, FX_TEST_BASE_CCY/*currency*/,
                    "4"/*TimeInForce*/, "N"/*AggressorIndicator*/, "PS0"/*StreamReference*/);

            maker.orderReplyFilled(order);
            Message execReport = oxoTaker.getOrderUpdateMsg(clOrdID, 10000);
            assertEquals(msg.getStringFieldValue(Constants.TAGOrderID),
                    execReport.getStringFieldValue(Constants.TAGOrderID));

            //the ticker rate or the rate at which the order is filled in 1.30154 as there
            //is a spread of 0.4 applied on the hub for this taker
            //do assertion check for the execution report when order is full filled
            doAssertionCheckForExecutioReport(execReport, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                    "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId, "F"/*execType*/,
                    "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                    FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/,
                    ordType, OFFER_PX_TAKER/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                    OFFER_PX_MATCH/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, OFFER_PX_MATCH/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

            //the itch ticker msg will see the clean rate, not the spread rate
            String price = itchClient.getTicker(10000);
            assertNotNull("no ticker msg was received!!", price);
            assertEquals("different rate received!", "13168900", price);
    }


    /* DEV-21758 */
    /* Make sure we have a spread applied for the hub with the aggressor taker
     * Here we have a 0.4 spread applied for taker*/
    @Test
    public void testItchTickerOXOAggressorSell() throws Exception {
        
        itchClient.start();
        assertTrue("oxoTaker is not logged on:"+oxoTaker.getUserName(),oxoTaker.logon());
        assertTrue("oxo2Taker is not logged on:"+oxo2Taker.getUserName(),oxo2Taker.logon());

        Thread.sleep(5000);
        
        Message msg = null;
        String clOrdID = "testClOrdId1";
        String hubParty = hubTaker.getPartyName();

        // submit order
        //the limit rate is 1.3009 and any rate from another order below this rate
        //on the other side will get the order filled
        oxo2Taker.submitRetailOrder(clOrdID, null, FX_TEST_INSTR,
                PRODUCT_CURRENCY, Constants.SIDE_Buy, FX_TEST_BASE_CCY,
                amount, Constants.ORDTYPE_ForexLimit, OFFER_PX_TAKER, null,
                Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                null, null);

        msg = oxo2Taker.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        String orderId = msg.getStringFieldValue(Constants.TAGOrderID);
        String execId = msg.getStringFieldValue(Constants.TAGExecID);

        //do assertion check for the execution report when order is accepted
        doAssertionCheckForExecutioReport(msg, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId, "0"/*execType*/,
                "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/, ordType, OFFER_PX_TAKER/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);


        String clOrdID1 = "testClOrdId2";
        // submit order
        //the limit rate is 1.3008 and any rate from another order above this rate
        //on the other side will get the order filled
        oxoTaker.submitRetailOrder(clOrdID1, null, FX_TEST_INSTR,
                PRODUCT_CURRENCY, Constants.SIDE_Sell, FX_TEST_BASE_CCY,
                amount, Constants.ORDTYPE_ForexLimit, BID_PX_TAKER, null,
                Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                null, null);

        Message msg1 = oxoTaker.getOrderUpdateMsg(clOrdID1, DEF_WAIT_TIME);
        String orderId1 = msg.getStringFieldValue(Constants.TAGOrderID);
        String execId1 = msg.getStringFieldValue(Constants.TAGExecID);

        //do assertion check for the execution report when order is accepted
        doAssertionCheckForExecutioReport(msg1, orderId1, clOrdID1/*clOrdId*/, clOrdID1/*origClOrderId*/,
                null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId1, "0"/*execType*/,
                "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/, ordType, BID_PX_TAKER/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        //order fills
        //the ticker rate or the rate at which the order is filled is 1.3009 as this is the
        //order that is aggressed
        Message execReport = oxo2Taker.getOrderUpdateMsg(clOrdID, 10000);
        assertEquals(msg.getStringFieldValue(Constants.TAGOrderID),
                execReport.getStringFieldValue(Constants.TAGOrderID));

        //do assertion check for the execution report when order is full filled
        doAssertionCheckForExecutioReport(execReport, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId, "F"/*execType*/,
                "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/,
                ordType, OFFER_PX_TAKER/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                OFFER_PX_TAKER/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, OFFER_PX_TAKER/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        //the ticker rate or the rate at which the order is filled is 1.30086 as this is the
        //order that is the aggressor and the spread is applied to this taker
        Message execReport1 = oxoTaker.getOrderUpdateMsg(clOrdID1, 10000);
        assertEquals(msg1.getStringFieldValue(Constants.TAGOrderID),
                execReport1.getStringFieldValue(Constants.TAGOrderID));

        //do assertion check for the execution report when order is full filled
        doAssertionCheckForExecutioReport(execReport1, orderId1, clOrdID1/*clOrdId*/, clOrdID1/*origClOrderId*/,
                "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId1, "F"/*execType*/,
                "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/,
                ordType, BID_PX_TAKER/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                OFFER_PX_MATCH2/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, OFFER_PX_MATCH2/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        //the itch ticker msg will see the clean rate, not the spread rate
        String price = itchClient.getTicker(10000);
        assertNotNull("no ticker msg was received!!", price);
        assertEquals("different rate received!", "131690", price);

    }


    /* DEV-21758 */
    /* Make sure we have a spread applied for the hub with the aggressor taker
     * Here we have a 0.4 spread applied for taker*/
    @Test
    public void testItchTickerOXOAggressorBuy() throws Exception {
        
        itchClient.start();
        assertTrue("taker is not logged on:"+oxoTaker.getUserName(),oxoTaker.logon());
        assertTrue("taker1 is not logged on:"+oxo2Taker.getUserName(),oxo2Taker.logon());
        
        Thread.sleep(5000);

        Message msg = null;
        String clOrdID = "testClOrdId1";
        String BID_PX = "1.3009";
        String hubParty = hubTaker.getPartyName();

        // submit order
        //the limit rate is 1.3009 and any rate from another order above this rate
        //on the other side will get the order filled
        oxo2Taker.submitRetailOrder(clOrdID, null, FX_TEST_INSTR,
                PRODUCT_CURRENCY, Constants.SIDE_Sell, FX_TEST_BASE_CCY,
                amount, Constants.ORDTYPE_ForexLimit, BID_PX, null,
                Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                null, null);

        msg = oxo2Taker.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        String orderId = msg.getStringFieldValue(Constants.TAGOrderID);
        String execId = msg.getStringFieldValue(Constants.TAGExecID);

        //do assertion check for the execution report when order is accepted
        doAssertionCheckForExecutioReport(msg, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId, "0"/*execType*/,
                "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/, ordType, BID_PX/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);


        String clOrdID1 = "testClOrdId2";
        String OFFER_PX = "1.3010";
        // submit order
        //the limit rate is 1.3010 and any rate from another order below this rate
        //on the other side will get the order filled
        oxoTaker.submitRetailOrder(clOrdID1, null, FX_TEST_INSTR,
                PRODUCT_CURRENCY, Constants.SIDE_Buy, FX_TEST_BASE_CCY,
                amount, Constants.ORDTYPE_ForexLimit, OFFER_PX, null,
                Constants.TIMEINFORCE_Day, null, null, amount, null, null,
                null, null);

        Message msg1 = oxoTaker.getOrderUpdateMsg(clOrdID1, DEF_WAIT_TIME);
        String orderId1 = msg.getStringFieldValue(Constants.TAGOrderID);
        String execId1 = msg.getStringFieldValue(Constants.TAGExecID);

        //do assertion check for the execution report when order is accepted
        doAssertionCheckForExecutioReport(msg1, orderId1, clOrdID1/*clOrdId*/, clOrdID1/*origClOrderId*/,
                null/*NoPartyIds*/, null/*PartyID*/, null/*PartyRole*/, execId1, "0"/*execType*/,
                "0"/*ordStatus*/, null/*OrdRejReason*/, null/*SettDate*/, FX_TEST_INSTR/*symbol*/,
                PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/, ordType, OFFER_PX/*price*/,
                null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, "0"/*LastQty*/, null/*LastPx*/,
                amount/*Leaves Qty*/, "0"/*cum Qty*/, "0.0000"/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        String LastPx = BID_PX;
        String AvgPx = LastPx;

        //order fills
        //the ticker rate or the rate at which the order is filled is 1.3009 as this is the
        //order that is aggressed
        Message execReport = oxo2Taker.getOrderUpdateMsg(clOrdID, 10000);
        assertEquals(msg.getStringFieldValue(Constants.TAGOrderID),
                execReport.getStringFieldValue(Constants.TAGOrderID));

        //do assertion check for the execution report when order is full filled
        doAssertionCheckForExecutioReport(execReport, orderId, clOrdID/*clOrdId*/, clOrdID/*origClOrderId*/,
                "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId, "F"/*execType*/,
                "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Sell/*side*/, amount/*orderQty*/,
                ordType, BID_PX/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                LastPx/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, AvgPx/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        String LastPx1 = "1.30094";
        String AvgPx1 = LastPx1;

        //the ticker rate or the rate at which the order is filled is 1.30094 as this is the
        //order that is the aggressor and the spread is applied to this taker
        Message execReport1 = oxoTaker.getOrderUpdateMsg(clOrdID1, 10000);
        assertEquals(msg1.getStringFieldValue(Constants.TAGOrderID),
                execReport1.getStringFieldValue(Constants.TAGOrderID));

        //do assertion check for the execution report when order is full filled
        doAssertionCheckForExecutioReport(execReport1, orderId1, clOrdID1/*clOrdId*/, clOrdID1/*origClOrderId*/,
                "1"/*NoPartyIds*/, hubParty/*PartyID*/, "1"/*PartyRole*/, execId1, "F"/*execType*/,
                "2"/*ordStatus*/, null/*OrdRejReason*/, execReport.getStringFieldValue(Constants.TAGSettlDate)/*SettDate*/,
                FX_TEST_INSTR/*symbol*/, PRODUCT_CURRENCY/*Product*/, Constants.SIDE_Buy/*side*/, amount/*orderQty*/,
                ordType, OFFER_PX/*price*/, null/*StopPx*/, null/*Trail by*/, null/*max slippage*/, FX_TEST_BASE_CCY/*currency*/, amount/*LastQty*/,
                LastPx1/*LastPx*/, "0"/*Leaves Qty*/, amount/*cum Qty*/, AvgPx1/*AvgPx*/, amount/*min Qty*/, null/*stopSide*/);

        //the itch ticker msg will see the clean rate, not the spread rate
        String price = itchClient.getTicker(10000);
        assertNotNull("no ticker msg was received!!", price);
        assertEquals("different rate received!", "131690", price);

    }

    private void doAssertionCheckForExecutioReport(Message msg, String orderId, String clOrderID,
            String OrigClOrderID, String NoPartyIds, String PartyId, String PartyRole, String execId, String
            execType, String orderStatus, String OrdRejReason, String SettlDate, String symbol, String product,
            String sellBuySide, String orderAmt, String orderType, String price, String stopPx, String trailBy,
            String maxSlippage, String currenecy, String lastQty, String lastPx, String leavesQty, String cumQty,
            String AvgPx, String minQty, String stopSide) throws Exception
    {
        assertNotNull("no ER msg was received", msg);
        assertNotNull(msg.getStringFieldValue(Constants.TAGOrderID));
        assertEquals(clOrderID, msg.getStringFieldValue(Constants.TAGClOrdID));
        assertEquals(OrigClOrderID, msg.getStringFieldValue(Constants.TAGOrigClOrdID));
        if(NoPartyIds!=null) {
            assertEquals(NoPartyIds, msg.getStringFieldValue(Constants.TAGNoPartyIDs));
        }
        if(PartyId!=null) {
            assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyID,
                    PartyId, Constants.MSGExecutionReport));
        }
        if(PartyRole!=null) {
            assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyRole,
                    PartyRole, Constants.MSGExecutionReport));
        }
        if(execId!=null) {
            assertNotNull(msg.getStringFieldValue(Constants.TAGExecID));
        }
        assertEquals(execType, msg.getStringFieldValue(Constants.TAGExecType));
        assertEquals(orderStatus, msg.getStringFieldValue(Constants.TAGOrdStatus));
        if(OrdRejReason!=null) {
            assertEquals(OrdRejReason, msg.getStringFieldValue(Constants.TAGOrdRejReason));
        }
        if(SettlDate!=null) {
            assertEquals(SettlDate, msg.getStringFieldValue(Constants.TAGSettlDate));
        }
        assertEquals(symbol, msg.getStringFieldValue(Constants.TAGSymbol));
        assertEquals(product, msg.getStringFieldValue(Constants.TAGProduct));
        assertEquals(sellBuySide, msg.getStringFieldValue(Constants.TAGSide));
        assertEquals(orderAmt, msg.getStringFieldValue(Constants.TAGOrderQty));
        assertEquals(orderType, msg.getStringFieldValue(Constants.TAGOrdType));
        if(price!=null) {
            assertEquals(price, msg.getStringFieldValue(Constants.TAGPrice));
        }
        if(stopPx!=null) {
            assertEquals(stopPx, msg.getStringFieldValue(Constants.TAGStopPx));
        }
        if(trailBy!=null) {
            assertEquals(trailBy, msg.getStringFieldValue("7587"));
        }
        if(maxSlippage!=null) {
            assertEquals(maxSlippage, msg.getStringFieldValue("7588"));
        }
        assertEquals(currenecy, msg.getStringFieldValue(Constants.TAGCurrency));
        if(lastQty!=null) {
            assertEquals(lastQty, msg.getStringFieldValue(Constants.TAGLastQty));
        }
        if(lastPx!=null) {
            assertEquals(lastPx, msg.getStringFieldValue(Constants.TAGLastPx));
        }
        assertEquals(leavesQty, msg.getStringFieldValue(Constants.TAGLeavesQty));
        assertEquals(cumQty, msg.getStringFieldValue(Constants.TAGCumQty));
        if(AvgPx!=null) {
            assertEquals(AvgPx, msg.getStringFieldValue(Constants.TAGAvgPx));
        }
        if(minQty!=null) {
            assertEquals(minQty, msg.getStringFieldValue(Constants.TAGMinQty));
        }
        if(stopSide!=null) {
            assertEquals(stopSide, msg.getStringFieldValue("7534"));
        }
    }

    private void doAssertionCheckForMakerReceivingOrder(Message msg, String NoPartyIds,
            String PartyId1, String PartyRole1, String PartyId2, String PartyRole2, String handleInst,
            String symbol, String symbolSfx, String product, String sellBuySide, String orderAmt,
            String orderType, String price, String currenecy, String TimeInForce, String AggressorIndicator,
            String StreamReference) throws Exception
    {
        assertNotNull("no order was received", msg);
        assertNotNull(msg.getStringFieldValue(Constants.TAGClOrdID));
        if(NoPartyIds!=null) {
            assertEquals(NoPartyIds, msg.getStringFieldValue(Constants.TAGNoPartyIDs));
        }
        if(PartyId1!=null) {
            assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyID,
                    PartyId1, Constants.MSGOrder));
        }
        if(PartyRole1!=null) {
            assertTrue(validateTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyRole,
                    PartyRole1, Constants.MSGOrder));
        }
        if(PartyId2!=null) {
            assertTrue(validateSecondTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyID,
                    PartyId2, Constants.MSGOrder));
        }
        if(PartyRole2!=null) {
            assertTrue(validateSecondTagWithinRepeatedGroup(msg, Constants.TAGNoPartyIDs, Constants.TAGPartyRole,
                    PartyRole2, Constants.MSGOrder));
        }
        assertNotNull(msg.getStringFieldValue(Constants.TAGSettlDate));
        assertEquals(handleInst, msg.getStringFieldValue(Constants.TAGHandlInst));
        assertEquals(symbol, msg.getStringFieldValue(Constants.TAGSymbol));
        assertEquals(symbolSfx, msg.getStringFieldValue(Constants.TAGSymbolSfx));
        assertEquals(product, msg.getStringFieldValue(Constants.TAGProduct));
        assertEquals(sellBuySide, msg.getStringFieldValue(Constants.TAGSide));
        assertEquals(orderAmt, msg.getStringFieldValue(Constants.TAGOrderQty));
        assertEquals(orderType, msg.getStringFieldValue(Constants.TAGOrdType));
        if(price!=null) {
            assertEquals(price, msg.getStringFieldValue(Constants.TAGPrice));
        }
        assertEquals(currenecy, msg.getStringFieldValue(Constants.TAGCurrency));
        assertNotNull(msg.getStringFieldValue(Constants.TAGQuoteID));
        assertEquals(TimeInForce, msg.getStringFieldValue(Constants.TAGTimeInForce));
        assertEquals(AggressorIndicator, msg.getStringFieldValue("1057"));
        assertEquals(StreamReference, msg.getStringFieldValue("7533"));
    }
}

