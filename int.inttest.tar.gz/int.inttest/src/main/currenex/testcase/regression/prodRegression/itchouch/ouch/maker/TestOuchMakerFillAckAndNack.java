package currenex.testcase.regression.prodRegression.itchouch.ouch.maker;

import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;
import static currenex.server.fxintegrate.adaptor.inttest.ouch.Constants.NEW_ORDER_STATUS_CONFIRMED;
import static org.junit.Assert.*;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.ouch.OuchClient;
import currenex.server.fxintegrate.adaptor.inttest.ouch.message.NewOrderAck;
import currenex.server.fxintegrate.adaptor.inttest.ouchMaker.OuchMakerClient;
import currenex.server.fxintegrate.adaptor.inttest.ouchMaker.message.ExecutionReportAck;
import currenex.server.fxintegrate.adaptor.inttest.ouchMaker.message.NewOrder;
import currenex.server.fxintegrate.adaptor.ouchtwo.taker.TakerErrorCode;
import currenex.testcase.ATestCase;
import org.apache.mina.common.ByteBuffer;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class TestOuchMakerFillAckAndNack extends ATestCase {
    
    private OuchMakerClient ouchMakerStreaming;
    private OuchMakerClient ouchMakerStreaming2;
    private OuchMakerClient ouchMakerTrading;
    private OuchMakerClient ouchMakerTradingAck;
    
    private OuchClient ouchTakerClient;
    private Integer eurUsdRate = 112180;
    private Random rd;

    private Charset charset = Charset.forName("US-ASCII");

    @Before
    public void setUp() throws Exception {

        String host = props().getProperty("ouchHost", "localhost");
        int port = Integer.parseInt(props().getProperty("ouchPort", "32000"));
        String userId = props().getProperty("ouchUserId", "testouchtakeru1");
        ouchTakerClient = new OuchClient(host, port, userId); 
        
        ouchMakerStreaming = getOuchMaker("BIxxMakerTHMOuchStr");
        ouchMakerStreaming2 = getOuchMaker("BIxxMakerTHMOuchSt2");
        ouchMakerTrading = getOuchMaker("BIxxMakerTHMOuchTrd");
        ouchMakerTradingAck = getOuchMaker("BIxxMakerTHMOuchAck");
        
        rd = new Random();
    }
    
    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));
    
    @Test
    public void testOuchMakerFillAck_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        
        Thread.sleep(5000);

        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReport(makerClOrdId,
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, (short) 1);

        ExecutionReportAck fillAck =ouchMakerTradingAck.getMessageFromFillAckQueue(5000);
        assertNotNull(fillAck);
    }
    
    @Test
    public void testOuchMakerFillNackIncorrectClOrdID_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReport(makerClOrdId+1,
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, (short) 1);

        Object fillAck =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillAck);
    }
    @Test
    public void testOuchMakerFillNackTimeOut_owner() throws Exception {

        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        Thread.sleep(8000);
        ouchMakerTradingAck.sendExecutionReport(makerClOrdId,
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, (short) 1);
        Thread.sleep(5000);
        Object fillNack =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillNack);
    }

    @Test
    public void testOuchMakerDenyAck_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");
        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(takerClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        ouchMakerTradingAck.sendExecutionReportReject(makerClOrdId, 0);
        Object denyAck =ouchMakerTradingAck.getMessageFromDenyAckQueue(5000);
        assertNotNull(denyAck);
        
        int takerOrderCancelId = rd.nextInt(1000);
        ouchTakerClient.sendOrderCancel(takerOrderCancelId, takerClOrdId, "EUR/USD-SP");
        Object orderCancelledOrExpired = ouchTakerClient.getSysCancel(3000);
        assertNotNull(orderCancelledOrExpired);
    }
    
    //DEV-32100
    @Test
    public void testOuchMakerDenyReasons_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
                
        Thread.sleep(5000);
        
        List<Integer> errorCodes = new ArrayList<>();
        errorCodes.add(0); //Price unavailable
        errorCodes.add(1); //Invalid offer
        errorCodes.add(2); //Not enough credit
        errorCodes.add(99); //Invalid error
        errorCodes.add(3); //**Invalid errorCode**
        
        byte orderType = 'F';
        byte side = 'S';
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        int takerClOrdId = rd.nextInt(1000);
        int rate = eurUsdRate;
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(takerClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        Thread.sleep(500);
        
        int quoteId = 0;
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");
        
        for(Integer errorCode:errorCodes){
            ouchMakerStreaming2.sendQuote(quoteId++, instrInfoId1, orderAmt, rate);
            
            NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
            assertNotNull("Ouch maker didnt recieve order", makerOrder);
            int makerClOrdId = makerOrder.getClOrdID();

            ouchMakerTradingAck.sendExecutionReportReject(makerClOrdId, errorCode);
            Object denyAck =ouchMakerTradingAck.getMessageFromDenyAckQueue(5000);
            assertNotNull(denyAck);
        }
    }

    @Test
    public void testOuchMakerDenyNackTimeOut_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false)); 
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");
        int orderAmt = 4000000;
        int rate = eurUsdRate;
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, orderAmt, rate);
        Thread.sleep(500);
        
        int clOrdId = rd.nextInt(1000);
        Integer minAmt = -1;
        byte expireType = 'G';
        byte orderType = 'F';
        byte side = 'S';
        ouchTakerClient.sendOrder(clOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, orderAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(clOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        Thread.sleep(8000);//fortesting
        ouchMakerTradingAck.sendExecutionReportReject(makerClOrdId, 0);
        Object denyNack = ouchMakerTradingAck.getMessageFromDenyNackQueue(10000);
        assertNotNull(denyNack);
    }
    
    @Test
    public void testOuchMakerDenyNackIncorrectClOrdId_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");
        int orderAmt = 4000000;
        int rate = eurUsdRate;
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, orderAmt, rate);
        Thread.sleep(500);
        
        int clOrdId = rd.nextInt(1000);
        Integer minAmt = -1;
        byte expireType = 'G';
        byte orderType = 'F';
        byte side = 'S';
        ouchTakerClient.sendOrder(clOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, orderAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(clOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        ouchMakerTradingAck.sendExecutionReportReject(makerClOrdId+1, 0);
        Object denyNack = ouchMakerTradingAck.getMessageFromDenyNackQueue(10000);
        assertNotNull(denyNack);
    }
    
    @Test
    public void testOuchMakerMultiFillTimeout_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        
        ByteBuffer timeOut = ouchMakerTradingAck.getTimeOut(15000);
        assertNotNull("Ouch Trade maker should get time out", timeOut);
    }
    
    @Test
    public void testOuchMakerMultiFillAck_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");
        int orderAmt = 4000000;
        int rate = eurUsdRate;
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, orderAmt, rate);
        Thread.sleep(500);
        
        int clOrdId = rd.nextInt(1000);
        Integer minAmt = -1;
        byte expireType = 'G';
        byte orderType = 'F';
        byte side = 'S';
        ouchTakerClient.sendOrder(clOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, orderAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(clOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId, "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, orderAmt, 0, rate);

        ExecutionReportAck fillAck =ouchMakerTradingAck.getMessageFromFillAckQueue(5000);
        assertNotNull(fillAck);
    }
    
    @Test
    public void testOuchMakerMultiFillNackIncorrectClOrdId_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId+1, "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, amt, 0, rate);

        Object fillNack =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillNack);
    }
    
    @Test
    public void testOuchMakerMultiFillNackTimeOut_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        Thread.sleep(8000);

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId, "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CONFIRMED, amt, 0, rate);

        Object fillNack =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillNack);
    }
    
    @Test
    public void testOuchMakerMultiFillDenyNack_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId, "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CANCELED, amt, 0, rate);

        Object denyNack =ouchMakerTradingAck.getMessageFromDenyNackQueue(5000);
        assertNotNull(denyNack);
    }
    
    @Test
    public void testOuchMakerMultiFillDenyNackIncorrectClOrdId_owner() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));

        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId+1, "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CANCELED, amt, 0, rate);

        Object fillNack =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillNack);
    }
    
    @Test
    public void testOuchMakerMultiFillDenyNackTimeOut_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        int takerClOrdId = rd.nextInt(1000);
        byte orderType = 'F';
        byte side = 'S';
        int instrInfoId1 = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "EUR/USD-SP");

        long amt = 4000000;
        int rate = eurUsdRate;
        int orderAmt = 4000000;
        Integer minAmt = -1;
        Integer showAmt = 4000000;
        byte expireType = 'G';
        ouchMakerStreaming2.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder(takerClOrdId, orderType, "EUR/USD-SP", side, orderAmt, rate, minAmt, showAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(3000);
        assertNotNull(ack);
        ack.doAssert(takerClOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTradingAck.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        Thread.sleep(9000);

        ouchMakerTradingAck.sendExecutionReportMultiFill(makerClOrdId,
                "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CANCELED,
                amt,
                0,
                rate);

        Object fillNack =ouchMakerTradingAck.getMessageFromFillNackQueue(5000);
        assertNotNull(fillNack);
    }
    
    //DEV-30922
    @Test
    public void testOuchMakerRejectWithZeroAmt_THMAck() throws Exception {
        doTestOuchMakerRejectWithZeroAmt(true);
    }
    
    //DEV-30922
    @Test
    public void testOuchMakerRejectWithZeroAmt_THM() throws Exception {
        doTestOuchMakerRejectWithZeroAmt(false);
    }
    
    //DEV-30922
    private void doTestOuchMakerRejectWithZeroAmt(boolean makerAckEnabled) throws Exception {
        
        OuchMakerClient ouchMakerTrader = makerAckEnabled?ouchMakerTradingAck:ouchMakerTrading;
        OuchMakerClient ouchMakerStreamUser = makerAckEnabled?ouchMakerStreaming2:ouchMakerStreaming;
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreamUser.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrader.start(false));
        
        Thread.sleep(5000);
        
        int quoteId = rd.nextInt(1000);
        String streamRefId = makerAckEnabled?"PS2":"PS1";
        int instrInfoId1 = ouchMakerStreamUser.getInstrInfoIdForBid(streamRefId, "EUR/USD-SP");
        long makerQuoteAmt = 4000000;
        long takerOrderAmt = makerQuoteAmt;
        int rate = eurUsdRate;
        ouchMakerStreamUser.sendQuote(quoteId, instrInfoId1, makerQuoteAmt, rate);
        Thread.sleep(500);
        
        int clOrdId = rd.nextInt(1000);
        Integer minAmt = -1;
        byte expireType = 'G';
        byte orderType = 'F';
        byte side = 'S';
        ouchTakerClient.sendOrder(clOrdId, orderType, "EUR/USD-SP", side, takerOrderAmt, rate, minAmt, takerOrderAmt, expireType);
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(2000);
        assertNotNull(ack);
        ack.doAssert(clOrdId, (char)NEW_ORDER_STATUS_CONFIRMED, TakerErrorCode.OK);
        
        NewOrder makerOrder = ouchMakerTrader.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();

        ouchMakerTrader.sendExecutionReportMultiFill(makerClOrdId,
                "execId",
                currenex.server.fxintegrate.adaptor.ouchtwo.Constants.NEW_ORDER_STATUS_CANCELED,
                0,
                makerQuoteAmt,
                0);
        
        if(makerAckEnabled){
            Object denyNack =ouchMakerTrader.getMessageFromDenyNackQueue(3000);
            assertNotNull("Ouch Trade maker didnt get deny nack", denyNack);
            
            ByteBuffer timeOut =ouchMakerTrader.getTimeOut(10000);
            assertNotNull("Ouch Trade maker should get time out", timeOut);
        }else{
            Thread.sleep(10000);
            
            Object denyNack =ouchMakerTrader.getMessageFromDenyNackQueue(500);
            assertNull("Ouch Trade maker should not get deny nack", denyNack);
            
            ByteBuffer timeOut =ouchMakerTrader.getTimeOut(500);
            assertNull("Ouch Trade maker should not get time out", timeOut);
        }
    }
    
    @After
    public void tearDown()throws Exception
    {
        Thread.sleep(1500);
        ouchMakerStreaming.disconnect();
        ouchMakerStreaming2.disconnect();
        ouchMakerTrading.disconnect();
        ouchMakerTradingAck.disconnect();
        ouchTakerClient.disconnect();
        Thread.sleep(2000);
    }

}
