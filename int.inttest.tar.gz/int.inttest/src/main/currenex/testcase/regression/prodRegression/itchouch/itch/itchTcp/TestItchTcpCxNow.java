package currenex.testcase.regression.prodRegression.itchouch.itch.itchTcp;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.TradeGenerator;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Client;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.message.CxNowDepthOfBook;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.message.CxNowTicker;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.message.CxNowWamr;
import currenex.testcase.ATestCase;

public class TestItchTcpCxNow extends ATestCase{
    
    Client itchClient;
    private TakerTestSession streamTaker;
    private TakerTestSession espTaker;
    private MakerTestSession espMaker;
    
    private TakerTestSession espOXOTaker1;
    private TakerTestSession espOXOTaker2;
    
    private TakerTestSession midXTaker1;
    private TakerTestSession midXTaker2;
    
    private TakerTestSession outOfScopeTaker;
    private MakerTestSession outOfScopeMaker;
    private TakerTestSession outOfScopeOXOTaker1;
    private TakerTestSession outOfScopeOXOTaker2;
    
    
    private MakerTestSession pricingMaker1;
    private MakerTestSession pricingMaker2;
    private MakerTestSession pricingMaker3;
    private MakerTestSession pricingMaker4;
    
    String FX_TEST_INSTR_FIX = props().getProperty("ccyPair", "AUD/USD");
    String SYMBOLSFX = "SP";
    String FX_TEST_INSTR_ITCH = FX_TEST_INSTR_FIX+"-"+SYMBOLSFX;
    final long DEF_WAIT_TIME = 3000;
    final String amount300K = "300000";
    final String amount500K = "500000";
    final String amount1M = "1000000";
    final String amount2M = "2000000";
    final String amount3M = "3000000";
    final String FX_INSTR_EURUSD = "EUR/USD";
    final String FX_INSTR_GBPUSD = "GBP/USD";
    final String FX_INSTR_USDCAD = "USD/CAD";
    
    final String mttl = "L";
    final String mttlMatchingPreference = "1";

    long t20matchEURUSD = 0;
    long t20matchGBPUSD = 0;
    long t20matchUSDCAD = 0;
    
    boolean subscribeDepthOfBook;
    boolean subscribeTicker; 
    boolean subscribeWAMR;
    boolean subscribeMidX;
    boolean unsubscribeEURUSD;
    
    String userId;
    String host;
    int port;
    
    String testingTarget;
    
    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));

    @Before
    public void setUp() throws Exception {
        
        testingTarget = props().getProperty("RUN_STACK", "Local");
        
        if(testingTarget.equals("QA12")){
            
            userId = props().getProperty("ITCHTCP_USER_ID");
            host = props().getProperty("ITCHTCP_HOST");
            port = Integer.parseInt(props().getProperty("ITCHTCP_PORT"));
            
            outOfScopeTaker = getTaker("fixtesttakertrdr01");
            outOfScopeMaker = getMaker("fixmakeru1");
            
            streamTaker = getTaker("fixtesttakerstrm");
            espTaker = getTaker("JCxxTakerU2");
            midXTaker1 = getTaker("JCMidXtk1u2");
            midXTaker2 = getTaker("JCMidXtk2u2");
            
        }else{
            
            userId = props().getProperty("ITCHTCP_USER_ID_LOCAL");
            host = props().getProperty("ITCHTCP_HOST_LOCAL");
            port = Integer.parseInt(props().getProperty("ITCHTCP_PORT_LOCAL"));
            
            pricingMaker1 = getMaker("MDxxMakerU2");
            pricingMaker2 = getMaker("MDxxMakerU3");
            pricingMaker3 = getMaker("MDxxMakerU4");
            pricingMaker4 = getMaker("MDxxMakerU5");
            
            espTaker = getTaker("MDxxTakerU2");
            espMaker = getMaker("MDxxMakerU2");
            espOXOTaker1 = getTaker("MDxxTakerTHHMu2");
            espOXOTaker2 = getTaker("MDxxTakerTHHM2u2");
            
            outOfScopeTaker = getTaker("ESP2xxTakerTHHMu2");
            outOfScopeMaker = getMaker("ESP2xxMakerTHHMu2");
            outOfScopeOXOTaker1 = getTaker("ESP2xxTakerOXOU2");
            outOfScopeOXOTaker2 = getTaker("ESP2xxTakerOXO2U2");
        }
        
        itchClient = new Client(userId, host, port, "Test123456", new String[] { });
        
        subscribeDepthOfBook = props().getProperty("subscribeDepthOfBook")!=null 
                && props().getProperty("subscribeDepthOfBook").equals("Y");
        
        subscribeTicker = props().getProperty("subscribeTicker")!=null 
                && props().getProperty("subscribeTicker").equals("Y");
        
        subscribeWAMR = props().getProperty("subscribeWAMR")!=null 
                && props().getProperty("subscribeWAMR").equals("Y");
        
        subscribeMidX = props().getProperty("subscribeMidX")!=null 
                && props().getProperty("subscribeMidX").equals("Y");
        
        unsubscribeEURUSD = false;
    }

    @After
    public void tearDown() throws Exception {
        itchClient.logout("bye!");
        this.logoutUsers(2000);
    }

    @Test
    public void testItchTcpSubscribeCxNow_Owner() throws Exception {
        
        assertTrue(pricingMaker1.getUserName()+" is not logged on",pricingMaker1.logon());
        assertTrue(pricingMaker2.getUserName()+" is not logged on",pricingMaker2.logon());
        assertTrue(pricingMaker3.getUserName()+" is not logged on",pricingMaker3.logon());
        assertTrue(pricingMaker4.getUserName()+" is not logged on",pricingMaker4.logon());
                
        itchClient.start();
        pricingMaker1.initialize(10);
        pricingMaker2.initialize(10);
        pricingMaker3.initialize(10);
        pricingMaker4.initialize(10);
        
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
        true /*subscribeDepthOfBook*/, 
        false /*subscribeTicker*/, 
        false /*subscribeWAMR*/, 
        false /*subscribeMidX*/);
        
        pricingMaker1.submitQuoteEsp(amount1M, FX_INSTR_EURUSD, "1.09234", "1.09334");
        Thread.sleep(1000);
        pricingMaker2.submitQuoteEsp(amount2M, FX_INSTR_EURUSD, "1.09244", "1.09324");
        Thread.sleep(1000);
        pricingMaker3.submitQuoteEsp(amount3M, FX_INSTR_EURUSD, "1.09254", "1.09314");
        Thread.sleep(1000);
        pricingMaker4.submitQuoteEsp(amount500K, FX_INSTR_EURUSD, "1.09234", "1.09334");
//        itchClient.subscribeCxNow("EUR/USD-SP", 
//                subscribeDepthOfBook, 
//                subscribeTicker, 
//                subscribeWAMR, 
//                subscribeMidX);
        
        Thread.sleep(60000);
        
        
        streamTaker = getTaker("MDxxTakerU3");
        
        assertTrue(streamTaker.getUserName()+" is not logged on",streamTaker.logon());
        String requestId = generateOrderId("testMdr-");
        //MD incremental refresh
        streamTaker.submitMarketDataRequestCXNow(requestId,
                true /*isSubscribe*/,
                subscribeDepthOfBook /*subscribeDepthOfBook*/ /*subscribeDepthOfBook*/,
                subscribeTicker /*subscribeTicker*/ /*subscribeTicker*/,
                subscribeWAMR /*subscribeWAMR*/,
                subscribeMidX /*subscribeMidX*/,
                false /*subscribeL1*/,
                FX_INSTR_EURUSD /*symbol*/,
                SYMBOLSFX /*symbolSfx*/);
        
//        String requestId = generateOrderId("testMdr-");
//        //MD incremental refresh
//        streamTaker.submitMarketDataRequestCXNow(requestId,
//                true /*isSubscribe*/,
//                subscribeDepthOfBook /*subscribeDepthOfBook*/,
//                subscribeTicker /*subscribeTicker*/,
//                subscribeWAMR /*subscribeWAMR*/,
//                subscribeMidX /*subscribeMidX*/,
//                FX_TEST_INSTR_FIX /*symbol*/,
//                SYMBOLSFX /*symbolSfx*/);
       
//        MDEntry md = streamTaker.getMDEntryFromQueue(9000000);
//        
//        while(md!=null){
//            md = streamTaker.getMDEntryFromQueue(9000000);
//        }
        
        Thread.sleep(120000);
        
        itchClient.unsubscribeCxNow("EUR/USD-SP", 
                subscribeDepthOfBook, 
                subscribeTicker, 
                subscribeWAMR, 
                subscribeMidX);
        
        Thread.sleep(5000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
                subscribeDepthOfBook, 
                subscribeTicker, 
                subscribeWAMR, 
                subscribeMidX);
        
        Thread.sleep(30000);
    }
    

    @Test
    public void testItchTcpCxNow_UnsubscribeAndSubscribe() throws Exception {
                        
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                true /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(5000);
        
        itchClient.unsubscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                true /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(5000);
        
        itchClient.subscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                true /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(5000);
    }
    
    
    @Test
    public void testItchTcpCxNow_Resubscribe() throws Exception {
                        
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                false /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(5000);
        
        itchClient.resubscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                true /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(5000);
    }
    
    @Test
    public void testItchTcpSubscribeCxNow_DepthOfBook() throws Exception {
                        
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                false /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        itchClient.subscribeCxNow("GBP/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                false /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        CxNowDepthOfBook price = itchClient.getMessageFromCxNowDepthOfBookQueue(2000);
        assertNotNull("itchtcp client didnt get CxNowDepthOfBook price", price);
        
        boolean getAUDUSD = false;
        boolean getGBPUSD = false;
        int count = 0;
        
        while((!getAUDUSD || !getGBPUSD) && count<30){
                        
            if(price.getInstrIndex() == itchClient.getInstrumentIndex("AUD/USD-SP")){
                getAUDUSD = true;
            }else if(price.getInstrIndex() == itchClient.getInstrumentIndex("GBP/USD-SP")){
                getGBPUSD = true;
            }
            
            price = itchClient.getMessageFromCxNowDepthOfBookQueue(2000);
            assertNotNull("itchtcp client didnt get CxNowDepthOfBook price", price);
            
            count++;
        }
        
        assertTrue(getAUDUSD);
        assertTrue(getGBPUSD);
                
        itchClient.unsubscribeCxNow("AUD/USD-SP", 
                true /*subscribeDepthOfBook*/, 
                false /*subscribeTicker*/, 
                false /*subscribeWAMR*/, 
                false /*subscribeMidX*/);
        
        Thread.sleep(2000);
        itchClient.clearCxNowDepthOfBookQueue();
        
        price = itchClient.getMessageFromCxNowDepthOfBookQueue(2000);
        assertNotNull("itchtcp client didnt get CxNowDepthOfBook price", price);
        
        getAUDUSD = false;
        getGBPUSD = false;
        
        for(int i=0;i<10;i++){
            if(price.getInstrIndex() == itchClient.getInstrumentIndex("AUD/USD-SP")){
                getAUDUSD = true;
            }else if(price.getInstrIndex() == itchClient.getInstrumentIndex("GBP/USD-SP")){
                getGBPUSD = true;
            }
            
            price = itchClient.getMessageFromCxNowDepthOfBookQueue(2000);
            assertNotNull("itchtcp client didnt get CxNowDepthOfBook price", price);
        }
        
        assertFalse(getAUDUSD);
        assertTrue(getGBPUSD);
    }
    
    @Test
    public void testItchTcpSubscribeCxNow_Ticker() throws Exception{
        
        assertTrue(espTaker.getUserName()+" is not logged on",espTaker.logon());
                        
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                true /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        itchClient.subscribeCxNow("GBP/USD-SP", 
                false /*subscribeDepthOfBook*/,
                true /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        Thread.sleep(2000);
             
        
        for(int i=0;i<10;i++){
        
            String clOrdId = generateOrderId("testOrder-");        
            espTaker.submitMarketOrderAndValidate(clOrdId, amount1M, FX_INSTR_EURUSD, Constants.SIDE_Buy, true);
            
            Message order1R2 = espTaker.getOrderUpdateMsg(clOrdId, 3000);
            assertNotNull("taker didnt get match", order1R2);
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, order1R2.getStringFieldValue(Constants.TAGOrdStatus));
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, order1R2.getStringFieldValue(Constants.TAGExecType));
            
            if(i<=2){
                assertNotNull("itchtcp client didnt get CxNowTicker", itchClient.getMessageFromCxNowTickerQueue(2000));
            }else{
                assertNull("itchtcp client shouldnt get CxNowTicker", itchClient.getMessageFromCxNowTickerQueue(1500));
            }
            
                        
            String clOrdId2 = generateOrderId("testOrder2-");        
            espTaker.submitMarketOrderAndValidate(clOrdId2, amount1M, FX_INSTR_GBPUSD, Constants.SIDE_Sell, false);
            
            Message order2R2 = espTaker.getOrderUpdateMsg(clOrdId2, 300000);
            assertNotNull("taker didnt get match", order2R2);
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, order2R2.getStringFieldValue(Constants.TAGOrdStatus));
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, order2R2.getStringFieldValue(Constants.TAGExecType));
            
            assertNotNull("itchtcp client didnt get CxNowTicker", itchClient.getMessageFromCxNowTickerQueue(2000));

            
            String clOrdId3 = generateOrderId("testOrder3-");        
            espTaker.submitMarketOrderAndValidate(clOrdId3, amount300K, FX_INSTR_EURUSD, Constants.SIDE_Buy, false);
            
            Message order3R2 = espTaker.getOrderUpdateMsg(clOrdId3, 3000);
            assertNotNull("taker didnt get match", order3R2);
            validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, order3R2.getStringFieldValue(Constants.TAGOrdStatus));
            validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, order3R2.getStringFieldValue(Constants.TAGExecType));
            
            if(i<=2){
                assertNotNull("itchtcp client didnt get CxNowTicker", itchClient.getMessageFromCxNowTickerQueue(2000));
            }else{
                assertNull("itchtcp client shouldnt get CxNowTicker", itchClient.getMessageFromCxNowTickerQueue(1500));
            }
            
            if(i==2){
                
                itchClient.unsubscribeCxNow("EUR/USD-SP", 
                        false /*subscribeDepthOfBook*/,
                        true /*subscribeTicker*/,
                        false /*subscribeWAMR*/,
                        false /*subscribeMidX*/);
                
                Thread.sleep(2000);
            }
        }
    }
    
    
    
    @Test
    public void testItchTcpSubscribeCxNow_NewTicker() throws Exception{
        
        assertTrue(espMaker.getUserName()+" is not logged on",espMaker.logon());
        assertTrue(espTaker.getUserName()+" is not logged on",espTaker.logon());
        assertTrue(espOXOTaker1.getUserName()+" is not logged on",espOXOTaker1.logon());
        assertTrue(espOXOTaker2.getUserName()+" is not logged on",espOXOTaker2.logon());
        assertTrue(outOfScopeTaker.getUserName()+" is not logged on",outOfScopeTaker.logon());
        assertTrue(outOfScopeMaker.getUserName()+" is not logged on",outOfScopeMaker.logon());
        assertTrue(outOfScopeOXOTaker1.getUserName()+" is not logged on",outOfScopeOXOTaker1.logon());
        assertTrue(outOfScopeOXOTaker2.getUserName()+" is not logged on",outOfScopeOXOTaker2.logon());

                        
        espMaker.initialize(10);
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                true /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        Thread.sleep(2000);
        
        //Out-of-scope OXP
        TradeGenerator.doTradeForEspLimit(outOfScopeTaker, outOfScopeMaker);
        CxNowTicker ticker = itchClient.getMessageFromCxNowTickerQueue(3000);
        assertNull("itch client should not receive CxNow ticker for out of scope trades", ticker);
        
        //In-scope OXP
        doTradeAndValidateCxNowTicker(FX_INSTR_EURUSD, amount300K, "1");
        Thread.sleep(2000);
        
        doTradeAndValidateCxNowTicker(FX_INSTR_EURUSD, amount500K, "2");
        Thread.sleep(2000);
        
        doTradeAndValidateCxNowTicker(FX_INSTR_EURUSD, amount2M, "2");
        Thread.sleep(2000);
        
        doTradeAndValidateCxNowTicker(FX_INSTR_EURUSD, amount3M, "3");
        Thread.sleep(2000);
        
        //In-scope OXO
        TradeGenerator.doTradeEspOxo(espOXOTaker1, espOXOTaker2);
        ticker = itchClient.getMessageFromCxNowTickerQueue(3000);
        assertNotNull("itch client didnt receive CxNow ticker for in-scope trade", ticker);
        
        //Out-of-scope OXO
        TradeGenerator.doTradeEspOxo(outOfScopeOXOTaker1, outOfScopeOXOTaker2);
        ticker = itchClient.getMessageFromCxNowTickerQueue(3000);
        assertNull("itch client should not receive CxNow ticker for out-of-scope trades", ticker);
        
        itchClient.unsubscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                true /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        Thread.sleep(2000);
    }
    
    
    
    
    
    
    
    private void doTradeAndValidateCxNowTicker(String instrument, String orderAmt, String sizeIndicator) throws Exception{
        
        if(testingTarget.equals("Local")){
            espMaker.submitQuoteEsp(orderAmt, instrument, "1.09625", "1.09645");   
        }
        
        String clOrdId = generateOrderId("testOrder-");        
        espTaker.submitMarketOrderAndValidate(clOrdId, orderAmt, instrument, Constants.SIDE_Buy, true);
        
        if(testingTarget.equals("Local")){
            Message order = espMaker.getOrder(5000);
            assertNotNull("Maker didnt get the order", order);
            espMaker.orderReplyFilled(order);
        }
        
        Message order1R2 = espTaker.getOrderUpdateMsg(clOrdId, 3000);
        assertNotNull("taker didnt get match", order1R2);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, order1R2.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, order1R2.getStringFieldValue(Constants.TAGExecType));
        
        String price = order1R2.getStringFieldValue(Constants.TAGLastPx);
        
        CxNowTicker ticker = itchClient.getMessageFromCxNowTickerQueue(2000);
        assertNotNull("itchClient didnt get ticker for "+instrument, ticker);
        
        validateField("Rate", price, Double.toString((((double)ticker.getRate())/100000)));
        validateField("SizeIndicator", sizeIndicator, Character.toString(ticker.getSizeIndicator()));
    }
    
    
    @Test
    public void testItchTcpSubscribeCxNow_WAMRDecimal() throws Exception{
                
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                true /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        CxNowWamr wamr = itchClient.getMessageFromCxNowWamrQueue(30000);
        assertNotNull("itchClient didnt get CxNowWAMR for EUR/USD", wamr);
        
        while(wamr!=null){
            double scaledRate = ((double)wamr.getRate()) / 1000000;
            int[] originalPrices = wamr.getPrices();
            assertNotNull("There is no price in WAMR msg", originalPrices);
            double[] scaledPrices = new double[originalPrices.length];
            for(int i=0;i<originalPrices.length;i++){
                scaledPrices[i] = ((double)originalPrices[i]) / 100000;
                double priceDiff = Math.abs(scaledRate - scaledPrices[i]);
                assertTrue((priceDiff/scaledRate) < 0.2 );
            }
            wamr = itchClient.getMessageFromCxNowWamrQueue(30000);
        }    
    }
    
    
    @Test
    public void testItchTcpSubscribeCxNow_WAMR() throws Exception{
                
        itchClient.start();
        Thread.sleep(10000);
        
        itchClient.subscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                true /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        itchClient.subscribeCxNow("GBP/USD-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                true /*subscribeWAMR*/,
                false /*subscribeMidX*/);
                
        CxNowWamr wamr = itchClient.getMessageFromCxNowWamrQueue(5000);
        assertNotNull("itchtcp client didnt get CxNowWamr price", wamr);
        
        boolean getEURUSD = false;
        boolean getGBPUSD = false;
        int count = 0;
        
        while((!getEURUSD || !getGBPUSD) && count<10){
                        
            if(wamr.getInstrIndex() == itchClient.getInstrumentIndex("EUR/USD-SP")){
                getEURUSD = true;
            }else if(wamr.getInstrIndex() == itchClient.getInstrumentIndex("GBP/USD-SP")){
                getGBPUSD = true;
            }
            
            wamr = itchClient.getMessageFromCxNowWamrQueue(2000);
            assertNotNull("itchtcp client didnt get CxNowWamr price", wamr);
            
            count++;
        }
        
        assertTrue(getEURUSD);
        assertTrue(getGBPUSD);
        
        itchClient.unsubscribeCxNow("EUR/USD-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                true /*subscribeWAMR*/,
                false /*subscribeMidX*/);
        
        Thread.sleep(2000);
        itchClient.clearCxNowWamrQueue();
        
        wamr = itchClient.getMessageFromCxNowWamrQueue(10000);
        assertNotNull("itchtcp client didnt get CxNowWamr price", wamr);
        
        getEURUSD = false;
        getGBPUSD = false;
        
        for(int i=0;i<10;i++){
            if(wamr.getInstrIndex() == itchClient.getInstrumentIndex("EUR/USD-SP")){
                getEURUSD = true;
            }else if(wamr.getInstrIndex() == itchClient.getInstrumentIndex("GBP/USD-SP")){
                getGBPUSD = true;
            }
            
            wamr = itchClient.getMessageFromCxNowWamrQueue(10000);
            assertNotNull("itchtcp client didnt get CxNowWamr price", wamr);
        }
        
        assertFalse(getEURUSD);
        assertTrue(getGBPUSD);
    }
    
    @Test
    public void testItchTcpSubscribeCxNow_MidXTrades() throws Exception{//need market data feed running for this to work
        
        assertTrue(midXTaker1.getUserName()+" is not logged on",midXTaker1.logon());
        assertTrue(midXTaker2.getUserName()+" is not logged on",midXTaker2.logon());
               
        itchClient.start();
        Thread.sleep(5000);
        
        itchClient.subscribeCxNow(FX_INSTR_EURUSD+"-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                true /*subscribeMidX*/);
        
        itchClient.subscribeCxNow(FX_INSTR_GBPUSD+"-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                true /*subscribeMidX*/);
        
        itchClient.subscribeCxNow(FX_INSTR_USDCAD+"-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                true /*subscribeMidX*/);

        Runnable doMidXEURUSD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String clOrdId1 = generateOrderId("midXEURUSD1-");
                        String clOrdId2 = generateOrderId("midXEURUSD2-");
                        
                        midXTaker1.submitMidMatchOrder(clOrdId1, Constants.SIDE_Buy, FX_INSTR_EURUSD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order1R1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 10000);
                        assertNotNull("taker1 did not receive er-ack", order1R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order1R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order1R1.getStringFieldValue(Constants.TAGExecType));

                        midXTaker2.submitMidMatchOrder(clOrdId2, Constants.SIDE_Sell, FX_INSTR_EURUSD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order2R1 = midXTaker2.getOrderUpdateMsg(clOrdId2, 10000);
                        assertNotNull("taker2 did not receive er-ack", order2R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order2R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order2R1.getStringFieldValue(Constants.TAGExecType));


                        Message t0ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 6000);
                        assertNotNull("taker1 didnt get t0 match", t0ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        Message t0ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t0 match", t0ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER2.getStringFieldValue(Constants.TAGExecType));
                                
                        
                        Message t20ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 30000);
                        
                        t20matchEURUSD = System.currentTimeMillis();
                        
                        assertNotNull("taker1 didnt get t20 match", t20ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        
                        Message t20ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t20 match", t20ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER2.getStringFieldValue(Constants.TAGExecType));
                        
                        
                        
                        Thread.sleep(2000);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        
        Runnable doMidXGBPUSD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String clOrdId1 = generateOrderId("midXGBPUSD1-");
                        String clOrdId2 = generateOrderId("midXGBPUSD2-");
                        
                        midXTaker1.submitMidMatchOrder(clOrdId1, Constants.SIDE_Buy, FX_INSTR_GBPUSD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order1R1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 10000);
                        assertNotNull("taker1 did not receive er-ack", order1R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order1R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order1R1.getStringFieldValue(Constants.TAGExecType));

                        midXTaker2.submitMidMatchOrder(clOrdId2, Constants.SIDE_Sell, FX_INSTR_GBPUSD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order2R1 = midXTaker2.getOrderUpdateMsg(clOrdId2, 10000);
                        assertNotNull("taker2 did not receive er-ack", order2R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order2R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order2R1.getStringFieldValue(Constants.TAGExecType));


                        Message t0ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 6000);
                        assertNotNull("taker1 didnt get t0 match", t0ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        Message t0ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t0 match", t0ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER2.getStringFieldValue(Constants.TAGExecType));
                                
                        
                        Message t20ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 30000);
                        
                        t20matchGBPUSD = System.currentTimeMillis();
                        
                        assertNotNull("taker1 didnt get t20 match", t20ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        
                        Message t20ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t20 match", t20ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER2.getStringFieldValue(Constants.TAGExecType));
                        
                        
                        
                        Thread.sleep(5000);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        
        Runnable doMidXUSDCAD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String clOrdId1 = generateOrderId("midXUSDCAD1-");
                        String clOrdId2 = generateOrderId("midXUSDCAD2-");
                        
                        midXTaker1.submitMidMatchOrder(clOrdId1, Constants.SIDE_Buy, FX_INSTR_USDCAD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order1R1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 10000);
                        assertNotNull("taker1 did not receive er-ack", order1R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order1R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order1R1.getStringFieldValue(Constants.TAGExecType));

                        midXTaker2.submitMidMatchOrder(clOrdId2, Constants.SIDE_Sell, FX_INSTR_USDCAD, amount1M, null, null, mttl, mttlMatchingPreference);
                        
                        Message order2R1 = midXTaker2.getOrderUpdateMsg(clOrdId2, 10000);
                        assertNotNull("taker2 did not receive er-ack", order2R1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, order2R1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, order2R1.getStringFieldValue(Constants.TAGExecType));


                        Message t0ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 6000);
                        assertNotNull("taker1 didnt get t0 match", t0ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        Message t0ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t0 match", t0ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t0ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchT0Trade, t0ER2.getStringFieldValue(Constants.TAGExecType));
                                
                        
                        Message t20ER1 = midXTaker1.getOrderUpdateMsg(clOrdId1, 30000);
                        
                        t20matchUSDCAD = System.currentTimeMillis();
                        
                        assertNotNull("taker1 didnt get t20 match", t20ER1);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER1.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER1.getStringFieldValue(Constants.TAGExecType));
                        
                        Message t20ER2 = midXTaker2.getOrderUpdateMsg(clOrdId2, 3000);
                        assertNotNull("taker2 didnt get t20 match", t20ER2);
                        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, t20ER2.getStringFieldValue(Constants.TAGOrdStatus));
                        validateTag(Constants.TAGExecType, Constants.EXECTYPE_MidMatchTNTrade, t20ER2.getStringFieldValue(Constants.TAGExecType));
                        
                        Thread.sleep(3000);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        
        Runnable getItchEURUSD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String midXActivityIndicatorReceived = itchClient.getMidXActivityIndicator(FX_INSTR_EURUSD+"-SP", 35000);
                        
                        if(unsubscribeEURUSD){
                            assertNull("Itch client should not get CxNow_MidX for "+FX_INSTR_EURUSD+"-SP", midXActivityIndicatorReceived);
                        }else{
                            assertNotNull("Itch client didnt get CxNow_MidX for "+FX_INSTR_EURUSD+"-SP", midXActivityIndicatorReceived);
                            
                            long itchReceivedTime = System.currentTimeMillis();                        
                            long timeDiffMdAndT20 = itchReceivedTime-t20matchEURUSD;
                            
                            String midXActivityIndicator = getMidXActivityCodeByTime(timeDiffMdAndT20);
                            assertNotNull("Error in EURUSD t20 and MD received time processing, mdReceivedTime="+itchReceivedTime+", t20matchEURUSD="+t20matchEURUSD,
                                    midXActivityIndicator);
                            assertEquals("Unexpected midXActIndicator", midXActivityIndicator, midXActivityIndicatorReceived);
                        }
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        Runnable getItchGBPUSD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String midXActivityIndicatorReceived = itchClient.getMidXActivityIndicator(FX_INSTR_GBPUSD+"-SP", 35000);
                        assertNotNull("Itch client didnt get CxNow_MidX for "+FX_INSTR_GBPUSD+"-SP", midXActivityIndicatorReceived);
                        
                        long itchReceivedTime = System.currentTimeMillis();                        
                        long timeDiffMdAndT20 = itchReceivedTime-t20matchGBPUSD;
                        
                        String midXActivityIndicator = getMidXActivityCodeByTime(timeDiffMdAndT20);
                        assertNotNull("Error in GBPUSD t20 and MD received time processing, mdReceivedTime="+itchReceivedTime+", t20matchGBPUSD="+t20matchGBPUSD,
                                midXActivityIndicator);
                        assertEquals("Unexpected midXActIndicator", midXActivityIndicator, midXActivityIndicatorReceived);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        Runnable getItchUSDCAD = new Runnable() {
            @Override
            public void run(){
                try{
                    while (true){
                        
                        String midXActivityIndicatorReceived = itchClient.getMidXActivityIndicator(FX_INSTR_USDCAD+"-SP", 35000);
                        assertNotNull("Itch client didnt get CxNow_MidX for "+FX_INSTR_USDCAD+"-SP", midXActivityIndicatorReceived);
                        
                        long itchReceivedTime = System.currentTimeMillis();                        
                        long timeDiffMdAndT20 = itchReceivedTime-t20matchUSDCAD;
                        
                        String midXActivityIndicator = getMidXActivityCodeByTime(timeDiffMdAndT20);
                        assertNotNull("Error in USDCAD t20 and MD received time processing, mdReceivedTime="+itchReceivedTime+", t20matchUSDCAD="+t20matchUSDCAD,
                                midXActivityIndicator);
                        assertEquals("Unexpected midXActIndicator", midXActivityIndicator, midXActivityIndicatorReceived);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        
        Thread tMidxEURUSD = new Thread(doMidXEURUSD);
        Thread tMidxGBPUSD = new Thread(doMidXGBPUSD);
        Thread tMidxUSDCAD = new Thread(doMidXUSDCAD);
        
        Thread tItchEURUSD = new Thread(getItchEURUSD);
        Thread tItchGBPUSD = new Thread(getItchGBPUSD);
        Thread tItchUSDCAD = new Thread(getItchUSDCAD);
                
        tItchEURUSD.start();
        tItchGBPUSD.start();
        tItchUSDCAD.start();
        
        tMidxGBPUSD.start();
        tMidxEURUSD.start();
        tMidxUSDCAD.start();
        
        Thread.sleep(60000);
        
        itchClient.unsubscribeCxNow(FX_INSTR_EURUSD+"-SP", 
                false /*subscribeDepthOfBook*/,
                false /*subscribeTicker*/,
                false /*subscribeWAMR*/,
                true /*subscribeMidX*/);
        
        unsubscribeEURUSD = true;
        
        Thread.sleep(120000);
    }
    
    private String getMidXActivityCodeByTime(long timeDiffMdAndT20){
        if(timeDiffMdAndT20 > 45000){
            return "C";
        }else if(timeDiffMdAndT20 > 15000){
            return "B";
        }else if(timeDiffMdAndT20 > 0){
            return "A";
        }else{
            return null;
        }
    }

}
