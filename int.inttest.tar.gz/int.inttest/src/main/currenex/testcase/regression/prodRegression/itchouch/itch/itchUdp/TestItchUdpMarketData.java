package currenex.testcase.regression.prodRegression.itchouch.itch.itchUdp;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;
import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.itch.ItchClient;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.testcase.ATestCase;

/**
 *
 * Properties file: testBinaryRegression.properties
 * @author mgopalakrishnan
 */
public final class TestItchUdpMarketData extends ATestCase {
    ItchClient itchClient;
    private TakerTestSession takerOXO;
    private MakerTestSession maker;
    private MakerTestSession maker2;
    private MakerTestSession maker3;
    private MakerTestSession maker4;

    final String FX_TEST_INSTR = "EUR/USD";
    final String PRODUCT_CURRENCY = "4";
    final String FX_TEST_BASE_CCY = "EUR";
    final String FX_TEST_TERMS_CCY = "USD";
    final long DEF_WAIT_TIME = 3000;
    final String OFFER_PX = "1.3207";
    
    final String amt1M = "1000000";
    final String amt2M = "2000000";
    final String amt3M = "3000000";
    
    String testingTarget;
    String itchUserId;
    String itchHost;
    int itchPort;
    
    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));

    @Before
    public void setUp() throws Exception {

        testingTarget = props().getProperty("RUN_STACK", "Local");
        itchPort = Integer.parseInt(props().getProperty("ITCH_PORT"));

        if(testingTarget.equals("QA13")){
            itchUserId = props().getProperty("ITCH_USER_ID_QA13");
            itchHost = props().getProperty("ITCH_HOST_QA13");
                
            maker = getMaker("JCxxMaker3U2");
            maker2 = getMaker("JCxxMaker3U3");
            maker3 = getMaker("JCxxMaker3U4");
            maker4 = getMaker("JCxxMaker3U5");
            
        }else{
            itchUserId = props().getProperty("ITCH_USER_ID");
            itchHost = props().getProperty("ITCH_HOST");

            takerOXO = getTaker("BIxxTakerTHM2U2");
            maker = getMaker("BIxxMakerTHMU2");
            maker2 = getMaker("BIxxMakerTHMU3");
            maker3 = getMaker("BIxxMakerTHMU4");
            maker4 = getMaker("BIxxMakerTHMU5");
        }
        
        itchClient = new ItchClient(itchUserId, itchHost, itchPort, "Test123456",
                new String[] { "EUR/USD-SP", "GBP/USD-SP", "USD/CAD-SP", "EUR/JPY-SP" });
    }

    @After
    public void tearDown() throws Exception {
        itchClient.logout("bye!");
        this.logoutUsers(5000);
    }

    @Test
    public void testItchPrice_OXP() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        
        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX);

        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }

    @Test
    public void testItchPrice_OXO() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);

        assertTrue("takerOXO is not logged on:"+takerOXO.getUserName(),takerOXO.logon());

        Thread.sleep(5000);
        
        String clOrdID = "testClOrdId1";

        takerOXO.submitRetailOrderOnBehalf(clOrdID, null, FX_TEST_INSTR, null,
                PRODUCT_CURRENCY, Constants.SIDE_Buy, FX_TEST_BASE_CCY,
                "1000000", Constants.ORDTYPE_ForexLimit, OFFER_PX, null,
                Constants.TIMEINFORCE_Day, null, null, null, "1000000", null, null,
                null, null, null);
        
        Message acceptedER = takerOXO.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, acceptedER.getStringFieldValue(Constants.TAGExecType));

        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    //@Ignore
    @Test
    public void testItchUdp_DepthOfBook() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        String INSTR_USDCAD = "USD/CAD";
        String INSTR_EURUSD = "EUR/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        String price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNull("no price should be received!!", price);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        
        
        
        String USDCAD_BID_PX = "1.3123";
        String USDCAD_BID_PX2 = "1.3125";
        String USDCAD_BID_PX3 = "1.3128";
        String USDCAD_BID_PX4 = "1.3130";
        String USDCAD_BID_PX5 = "1.3132";
        
        //USD/CAD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX4, null);
        
        String price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        double receivedPrice2 = (Double.valueOf(price2))/100000;
        double submittedPrice2 = Double.valueOf(USDCAD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX3, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX5, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX2, null);
        
        price2 = itchClient.getPrice(1000);
        assertNull("no price should be received!!", price2);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        
        
        String EURUSD_BID_PX = "1.1123";
        String EURUSD_BID_PX2 = "1.1125";
        String EURUSD_BID_PX3 = "1.1128";
        String EURUSD_BID_PX4 = "1.1130";
        String EURUSD_BID_PX5 = "1.1132";
        
        //EUR/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX, null);
        
        String price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        double receivedPrice3 = (Double.valueOf(price3))/100000;
        double submittedPrice3 = Double.valueOf(EURUSD_BID_PX);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX2, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX3, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX4, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX5, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
    }
    
    @Ignore
    @Test
    public void testItchUdp_DepthOfBookOff() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        String INSTR_USDCAD = "USD/CAD";
        String INSTR_EURUSD = "EUR/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        String price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        
        
        
        String USDCAD_BID_PX = "1.3123";
        String USDCAD_BID_PX2 = "1.3125";
        String USDCAD_BID_PX3 = "1.3128";
        String USDCAD_BID_PX4 = "1.3130";
        String USDCAD_BID_PX5 = "1.3132";
        
        //USD/CAD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX2, null);
        
        String price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        double receivedPrice2 = (Double.valueOf(price2))/100000;
        double submittedPrice2 = Double.valueOf(USDCAD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX3, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX4, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX5, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_USDCAD, USDCAD_BID_PX, null);
        
        price2 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price2);
        receivedPrice2 = (Double.valueOf(price2))/100000;
        submittedPrice2 = Double.valueOf(USDCAD_BID_PX);
        assertEquals("Incorred received price", submittedPrice2, receivedPrice2, 0.00001);
        
        
        
        String EURUSD_BID_PX = "1.1123";
        String EURUSD_BID_PX2 = "1.1125";
        String EURUSD_BID_PX3 = "1.1128";
        String EURUSD_BID_PX4 = "1.1130";
        String EURUSD_BID_PX5 = "1.1132";
        
        //EUR/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX, null);
        
        String price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        double receivedPrice3 = (Double.valueOf(price3))/100000;
        double submittedPrice3 = Double.valueOf(EURUSD_BID_PX);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX2, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX2);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX3, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX3);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker4.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX4, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX4);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_EURUSD, EURUSD_BID_PX5, null);
        
        price3 = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price3);
        receivedPrice3 = (Double.valueOf(price3))/100000;
        submittedPrice3 = Double.valueOf(EURUSD_BID_PX5);
        assertEquals("Incorred received price", submittedPrice3, receivedPrice3, 0.00001);
    }
    
    

    @Test
    public void testItchUdp_DepthOfBookZero() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        assertTrue(maker3.getUserName()+" is not logged on",maker3.logon());
        assertTrue(maker4.getUserName()+" is not logged on",maker4.logon());
        maker.initialize(10);
        maker2.initialize(10);
        maker3.initialize(10);
        maker4.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_EURJPY = "EUR/JPY";
        
        String EURJPY_OFFER_PX = "113.11";
        String EURJPY_OFFER_PX2 = "113.12";
        String EURJPY_OFFER_PX3 = "113.13";
        String EURJPY_OFFER_PX4 = "113.15";
        String EURJPY_OFFER_PX5 = "113.18";
        
        //EUR/JPY offer prices
        maker3.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX5);
        
        String price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(EURJPY_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX4);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker3.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX2);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_EURJPY, null, EURJPY_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(EURJPY_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    

    @Test
    public void testItchUdp_DepthOfBookWithCancel() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue(maker.getUserName()+" is not logged on",maker.logon());
        assertTrue(maker2.getUserName()+" is not logged on",maker2.logon());
        
        maker.initialize(10);
        maker2.initialize(10);
        Thread.sleep(5000);
        
        String INSTR_GBPUSD = "GBP/USD";
        
        String GBPUSD_OFFER_PX = "1.3081";
        String GBPUSD_OFFER_PX2 = "1.3082";
        String GBPUSD_OFFER_PX3 = "1.3083";
        String GBPUSD_OFFER_PX4 = "1.3085";
        String GBPUSD_OFFER_PX5 = "1.3088";
        
        //GBP/USD bid prices
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX5);
        
        String price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(GBPUSD_OFFER_PX5);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX4);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX4);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");
        
        maker.submitCancelAllRates(dateFormat.format(new Date()));
        String ccy = itchClient.getPriceCancel(1000);
        assertNotNull("itchtcp client didnt get priceCancel", ccy);
        
        maker2.submitCancelAllRates(dateFormat.format(new Date()));
        ccy = itchClient.getPriceCancel(1000);
        assertNotNull("itchtcp client didnt get priceCancel", ccy);
        
        Thread.sleep(500);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker2.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
        
        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX2);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX2);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);

        maker.submitQuoteEsp(amt1M, INSTR_GBPUSD, null, GBPUSD_OFFER_PX3);
        
        price = itchClient.getPrice(1000);
        assertNotNull("no price was received!!", price);
        receivedPrice = (Double.valueOf(price))/100000;
        submittedPrice = Double.valueOf(GBPUSD_OFFER_PX3);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }
    
    
    
    @Test
    public void testItchUdpResubscribeFailed_owner() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(5000);
        
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());

        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX);
        
        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        
        itchClient.unsubscribe("EUR/USD-SP");        
        
        String priceCancel = itchClient.getPriceCancel(DEF_WAIT_TIME);
        assertNotNull("no priceCancel was received!!", priceCancel);
        
        itchClient.resubscribe("EUR/USD-SP");
        Thread.sleep(5000);
        
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, "1.3066");
        price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNull("no price should be received!", price);
    }
    
    @Test
    public void testItchUdpResubscribe_owner() throws Exception {
        
        itchClient.start();
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX);
        
        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
                
        itchClient.resubscribe("EUR/USD-SP");
        
        price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!", price);
    }

    @Test
    public void testItchUdpUnsubscribe_owner() throws Exception {
        
        itchClient.start();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());

        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX);

        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);

        itchClient.unsubscribe("EUR/USD-SP");        
        
        String priceCancel = itchClient.getPriceCancel(DEF_WAIT_TIME);
        assertNotNull("no priceCancel was received!!", priceCancel);

        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, "1.3066");
        price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNull("no price should be received!", price);
    }
    
    @Test
    public void testItchEmptyDatagramBeforeLogon_OXP() throws Exception {
        
        itchClient.startEmptyLogon();
        itchClient.cleanPriceQueue(DEF_WAIT_TIME);
        
        assertTrue("maker is not logged on:"+maker.getUserName(),maker.logon());
        
        Thread.sleep(5000);
        
        maker.initialize(10);
        maker.submitQuoteEsp("1000000", FX_TEST_INSTR, null, OFFER_PX);

        String price = itchClient.getPrice(DEF_WAIT_TIME);
        assertNotNull("no price was received!!", price);
        double receivedPrice = (Double.valueOf(price))/100000;
        double submittedPrice = Double.valueOf(OFFER_PX);
        assertEquals("Incorred received price", submittedPrice, receivedPrice, 0.00001);
    }

}
