package currenex.testcase.regression.prodRegression.itchouch.itch.itchTcp.itchtcpStress;

import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.waitFor;
import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Map.Entry;
import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Client;
import currenex.server.fxintegrate.adaptor.inttest.ouch.OuchClient;
//import currenex.server.fxintegrate.adaptor.inttest.itchTcp.Client;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import currenex.server.fxintegrate.adaptor.inttest.fix.RandomPriceGenerator;
import currenex.server.fxintegrate.adaptor.inttest.fix.ao.Quote;

import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.MakerTestSession.Subscription;
import currenex.testcase.ATestCase;

/**
 *
 *
 * @author mgopalakrishnan
 */
public final class TestItchTcpMarketDataStress extends ATestCase {
    Client itchClient;
    private TakerTestSession streamUser;
    private TakerTestSession tradeUser;
    private TakerTestSession selfUser;
    private MakerTestSession maker;
    private OuchClient ouchClient;
    private int makerQuoteCount = 0;
    private final RandomPriceGenerator m_gen = new RandomPriceGenerator();

    final String FX_TEST_INSTR = "EUR/USD";
    final String PRODUCT_CURRENCY = "4";
    final String FX_TEST_INSTR2 = "USD/JPY";
    final String FX_TEST_INSTR_XAGUSD = "XAG/USD";
    final String FX_TEST_CCY_XAG = "XAG";
    final String FX_TEST_BASE_CCY = "EUR";
    final String FX_TEST_TERMS_CCY = "USD";
    final String TimeInForce_GFS = "X";
    final long DEF_WAIT_TIME = 3000;
    final String ALL_OPEN_ORDERS = "OPEN_ORDER";
    final static String SecurityListRequestType_Symbol = "0";
    final static String MDEntryType_SwapRates = "6";
    final static String PositionReqType_Positions = "0";
    final static String PositionReqType_Trades = "1";
    final static String AccountType_Customer = "1";
    final static String OrderStatus_All = "7";
    final static String OrderStatus_Mass = "8";
    final static String Ordtype_TrailingStop = "V";
    final String Ordtype_Iceberg = "Z";
    final String BID_PX = "1.3203";
    final String OFFER_PX = "1.3207";
    final String OFFER_PX2 = "1.3211";
    final String SPREAD = "3.0000";
    final SimpleDateFormat m_format = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");


    @Before
    public void setUp() throws Exception {
        String userId = props().getProperty("ITCH_USER_ID");
        String host = props().getProperty("ITCH_HOST");
        int port = Integer.parseInt(props().getProperty("ITCH_PORT"));
        itchClient = new Client(userId, host, port, "test1234",
                new String[] { "EUR/USD-SP" });
        itchClient.start();
        Thread.sleep(5000);

        for (TakerTestSession taker: takers()) {
            if (taker.getUserName().equals("Long1__regressionT")){
                this.tradeUser = taker;
            } else if (taker.getUserName().equals("Long1__lxiaoit_gui")){
                this.selfUser = taker;
            } else if (taker.getUserName().equals("Long1__lxiaoit_str")){
                this.streamUser = taker;
            }
        }
        
        for (MakerTestSession maker : makers()){
            if (maker.getUserName().equals("Long1__regressionM")){
                this.maker = maker;
            }
        }
        
//        ouchClient = ouchTakerClients().get(0);
//        makerUser=makers().get(0);
//        if (!makerUser.isLoggedOn()) {
//            makerUser.logon("test1234", 15000, true);
//            waitFor(1000);
//            setupPricing();
//        }
    }

    @After
    public void tearDown() throws Exception {
        for (TakerTestSession taker: takers()) {
            if (taker.isLoggedOn()) {
                taker.logout();
            }
        }
        for (MakerTestSession maker : makers()) {
            if (maker.isLoggedOn()) {
                maker.logout();
            }
        }

        itchClient.logout("bye!");
        Thread.sleep(10000); // wait on clean up


    }

    @Test
    public void testItchPrice_OXP() throws Exception {
        String amount = "1000000";
        maker.logon("test1234", 15000, true);
        String clOrdID = "testClOrdId1";
        int id1 = 1;
        int id2 = 2;
        int id3 = 3;
        int id4 = 4;
        byte orderType='F';
        String ccy = "EUR/USD-SP";
        byte side = 'B';
        byte oppositeSide = 'S';
        long rate = 7812500000L;
        
        long minAmt = -1;
        long showAmt = -1;
        byte expiry = 'G';  
        
        maker.initialize();
        
        Thread.sleep(5000);
        // get all the quote requests
        Map<String, MakerTestSession.Subscription> allSubs = maker
                .getActiveSubscriptionsSnapshot();
        assertFalse("quote request list is empty", allSubs.isEmpty());
        Subscription sub = getSubscription(allSubs);

        for (int i = 0; ; i++){
            // submit offer quote
            submitQuotesOffer(maker, sub);
            Thread.sleep(20);
            submitQuotesOffer2(maker, sub);
            Thread.sleep(20);
        }
    }
    
    private void setupPricing() {
        try {
                assertTrue(maker.isLoggedOn());
                maker.initialize();
                waitFor(5000);
                Map<String, MakerTestSession.Subscription> allSubs = maker.getActiveSubscriptionsSnapshot();
                assertFalse(allSubs.isEmpty());
        }
        catch (Exception e) {
            fail("test maker subscription failed with exception=" + e.getMessage());
        }
        waitFor(1000);
    }

    private String submitQuotes(MakerTestSession maker, String ccyPair, String bid_price,
            String offer_price, String amount) throws Exception{
        Map<String, MakerTestSession.Subscription> allSubs = maker.getActiveSubscriptionsSnapshot();
        for (Entry<String, MakerTestSession.Subscription> subEntry : allSubs.entrySet()) {
            MakerTestSession.Subscription sub = subEntry.getValue();
            if (sub.symbol.equals(ccyPair)) {
                String quoteId = "makerTestQuote"+(++makerQuoteCount);
                Quote quote = new Quote(sub.requestId, quoteId, sub.symbol, bid_price,
                        offer_price, amount, amount, sub.valueDate);
                maker.submitQuote(quote);
                return quoteId;
            }
        }
        return null;
    }

    private Subscription getSubscription(Map<String, Subscription> allSubs) {
        Subscription sub = null;

        for (Entry<String, Subscription> subEntry : allSubs.entrySet()) {
            sub = subEntry.getValue();
            if (sub.symbol.equals("EUR/USD")) {
                return sub;
            }
        }
        return null;
    }
    private void submitQuotesOffer(MakerTestSession maker, Subscription sub)
            throws Exception {
        Quote quote = new Quote(sub.requestId, "makerTestQuote1"
                + System.currentTimeMillis(), sub.symbol, null, OFFER_PX, null,
                "1000000", sub.valueDate);
        maker.submitQuote(quote);
        Thread.sleep(2000);
    }
    
    private void submitQuotesOffer2(MakerTestSession maker, Subscription sub)
            throws Exception {
        Quote quote = new Quote(sub.requestId, "makerTestQuote1"
                + System.currentTimeMillis(), sub.symbol, null, OFFER_PX2, null,
                "1000000", sub.valueDate);
        maker.submitQuote(quote);
        Thread.sleep(2000);
    }
    
    private void submitQuotesOfferPartial(MakerTestSession maker, Subscription sub)
            throws Exception {
        Quote quote = new Quote(sub.requestId, "makerTestQuote1"
                + System.currentTimeMillis(), sub.symbol, null, OFFER_PX, null,
                "500000", sub.valueDate);
        maker.submitQuote(quote);
        Thread.sleep(2000);
    }

}
