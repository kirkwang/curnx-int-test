package currenex.testcase.regression.prodRegression.itchouch.ouch.maker;

import static org.junit.Assert.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.AFUtils.*;
import static currenex.server.fxintegrate.adaptor.inttest.fix.TestConstants.FAILED_TEST_RETRIES;

import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.Random;

import currenex.server.fxintegrate.adaptor.inttest.Retry;
import currenex.server.fxintegrate.adaptor.inttest.fix.Constants;
import currenex.server.fxintegrate.adaptor.inttest.fix.Message;
import currenex.server.fxintegrate.adaptor.inttest.fix.component.MDEntry;
import currenex.server.fxintegrate.adaptor.inttest.fix.session.TakerTestSession;
import currenex.server.fxintegrate.adaptor.inttest.ouch.OuchClient;
import currenex.server.fxintegrate.adaptor.inttest.ouch.message.NewOrderAck;
import currenex.server.fxintegrate.adaptor.inttest.ouch.message.Trade;
import currenex.server.fxintegrate.adaptor.inttest.ouchMaker.OuchMakerClient;
import currenex.server.fxintegrate.adaptor.inttest.ouchMaker.message.NewOrder;
import currenex.server.fxintegrate.adaptor.ouchtwo.maker.MakerConstants;
import currenex.testcase.ATestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class TestOuchMakerRegression extends ATestCase implements MakerConstants{
    final String FX_TEST_INSTR = "EUR/USD";
    final long DEF_WAIT_TIME = 5000;
    final String amt1M = "1000000";
    private OuchMakerClient ouchMakerStreaming;
    private OuchMakerClient ouchMakerStreaming2;
    private OuchMakerClient ouchMakerTrading;
    private OuchMakerClient ouchMakerTradingAck;
    private OuchClient ouchTakerClient;
    private TakerTestSession fixTakerStreaming;
    private TakerTestSession fixTakerTrading;
    private Random rd;
    Charset f_charset = Charset.forName("US-ASCII");
    CharsetDecoder f_charDecoder = f_charset.newDecoder();
    
    @Before
    public void setUp() throws Exception {
        
        String host = props().getProperty("ouchHost", "localhost");
        int port = Integer.parseInt(props().getProperty("ouchPort", "32000"));
        String userId = props().getProperty("ouchUserId", "testouchtakeru1");
        ouchTakerClient = new OuchClient(host, port, userId);
        fixTakerStreaming = getTaker("BIxxTakerTHMU3");
        fixTakerTrading = getTaker("BIxxTakerTHMU2");
        
        ouchMakerStreaming = getOuchMaker("BIxxMakerTHMOuchStr");
        ouchMakerStreaming2 = getOuchMaker("BIxxMakerTHMOuchSt2");
        ouchMakerTrading = getOuchMaker("BIxxMakerTHMOuchTrd");
        ouchMakerTradingAck = getOuchMaker("BIxxMakerTHMOuchAck");
        
        rd = new Random();
    }

    @Rule
    public Retry retry = new Retry(Integer.valueOf(props().getProperty(FAILED_TEST_RETRIES, "1")));
    
    @Test
    public void testWarmUp_Owner() throws Exception {
        
        assertTrue(fixTakerTrading.getUserName()+" is not logged on",fixTakerTrading.logon());
        
        String clOrdIdBuy = generateOrderId("testBuy-");
        String clOrdIdSell = generateOrderId("testSell-");
        
        fixTakerTrading.submitMarketOrderAndValidate(clOrdIdBuy, amt1M, FX_TEST_INSTR, Constants.SIDE_Buy, false);
        fixTakerTrading.submitMarketOrderAndValidate(clOrdIdSell, amt1M, FX_TEST_INSTR, Constants.SIDE_Sell, false);
                
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        
        assertNull("Ouch maker should not get any order", ouchMakerTrading.getOrder(5000));
        assertNull("Taker should not get any order update", fixTakerTrading.getOrderUpdateMsg(clOrdIdBuy, 5000));
        assertNull("Taker should not get any order update", fixTakerTrading.getOrderUpdateMsg(clOrdIdSell, 5000));
    }
    

    @Test
    public void testFullFill_THM() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerTrading.getUserName()+" is not logged on",fixTakerTrading.logon());
        
        String clOrdID = generateOrderId("testLimit-");
        String price = "1.2345";
        
        fixTakerTrading.submitRetailOrderOnBehalf(clOrdID, null, FX_TEST_INSTR, Constants.SYMBOLSFX_Spot,
                Constants.PRODUCT_Currency, Constants.SIDE_Buy, FX_TEST_INSTR.split("/")[0],
                amt1M, Constants.ORDTYPE_ForexLimit, price, null,
                Constants.TIMEINFORCE_Day, null, null, Constants.SECURITYTYPE_ForeignExchange, amt1M, null, null,
                null, null, fixTakerTrading.getUserName());
        
        Message acceptedER = fixTakerTrading.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        assertNotNull("taker didnt receive ER(accepted)", acceptedER);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, acceptedER.getStringFieldValue(Constants.TAGExecType));
        
        Thread.sleep(500);
        
        int quoteId = rd.nextInt(1000);
        int instrInfoId = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", FX_TEST_INSTR+"-"+Constants.SYMBOLSFX_Spot);
        long amt = 100000000L; 
        int rate = 123450; 
        ouchMakerStreaming.sendQuote(quoteId, instrInfoId, amt, rate);
                
        NewOrder makerOrder = ouchMakerTrading.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
                
        ouchMakerTrading.sendExecutionReport(makerClOrdId, NEW_ORDER_STATUS_CONFIRMED, (short)0);

        Message filledER = fixTakerTrading.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        assertNotNull("Taker didnt receive filled ER", filledER);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_Filled, filledER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, filledER.getStringFieldValue(Constants.TAGExecType));
    }
    
    //DEV-30908
    @Test
    public void testFillLessThanMinAmt_THM() throws Exception {
        dotestFillLessThanMinAmt(false);
    }
    
    //DEV-30908
    @Test
    public void testFillLessThanMinAmt_THMAck() throws Exception {
        dotestFillLessThanMinAmt(true);
    }
    
    //DEV-30908
    private void dotestFillLessThanMinAmt(boolean makerAckEnabled) throws Exception {
        
        OuchMakerClient ouchMakerTrader = makerAckEnabled?ouchMakerTradingAck:ouchMakerTrading;
        OuchMakerClient ouchMakerStreamUser = makerAckEnabled?ouchMakerStreaming2:ouchMakerStreaming;
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreamUser.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrader.start(false));        
        assertTrue(fixTakerTrading.getUserName()+" is not logged on",fixTakerTrading.logon());
                
        String clOrdID = generateOrderId("testLimit-");
        String price = "1.2345";
        
        fixTakerTrading.submitRetailOrderOnBehalf(clOrdID, null, FX_TEST_INSTR, Constants.SYMBOLSFX_Spot,
                Constants.PRODUCT_Currency, Constants.SIDE_Buy, FX_TEST_INSTR.split("/")[0],
                amt1M, Constants.ORDTYPE_ForexLimit, price, null,
                Constants.TIMEINFORCE_Day, null, null, Constants.SECURITYTYPE_ForeignExchange, amt1M, null, null,
                null, null, fixTakerTrading.getUserName());
        
        Message acceptedER = fixTakerTrading.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        assertNotNull("taker didnt receive ER(accepted)", acceptedER);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, acceptedER.getStringFieldValue(Constants.TAGExecType));
        
        Thread.sleep(500);
        
        int quoteId = rd.nextInt(1000);
        String streamRefId = makerAckEnabled?"PS2":"PS1";
        int instrInfoId = ouchMakerStreamUser.getInstrInfoIdForOffer(streamRefId, FX_TEST_INSTR+"-"+Constants.SYMBOLSFX_Spot);
        long makerQuoteAmt = 100000000L;
        long makerFillAmt = 50000000L;
        int rate = 123450; 
        ouchMakerStreamUser.sendQuote(quoteId, instrInfoId, makerQuoteAmt, rate);
        
        NewOrder makerOrder = ouchMakerTrader.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        
        ouchMakerTrader.sendExecutionReportMultiFill(makerClOrdId, "exec0", NEW_ORDER_STATUS_CONFIRMED, makerFillAmt, makerFillAmt, rate);
        
        if(makerAckEnabled){
            Object fillNack = ouchMakerTrader.getMessageFromFillNackQueue(3000);
            assertNotNull("Ouch maker didnt receive fill nack", fillNack);
        }else{
            Object dontKnowTrade = ouchMakerTrader.getDontKnowTrade(3000);
            assertNotNull("Ouch maker didnt receive dontKnowTrade", dontKnowTrade);
        }
        
        Object timeOut = ouchMakerTrader.getTimeOut(10000);
        assertNotNull("Ouch maker didnt receive timeOut", timeOut);
        
        Message updatedER = fixTakerTrading.getOrderUpdateMsg(clOrdID, 2000);
        assertNull("Taker should not receive ER", updatedER);
    }
    
    @Test
    public void testPartialFill_THM() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerTrading.getUserName()+" is not logged on",fixTakerTrading.logon());
                
        String clOrdID = generateOrderId("testLimit-");
        String amt500k = "500000";
        String price = "1.2345";
        
        fixTakerTrading.submitRetailOrderOnBehalf(clOrdID, null, FX_TEST_INSTR, Constants.SYMBOLSFX_Spot,
                Constants.PRODUCT_Currency, Constants.SIDE_Buy, FX_TEST_INSTR.split("/")[0],
                amt1M, Constants.ORDTYPE_ForexLimit, price, null,
                Constants.TIMEINFORCE_Day, null, null, Constants.SECURITYTYPE_ForeignExchange, amt500k, null, null,
                null, null, fixTakerTrading.getUserName());
        
        Message acceptedER = fixTakerTrading.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        assertNotNull("taker didnt receive ER(accepted)", acceptedER);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_New, acceptedER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_New, acceptedER.getStringFieldValue(Constants.TAGExecType));
        
        Thread.sleep(500);
        
        int quoteId = rd.nextInt(1000);
        int instrInfoId = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", FX_TEST_INSTR+"-"+Constants.SYMBOLSFX_Spot);
        
        long amt = 50000000L; 
        int rate = 123450; 
        ouchMakerStreaming.sendQuote(quoteId, instrInfoId, amt, rate);
        
        NewOrder makerOrder = ouchMakerTrading.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int clOrdId = makerOrder.getClOrdID();
        ouchMakerTrading.sendExecutionReport(clOrdId, NEW_ORDER_STATUS_CONFIRMED, (short)0);

        Message filledER = fixTakerTrading.getOrderUpdateMsg(clOrdID, DEF_WAIT_TIME);
        assertNotNull("Taker didnt receive filled ER", filledER);
        validateTag(Constants.TAGOrdStatus, Constants.ORDSTATUS_PartiallyFilled, filledER.getStringFieldValue(Constants.TAGOrdStatus));
        validateTag(Constants.TAGExecType, Constants.EXECTYPE_Trade, filledER.getStringFieldValue(Constants.TAGExecType));
    }
    
        
    @Test
    public void testSingleQuoteFullFill_THM() throws Exception {
        
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
                
        int instrInfoId1 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/USD-SP");
        int quoteId = new Random().nextInt(1000);
        long amt = 4000000; 
        int rate = 135400; 
        ouchMakerStreaming.sendQuote(quoteId, instrInfoId1, amt, rate);
        Thread.sleep(500);
        ouchTakerClient.sendOrder();
        NewOrderAck ack = ouchTakerClient.getNewOrderAck(3000);
        assertNotNull(ack);
        
        NewOrder makerOrder = ouchMakerTrading.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        ouchMakerTrading.sendExecutionReport(makerClOrdId, NEW_ORDER_STATUS_CONFIRMED, (short)0);

        Trade trade = ouchTakerClient.getTrade(3000);
        assertNotNull(trade);
    }  
    
    //DEV-31139
    @Test
    public void testSingleQuoteRateUpdate_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerStreaming.getUserName()+" is not logged on",fixTakerStreaming.logon());
        
        String requestId = generateOrderId("testMdr-");
        String requestId2 = generateOrderId("testMdr2-");
        fixTakerStreaming.submitMarketDataRequest(requestId, "EUR", "USD", "N", "0");
        fixTakerStreaming.submitMarketDataRequest(requestId2, "EUR", "JPY", "N", "0");
                
        int instrInfoId1 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/USD-SP");
        int instrInfoId2 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/USD-SP");
        int instrInfoId3 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/JPY-SP");
        int instrInfoId4 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/JPY-SP");

        long amt = 4000000; 
        
        int[] instrInfoIds = new int[4];
        int[] quoteIds = new int[4];
        int[] rates = new int[4];

        instrInfoIds[0] = instrInfoId1;
        instrInfoIds[1] = instrInfoId2;
        instrInfoIds[2] = instrInfoId3;
        instrInfoIds[3] = instrInfoId4;
        
        int previousRandomPriceFactor = -1;
        
        for(int i=0;i<10;i++){
            
            quoteIds[0] = 1 + 4*i;
            quoteIds[1] = 2 + 4*i;
            quoteIds[2] = 3 + 4*i;
            quoteIds[3] = 4 + 4*i;
            
            Random rd = new Random();
            int randomPriceFactor = rd.nextInt(6);
            
            rates[0] = 111000 + randomPriceFactor*100;
            rates[1] = rates[0] + 300;
            rates[2] = 12320000 + randomPriceFactor*1000;
            rates[3] = rates[2] + 3000;
            
            ouchMakerStreaming.sendQuote(quoteIds[0], instrInfoIds[0], amt, rates[0]);
            ouchMakerStreaming.sendQuote(quoteIds[1], instrInfoIds[1], amt, rates[1]);
            ouchMakerStreaming.sendQuote(quoteIds[2], instrInfoIds[2], amt, rates[2]);
            ouchMakerStreaming.sendQuote(quoteIds[3], instrInfoIds[3], amt, rates[3]);
            
            if(previousRandomPriceFactor != randomPriceFactor){
                
                boolean gotRate0 = false;
                boolean gotRate1 = false;
                boolean gotRate2 = false;
                boolean gotRate3 = false;
                
                MDEntry mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                
                while(mdEntry!=null){
                    
                    if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("EUR/USD")){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[0] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amt / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate0 = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[1] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amt / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate1 = true;
                        }
                        
                    }else if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("EUR/JPY")){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)(rates[2]-400) / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amt / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate2 = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)(rates[3]+400) / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amt / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate3 = true;
                        }
                    }
                    mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                }
                assertTrue("Taker didnt get rate0", gotRate0);
                assertTrue("Taker didnt get rate1", gotRate1);
                assertTrue("Taker didnt get rate2", gotRate2);
                assertTrue("Taker didnt get rate3", gotRate3);
            }
            Thread.sleep(1000);
            previousRandomPriceFactor = randomPriceFactor;
        }
    }
    
    
    @Test
    public void testMassQuoteFill_THM() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue("Ouch taker is not logged on", ouchTakerClient.start());
        
        int instrInfoId1 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/USD-SP");
        int instrInfoId2 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "GBP/USD-SP");
        int instrInfoId3 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/USD-SP");
        int instrInfoId4 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "GBP/USD-SP");
        long amt = 4000000;
        final int[] quoteIds = new int[4];
        final int[] instrInfoIds = new int[4];
        final long[] amts = new long[4];
        final int[] rates1 = new int[4];
        quoteIds[0] = 8;
        quoteIds[1] = 9;
        quoteIds[2] = 10;
        quoteIds[3] = 11;
        instrInfoIds[0] = instrInfoId1;
        instrInfoIds[1] = instrInfoId2;
        instrInfoIds[2] = instrInfoId3;
        instrInfoIds[3] = instrInfoId4;
        amts[0] = amt;
        amts[1] = amt;
        amts[2] = amt;
        amts[3] = amt;
        rates1[0] = 135400;
        rates1[2] = 135500;
        rates1[1] = 162100;
        rates1[3] = 162200;

        ouchMakerStreaming.sendMassQuote((short)4, quoteIds, instrInfoIds, amts, rates1);
        Thread.sleep(500);
        
        int clOrdId = 9900;
        byte orderType = 'F';
        String ccy = "EUR/USD-SP";
        byte side = 'S';
        byte expireType = 'G';
        
        ouchTakerClient.sendOrder(clOrdId,
                orderType,
                ccy,
                side,
                amt, 
                rates1[0], 
                amt, 
                amt,
                expireType);
        
        Object orderAck = ouchTakerClient.getOrderAck(5000);
        assertNotNull("Ouch taker didnt get OrderAck msg", orderAck);
        
        NewOrder makerOrder = ouchMakerTrading.getMessageFromNewOrderQueue(2000);
        assertNotNull("Ouch maker didnt recieve order", makerOrder);
        int makerClOrdId = makerOrder.getClOrdID();
        ouchMakerTrading.sendExecutionReport(makerClOrdId, NEW_ORDER_STATUS_CONFIRMED, (short)0);
        
        Object trade = ouchTakerClient.getOrderFill(5000);
        assertNotNull("Ouch taker didnt get Trade msg(filled)", trade);
    }
    
    
    //DEV-31139
    @Test
    public void testMassQuoteOneStreamTwoInstrs_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerStreaming.getUserName()+" is not logged on",fixTakerStreaming.logon());
        
        fixTakerStreaming.clearMDEntryQueue();
        String requestId = generateOrderId("testMdr-");
        String requestId2 = generateOrderId("testMdr2-");
        fixTakerStreaming.submitMarketDataRequest(requestId, "EUR", "USD", "N", "0");
        fixTakerStreaming.submitMarketDataRequest(requestId2, "EUR", "JPY", "N", "0");
        
        int instrInfoId1 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/USD-SP");
        int instrInfoId2 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/USD-SP");
        int instrInfoId3 = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/JPY-SP");
        int instrInfoId4 = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/JPY-SP");
        
        long amt = 4000000; 
        
        int[] instrInfoIds = new int[4];
        long[] amts = new long[4];
        int[] quoteIds = new int[4];
        int[] rates = new int[4];

        instrInfoIds[0] = instrInfoId1;
        instrInfoIds[1] = instrInfoId2;
        instrInfoIds[2] = instrInfoId3;
        instrInfoIds[3] = instrInfoId4;
        amts[0] = amt;
        amts[1] = amt;
        amts[2] = amt;
        amts[3] = amt;
        
        int previousRandomPriceFactor = -1;
        
        for(int i=0;i<10;i++){
            
            quoteIds[0] = 1 + 4*i;
            quoteIds[1] = 2 + 4*i;
            quoteIds[2] = 3 + 4*i;
            quoteIds[3] = 4 + 4*i;
            
            Random rd = new Random();
            
            int randomPriceFactor = rd.nextInt(6);
            
            rates[0] = 111000 + randomPriceFactor*100;
            rates[1] = rates[0] + 300;
            rates[2] = 12320000 + randomPriceFactor*1000;
            rates[3] = rates[2] + 3000;
            
            ouchMakerStreaming.sendMassQuote((short)4, quoteIds, instrInfoIds, amts, rates);
            
            if(previousRandomPriceFactor != randomPriceFactor){
                
                boolean gotRate0 = false;
                boolean gotRate1 = false;
                boolean gotRate2 = false;
                boolean gotRate3 = false;
                
                MDEntry mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                
                while(mdEntry!=null){
                    
                    if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("EUR/USD")){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[0] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amts[0] / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate0 = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[1] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amts[1] / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate1 = true;
                        }
                        
                    }else if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("EUR/JPY")){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)(rates[2]-400) / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amts[2] / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate2 = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)(rates[3]+400) / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            validateTag(Constants.TAGMDEntrySize, (amts[3] / 100), Double.valueOf(mdEntry.getMDEntrySize()));
                            gotRate3 = true;
                        }
                    }
                    mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                }
                assertTrue("Taker didnt get rate0", gotRate0);
                assertTrue("Taker didnt get rate1", gotRate1);
                assertTrue("Taker didnt get rate2", gotRate2);
                assertTrue("Taker didnt get rate3", gotRate3);
            }
            Thread.sleep(1000);
            previousRandomPriceFactor = randomPriceFactor;
        }
    }
    
    //DEV-31139
    @Test
    public void testMassQuoteMultiStreamsMultiInstrs_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerStreaming.getUserName()+" is not logged on",fixTakerStreaming.logon());
        
        String requestId = generateOrderId("testMdr-");
        String requestId2 = generateOrderId("testMdr2-");
        fixTakerStreaming.submitMarketDataRequest(requestId, "NZD", "USD", "N", "0");
        fixTakerStreaming.submitMarketDataRequest(requestId2, "GBP", "USD", "N", "0");

        long amt = 2000000;
        long amt2 = 4000000;
        
        int[] instrInfoIds = new int[8];
        long[] amts = new long[8];
        int[] quoteIds = new int[8];
        int[] rates = new int[8];
        
        instrInfoIds[0] = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "NZD/USD-SP");
        instrInfoIds[1] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS2", "NZD/USD-SP");
        instrInfoIds[2] = ouchMakerStreaming2.getInstrInfoIdForBid("PS3", "NZD/USD-SP");
        instrInfoIds[3] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS3", "NZD/USD-SP");
        instrInfoIds[4] = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "GBP/USD-SP");
        instrInfoIds[5] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS2", "GBP/USD-SP");
        instrInfoIds[6] = ouchMakerStreaming2.getInstrInfoIdForBid("PS3", "GBP/USD-SP");
        instrInfoIds[7] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS3", "GBP/USD-SP");

        amts[0] = amts[1] = amts[4] = amts[5] = amt;
        amts[2] = amts[3] = amts[6] = amts[7] = amt2;
        
        int previousRandomPriceFactor = -1;
        
        for(int i=0;i<10;i++){

            for(int j=0;j<quoteIds.length;j++){
                quoteIds[j] = j + 4*i;
            }
            
            Random rd = new Random();
            int randomPriceFactor = rd.nextInt(6);
            
            rates[0] = 70300 + randomPriceFactor*10;
            rates[1] = rates[0] + 30;
            rates[2] = 70100 + randomPriceFactor*10;
            rates[3] = rates[2] + 30;
            
            rates[4] = 125100 + randomPriceFactor*100;
            rates[5] = rates[4] + 300;
            rates[6] = 125300 + randomPriceFactor*100;
            rates[7] = rates[6] + 300;
            
            ouchMakerStreaming2.sendMassQuote((short)8, quoteIds, instrInfoIds, amts, rates);
            
            if(previousRandomPriceFactor != randomPriceFactor){
                
                boolean[] gotRate = new boolean[8];
                
                for(int k=0;k<gotRate.length;k++){
                    gotRate[k]=false;
                }
                
                MDEntry mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                
                while(mdEntry!=null){
                    
                    if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("NZD/USD")
                            && Double.valueOf(mdEntry.getMDEntrySize()) == (amt / 100)){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[0] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            gotRate[0] = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[1] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                            gotRate[1] = true;
                        }
                        
                    }else if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("NZD/USD")
                            && Double.valueOf(mdEntry.getMDEntrySize()) == (amt2 / 100)){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[2] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                            gotRate[2] = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[3] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                             
                            gotRate[3] = true;
                        }
                    }else if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("GBP/USD")
                            && Double.valueOf(mdEntry.getMDEntrySize()) == (amt / 100)){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[4] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                            gotRate[4] = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[5] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                            gotRate[5] = true;
                        }
                        
                    }else if(mdEntry.getSymbol()!=null && mdEntry.getSymbol().equals("GBP/USD")
                            && Double.valueOf(mdEntry.getMDEntrySize()) == (amt2 / 100)){
                        
                        if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[6] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                            gotRate[6] = true;
                        }
                        else if(mdEntry.getMDEntryType()!=null && mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                            validateTag(Constants.TAGMDEntryPx, ((double)rates[7] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                             
                            gotRate[7] = true;
                        }
                    }
                    mdEntry = fixTakerStreaming.getMDEntryFromQueue(1500);
                }
                
                for(int k=0;k<gotRate.length;k++){
                    assertTrue("Taker didnt get rate["+k+"]", gotRate[k]);
                }
            }
            Thread.sleep(1000);
            previousRandomPriceFactor = randomPriceFactor;
        }
    }
    
    //DEV-31139
    @Test
    public void tesMassQuoteCancelWithZeroAmt_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming2.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTradingAck.start(false));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));
        assertTrue(fixTakerStreaming.getUserName()+" is not logged on",fixTakerStreaming.logon());
        
        fixTakerStreaming.clearMDEntryQueue();
        String requestId = generateOrderId("testMdr-");
        String requestId2 = generateOrderId("testMdr2-");
        fixTakerStreaming.submitMarketDataRequest(requestId, "NZD", "USD", "N", "0");
        fixTakerStreaming.submitMarketDataRequest(requestId2, "GBP", "USD", "N", "0");

        long amt = 2000000;
        long amt2 = 4000000;
        
        int[] instrInfoIds = new int[8];
        long[] amts = new long[8];
        int[] quoteIds = new int[8];
        int[] rates = new int[8];
        
        instrInfoIds[0] = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "NZD/USD-SP");
        instrInfoIds[1] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS2", "NZD/USD-SP");
        instrInfoIds[2] = ouchMakerStreaming2.getInstrInfoIdForBid("PS3", "NZD/USD-SP");
        instrInfoIds[3] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS3", "NZD/USD-SP");
        instrInfoIds[4] = ouchMakerStreaming2.getInstrInfoIdForBid("PS2", "GBP/USD-SP");
        instrInfoIds[5] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS2", "GBP/USD-SP");
        instrInfoIds[6] = ouchMakerStreaming2.getInstrInfoIdForBid("PS3", "GBP/USD-SP");
        instrInfoIds[7] = ouchMakerStreaming2.getInstrInfoIdForOffer("PS3", "GBP/USD-SP");

        int previousRandomPriceFactor = -1;
        
        fixTakerStreaming.clearMDEntryQueue();
        
        for(int i=0;i<10;i++){

            for(int j=0;j<quoteIds.length;j++){
                quoteIds[j] = j + 4*i;
            }
            
            amts[0] = amts[1] = amts[4] = amts[5] = amt;
            amts[2] = amts[3] = amts[6] = amts[7] = amt2;
            
            if(i==3){
                amts[0] = amts[3] = amts[5] = amts[6] = 0;
            }
            
            Random rd = new Random();
            int randomPriceFactor = rd.nextInt(6);
            
            rates[0] = 70100 + randomPriceFactor*10;
            rates[1] = rates[0] + 30;
            rates[2] = 72200 + randomPriceFactor*10;
            rates[3] = rates[2] + 30;
            
            rates[4] = 140100 + randomPriceFactor*100;
            rates[5] = rates[4] + 300;
            rates[6] = 142200 + randomPriceFactor*100;
            rates[7] = rates[6] + 300;
            
            ouchMakerStreaming2.sendMassQuote((short)8, quoteIds, instrInfoIds, amts, rates);
            
            if(previousRandomPriceFactor != randomPriceFactor){
                
                boolean[] gotRate = new boolean[8];
                
                for(int k=0;k<gotRate.length;k++){
                    gotRate[k]=false;
                }
                
                MDEntry mdEntry = fixTakerStreaming.getMDEntryFromQueue(3000);
                
                while(mdEntry!=null){
                    
                    assertNotNull("Symbol is null in MarketData", mdEntry.getSymbol());
                    assertNotNull("MDEntryType is null in MarketData", mdEntry.getMDEntryType());
                    assertNotNull("MDUpdateAction is null in MarketData", mdEntry.getMDUpdateAction());
                    
                    if(mdEntry.getMDUpdateAction().equals(Constants.MDUPDATEACTION_Delete)){
                        
                        if(mdEntry.getSymbol().equals("NZD/USD")){
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                gotRate[0] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){                          
                                gotRate[3] = true;
                            }
                        }else if(mdEntry.getSymbol().equals("GBP/USD")){
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                gotRate[6] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){                       
                                gotRate[5] = true;
                            }
                        }
                        
                    }else if(mdEntry.getMDUpdateAction().equals(Constants.MDUPDATEACTION_New)){
                        
                        if(mdEntry.getSymbol().equals("NZD/USD")
                                && Double.valueOf(mdEntry.getMDEntrySize()) == (amt / 100)){
                            
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[0] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                                gotRate[0] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[1] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                                gotRate[1] = true;
                            }
                            
                        }else if(mdEntry.getSymbol().equals("NZD/USD")
                                && Double.valueOf(mdEntry.getMDEntrySize()) == (amt2 / 100)){
                            
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[2] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                                gotRate[2] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[3] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                             
                                gotRate[3] = true;
                            }
                        }else if(mdEntry.getSymbol().equals("GBP/USD")
                                && Double.valueOf(mdEntry.getMDEntrySize()) == (amt / 100)){
                            
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[4] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));
                                gotRate[4] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[5] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                                gotRate[5] = true;
                            }
                            
                        }else if(mdEntry.getSymbol().equals("GBP/USD")
                                && Double.valueOf(mdEntry.getMDEntrySize()) == (amt2 / 100)){
                            
                            if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Bid)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[6] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                            
                                gotRate[6] = true;
                            }
                            else if(mdEntry.getMDEntryType().equals(Constants.MDENTRYTYPE_Offer)){
                                validateTag(Constants.TAGMDEntryPx, ((double)rates[7] / 100000), Double.valueOf(mdEntry.getMDEntryPx()));                             
                                gotRate[7] = true;
                            }
                        }
                    }
                    

                    mdEntry = fixTakerStreaming.getMDEntryFromQueue(1500);
                }
                
                for(int k=0;k<gotRate.length;k++){
                    assertTrue("Taker didnt get rate["+k+"]", gotRate[k]);
                }
            }
            Thread.sleep(1000);
            previousRandomPriceFactor = randomPriceFactor;
        }
    }
    
    
    //DEV-31139
    @Test
    public void testMassQuoteZeroRate_owner() throws Exception {
        
        assertTrue("Ouch streaming maker is not logged on", ouchMakerStreaming.start(true));
        assertTrue("Ouch trading maker is not logged on", ouchMakerTrading.start(false));        
                
        long amt = 4000000; 
        
        int[] instrInfoIds = new int[4];
        long[] amts = new long[4];
        int[] quoteIds = new int[4];
        int[] rates = new int[4];
        
        instrInfoIds[0] = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/USD-SP");
        instrInfoIds[1] = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/USD-SP");
        instrInfoIds[2] = ouchMakerStreaming.getInstrInfoIdForBid("PS1", "EUR/JPY-SP");
        instrInfoIds[3] = ouchMakerStreaming.getInstrInfoIdForOffer("PS1", "EUR/JPY-SP");
        
        amts[0] = amts[1] = amts[2] = amts[3] = amt;
        
        quoteIds[0] = 1;
        quoteIds[1] = 2;
        quoteIds[2] = 3;
        quoteIds[3] = 4;
        
        ouchMakerStreaming.sendMassQuote((short)4, quoteIds, instrInfoIds, amts, rates);
        Object reject = ouchMakerStreaming.getReject(3000);
        assertNotNull("ouch maker didnt get reject", reject);
    }
    
    @After
    public void tearDown()throws Exception
    {   
        ouchMakerStreaming.disconnect();
        ouchMakerStreaming2.disconnect();
        ouchMakerTrading.disconnect();
        ouchMakerTradingAck.disconnect();
        ouchTakerClient.disconnect();
        
        this.logoutUsers(2000);
    }
    
}
